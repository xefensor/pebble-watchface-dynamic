'use strict';
// Generated from Dynamic navigation sources; see bundled licenses.
(function(modules){var cache={};function load(id){if(cache[id])return cache[id].exports;var module={exports:{}};cache[id]=module;modules[id](module,module.exports,load);return module.exports;}load(0);})([
function(module,exports,require){
'use strict';

var navigation=require(1);
Pebble.registerSourceHandler(function(request,respond){
  if(!request||request.category!=='navigation'||request.item!=='presented_activities'){
    respond.error('INVALID_REQUEST');return;
  }
  respond.data(navigation.source(localStorage,Date.now()));
});
if (typeof Pebble.registerConfigHandler === 'function') Pebble.registerConfigHandler(function(message,respond){
  try {
    // A navigation read must not initialise settings/localisation or the host
    // helpers on the Quick Launch path.
    var settings=require(2);
    var display=require(14);
    message = message || {};
    if (message.type === 'load_settings') {
      var current = settings.read(localStorage);
      respond(current ? require(15)(current,message.language,{save:display.status(localStorage).delivery}) : {ok:false});
    } else if (message.type === 'save_settings') {
      var saved=settings.save(localStorage,message.settings);if(saved.ok)saved.delivery=display.status(localStorage).delivery;respond(saved);
    } else if(message.type==='display_status'||message.type==='retry_display')respond(display.status(localStorage));
    else respond({ok:false,notSaved:true});
  } catch (ignored) { respond({ok:false}); }
});

},
function(module,exports,require){
'use strict';

// Only destination app identities and freshness/session metadata cross an app
// switch. Source records, occurrence IDs and private display contents do not.
var KEY='dynamic-navigation-v1';
var UUID='cc1281f1-3b4d-45b5-b235-6881b1fd8fbd';
var LEASE=45000,MAX=4294967295;
function object(value){return value&&typeof value==='object'&&!Array.isArray(value);}
function integer(value,min,max){return typeof value==='number'&&isFinite(value)&&Math.floor(value)===value&&value>=min&&value<=max;}
function uuid(value){return typeof value==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(value)&&value!=='00000000-0000-0000-0000-000000000000';}
function keys(value,allowed){return object(value)&&Object.keys(value).every(function(key){return allowed.indexOf(key)>=0;});}
function destination(value){return value===null?null:keys(value,['watchAppUuid'])&&uuid(value.watchAppUuid)?{watchAppUuid:value.watchAppUuid}:undefined;}
function remove(storage){try{if(typeof storage.removeItem==='function')storage.removeItem(KEY);else storage.setItem(KEY,'');}catch(ignored){}}
function read(storage,now){
  var hint,text;
  try{text=storage.getItem(KEY);if(text===null||text===undefined)return null;if(typeof text!=='string'||!text||text.length>512){remove(storage);return null;}hint=JSON.parse(text);}catch(ignored){remove(storage);return null;}
  var primary=object(hint)?destination(hint.primary):undefined;
  var secondary=object(hint)?destination(hint.secondary):undefined;
  if(!keys(hint,['schema','watchfaceUuid','nativeSession','viewSequence','presentationSequence','presentedAtMs','expiresAtMs','primary','secondary'])||
      hint.schema!==1||hint.watchfaceUuid!==UUID||!integer(hint.nativeSession,2,MAX)||
      !integer(hint.viewSequence,1,MAX)||!integer(hint.presentationSequence,1,MAX)||
      !integer(hint.presentedAtMs,1,9007199254740991)||!integer(hint.expiresAtMs,1,9007199254740991)||
      hint.presentedAtMs>now||hint.expiresAtMs<=now||hint.expiresAtMs<=hint.presentedAtMs||
      hint.expiresAtMs-hint.presentedAtMs>LEASE||primary===undefined||secondary===undefined||(!primary&&!secondary)){
    remove(storage);return null;
  }
  return {schema:1,watchfaceUuid:UUID,nativeSession:hint.nativeSession,
    viewSequence:hint.viewSequence,presentationSequence:hint.presentationSequence,
    presentedAtMs:hint.presentedAtMs,expiresAtMs:hint.expiresAtMs,primary:primary,secondary:secondary};
}
function source(storage,now){
  var hint=read(storage,now);
  return {validUntilMs:hint?hint.expiresAtMs:now+30000,instances:hint?[{instanceId:'current',properties:{hint:{longText:{text:JSON.stringify(hint)}}}}]:[]};
}
function create(options){
  var storage=options.storage,now=options.now||Date.now;
  var mapping=null,lastPresentation=0;
  remove(storage);
  function view(snapshot){
    if(!snapshot||!integer(snapshot.session,2,MAX)||!integer(snapshot.sequence,1,MAX)||!Array.isArray(snapshot.cards)||snapshot.cards.length>2){mapping=null;remove(storage);return;}
    if(mapping&&mapping.session===snapshot.session&&snapshot.sequence<=mapping.sequence)return;
    if(!mapping||mapping.session!==snapshot.session)lastPresentation=0;
    mapping={session:snapshot.session,sequence:snapshot.sequence,cards:snapshot.cards.map(function(card){
      var target=destination(card.openApp===undefined?null:card.openApp);
      return {destination:target===undefined?null:target,until:integer(card.validUntil,1,MAX)?card.validUntil*1000:0};
    })};
    remove(storage);
  }
  function u32(bytes,at){return (bytes[at]+bytes[at+1]*256+bytes[at+2]*65536+bytes[at+3]*16777216)>>>0;}
  function receive(bytes){
    if(!mapping||!bytes||bytes.length!==24||bytes[0]!==1||bytes[3]!==0)return false;
    for(var i=0;i<bytes.length;i++)if(!integer(bytes[i],0,255))return false;
    var session=u32(bytes,4),sequence=u32(bytes,8),presentation=u32(bytes,12),reported=u32(bytes,16)*1000,until=u32(bytes,20)*1000;
    if(session!==mapping.session||sequence!==mapping.sequence||!presentation||presentation<=lastPresentation)return false;
    var primary=bytes[1],secondary=bytes[2],current=now();
    if((primary!==255&&primary>=mapping.cards.length)||(secondary!==255&&secondary>=mapping.cards.length)||
        (secondary!==255&&(primary===255||primary===secondary)))return false;
    lastPresentation=presentation;
    if(primary===255){remove(storage);return true;}
    if(!reported||reported>current+5000||current-reported>=LEASE){remove(storage);return false;}
    var first=mapping.cards[primary];
    var second=secondary===255?null:mapping.cards[secondary];
    var expires=Math.min(current+LEASE,reported+LEASE,until,first.until,second?second.until:Infinity);
    if(expires<=current||(!first.destination&&(!second||!second.destination))){remove(storage);return true;}
    var hint={schema:1,watchfaceUuid:UUID,nativeSession:session,viewSequence:sequence,presentationSequence:presentation,
      presentedAtMs:current,expiresAtMs:expires,primary:first.destination,secondary:second?second.destination:null};
    var text=JSON.stringify(hint);if(text.length>512){remove(storage);return false;}
    try{storage.setItem(KEY,text);return storage.getItem(KEY)===text;}catch(ignored){remove(storage);return false;}
  }
  return {view:view,receive:receive,clear:function(){mapping=null;remove(storage);}};
}
module.exports={KEY:KEY,UUID:UUID,LEASE:LEASE,create:create,read:read,source:source};

},
function(module,exports,require){
'use strict';

// The existing Clay key remains authoritative. Keeping the stable activity
// preferences in this same verified record makes one Save one storage write.
var selection = require(3).selection;
var KEY = 'clay-settings';
var PREFERENCES = '__dynamicActivityPreferences';
var OLD_PREFERENCES = 'dynamic-activity-preferences-v1';
var names = ['TEMPERATURE','REQUEST_WEATHER','BACKGROUND_COLOR','TEXT_COLOR','DEPTH_EFFECT','TEXT_SHADOW','LARGE_TEXT','USE_12_HOUR','USE_FAHRENHEIT','TEMPERATURE_FAHRENHEIT','WEATHER_UPDATED_AT','FORECAST_DATA','FOLLOW_PEBBLE_UNITS','WEATHER_LOCATION','WEATHER_CLEAR','SHOW_DAILY_RANGE','SHOW_RAIN_CHANCE','WEATHER_DETAILS','LAYOUT_STYLE','SHOW_WEATHER_ICON','WEATHER_CONDITION','COMPLICATION_DATA','REQUEST_COMPLICATIONS','CONTEXT_DATA','REQUEST_CONTEXT','SHOW_MUSIC','SHOW_NOTIFICATIONS','NOTIFICATION_PREVIEW','NOTIFICATION_APPS','SHOW_STATUS','PANEL_TRANSITIONS','ACCENT_COLOR','ANIMATIONS','CLOCK_FORMAT','NOTIFICATION_VIBRATION','NIGHT_PALETTE','NIGHT_BACKGROUND_COLOR','NIGHT_TEXT_COLOR','NIGHT_ACCENT_COLOR','NOTIFICATION_APP_ONLY','CONTEXT_STATE','ACTIVITY_DATA','REQUEST_ACTIVITIES','SHOW_ACTIVITIES','ACTIVITY_PRESENTED','REQUEST_PRESENTATION'];
names=names.concat(['TEXT_SIZE','APPEARANCE_MODE','MANUAL_APPEARANCE','DISPLAY_PREFERENCES','DISPLAY_PREFERENCES_RESULT','SCREEN_SPLIT','READING_LAYOUT','HIDE_READING_TITLES','SHAKE_READINGS','LOWER_BACKGROUND_COLOR','LOWER_TEXT_COLOR','NIGHT_LOWER_BACKGROUND_COLOR','NIGHT_LOWER_TEXT_COLOR']);
var defaults = {SCREEN_SPLIT:false,READING_LAYOUT:0,HIDE_READING_TITLES:false,SHAKE_READINGS:false,LOWER_BACKGROUND_COLOR:0,LOWER_TEXT_COLOR:0xffffff,NIGHT_LOWER_BACKGROUND_COLOR:0xffffff,NIGHT_LOWER_TEXT_COLOR:0,BACKGROUND_COLOR:0xffffff,TEXT_COLOR:0,ACCENT_COLOR:0x55aaff,CLOCK_FORMAT:0,ANIMATIONS:true,SHOW_STATUS:true,SHOW_ACTIVITIES:true,SHOW_MUSIC:true,SHOW_NOTIFICATIONS:false,NOTIFICATION_PREVIEW:false,NOTIFICATION_APP_ONLY:false,NOTIFICATION_VIBRATION:0,NIGHT_PALETTE:false,NIGHT_BACKGROUND_COLOR:0,NIGHT_TEXT_COLOR:0xffffff,NIGHT_ACCENT_COLOR:0x55aaff,NOTIFICATION_APPS:'',TEXT_SIZE:0,APPEARANCE_MODE:2,MANUAL_APPEARANCE:0};
function object(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function unwrap(value) { return object(value) && Object.prototype.hasOwnProperty.call(value,'value') ? value.value : value; }
function value(source,name) { var index=names.indexOf(name);return unwrap(source[name]!==undefined?source[name]:source[10000+index]!==undefined?source[10000+index]:source[index]); }
function valid(name,input) {
  if(name==='READING_LAYOUT')return input===0||input===1||input===2;
  if (name==='TEXT_SIZE') return [0,1,2,3].indexOf(input)>=0;
  if (name==='APPEARANCE_MODE') return [0,1,2].indexOf(input)>=0;
  if (name==='MANUAL_APPEARANCE') return input===0 || input===1;
  if (/_COLOR$/.test(name)) return typeof input === 'number' && isFinite(input) && Math.floor(input) === input && input >= 0 && input <= 0xffffff;
  if (name === 'CLOCK_FORMAT') return input === 0 || input === 12 || input === 24;
  if (name === 'NOTIFICATION_VIBRATION') return input === 0 || input === 1 || input === 2;
  if (name === 'NOTIFICATION_APPS') return typeof input === 'string' && input.length <= 160 && !/[\u0000-\u001f]/.test(input);
  return input === true || input === false || input === 0 || input === 1;
}
function normalize(source,strict) {
  if (!object(source)) return null;
  var result = {}, invalid = false;
  var additions=['SCREEN_SPLIT','READING_LAYOUT','HIDE_READING_TITLES','SHAKE_READINGS','LOWER_BACKGROUND_COLOR','LOWER_TEXT_COLOR','NIGHT_LOWER_BACKGROUND_COLOR','NIGHT_LOWER_TEXT_COLOR'];
  Object.keys(defaults).forEach(function(name) {
    var input = value(source,name);
    if(input===undefined&&additions.indexOf(name)>=0)input=defaults[name];
    // Old complete drafts and persisted numeric Clay keys remain valid.
    if (input===undefined && name==='APPEARANCE_MODE') input=result.NIGHT_PALETTE ? 1 : 2;
    if (input===undefined && (name==='TEXT_SIZE'||name==='MANUAL_APPEARANCE')) input=0;
    if (!strict && typeof defaults[name] === 'boolean' && ['true','false','0','1'].indexOf(input) >= 0) input = input === 'true' || input === '1';
    if (input === undefined && name === 'CLOCK_FORMAT') {
      var old = value(source,'USE_12_HOUR');
      if (old === true || old === 1) input = 12;
      else if (old === false || old === 0) input = 24;
    }
    if (!valid(name,input)) { if (strict) invalid = true; input = defaults[name]; }
    result[name] = typeof defaults[name] === 'boolean' ? !!input : input;
  });
  [['LOWER_BACKGROUND_COLOR','TEXT_COLOR'],['LOWER_TEXT_COLOR','BACKGROUND_COLOR'],['NIGHT_LOWER_BACKGROUND_COLOR','NIGHT_TEXT_COLOR'],['NIGHT_LOWER_TEXT_COLOR','NIGHT_BACKGROUND_COLOR']].forEach(function(pair){if(value(source,pair[0])===undefined)result[pair[0]]=result[pair[1]];});
  result.NIGHT_PALETTE=result.APPEARANCE_MODE===1;
  var preferences = source[PREFERENCES];
  preferences = unwrap(preferences);
  if (typeof preferences === 'string') { try { preferences = JSON.parse(preferences); } catch (ignored) { invalid = true; } }
  if (strict && !object(preferences)) invalid = true;
  result[PREFERENCES] = selection.normalizePreferences(preferences);
  return invalid ? null : result;
}
function read(storage) {
  var raw = storage.getItem(KEY), source = {};
  if (raw !== null && raw !== undefined && raw !== '') {
    try { source = JSON.parse(raw); } catch (ignored) { return null; }
    if (!object(source)) return null;
  }
  if (source[PREFERENCES] === undefined) {
    try { source[PREFERENCES] = JSON.parse(storage.getItem(OLD_PREFERENCES)); } catch (ignored) {}
  }
  return normalize(source,false);
}
function save(storage,candidate) {
  var selected = normalize(candidate,true);
  if (!selected) return {ok:false,notSaved:true};
  try {
    // Preserve retired/unknown saved keys for compatibility, but never accept
    // new unrecognised fields or activity content from the configuration page.
    var previous = {}, raw = storage.getItem(KEY);
    if (raw) { try { var parsed = JSON.parse(raw); if (object(parsed)) previous = parsed; } catch (ignored) {} }
    Object.keys(selected).forEach(function(name) { previous[name] = selected[name]; });
    var serialized = JSON.stringify(previous);
    if (raw !== serialized) storage.setItem(KEY,serialized);
    if (storage.getItem(KEY) !== serialized) return {ok:false};
    var actual = read(storage);
    if (JSON.stringify(actual) !== JSON.stringify(selected)) return {ok:false};
    return {ok:true,settings:actual};
  } catch (ignored) { return {ok:false}; }
}
function patch(storage,source){
  var current=read(storage),changed=false;if(!current||!object(source))return {ok:false};
  Object.keys(defaults).forEach(function(name){var input=value(source,name);if(input!==undefined&&valid(name,input)){current[name]=typeof defaults[name]==='boolean'?!!input:input;changed=true;}});
  if(value(source,'CLOCK_FORMAT')===undefined){var old=value(source,'USE_12_HOUR');if(old===true||old===1||old===false||old===0){current.CLOCK_FORMAT=old?12:24;changed=true;}}
  if(value(source,'APPEARANCE_MODE')===undefined&&valid('NIGHT_PALETTE',value(source,'NIGHT_PALETTE')))current.APPEARANCE_MODE=value(source,'NIGHT_PALETTE')?1:2;
  if(source[PREFERENCES]!==undefined){var p=unwrap(source[PREFERENCES]);if(typeof p==='string'){try{p=JSON.parse(p);}catch(ignored){return {ok:false};}}current[PREFERENCES]=selection.normalizePreferences(p);changed=true;}
  current.NIGHT_PALETTE=current.APPEARANCE_MODE===1;
  return changed?save(storage,current):{ok:true,settings:current};
}
module.exports = {read:read,save:save,patch:patch,normalize:normalize,defaults:defaults,names:names,preferencesKey:PREFERENCES};

},
function(module,exports,require){
'use strict';
module.exports=require(4);

},
function(module,exports,require){
'use strict';

// Read-only hosts do not need the native-owner publisher/storage bridge.
// Keep the complete historical API in index.js for existing consumers.
module.exports={
  activity:require(5),
  summary:require(8),
  summaryView:require(9),
  wire:require(6),
  view:require(7),
  selection:require(10),
  createActivities:require(11),
  createContext:require(12)
};

},
function(module,exports,require){
'use strict';

// Public notification-style activities. The ACT2 card is an internal transport
// adapter; plugins never arrange slots, mandatory labels, meters or layouts.
var wire=require(6),view=require(7),MAX=wire.MAX_EPOCH;
var LIMITS={text:192,label:64,appName:32,descriptor:512};
var SOURCE_PROPERTIES={schema_version:['numericValue'],kind:['shortText'],state:['shortText'],revision:['numericValue'],
  app_name:['longText'],observed_at:['timestamp'],valid_until:['timestamp'],private:['boolean'],
  unconfirmed:['boolean'],show_terminal:['boolean'],content:['longText'],detail:['longText'],artwork:['image','icon']};
var FIELDS=['provider','id','kind','state','revision','appName','observedAt','validUntil','private','unconfirmed','showTerminal','content','detail','image'];
var DATUM_FIELDS=['label','observedAt','validUntil','estimated'];
function own(value,key){return Object.prototype.hasOwnProperty.call(value,key);}
function known(value,keys){return wire.object(value)&&Object.keys(value).every(function(key){return keys.indexOf(key)>=0;});}
function bool(value){return value===undefined||typeof value==='boolean';}
function finite(value){return typeof value==='number'&&isFinite(value);}
function string(value,limit){return typeof value==='string'&&value.length<=limit&&wire.utf8(value).length<=limit?wire.text(value,limit):null;}
function datum(input,card){
  if(typeof input==='string'){input={text:input};}
  if(!wire.object(input)){return null;}
  var keys=DATUM_FIELDS.concat(own(input,'text')?['text']:own(input,'value')?['value','unit']:['clock','deadline','seconds','since']);
  if(!known(input,keys)||!bool(input.estimated)){return null;}
  var out={},label=input.label===undefined?'':string(input.label,LIMITS.label);
  if(label===null){return null;}if(label){out.label=label;}
  if(input.observedAt!==undefined){out.observedAt=input.observedAt;}
  if(input.validUntil!==undefined){out.validUntil=input.validUntil;}
  if(input.estimated!==undefined){out.estimated=input.estimated;}
  var observed=input.observedAt===undefined?card.observedAt:input.observedAt;
  var expiry=input.validUntil===undefined?card.validUntil:input.validUntil;
  if(!wire.integer(observed,1,card.observedAt)||!wire.integer(expiry,observed,card.validUntil)){return null;}
  if(own(input,'text')){
    out.text=string(input.text,LIMITS.text);if(!out.text){return null;}
  }else if(own(input,'value')){
    if(finite(input.value)){out.value=input.value;}
    else if(typeof input.value==='string'&&input.unit===undefined){out.value=string(input.value,LIMITS.text);if(!out.value){return null;}}
    else{return null;}
    if(input.unit!==undefined){out.unit=string(input.unit,16);if(out.unit===null){return null;}}
    if(wire.utf8(typeof out.value==='string'?out.value:view.numericText(out.value,out.unit)).length>LIMITS.text){return null;}
  }else{
    out.clock=input.clock;
    if(out.clock==='countdown'){
      if(input.since!==undefined||own(input,'deadline')===own(input,'seconds')){return null;}
      if(own(input,'deadline')){if(!wire.integer(input.deadline,1,MAX)){return null;}out.deadline=input.deadline;}
      else{if(!wire.integer(input.seconds,0,MAX)){return null;}out.seconds=input.seconds;}
    }else if(out.clock==='elapsed'){
      if(input.deadline!==undefined||input.since===undefined&&input.seconds===undefined){return null;}
      if(input.since!==undefined){if(!wire.integer(input.since,1,observed)){return null;}out.since=input.since;}
      if(input.seconds!==undefined){if(!wire.integer(input.seconds,0,MAX)){return null;}out.seconds=input.seconds;}
    }else{return null;}
  }
  return wire.utf8(JSON.stringify(out)).length<=LIMITS.descriptor?out:null;
}
function normalize(input,provider){
  if(!known(input,FIELDS)||!wire.uuid(provider||input.provider)||!wire.identity(input.id,64)||
      !wire.integer(input.revision,1,MAX)||!wire.integer(input.observedAt,1,MAX)||
      !wire.integer(input.validUntil,input.observedAt,MAX)||!bool(input.private)||!bool(input.unconfirmed)||!bool(input.showTerminal)){return null;}
  var kind=input.kind===undefined?'activity':wire.identity(input.kind,24),state=input.state===undefined?'active':input.state;
  if(!kind||!own(wire.STATES,state)){return null;}kind=kind.toLowerCase();
  var app=input.appName===undefined?'':string(input.appName,LIMITS.appName);if(app===null){return null;}
  var result={provider:provider||input.provider,id:input.id,kind:kind,state:state,revision:input.revision,
    observedAt:input.observedAt,validUntil:input.validUntil,private:input.private!==false||kind==='music'||kind==='notification'||kind==='notifications',
    unconfirmed:input.unconfirmed===true,showTerminal:input.showTerminal===true,appName:app};
  if(result.private&&result.unconfirmed){return null;}
  result.content=datum(input.content,result);if(!result.content){return null;}
  result.detail=input.detail===undefined||input.detail===null?null:datum(input.detail,result);
  if(input.detail!==undefined&&input.detail!==null&&!result.detail){return null;}
  if(input.image!==undefined&&input.image!==null){result.image=wire.image(input.image);if(!result.image){return null;}}
  return result;
}
function compiledDatum(input,card){
  var label=input.label||card.appName||'Activity';
  var observed=input.observedAt===undefined?card.observedAt:input.observedAt;
  var out={label:label,observedAt:observed,validUntil:input.validUntil===undefined?card.validUntil:input.validUntil,
    estimated:input.estimated===true,retain:!card.private};
  if(input.text!==undefined){out.type='text';out.text=input.text;}
  else if(input.value!==undefined){out.type='value';if(typeof input.value==='string'){out.text=input.value;}else{out.value=input.value;out.unit=input.unit||'';}}
  else{
    out.type='clock';out.mode=input.clock==='countdown'?'deadline':'elapsed';
    out.running=input.deadline!==undefined||input.since!==undefined;
    out.anchorAt=out.running?(input.since===undefined?observed:input.since):0;
    out.baseSeconds=input.deadline===undefined?input.seconds||0:Math.max(0,input.deadline-observed);
  }
  return out;
}
function toView(input,provider){
  var record=normalize(input,provider);if(!record){return null;}
  var projection={provider:record.provider,id:record.id,kind:record.kind,state:record.state,revision:record.revision,
    observedAt:record.observedAt,validUntil:record.validUntil,private:record.private,unconfirmed:record.unconfirmed,
    showTerminal:record.showTerminal,caption:record.appName||'Activity',main:compiledDatum(record.content,record),
    support:record.detail?compiledDatum(record.detail,record):null,image:record.image};
  var card=view.normalize(projection);
  // A bounded native host can omit optional detail, never an essential value,
  // unit or clock. This does not modify the authoritative source/fingerprint.
  if(!card&&projection.support){projection.support=null;card=view.normalize(projection);}
  if(card){card.sourceFormat=3;if(record.appName){card.providerName=record.appName;}}
  return card;
}
function scalar(p,name,shape,field){return p&&p[name]&&p[name][shape]?p[name][shape][field||'value']:undefined;}
function parseDescriptor(p,name,optional){
  if(!p||p[name]===undefined){return optional?null:undefined;}
  var raw=scalar(p,name,'longText','text');
  if(typeof raw!=='string'||raw.length>LIMITS.descriptor||wire.utf8(raw).length>LIMITS.descriptor){return undefined;}
  try{var value=JSON.parse(raw);return wire.object(value)||typeof value==='string'?value:undefined;}catch(ignored){return undefined;}
}
function sourceCard(instance,provider){
  var p=instance&&instance.properties;if(!wire.object(p)||scalar(p,'schema_version','numericValue')!==3){return null;}
  var malformed=Object.keys(SOURCE_PROPERTIES).some(function(name){
    if(p[name]===undefined||name==='artwork'){return false;}
    var shape=SOURCE_PROPERTIES[name][0],field=shape==='shortText'||shape==='longText'?'text':'value';
    return !wire.object(p[name])||!wire.object(p[name][shape])||scalar(p,name,shape,field)===undefined;
  });
  if(malformed||p.artwork!==undefined&&(!wire.object(p.artwork)||!p.artwork.image&&!p.artwork.icon)){return null;}
  var content=parseDescriptor(p,'content',false),detail=parseDescriptor(p,'detail',true);
  if(content===undefined||detail===undefined){return null;}
  return normalize({provider:provider,id:instance.instanceId,kind:scalar(p,'kind','shortText','text'),state:scalar(p,'state','shortText','text'),
    revision:scalar(p,'revision','numericValue'),appName:scalar(p,'app_name','longText','text'),observedAt:scalar(p,'observed_at','timestamp'),
    validUntil:scalar(p,'valid_until','timestamp'),private:scalar(p,'private','boolean'),unconfirmed:scalar(p,'unconfirmed','boolean'),
    showTerminal:scalar(p,'show_terminal','boolean'),content:content,detail:detail,image:p.artwork&&(p.artwork.image||p.artwork.icon)},provider);
}
function toSourceInstance(input,request){
  var record=normalize(input);if(!record){return null;}
  var p={schema_version:{numericValue:{value:3}},kind:{shortText:{text:record.kind}},state:{shortText:{text:record.state}},
    revision:{numericValue:{value:record.revision}},app_name:{longText:{text:record.appName}},observed_at:{timestamp:{value:record.observedAt}},
    valid_until:{timestamp:{value:record.validUntil}},private:{boolean:{value:record.private}},unconfirmed:{boolean:{value:record.unconfirmed}},
    show_terminal:{boolean:{value:record.showTerminal}},content:{longText:{text:JSON.stringify(record.content)}}};
  if(record.detail){p.detail={longText:{text:JSON.stringify(record.detail)}};}
  if(record.image&&request&&request.iconPixelSize){
    var internal=view.toSourceInstance(toView(record),request);if(!internal){return null;}p.artwork=internal.properties.artwork;
  }
  return {instanceId:record.id,properties:p};
}
function fromLegacy(input,options){
  options=options||{};var record=wire.normalize(input);if(!record){return null;}
  var content;
  if(record.clock==='deadline'){content={clock:'countdown'};content[record.state==='active'?'deadline':'seconds']=record.state==='active'?record.deadline:record.duration;}
  else if(record.clock==='elapsed'){content={clock:'elapsed',seconds:record.duration};if(record.state==='active'){content.since=record.clockAt;}}
  else if(record.kind==='timer'&&(record.state==='completed'||record.state==='cancelled')){content=record.state==='completed'?'Finished':'Cancelled';}
  else{content=record.value===undefined?record.main:{value:record.value,unit:record.unit};}
  return normalize({provider:record.provider,id:record.id,kind:record.kind,state:record.state,revision:record.revision,
    appName:options.appName||'',observedAt:record.observedAt,validUntil:record.validUntil,private:record.private,
    unconfirmed:record.unconfirmed,showTerminal:input.showTerminal===true,content:content,image:record.image});
}
function helper(value,options){var result={};Object.keys(options||{}).forEach(function(k){result[k]=options[k];});Object.keys(value).forEach(function(k){result[k]=value[k];});return result;}
function value(number,unit,options){var out={value:number};if(unit!==undefined){out.unit=unit;}return helper(out,options);}
function countdown(options){return helper({clock:'countdown'},options);}
function elapsed(options){return helper({clock:'elapsed'},options);}
function createProvider(options){
  options=options||{};if(!wire.uuid(options.pluginUuid)||typeof options.getActivities!=='function'){throw new Error('INVALID_PROVIDER');}
  var now=options.now||Date.now;
  function source(request){
    var input=options.getActivities(),instances=[];if(!Array.isArray(input)||input.length>wire.LIMITS.instances){throw new Error('INVALID_ACTIVITIES');}
    var time=now(),ids=Object.create(null);
    input.forEach(function(raw){
      var copy={};if(!wire.object(raw)){throw new Error('INVALID_ACTIVITY');}Object.keys(raw).forEach(function(k){copy[k]=raw[k];});
      if(copy.appName===undefined){copy.appName=options.appName;}
      var record=normalize(copy,options.pluginUuid);if(!record||ids[record.id]){throw new Error('INVALID_ACTIVITY');}ids[record.id]=true;
      if(record.validUntil*1000>time){var instance=toSourceInstance(record,request);if(!instance){throw new Error('INVALID_ACTIVITY');}instances.push(instance);}
    });
    return {validUntilMs:Math.min(MAX*1000,Math.floor(time+30000)),instances:instances};
  }
  function handleSource(request,respond){
    if(!request||request.category!=='activity'||request.item!=='live'){if(respond&&typeof respond.error==='function'){respond.error('INVALID_REQUEST','Unsupported source');}return;}
    try{respond.data(source(request));}catch(ignored){if(respond&&typeof respond.error==='function'){respond.error('INVALID_DATA','Invalid activity snapshot');}}
  }
  return {source:source,handleSource:handleSource};
}
module.exports={VERSION:3,CATEGORY:'activity',ITEM:'live',LIMITS:LIMITS,SOURCE_PROPERTIES:SOURCE_PROPERTIES,PROPERTIES:Object.keys(SOURCE_PROPERTIES),
  normalize:normalize,toView:toView,sourceCard:sourceCard,toSourceInstance:toSourceInstance,fromLegacy:fromLegacy,
  value:value,countdown:countdown,elapsed:elapsed,createProvider:createProvider};

},
function(module,exports,require){
'use strict';

var MAX = 4294967295;
var STATES = {active:1, paused:2, completed:3, cancelled:4};
var CLOCKS = {none:0, deadline:1, elapsed:2};
var LIMITS = {providers:32, instances:16, cards:2, main:192, footer:128, id:64, kind:24, unit:16, image:40, packet:2672};
function object(v) { return !!v && typeof v === 'object' && !Array.isArray(v); }
function integer(v, min, max) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v && v >= min && v <= max; }
function uuid(v) { return typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(v); }
function utf8(value) {
  var out=[];
  for (var i=0; i<value.length; i++) {
    var c=value.charCodeAt(i);
    if (c>=0xd800 && c<=0xdbff && i+1<value.length) {
      var next=value.charCodeAt(i+1);
      if (next>=0xdc00 && next<=0xdfff) { c=0x10000+((c-0xd800)<<10)+(next-0xdc00); i++; }
      else { c=0xfffd; }
    } else if (c>=0xd800 && c<=0xdfff) { c=0xfffd; }
    if (c<128) { out.push(c); }
    else if (c<2048) { out.push(192|(c>>6),128|(c&63)); }
    else if (c<65536) { out.push(224|(c>>12),128|((c>>6)&63),128|(c&63)); }
    else { out.push(240|(c>>18),128|((c>>12)&63),128|((c>>6)&63),128|(c&63)); }
  }
  return out;
}
function text(value, limit) {
  if (typeof value !== 'string') { return ''; }
  value=value.slice(0,4096).replace(/[\x00-\x1f\x7f-\x9f\u00ad\u061c\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/g,' ').replace(/\s+/g,' ').trim();
  if (utf8(value).length<=limit) { return value; }
  var out='';
  for (var i=0; i<value.length; i++) {
    var c=value.charAt(i), code=value.charCodeAt(i);
    if (code>=0xd800 && code<=0xdbff && i+1<value.length) { c+=value.charAt(++i); }
    if (utf8(out+c).length>limit-3) { break; }
    out+=c;
  }
  return out+'\u2026';
}
function identity(v, limit) { return typeof v === 'string' && v.length>0 && !/[\x00-\x1f\x7f-\x9f]/.test(v) && utf8(v).length<=limit ? v : null; }
function bytes(v, max) {
  if (Array.isArray(v)) { return v.length<=max && v.every(function(n){return integer(n,0,255);}) ? v.slice() : null; }
  if (typeof v !== 'string' || v.length>Math.ceil(max/3)*4 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(v)) { return null; }
  var alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/', out=[];
  for (var i=0;i<v.length;i+=4) {
    var a=alphabet.indexOf(v[i]), b=alphabet.indexOf(v[i+1]), c=v[i+2]==='='?0:alphabet.indexOf(v[i+2]), d=v[i+3]==='='?0:alphabet.indexOf(v[i+3]);
    if (v[i+2]==='=' && (b&15) || v[i+3]==='=' && v[i+2]!=='=' && (c&3)) { return null; }
    out.push((a<<2)|(b>>4));
    if(v[i+2]!=='=') {out.push(((b&15)<<4)|(c>>2));}
    if(v[i+3]!=='=') {out.push(((c&3)<<6)|d);}
  }
  return out.length<=max ? out : null;
}
function image(v) {
  if (!object(v) || !integer(v.width,1,40) || !integer(v.height,1,40)) { return null; }
  var palette=bytes(v.palette,16), pixels=bytes(v.pixels,800), stride=Math.ceil(v.width/2);
  if (!palette || !palette.length || !pixels || pixels.length!==stride*v.height) { return null; }
  for (var y=0;y<v.height;y++) {
    for (var x=0;x<v.width;x++) { var pair=pixels[y*stride+(x>>1)], n=x&1 ? pair&15 : pair>>4; if(n>=palette.length) {return null;} }
    if(v.width&1) { pixels[y*stride+stride-1]&=240; }
  }
  while(palette.length<16) {palette.push(0);}
  return {width:v.width,height:v.height,palette:palette,pixels:pixels};
}
function normalize(v, provider) {
  if (!object(v) || !uuid(provider || v.provider)) { return null; }
  var id=identity(v.id,LIMITS.id), kind=identity(typeof v.kind==='string'?v.kind.toLowerCase():v.kind,LIMITS.kind);
  var state=v.state==='running'?'active':v.state==='finished'?'completed':v.state;
  if(!id || !kind || !STATES[state] || !Object.prototype.hasOwnProperty.call(CLOCKS,v.clock) ||
      !integer(v.revision,1,MAX) || !integer(v.observedAt,1,MAX) || !integer(v.validUntil,v.observedAt,MAX)) { return null; }
  var result={provider:provider || v.provider,id:id,kind:kind,state:state,clock:v.clock,revision:v.revision,
    observedAt:v.observedAt,validUntil:v.validUntil,deadline:v.deadline===undefined?0:v.deadline,
    duration:v.duration===undefined?0:v.duration,clockAt:v.clockAt===undefined?0:v.clockAt,
    main:text(v.main,LIMITS.main),footer:text(v.footer===undefined?v.name:v.footer,LIMITS.footer),unit:text(v.unit,LIMITS.unit),private:v.private!==false||kind==='music'||kind==='notification'||kind==='notifications',unconfirmed:v.unconfirmed===true};
  if(result.private && result.unconfirmed) {return null;}
  if(!integer(result.deadline,0,MAX) || !integer(result.duration,0,MAX) || !integer(result.clockAt,0,MAX)) { return null; }
  if(state==='completed' || state==='cancelled') { result.clock='none';result.deadline=result.duration=result.clockAt=0; }
  if(result.clock==='none' && (result.deadline || result.duration || result.clockAt)) {return null;}
  if(result.clock==='deadline') {
    if(state==='active' && (!result.deadline || result.duration || result.clockAt)) {return null;}
    if(state==='paused' && (result.deadline || result.clockAt)) {return null;}
  }
  if(result.clock==='elapsed' && (result.deadline || state==='active' && !result.clockAt || state==='paused' && result.clockAt)) {return null;}
  if(result.clock==='none' && (state==='active'||state==='paused') && !result.main && (v.value===undefined||v.value===null)) {return null;}
  if(v.value!==undefined && v.value!==null) { if(typeof v.value!=='number'||!isFinite(v.value)) {return null;} result.value=v.value; }
  if(v.image!==undefined && v.image!==null) {result.image=image(v.image);if(!result.image) {return null;}}
  return result;
}
function put16(out, at, v) {out[at]=v&255;out[at+1]=(v>>>8)&255;}
function put32(out, at, v) {for(var i=0;i<4;i++){out[at+i]=Math.floor(v/Math.pow(256,i))&255;}}
function crc16(out) {var crc=65535;for(var i=0;i<out.length;i++){if(i===8||i===9){continue;}crc^=out[i]<<8;for(var n=0;n<8;n++){crc=((crc<<1)^(crc&32768?0x1021:0))&65535;}}return crc;}
function encode(cards, options) {
  options=options||{};
  if(!Array.isArray(cards)||cards.length>2||!integer(options.session,2,MAX)||!integer(options.revision,1,MAX)||!integer(options.sentAt,1,MAX)) {throw new Error('INVALID_SNAPSHOT');}
  var out=[65,67,84,49,1,cards.length,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
  put32(out,12,options.session);put32(out,16,options.revision);put32(out,20,options.sentAt);
  cards.forEach(function(raw){
    var card=normalize(raw);
    if(!card){throw new Error('INVALID_ACTIVITY');}
    var strings=[card.provider,card.id,card.kind,card.main,card.footer,card.unit].map(utf8), record=[];
    for(var i=0;i<48;i++){record.push(0);}
    record[0]=STATES[card.state];record[1]=CLOCKS[card.clock];record[2]=(card.private?1:0)|(card.image?2:0)|(card.value===undefined?0:4)|(card.unconfirmed?8:0);
    put32(record,4,card.revision);put32(record,8,card.observedAt);put32(record,12,card.validUntil);put32(record,16,card.deadline);put32(record,20,card.duration);put32(record,24,card.clockAt);
    if(card.value!==undefined){var b=new ArrayBuffer(8),view=new DataView(b);view.setFloat64(0,card.value,true);for(i=0;i<8;i++){record[28+i]=view.getUint8(i);}}
    strings.forEach(function(value,i){record[36+i]=value.length;});
    if(card.image){record[42]=card.image.width;record[43]=card.image.height;put16(record,44,card.image.pixels.length);}
    out=out.concat(record);strings.forEach(function(value){out=out.concat(value);});
    if(card.image){out=out.concat(card.image.palette,card.image.pixels);}
  });
  if(out.length>LIMITS.packet){throw new Error('SNAPSHOT_TOO_LARGE');}
  put16(out,6,out.length);put16(out,8,crc16(out));return out;
}
function clockValue(card, now) {
  if(card.clock==='deadline'){return card.state==='paused'?card.duration:Math.max(0,card.deadline-Math.max(now,card.observedAt));}
  if(card.clock==='elapsed'){return Math.min(MAX,card.duration+(card.state==='active'?Math.max(0,now-card.clockAt):0));}
  return null;
}
function formatClock(seconds) {seconds=Math.max(0,Math.floor(seconds));var hours=Math.floor(seconds/3600),minutes=Math.floor(seconds/60)%60,s=seconds%60;return hours?hours+':'+('0'+minutes).slice(-2)+':'+('0'+s).slice(-2):('0'+minutes).slice(-2)+':'+('0'+s).slice(-2);}
module.exports={VERSION:1,CATEGORY:'activity',ITEM:'session',LIMITS:LIMITS,STATES:STATES,CLOCKS:CLOCKS,MAX_EPOCH:MAX,object:object,integer:integer,uuid:uuid,utf8:utf8,text:text,identity:identity,image:image,normalize:normalize,encode:encode,crc16:crc16,clockValue:clockValue,formatClock:formatClock};

},
function(module,exports,require){
'use strict';

// ACT2 is a bounded native view. Authoritative source revisions are checked by
// the consumer before projection; the frame sequence orders view changes.
var wire=require(6);
var MAX=wire.MAX_EPOCH;
var TYPES={text:1,value:2,clock:3};
var METERS={progress:1,level:2};
var LIMITS={cards:2,packet:2672,pool:320,label:64,text:192,caption:128};
var COMMON=['schema_version','kind','state','revision','name','caption','observed_at','valid_until','private','unconfirmed','show_terminal','artwork'];
var SOURCE_PROPERTIES={schema_version:['numericValue'],kind:['shortText'],state:['shortText'],revision:['numericValue'],
  name:['longText'],caption:['longText'],observed_at:['timestamp'],valid_until:['timestamp'],private:['boolean'],unconfirmed:['boolean'],show_terminal:['boolean'],artwork:['image','icon'],
  meter_kind:['shortText'],meter_source:['shortText'],meter_min:['numericValue'],meter_max:['numericValue']};
['main','support'].forEach(function(prefix){
  Object.keys({type:1,label:1,text:1,value:1,observed_at:1,valid_until:1,retain:1,estimated:1,clock:1,base:1,anchor:1,running:1}).forEach(function(suffix){
    SOURCE_PROPERTIES[prefix+'_'+suffix]=[suffix==='value'||suffix==='base'?'numericValue':suffix==='observed_at'||suffix==='valid_until'||suffix==='anchor'?'timestamp':suffix==='retain'||suffix==='estimated'||suffix==='running'?'boolean':suffix==='type'||suffix==='clock'?'shortText':'longText'];
  });
});
var PROPERTIES=Object.keys(SOURCE_PROPERTIES);
function bool(value){return value===undefined||typeof value==='boolean';}
function finite(value){return typeof value==='number'&&isFinite(value);}
function clean(value,limit){return wire.text(value,limit);}
function numericText(value,unit){return String(value)+(unit?(/^(%|°|°C|°F)$/.test(unit)?'':' ')+unit:'');}
function scalar(properties,name,shape,field){return properties&&properties[name]&&properties[name][shape]?properties[name][shape][field||'value']:undefined;}
function string(properties,name){var value=scalar(properties,name,'longText','text');return value===undefined?scalar(properties,name,'shortText','text'):value;}
function datum(input,card,summaryProfile){
  if(!wire.object(input)||!Object.prototype.hasOwnProperty.call(TYPES,input.type)||!bool(input.retain)||!bool(input.estimated)||!bool(input.running)){return null;}
  var result={type:input.type,label:clean(input.label,LIMITS.label),text:'',
    observedAt:input.observedAt===undefined?card.observedAt:input.observedAt,
    validUntil:input.validUntil===undefined?card.validUntil:input.validUntil,
    retain:input.retain===true,estimated:input.estimated===true};
  if((!summaryProfile&&!result.label)||!wire.integer(result.observedAt,1,card.observedAt)||!wire.integer(result.validUntil,result.observedAt,card.validUntil)){return null;}
  if(input.type==='clock'){
    result.mode=input.mode;result.running=input.running===true;
    result.baseSeconds=input.baseSeconds===undefined?0:input.baseSeconds;
    result.anchorAt=input.anchorAt===undefined?0:input.anchorAt;
    if((result.mode!=='deadline'&&result.mode!=='elapsed')||!wire.integer(result.baseSeconds,0,MAX)||
        !wire.integer(result.anchorAt,0,result.observedAt)||(result.running?!result.anchorAt:result.anchorAt!==0)){return null;}
    if(input.text){return null;}
  } else {
    if(input.running===true||input.mode!==undefined||input.baseSeconds!==undefined&&input.baseSeconds!==0||input.anchorAt!==undefined&&input.anchorAt!==0){return null;}
    if(input.type==='value'&&input.value!==undefined){
      if(!finite(input.value)||input.unit!==undefined&&(typeof input.unit!=='string'||wire.utf8(input.unit).length>16)){return null;}
      result.value=input.value;result.unit=clean(input.unit,16);
      result.text=numericText(result.value,result.unit);
      if(input.text!==undefined&&input.text!==''&&clean(input.text,LIMITS.text)!==result.text){return null;}
    } else {result.text=clean(input.text,LIMITS.text);}
    if(!result.text||wire.utf8(result.text).length>LIMITS.text){return null;}
  }
  return result;
}
function poolFor(card){
  var bytes=[],known=Object.create(null);
  function add(value){
    value=value||'';
    if(Object.prototype.hasOwnProperty.call(known,value)){return known[value];}
    var encoded=wire.utf8(value),reference={offset:bytes.length,length:encoded.length};
    known[value]=reference;bytes=bytes.concat(encoded,[0]);return reference;
  }
  var refs={caption:add(card.caption),main:{label:add(card.main.label),text:add(card.main.text)}};
  if(card.support){refs.support={label:add(card.support.label),text:add(card.support.text)};}
  return {bytes:bytes,refs:refs};
}
function normalize(input,provider,summaryProfile){
  if(!wire.object(input)||!wire.uuid(provider||input.provider)||!wire.identity(input.id,64)||!wire.identity(input.kind,24)||
      !wire.integer(input.revision,1,MAX)||!wire.integer(input.observedAt,1,MAX)||!wire.integer(input.validUntil,input.observedAt,MAX)||
      !Object.prototype.hasOwnProperty.call(wire.STATES,input.state)||!bool(input.private)||!bool(input.unconfirmed)||!bool(input.showTerminal)){return null;}
  var kind=input.kind.toLowerCase(),card={provider:provider||input.provider,id:input.id,kind:kind,revision:input.revision,state:input.state,
    observedAt:input.observedAt,validUntil:input.validUntil,private:input.private!==false||kind==='music'||kind==='notification'||kind==='notifications',
    unconfirmed:input.unconfirmed===true,showTerminal:input.showTerminal===true,caption:clean(input.caption===undefined?input.name:input.caption,LIMITS.caption)};
  if(card.private&&card.unconfirmed){return null;}
  card.main=datum(input.main,card,summaryProfile);if(!card.main){return null;}
  card.support=input.support===undefined||input.support===null?null:datum(input.support,card,summaryProfile);
  if(input.support!==undefined&&input.support!==null&&!card.support){return null;}
  card.meter=null;
  if(input.meter!==undefined&&input.meter!==null){
    var m=input.meter,target=card[m.source];
    if(!wire.object(m)||!Object.prototype.hasOwnProperty.call(METERS,m.kind)||(m.source!=='main'&&m.source!=='support')||!target||target.type!=='value'){return null;}
    var fraction;
    if(m.min!==undefined||m.max!==undefined){
      if(!finite(m.min)||!finite(m.max)||m.max<=m.min||!finite(target.value)||target.value<m.min||target.value>m.max){return null;}
      fraction=(target.value-m.min)/(m.max-m.min);
    } else {fraction=m.fraction;}
    if(!finite(fraction)||fraction<0||fraction>1){return null;}
    card.meter={kind:m.kind,source:m.source,fraction:fraction};
    if(m.min!==undefined){card.meter.min=m.min;card.meter.max=m.max;}
  }
  if(input.image!==undefined&&input.image!==null){card.image=wire.image(input.image);if(!card.image){return null;}}
  if(!summaryProfile&&poolFor(card).bytes.length>LIMITS.pool){return null;}
  return card;
}
function fromLegacy(input,options){
  options=options||{};
  var legacy=wire.normalize(input);if(!legacy||!bool(input.showTerminal)||
      options.timerPresentation!==undefined&&options.timerPresentation!=='detailed'&&options.timerPresentation!=='compact'){return null;}
  var compactTimer=legacy.kind==='timer'&&options.timerPresentation==='compact';
  var main,terminal=legacy.state==='completed'||legacy.state==='cancelled';
  if(legacy.clock!=='none'){
    main={type:'clock',label:legacy.clock==='deadline'?'Left':'Elapsed',mode:legacy.clock,running:legacy.state==='active',
      baseSeconds:legacy.clock==='deadline'&&legacy.state==='active'?Math.max(0,legacy.deadline-legacy.observedAt):legacy.duration,
      anchorAt:legacy.state==='active'?(legacy.clock==='deadline'?legacy.observedAt:legacy.clockAt):0,retain:!legacy.private};
  } else {
    main={type:legacy.value===undefined?'text':'value',label:terminal?'State':legacy.value===undefined?'Text':'Value',
      text:legacy.main|| (legacy.value===undefined?(terminal?legacy.state:''):numericText(legacy.value,legacy.unit))};
  }
  var card={provider:legacy.provider,id:legacy.id,kind:legacy.kind,revision:legacy.revision,state:legacy.state,
    observedAt:legacy.observedAt,validUntil:legacy.validUntil,private:legacy.private,unconfirmed:legacy.unconfirmed,
    caption:legacy.footer,main:main,image:legacy.image};
  if(!compactTimer&&legacy.kind==='timer'&&legacy.clock==='deadline'&&wire.integer(input.totalDuration,0,MAX)){
    card.support={type:'clock',label:'Elapsed',mode:'elapsed',running:legacy.state==='active',
      baseSeconds:Math.max(0,input.totalDuration-main.baseSeconds),anchorAt:legacy.state==='active'?legacy.observedAt:0,retain:!legacy.private};
  }
  if(options.terminalResults&&input.showTerminal!==false&&legacy.kind==='timer'&&legacy.state==='completed'){
    card.showTerminal=true;card.main={type:'text',label:'State',text:'Finished',retain:!legacy.private};
    if(!compactTimer&&wire.integer(input.totalDuration,0,MAX)){card.support={type:'clock',label:'Elapsed',mode:'elapsed',running:false,baseSeconds:input.totalDuration,anchorAt:0,retain:!legacy.private};}
  }
  if(compactTimer&&legacy.clock==='deadline'&&card.caption){
    // One explicit identity caption fits both fields, so a host can deduplicate
    // by exact equality without guessing which clock labels are expendable.
    card.caption=clean(card.caption,LIMITS.label);card.main.label=card.caption;
  }
  // Legacy sources had separate maximum main/caption buffers. Fit the optional
  // caption into the shared pool; never trim a structured clock or value unit.
  var result=normalize(card);
  for(var limit=LIMITS.caption-1;!result&&limit>=0;limit--){card.caption=clean(legacy.footer,limit);result=normalize(card);}
  return result;
}
function put16(bytes,offset,value){bytes[offset]=value&255;bytes[offset+1]=(value>>>8)&255;}
function put32(bytes,offset,value){for(var i=0;i<4;i++){bytes[offset+i]=Math.floor(value/Math.pow(256,i))&255;}}
function writeDatum(header,offset,item,refs){
  if(!item){return;}
  header[offset]=TYPES[item.type];header[offset+1]=(item.type==='clock'&&item.mode==='elapsed'?1:0)|(item.running?2:0)|(item.retain?4:0)|(item.estimated?8:0);
  put32(header,offset+4,item.observedAt);put32(header,offset+8,item.validUntil);
  put32(header,offset+12,item.baseSeconds||0);put32(header,offset+16,item.anchorAt||0);
  put16(header,offset+20,refs.text.offset);put16(header,offset+22,refs.text.length);
  put16(header,offset+24,refs.label.offset);put16(header,offset+26,refs.label.length);
}
function encode(cards,options){
  options=options||{};var seq=options.sequence===undefined?options.revision:options.sequence;
  if(!Array.isArray(cards)||cards.length>2||!wire.integer(options.session,2,MAX)||!wire.integer(seq,1,MAX)||!wire.integer(options.sentAt,1,MAX)){throw new Error('INVALID_SNAPSHOT');}
  var out=[65,67,84,50,2,cards.length,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],seen=Object.create(null);
  put32(out,12,options.session);put32(out,16,seq);put32(out,20,options.sentAt);
  cards.forEach(function(raw){
    var card=normalize(raw);if(!card||seen[card.provider+'|'+card.id]){throw new Error('INVALID_ACTIVITY');}seen[card.provider+'|'+card.id]=true;
    var pool=poolFor(card),id=wire.utf8(card.id),header=[];
    for(var i=0;i<88;i++){header.push(0);}
    header[2]=wire.STATES[card.state];header[3]=(card.private?1:0)|(card.unconfirmed?2:0)|(card.showTerminal?4:0)|(card.image?8:0);
    put32(header,4,card.revision);put32(header,8,card.observedAt);put32(header,12,card.validUntil);
    header[16]=id.length;header[17]=card.image?card.image.width:0;header[18]=card.image?card.image.height:0;
    header[19]=card.meter?METERS[card.meter.kind]:0;put16(header,20,card.image?card.image.pixels.length:0);put16(header,22,pool.bytes.length);
    put16(header,24,pool.refs.caption.offset);put16(header,26,pool.refs.caption.length);
    put16(header,28,card.meter?Math.round(card.meter.fraction*65535):0);header[30]=card.meter&&card.meter.source==='support'?1:0;
    writeDatum(header,32,card.main,pool.refs.main);writeDatum(header,60,card.support,pool.refs.support);
    var record=header.concat(wire.utf8(card.provider),id,pool.bytes);
    if(card.image){record=record.concat(card.image.palette,card.image.pixels);}
    put16(record,0,record.length);out=out.concat(record);
  });
  if(out.length>LIMITS.packet){throw new Error('SNAPSHOT_TOO_LARGE');}
  put16(out,6,out.length);put16(out,8,wire.crc16(out));return out;
}
function readDatum(properties,prefix){
  var type=string(properties,prefix+'_type');if(type===undefined){return null;}
  var number=properties[prefix+'_value']&&properties[prefix+'_value'].numericValue;
  var body=string(properties,prefix+'_text');
  if(number&&(type!=='value'||body!==undefined&&body!=='')){return false;}
  return {type:type,label:string(properties,prefix+'_label'),text:body,
    value:number&&number.value,unit:number&&number.unit,observedAt:scalar(properties,prefix+'_observed_at','timestamp'),
    validUntil:scalar(properties,prefix+'_valid_until','timestamp'),retain:scalar(properties,prefix+'_retain','boolean'),estimated:scalar(properties,prefix+'_estimated','boolean'),
    mode:string(properties,prefix+'_clock'),running:scalar(properties,prefix+'_running','boolean'),
    baseSeconds:scalar(properties,prefix+'_base','numericValue'),anchorAt:scalar(properties,prefix+'_anchor','timestamp')};
}
function sourceCard(instance,provider){
  var p=instance&&instance.properties;if(!wire.object(p)||scalar(p,'schema_version','numericValue')!==2){return null;}
  var main=readDatum(p,'main'),support=readDatum(p,'support');if(!main||support===false){return null;}
  var meterKind=string(p,'meter_kind'),meter=meterKind&&meterKind!=='none'?{kind:meterKind,source:string(p,'meter_source'),min:scalar(p,'meter_min','numericValue'),max:scalar(p,'meter_max','numericValue')}:null;
  return normalize({provider:provider,id:instance.instanceId,kind:string(p,'kind'),revision:scalar(p,'revision','numericValue'),state:string(p,'state'),
    observedAt:scalar(p,'observed_at','timestamp'),validUntil:scalar(p,'valid_until','timestamp'),private:scalar(p,'private','boolean'),
    unconfirmed:scalar(p,'unconfirmed','boolean'),showTerminal:scalar(p,'show_terminal','boolean'),caption:string(p,'caption')===undefined?string(p,'name'):string(p,'caption'),
    main:main,support:support,meter:meter,image:p.artwork&&(p.artwork.image||p.artwork.icon)});
}
function base64(bytes){var alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',out='';for(var i=0;i<bytes.length;i+=3){var a=bytes[i],b=i+1<bytes.length?bytes[i+1]:0,c=i+2<bytes.length?bytes[i+2]:0;out+=alphabet[a>>2]+alphabet[((a&3)<<4)|(b>>4)]+(i+1<bytes.length?alphabet[((b&15)<<2)|(c>>6)]:'=')+(i+2<bytes.length?alphabet[c&63]:'=');}return out;}
function toSourceInstance(input,request){
  var card=normalize(input);if(!card){return null;}
  var p={schema_version:{numericValue:{value:2}},revision:{numericValue:{value:card.revision}},kind:{shortText:{text:card.kind}},state:{shortText:{text:card.state}},
    name:{longText:{text:card.caption}},caption:{longText:{text:card.caption}},observed_at:{timestamp:{value:card.observedAt}},valid_until:{timestamp:{value:card.validUntil}},
    private:{boolean:{value:card.private}},unconfirmed:{boolean:{value:card.unconfirmed}},show_terminal:{boolean:{value:card.showTerminal}}};
  ['main','support'].forEach(function(prefix){var d=card[prefix];if(!d){return;}
    p[prefix+'_type']={shortText:{text:d.type}};p[prefix+'_label']={longText:{text:d.label}};
    p[prefix+'_observed_at']={timestamp:{value:d.observedAt}};p[prefix+'_valid_until']={timestamp:{value:d.validUntil}};
    p[prefix+'_retain']={boolean:{value:d.retain}};p[prefix+'_estimated']={boolean:{value:d.estimated}};
    if(d.type==='clock'){p[prefix+'_clock']={shortText:{text:d.mode}};p[prefix+'_base']={numericValue:{value:d.baseSeconds,unit:'s'}};p[prefix+'_anchor']={timestamp:{value:d.anchorAt}};p[prefix+'_running']={boolean:{value:d.running}};}
    else if(d.type==='value'&&finite(d.value)){p[prefix+'_value']={numericValue:{value:d.value,unit:d.unit}};}
    else{p[prefix+'_text']={longText:{text:d.text}};}
  });
  if(card.meter){if(!finite(card.meter.min)||!finite(card.meter.max)){return null;}p.meter_kind={shortText:{text:card.meter.kind}};p.meter_source={shortText:{text:card.meter.source}};p.meter_min={numericValue:{value:card.meter.min}};p.meter_max={numericValue:{value:card.meter.max}};}
  if(card.image&&request&&request.iconPixelSize){p.artwork={image:{width:card.image.width,height:card.image.height,palette:base64(card.image.palette),pixels:base64(card.image.pixels)}};}
  return {instanceId:card.id,properties:p};
}
module.exports={VERSION:2,CATEGORY:'activity',ITEM:'card',TYPES:TYPES,METERS:METERS,LIMITS:LIMITS,PROPERTIES:PROPERTIES,SOURCE_PROPERTIES:SOURCE_PROPERTIES,
  normalize:normalize,createCard:normalize,encode:encode,fromLegacy:fromLegacy,sourceCard:sourceCard,toSourceInstance:toSourceInstance,poolFor:poolFor,numericText:numericText};

},
function(module,exports,require){
'use strict';

// Schema 4 is semantic source content. Layout and source observation are never
// supplied by fresh-read authors; imported owners use the separate snapshot path.
var wire=require(6),MAX=wire.MAX_EPOCH;
var ICONS=['activity','timer','stopwatch','media','message','call','navigation','workout','recording','download','delivery'];
var DIRECTIONS=['turn-left','turn-right','straight','u-turn'];
var STATES=['active','paused','completed','cancelled'];
var PLAYBACK=['playing','paused','buffering','stopped','unknown'];
var META_KEY='pebble.activities.summary.metadata.v1';
var LIMITS={records:16,descriptor:1024,text:192,label:32,name:64,value:64,unit:16,actions:1536,entity:256,openApp:96};
var SOURCE_PROPERTIES={schema_version:['numericValue'],publisher_incarnation:['longText'],publisher_mode:['shortText'],snapshot_sequence:['numericValue'],activity_count:['numericValue'],
  revision:['numericValue'],observed_at:['timestamp'],valid_until:['timestamp'],private:['boolean'],unconfirmed:['boolean'],content:['longText'],
  app_name:['longText'],icon:['image','icon'],artwork:['image','icon'],entity_ref:['longText'],actions:['longText'],open_app:['longText']};
var SHARED=['id','type','name','icon','visibleUntil','entityRef','actions','openApp'];
function own(v,k){return Object.prototype.hasOwnProperty.call(v,k);}
function known(v,keys){return wire.object(v)&&Object.keys(v).every(function(k){return keys.indexOf(k)>=0;});}
function finite(v){return typeof v==='number'&&isFinite(v);}
function text(v,max){
  if(typeof v!=='string'||/[\x00-\x1f\x7f-\x9f\u00ad\u061c\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/.test(v)){return null;}
  var t=v.trim();
  if(!t||wire.utf8(t).length>max||/[\ud800-\udfff]/.test(t.replace(/[\ud800-\udbff][\udc00-\udfff]/g,''))){return null;}
  return t;
}
function bounded(v,max){try{return wire.utf8(JSON.stringify(v)).length<=max;}catch(ignored){return false;}}
function jsonValue(v,depth){
  if(v===null||typeof v==='string'||typeof v==='boolean'){return true;}
  if(typeof v==='number'){return finite(v);}
  if(depth<=0||typeof v!=='object'){return false;}
  if(Array.isArray(v)){return v.every(function(x){return jsonValue(x,depth-1);});}
  if(!wire.object(v)||Object.getPrototypeOf(v)!==Object.prototype&&Object.getPrototypeOf(v)!==null){return false;}
  return Object.keys(v).every(function(k){return jsonValue(v[k],depth-1);});
}
function extension(input,name){
  if(name==='openApp'){
    return known(input,['watchAppUuid'])&&wire.uuid(input.watchAppUuid)&&!/^0{8}-0{4}-0{4}-0{4}-0{12}$/.test(input.watchAppUuid)?{watchAppUuid:input.watchAppUuid}:null;
  }
  if(name==='entityRef'){
    if(!known(input,['category','item','instanceId'])){return null;}
    var out={};
    if(!['category','item','instanceId'].every(function(k){out[k]=text(input[k],64);return !!out[k];})){return null;}
    return bounded(out,LIMITS.entity)?out:null;
  }
  if(!Array.isArray(input)||input.length>3){return null;}
  var ids=Object.create(null),result=[];
  for(var i=0;i<input.length;i++){
    var a=input[i];if(!known(a,['id','label','action','args','semantic'])){return null;}
    var action={id:text(a.id,32),label:text(a.label,32),action:text(a.action,64),args:a.args===undefined?{}:a.args};
    if(!action.id||!action.label||!action.action||ids[action.id]||!wire.object(action.args)||!jsonValue(action.args,4)||!bounded(action.args,256)){return null;}
    ids[action.id]=true;
    if(a.semantic!==undefined){if(['play','pause','resume','stop','next','previous','cancel','acknowledge'].indexOf(a.semantic)<0){return null;}action.semantic=a.semantic;}
    result.push(action);
  }
  return bounded(result,LIMITS.actions)?result:null;
}
function datum(input,observedAt){
  if(!wire.object(input)){return null;}
  var d={type:input.type},keys=['type','label'];
  if(input.type==='text'){
    keys.push('text');d.text=text(input.text,LIMITS.text);if(!d.text){return null;}
  }else if(input.type==='value'){
    keys=keys.concat(['value','unit','range','symbol']);
    d.value=finite(input.value)?input.value:text(input.value,LIMITS.value);if(d.value===null){return null;}
    if(input.unit!==undefined){d.unit=text(input.unit,LIMITS.unit);if(!d.unit){return null;}}
    if(input.range!==undefined){
      var r=input.range,min=r&&r.min===undefined?0:r&&r.min;
      if(!known(r,['min','max'])||!finite(d.value)||!finite(min)||!finite(r.max)||r.max<=min||d.value<min||d.value>r.max){return null;}
      d.range={min:min,max:r.max};
    }
    if(input.symbol!==undefined){if(DIRECTIONS.indexOf(input.symbol)<0){return null;}d.symbol=input.symbol;}
  }else if(input.type==='clock'){
    keys=keys.concat(['mode','deadline','since','seconds']);d.mode=input.mode;
    if(d.mode==='countdown'){
      if(input.since!==undefined||own(input,'deadline')===own(input,'seconds')){return null;}
      if(own(input,'deadline')){if(!wire.integer(input.deadline,1,MAX)){return null;}d.deadline=input.deadline;}
      else{if(!wire.integer(input.seconds,0,MAX)){return null;}d.seconds=input.seconds;}
    }else if(d.mode==='elapsed'){
      if(input.deadline!==undefined||input.since===undefined&&input.seconds===undefined){return null;}
      if(input.since!==undefined){if(!wire.integer(input.since,1,observedAt||MAX)){return null;}d.since=input.since;}
      if(input.seconds!==undefined){if(!wire.integer(input.seconds,0,MAX)){return null;}d.seconds=input.seconds;}
    }else{return null;}
  }else{return null;}
  if(!known(input,keys)){return null;}
  if(input.label!==undefined){d.label=text(input.label,LIMITS.label);if(!d.label){return null;}}
  return d;
}
function descriptor(record){
  var out={};Object.keys(record).forEach(function(k){
    if(k==='artwork'||k==='entityRef'||k==='actions'||k==='openApp'||k==='icon'&&typeof record.icon!=='string'){return;}out[k]=record[k];
  });return out;
}
function normalize(input,observedAt){
  var keys=SHARED.concat(input&&input.type==='media'?['title','artist','artwork','itemId','playback']:['headline','detail','summary','state','result']);
  if(!known(input,keys)||!text(input.id,64)||input.id[0]==='@'||input.id!==input.id.trim()){return null;}
  var out={id:input.id,type:input.type};
  if(input.name!==undefined){out.name=text(input.name,LIMITS.name);if(!out.name){return null;}}
  if(input.icon!==undefined){
    out.icon=typeof input.icon==='string'?(ICONS.indexOf(input.icon)>=0?input.icon:null):wire.image(input.icon);if(!out.icon){return null;}
  }
  if(input.visibleUntil!==undefined){if(!wire.integer(input.visibleUntil,1,MAX)){return null;}out.visibleUntil=input.visibleUntil;}
  ['entityRef','actions','openApp'].forEach(function(k){if(input[k]!==undefined){out[k]=extension(input[k],k);}});
  if(['entityRef','actions','openApp'].some(function(k){return own(out,k)&&out[k]===null;})){return null;}
  if(input.type==='standard'){
    out.headline=datum(input.headline,observedAt);if(!out.headline){return null;}
    if(input.detail!==undefined){out.detail=datum(input.detail,observedAt);if(!out.detail){return null;}}
    out.summary=input.summary===undefined?'headline':input.summary;
    out.state=input.state===undefined?'active':input.state;out.result=input.result===undefined?false:input.result;
    if(['headline','detail'].indexOf(out.summary)<0||out.summary==='detail'&&!out.detail||STATES.indexOf(out.state)<0||typeof out.result!=='boolean'||out.result&&out.state!=='completed'&&out.state!=='cancelled'){return null;}
  }else if(input.type==='media'){
    out.title=text(input.title,LIMITS.text);if(!out.title){return null;}
    if(input.artist!==undefined){out.artist=text(input.artist,LIMITS.text);if(!out.artist){return null;}}
    if(input.itemId!==undefined){out.itemId=text(input.itemId,64);if(!out.itemId){return null;}}
    out.playback=input.playback===undefined?'unknown':input.playback;if(PLAYBACK.indexOf(out.playback)<0){return null;}
    if(input.artwork!==undefined){out.artwork=wire.image(input.artwork);if(!out.artwork){return null;}}
  }else{return null;}
  return bounded(descriptor(out),LIMITS.descriptor)?out:null;
}
function sourceRecord(input,provider){
  if(!wire.object(input)||!wire.uuid(provider||input.provider)||!wire.integer(input.revision,1,MAX)||
    !wire.integer(input.observedAt,1,MAX)||!wire.integer(input.validUntil,input.observedAt,MAX)||
    input.private!==undefined&&typeof input.private!=='boolean'||input.unconfirmed!==undefined&&typeof input.unconfirmed!=='boolean'){return null;}
  var record=normalize(input.record,input.observedAt);if(!record){return null;}
  var out={provider:provider||input.provider,record:record,id:record.id,type:record.type,revision:input.revision,observedAt:input.observedAt,
    validUntil:Math.min(input.validUntil,record.visibleUntil===undefined?MAX:record.visibleUntil),private:record.type==='media'||input.private!==false,
    unconfirmed:input.unconfirmed===true,displayName:text(input.displayName,64)||''};
  if(out.validUntil<out.observedAt||out.private&&out.unconfirmed){return null;}
  return out;
}
function scalar(p,k,shape,field){return p&&p[k]&&p[k][shape]?p[k][shape][field||'value']:undefined;}
function parseJson(p,key,limit){var raw=scalar(p,key,'longText','text');if(typeof raw!=='string'||wire.utf8(raw).length>limit){return null;}try{return JSON.parse(raw);}catch(ignored){return null;}}
function sourceCard(instance,provider){
  var p=instance&&instance.properties;if(!wire.object(p)||scalar(p,'schema_version','numericValue')!==4){return null;}
  if(!wire.integer(scalar(p,'revision','numericValue'),1,MAX)||!wire.integer(scalar(p,'observed_at','timestamp'),1,MAX)||
      !wire.integer(scalar(p,'valid_until','timestamp'),1,MAX)||typeof scalar(p,'private','boolean')!=='boolean'||typeof scalar(p,'unconfirmed','boolean')!=='boolean'){return null;}
  if(p.icon!==undefined&&(!wire.object(p.icon)||!p.icon.image&&!p.icon.icon)||p.artwork!==undefined&&(!wire.object(p.artwork)||!p.artwork.image&&!p.artwork.icon)){return null;}
  var record=parseJson(p,'content',LIMITS.descriptor);if(!wire.object(record)||instance.instanceId!==record.id){return null;}
  delete record.entityRef;delete record.actions;delete record.openApp;delete record.artwork;
  if(record.icon&&typeof record.icon!=='string'){delete record.icon;}
  if(p.icon!==undefined){record.icon=p.icon.image||p.icon.icon;}
  if(p.artwork!==undefined){record.artwork=p.artwork.image||p.artwork.icon;}
  // Malformed optional capabilities are discarded independently of content.
  [['entity_ref','entityRef',LIMITS.entity],['actions','actions',LIMITS.actions],['open_app','openApp',LIMITS.openApp]].forEach(function(pair){
    if(p[pair[0]]!==undefined){var value=extension(parseJson(p,pair[0],pair[2]),pair[1]);if(value!==null){record[pair[1]]=value;}}
  });
  return sourceRecord({record:record,revision:scalar(p,'revision','numericValue'),observedAt:scalar(p,'observed_at','timestamp'),
    validUntil:scalar(p,'valid_until','timestamp'),private:scalar(p,'private','boolean'),unconfirmed:scalar(p,'unconfirmed','boolean'),
    displayName:scalar(p,'app_name','longText','text')},provider);
}
function header(envelope){
  if(!envelope||!Array.isArray(envelope.instances)||envelope.instances.length>17){return null;}
  var found=envelope.instances.filter(function(i){return i&&i.instanceId==='@snapshot';});
  if(found.length!==1){return null;}var p=found[0].properties;
  var h={mode:scalar(p,'publisher_mode','shortText','text'),incarnation:scalar(p,'publisher_incarnation','longText','text'),sequence:scalar(p,'snapshot_sequence','numericValue'),count:scalar(p,'activity_count','numericValue')};
  return scalar(p,'schema_version','numericValue')===4&&['fresh','snapshot'].indexOf(h.mode)>=0&&typeof h.incarnation==='string'&&text(h.incarnation,64)===h.incarnation&&wire.integer(h.sequence,1,MAX)&&wire.integer(h.count,0,16)&&h.count===envelope.instances.length-1?h:null;
}
function base64(bytes){var alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',out='';for(var i=0;i<bytes.length;i+=3){var a=bytes[i],b=i+1<bytes.length?bytes[i+1]:0,c=i+2<bytes.length?bytes[i+2]:0;out+=alphabet[a>>2]+alphabet[((a&3)<<4)|(b>>4)]+(i+1<bytes.length?alphabet[((b&15)<<2)|(c>>6)]:'=')+(i+2<bytes.length?alphabet[c&63]:'=');}return out;}
function imageProperty(image){return {image:{width:image.width,height:image.height,palette:base64(image.palette),pixels:base64(image.pixels)}};}
function toSourceInstance(input,request){
  var value=sourceRecord(input);if(!value){return null;}var r=value.record;
  var p={schema_version:{numericValue:{value:4}},revision:{numericValue:{value:value.revision}},observed_at:{timestamp:{value:value.observedAt}},valid_until:{timestamp:{value:value.validUntil}},
    private:{boolean:{value:value.private}},unconfirmed:{boolean:{value:value.unconfirmed}},content:{longText:{text:JSON.stringify(descriptor(r))}}};
  if(value.displayName){p.app_name={longText:{text:value.displayName}};}
  if(request&&request.iconPixelSize){if(r.icon&&typeof r.icon!=='string'){p.icon=imageProperty(r.icon);}if(r.artwork){p.artwork=imageProperty(r.artwork);}}
  [['entityRef','entity_ref'],['actions','actions'],['openApp','open_app']].forEach(function(pair){if(r[pair[0]]!==undefined){p[pair[1]]={longText:{text:JSON.stringify(r[pair[0]])}};}});
  return {instanceId:r.id,properties:p};
}
function provider(options,snapshot){
  options=options||{};
  if(!wire.uuid(options.pluginUuid)||!options.storage||typeof options.storage.getItem!=='function'||typeof options.storage.setItem!=='function'||typeof options[snapshot?'readSnapshot':'readCurrent']!=='function'){throw new Error('INVALID_PROVIDER');}
  var refresh=options.refreshSeconds===undefined?30:options.refreshSeconds,validity=options.validitySeconds===undefined?90:options.validitySeconds;
  if(!wire.integer(refresh,1,MAX)||!wire.integer(validity,refresh+1,MAX)){throw new Error('INVALID_VALIDITY');}
  var now=options.now||Date.now,key=options.metadataKey||META_KEY;
  function reserve(){
    var meta;
    try{meta=JSON.parse(options.storage.getItem(key));}catch(ignored){}
    if(!known(meta,['version','incarnation','sequence'])||meta.version!==1||typeof meta.incarnation!=='string'||text(meta.incarnation,64)!==meta.incarnation||!wire.integer(meta.sequence,0,MAX)){
      meta={version:1,incarnation:String(now())+'-'+String(Math.random()).slice(2),sequence:0};
    }
    if(meta.sequence===MAX){throw new Error('SEQUENCE_EXHAUSTED');}meta.sequence++;
    var encoded=JSON.stringify(meta);options.storage.setItem(key,encoded);if(options.storage.getItem(key)!==encoded){throw new Error('STORAGE_UNAVAILABLE');}
    return meta;
  }
  function source(request){
    return Promise.resolve().then(function(){
    var meta=reserve();
    return Promise.resolve(options[snapshot?'readSnapshot':'readCurrent'](request||{})).then(function(raw){
      var records=Array.isArray(raw)?raw:raw&&raw.records,time=now(),observed=Math.max(1,Math.floor(time/1000)),seen=Object.create(null),instances=[];
      if(!Array.isArray(records)||records.length>16){throw new Error('INVALID_SNAPSHOT');}
      records.forEach(function(input){
        var entry;
        if(snapshot){entry=typeof options.adapt==='function'?options.adapt(input):input;}
        else{entry={record:input,revision:meta.sequence,observedAt:observed,validUntil:Math.min(MAX,observed+validity),private:true,unconfirmed:false};}
        if(!entry){throw new Error('INVALID_SNAPSHOT');}
        var copy={};Object.keys(entry).forEach(function(k){copy[k]=entry[k];});copy.displayName=options.displayName||copy.displayName;
        if(copy.record&&copy.record.icon===undefined&&options.icon!==undefined){copy.record=helper({icon:options.icon},copy.record);}
        var validated=normalize(copy.record,copy.observedAt);
        if(!validated||seen[validated.id]){throw new Error('INVALID_SNAPSHOT');}seen[validated.id]=true;
        copy.record=validated;
        if(validated.visibleUntil!==undefined&&validated.visibleUntil<=observed){return;}
        var result=sourceRecord(copy,options.pluginUuid);if(!result){throw new Error('INVALID_SNAPSHOT');}
        if(result.record.type==='standard'&&(result.record.state==='completed'||result.record.state==='cancelled')&&!result.record.result){return;}
        if(result.validUntil>observed){var instance=toSourceInstance(result,request);if(!instance){throw new Error('INVALID_SNAPSHOT');}instances.push(instance);}
      });
      var count=instances.length;
      instances.unshift({instanceId:'@snapshot',properties:{schema_version:{numericValue:{value:4}},publisher_incarnation:{longText:{text:meta.incarnation}},publisher_mode:{shortText:{text:snapshot?'snapshot':'fresh'}},snapshot_sequence:{numericValue:{value:meta.sequence}},activity_count:{numericValue:{value:count}}}});
      var expiry=Math.min(MAX*1000,time+(snapshot?refresh:validity)*1000);
      if(raw&&!Array.isArray(raw)&&raw.validUntilMs!==undefined){if(!wire.integer(raw.validUntilMs,1,MAX*1000)){throw new Error('INVALID_SNAPSHOT');}expiry=Math.min(expiry,raw.validUntilMs);}
      return {validUntilMs:expiry,instances:instances};
    });
    });
  }
  function handleSource(request,respond){
    if(!request||request.category!=='activity'||request.item!=='summary'){if(respond&&respond.error){respond.error('INVALID_REQUEST','Unsupported source');}return Promise.resolve();}
    return Promise.resolve().then(function(){return source(request);}).then(function(result){respond.data(result);},function(error){respond.error(error&&/^(STORAGE_UNAVAILABLE|SEQUENCE_EXHAUSTED)$/.test(error.message)?error.message:'INVALID_DATA','Activity source unavailable');});
  }
  return {source:source,handleSource:handleSource,sourceDeclaration:{category:'activity',items:['summary'],properties:SOURCE_PROPERTIES,supportsMultiple:true,suggestedRefreshIntervalSec:refresh}};
}
function helper(base,options){var result={};Object.keys(options||{}).forEach(function(k){result[k]=options[k];});Object.keys(base).forEach(function(k){result[k]=base[k];});return result;}
function timerSnapshot(raw){
  var original=wire.normalize(raw);if(!original||original.kind!=='timer'){return null;}
  var headline;
  if(original.state==='active'&&original.clock==='deadline'){headline={type:'clock',mode:'countdown',deadline:original.deadline};}
  else if(original.state==='paused'&&original.clock==='deadline'){headline={type:'clock',mode:'countdown',seconds:original.duration};}
  else{headline={type:'text',text:original.state==='completed'?'Finished':'Cancelled'};}
  var record={id:original.id,type:'standard',icon:'timer',headline:headline,state:original.state,result:raw.showTerminal===true,
    openApp:{watchAppUuid:'50e9ef12-a5ab-4369-a3b5-3447bfba5151'}};
  var name=text(original.footer,64);if(name){record.name=name;}
  var validUntil=original.validUntil;
  if(original.state==='paused'){validUntil=Math.min(validUntil,original.observedAt+300);}
  if(original.state==='active'&&original.deadline){validUntil=Math.min(validUntil,original.deadline+60);}
  return {record:record,revision:original.revision,observedAt:original.observedAt,validUntil:validUntil,private:original.private,unconfirmed:true};
}
function toView(input,provider){return require(9).fromSummary(input,provider);}
module.exports={VERSION:4,CATEGORY:'activity',ITEM:'summary',LIMITS:LIMITS,ICONS:ICONS,DIRECTIONS:DIRECTIONS,METADATA_KEY:META_KEY,
  SOURCE_PROPERTIES:SOURCE_PROPERTIES,PROPERTIES:Object.keys(SOURCE_PROPERTIES),normalize:normalize,datum:datum,sourceRecord:sourceRecord,sourceCard:sourceCard,header:header,
  descriptor:descriptor,toSourceInstance:toSourceInstance,toView:toView,extension:extension,
  standard:function(id,options){return helper({id:id,type:'standard'},options);},media:function(id,options){return helper({id:id,type:'media'},options);},
  text:function(value,options){return helper({type:'text',text:value},options);},
  value:function(value,unit,options){var out={type:'value',value:value};if(unit!==undefined&&unit!==''){out.unit=unit;}return helper(out,options);},
  countdown:function(options){return helper({type:'clock',mode:'countdown'},options);},elapsed:function(options){return helper({type:'clock',mode:'elapsed'},options);},
  defineProvider:function(options){return provider(options,false);},defineSnapshotProvider:function(options){return provider(options,true);},adapters:{timerSnapshot:timerSnapshot}};

},
function(module,exports,require){
'use strict';

// ACT3 is the bounded two-role projection. It preserves ACT2's datum layout
// while adding explicit media, summary and semantic-symbol metadata.
var wire=require(6),view=require(7),summary=require(8),MAX=wire.MAX_EPOCH;
var PRESENTATIONS={text:1,media:2,clock:3,value:4,ranged:5};
var LIMITS={cards:2,packet:2672,pool:304,header:104};
function own(v,k){return Object.prototype.hasOwnProperty.call(v,k);}
function clone(v){return JSON.parse(JSON.stringify(v));}
function put16(b,o,v){b[o]=v&255;b[o+1]=(v>>>8)&255;}
function put32(b,o,v){for(var i=0;i<4;i++){b[o+i]=Math.floor(v/Math.pow(256,i))&255;}}
function numericText(value,unit){return String(value)+(unit?(/^(%|°|°C|°F)$/.test(unit)?'':' ')+unit:'');}
function token(value){
  var bytes=wire.utf8(value||''),a=2166136261,b=2246822519;
  bytes.forEach(function(x){a=(a^x)>>>0;a=(a*16777619)>>>0;b=(b^x)>>>0;b=(b*65599)>>>0;});
  var out=[];put32(out,0,a);put32(out,4,b);return out;
}
function poolFor(card){
  var bytes=[],known=Object.create(null);
  function add(value){value=value||'';if(own(known,value)){return known[value];}var data=wire.utf8(value),ref={offset:bytes.length,length:data.length};known[value]=ref;bytes=bytes.concat(data,[0]);return ref;}
  var refs={caption:add(card.caption),main:{label:add(card.main.label),text:add(card.main.text)},qualifier:add(card.qualifier)};
  if(card.support){refs.support={label:add(card.support.label),text:add(card.support.text)};}
  return {bytes:bytes,refs:refs};
}
function normalize(input){
  var card=view.normalize(input,undefined,true);if(!card){return null;}
  card.main.label=wire.text(card.main.label,32);if(card.support){card.support.label=wire.text(card.support.label,32);}
  card.presentation=input.presentation===undefined?(card.main.type==='clock'?PRESENTATIONS.clock:card.main.type==='value'?(card.meter?PRESENTATIONS.ranged:PRESENTATIONS.value):PRESENTATIONS.text):input.presentation;
  card.identitySymbol=input.identitySymbol===undefined?0:input.identitySymbol;
  card.compactItem=input.compactItem===undefined?0:input.compactItem;
  card.directions=input.directions===undefined?[0,0]:input.directions;
  card.qualifier=typeof input.qualifier==='string'?wire.text(input.qualifier,304):'';
  card.visualToken=input.visualToken===undefined?[0,0,0,0,0,0,0,0]:input.visualToken;
  if(!wire.integer(card.presentation,1,5)||!wire.integer(card.identitySymbol,0,10)||!wire.integer(card.compactItem,0,1)||card.compactItem&&!card.support||
    !Array.isArray(card.directions)||card.directions.length!==2||!card.directions.every(function(x){return wire.integer(x,0,4);})||
    !Array.isArray(card.visualToken)||card.visualToken.length!==8||!card.visualToken.every(function(x){return wire.integer(x,0,255);})){return null;}
  if(card.presentation===PRESENTATIONS.media&&(card.main.type!=='text'||card.support&&card.support.type!=='text'||card.compactItem||card.meter)){return null;}
  if(card.presentation===PRESENTATIONS.text&&card.main.type!=='text'||card.presentation===PRESENTATIONS.clock&&card.main.type!=='clock'||card.presentation===PRESENTATIONS.value&&card.main.type!=='value'||card.presentation===PRESENTATIONS.ranged&&(!card.meter||card.main.type!=='value'||card.meter.source!=='main')){return null;}
  if(card.directions[0]&&card.main.type!=='value'||card.directions[1]&&(!card.support||card.support.type!=='value')||card.presentation!==PRESENTATIONS.media&&card.visualToken.some(function(x){return x!==0;})){return null;}
  ['providerName','selectionKey','name','openApp','playback','sourceFormat','entityRef','actions','mediaItemId'].forEach(function(k){if(input[k]!==undefined){card[k]=clone(input[k]);}});
  // Keep shrinking monotonic even when strings share a pool reference.
  // Splitting a deduplicated string can increase storage, so optional aliases
  // are omitted rather than leaving ellipsis-only context behind.
  var fields=[['qualifier'],['caption'],['main','label'],['support','label']];
  if(card.support&&card.support.type==='text'){fields.push(['support','text']);}
  if(card.main.type==='text'){fields.push(['main','text']);}
  for(var f=0;poolFor(card).bytes.length>304&&f<fields.length;f++){
    var field=fields[f],owner=field.length===1?card:card[field[0]],key=field[field.length-1];if(!owner||!owner[key]){continue;}
    var requiredText=key==='text'&&(field[0]==='main'||card.compactItem===1||card.presentation===PRESENTATIONS.media);
    var before=poolFor(card).bytes.length,original=owner[key],size=wire.utf8(original).length;
    var limit=Math.max(requiredText?8:0,size-(before-304));
    owner[key]=limit<4?'':wire.text(original,limit);
    if(poolFor(card).bytes.length>=before){owner[key]=requiredText?wire.text(original,8):'';}
    if(field[0]==='support'&&key==='text'&&!owner.text){card.support=null;card.directions[1]=0;if(card.meter&&card.meter.source==='support'){card.meter=null;}}
  }
  if(poolFor(card).bytes.length>304||!card.main.text&&card.main.type!=='clock'||card.compactItem===1&&(!card.support||!card.support.text&&card.support.type!=='clock')){return null;}
  return card;
}
function compiledDatum(d,source){
  var out={type:d.type,label:d.label||'',observedAt:source.observedAt,validUntil:source.validUntil,retain:!source.private,estimated:false};
  if(d.type==='text'){out.text=d.text;}
  else if(d.type==='value'){out.text=numericText(d.value,d.unit||'');if(typeof d.value==='number'){out.value=d.value;out.unit=d.unit||'';}}
  else{out.mode=d.mode==='countdown'?'deadline':'elapsed';out.running=d.deadline!==undefined||d.since!==undefined;out.anchorAt=out.running?(d.since===undefined?source.observedAt:d.since):0;out.baseSeconds=d.deadline===undefined?d.seconds||0:Math.max(0,d.deadline-source.observedAt);}
  return out;
}
function textPart(d){return d&&d.type==='text'?(d.label?d.label+': ':'')+d.text:'';}
function unique(parts){var seen=Object.create(null);return parts.filter(function(x){if(!x||seen[x]){return false;}seen[x]=true;return true;}).join(' · ');}
function fromSummary(input,provider){
  var source=summary.sourceRecord(input,provider);if(!source){return null;}
  var r=source.record,media=r.type==='media',selected=r.summary==='detail'?1:0;
  var card={provider:source.provider,id:r.id,kind:media?'music':typeof r.icon==='string'?r.icon:'activity',revision:source.revision,state:media?(r.playback==='paused'?'paused':'active'):r.state,
    observedAt:source.observedAt,validUntil:source.validUntil,private:source.private,unconfirmed:source.unconfirmed,showTerminal:!media&&r.result,
    caption:media?r.artist||'':r.name||source.displayName||'',main:media?compiledDatum({type:'text',text:r.title},source):compiledDatum(r.headline,source),
    support:media?(r.artist?compiledDatum({type:'text',text:r.artist},source):null):(r.detail?compiledDatum(r.detail,source):null),
    image:media?r.artwork||typeof r.icon==='object'&&r.icon:typeof r.icon==='object'?r.icon:undefined,
    compactItem:media?0:selected,identitySymbol:summary.ICONS.indexOf(typeof r.icon==='string'?r.icon:media?'media':'activity'),
    directions:media?[0,0]:[summary.DIRECTIONS.indexOf(r.headline.symbol)+1,summary.DIRECTIONS.indexOf(r.detail&&r.detail.symbol)+1],
    presentation:media?PRESENTATIONS.media:r.headline.type==='clock'?PRESENTATIONS.clock:r.headline.type==='value'?(r.headline.range?PRESENTATIONS.ranged:PRESENTATIONS.value):PRESENTATIONS.text,
    visualToken:media?token(r.itemId===undefined?r.title:r.itemId):[0,0,0,0,0,0,0,0],
    qualifier:media?unique([r.name,r.artist].filter(function(part){return part!==r.title;})):unique([textPart(selected?r.headline:r.detail),r.name].filter(function(part){var d=selected?r.detail:r.headline;return part!==d.label&&part!==textPart(d);})),sourceFormat:4,playback:r.playback,mediaItemId:r.itemId};
  if(!card.image){delete card.image;}
  if(r.headline&&r.headline.range){card.meter={kind:'progress',source:'main',min:r.headline.range.min,max:r.headline.range.max};}
  if(r.openApp){card.openApp=r.openApp;}if(r.actions){card.actions=r.actions;}if(r.entityRef){card.entityRef=r.entityRef;}
  if(source.displayName){card.providerName=source.displayName;}if(r.name){card.name=r.name;}
  return normalize(card);
}
function fromLegacy(input){
  var card=input&&input.main?clone(input):view.fromLegacy(input);if(!card){return null;}
  var media=card.kind==='music';
  card.presentation=media?PRESENTATIONS.media:card.main.type==='clock'?PRESENTATIONS.clock:card.main.type==='value'?(card.meter&&card.meter.source==='main'?PRESENTATIONS.ranged:PRESENTATIONS.value):PRESENTATIONS.text;
  var kind=card.kind==='music'?'media':card.kind==='notification'||card.kind==='notifications'?'message':card.kind;
  card.identitySymbol=Math.max(0,summary.ICONS.indexOf(kind));card.compactItem=0;card.directions=[0,0];card.qualifier='';
  if(media){
    if(card.caption&&card.caption.indexOf('__dynamic_media__')===0){card.caption=card.caption.slice('__dynamic_media__'.length);}
    card.visualToken=token(card.main.text);card.qualifier=card.support?card.support.text:'';card.caption=card.support?card.support.text:'';
  }
  [card.main,card.support].forEach(function(d){if(d&&['Track','Artist','Text','Value','Left','Activity','Music',card.caption,card.providerName].indexOf(d.label)>=0){d.label='';}});
  if(!media){card.qualifier=unique([card.support&&card.support.type==='text'?card.support.text:'',card.caption]);}
  return normalize(card);
}
function writeDatum(header,offset,item,refs){
  if(!item){return;}header[offset]=view.TYPES[item.type];header[offset+1]=(item.type==='clock'&&item.mode==='elapsed'?1:0)|(item.running?2:0)|(item.retain?4:0)|(item.estimated?8:0);
  put32(header,offset+4,item.observedAt);put32(header,offset+8,item.validUntil);put32(header,offset+12,item.baseSeconds||0);put32(header,offset+16,item.anchorAt||0);
  put16(header,offset+20,refs.text.offset);put16(header,offset+22,refs.text.length);put16(header,offset+24,refs.label.offset);put16(header,offset+26,refs.label.length);
}
function encode(cards,options){
  options=options||{};var seq=options.sequence===undefined?options.revision:options.sequence;
  if(!Array.isArray(cards)||cards.length>2||!wire.integer(options.session,2,MAX)||!wire.integer(seq,1,MAX)||!wire.integer(options.sentAt,1,MAX)){throw new Error('INVALID_SNAPSHOT');}
  var out=[65,67,84,51,3,cards.length,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],seen=Object.create(null);
  put32(out,12,options.session);put32(out,16,seq);put32(out,20,options.sentAt);
  cards.forEach(function(raw){
    var card=normalize(raw);if(!card||seen[card.provider+'|'+card.id]){throw new Error('INVALID_ACTIVITY');}seen[card.provider+'|'+card.id]=true;
    var pool=poolFor(card),id=wire.utf8(card.id),h=[];for(var i=0;i<104;i++){h.push(0);}
    h[2]=wire.STATES[card.state];h[3]=(card.private?1:0)|(card.unconfirmed?2:0)|(card.showTerminal?4:0)|(card.image?8:0);
    put32(h,4,card.revision);put32(h,8,card.observedAt);put32(h,12,card.validUntil);h[16]=id.length;h[17]=card.image?card.image.width:0;h[18]=card.image?card.image.height:0;h[19]=card.meter?view.METERS[card.meter.kind]:0;
    put16(h,20,card.image?card.image.pixels.length:0);put16(h,22,pool.bytes.length);put16(h,24,pool.refs.caption.offset);put16(h,26,pool.refs.caption.length);
    put16(h,28,card.meter?Math.round(card.meter.fraction*65535):0);h[30]=card.meter&&card.meter.source==='support'?1:0;
    writeDatum(h,32,card.main,pool.refs.main);writeDatum(h,60,card.support,pool.refs.support);
    h[88]=card.presentation;h[89]=card.identitySymbol;h[90]=card.compactItem;h[91]=card.directions[0]|card.directions[1]<<3;
    put16(h,92,pool.refs.qualifier.offset);put16(h,94,pool.refs.qualifier.length);for(i=0;i<8;i++){h[96+i]=card.visualToken[i];}
    var record=h.concat(wire.utf8(card.provider),id,pool.bytes);if(card.image){record=record.concat(card.image.palette,card.image.pixels);}put16(record,0,record.length);out=out.concat(record);
  });
  if(out.length>2672){throw new Error('SNAPSHOT_TOO_LARGE');}put16(out,6,out.length);put16(out,8,wire.crc16(out));return out;
}
function formatDatum(d,now){
  if(d.type==='text'){return textPart(d);}
  if(d.type==='value'){return numericText(d.value,d.unit||'');}
  return wire.formatClock(d.mode==='countdown'?(d.deadline===undefined?d.seconds:Math.max(0,d.deadline-now)):Math.min(MAX,(d.seconds||0)+(d.since===undefined?0:Math.max(0,now-d.since))));
}
function compactText(record,now){
  var r=summary.normalize(record,now);if(!r){return null;}
  if(r.type==='media'){return unique([r.title,r.name,r.artist]);}
  var selected=r.summary==='detail'?r.detail:r.headline,other=r.summary==='detail'?r.headline:r.detail;
  return unique([formatDatum(selected,now),selected.type==='text'?'':selected.label,textPart(other),r.name]);
}
module.exports={VERSION:3,PRESENTATIONS:PRESENTATIONS,LIMITS:LIMITS,normalize:normalize,encode:encode,fromSummary:fromSummary,fromLegacy:fromLegacy,poolFor:poolFor,compactText:compactText,visualToken:token,numericText:numericText};

},
function(module,exports,require){
'use strict';

var wire=require(6);
var MUSIC='builtin:music';
var NOTIFICATIONS='builtin:notifications';
function key(value){return value===MUSIC||value===NOTIFICATIONS||wire.uuid(value)?value:null;}
function list(value){return (Array.isArray(value)?value:[]).map(key).filter(function(v,i,a){return v&&a.indexOf(v)===i;}).slice(0,64);}
function normalizePreferences(value){value=value&&typeof value==='object'?value:{};return {order:list(value.order),hidden:list(value.hidden)};}
function providerKey(card){return card&&[MUSIC,NOTIFICATIONS].indexOf(card.selectionKey)>=0?card.selectionKey:card&&key(card.provider);}
function terminal(card){return card.state==='completed'||card.state==='cancelled';}
function countdown(card){var d=card.main;return d&&d.type==='clock'&&d.mode==='deadline'?d:null;}
/** Pure host policy. Persist provider keys only; cards and run IDs stay transient. */
function select(cards,options){
  options=options||{};var prefs=normalizePreferences(options),limit=wire.integer(options.limit,0,2)?options.limit:2;
  var entries=(Array.isArray(cards)?cards:[]).map(function(card,index){return {card:card,index:index,key:providerKey(card)};})
    .filter(function(entry){return entry.key&&prefs.hidden.indexOf(entry.key)<0;}),positions=Object.create(null);
  entries.forEach(function(entry,index){if(countdown(entry.card)&&!terminal(entry.card)){(positions[entry.key]||(positions[entry.key]=[])).push(index);}});
  Object.keys(positions).forEach(function(provider){
    var slots=positions[provider],runs=slots.map(function(index){return {card:entries[index].card,index:index};}).sort(function(a,b){
      var ac=countdown(a.card),bc=countdown(b.card);if(ac.running!==bc.running){return ac.running?-1:1;}
      return ac.baseSeconds+(ac.running?ac.anchorAt:0)-bc.baseSeconds-(bc.running?bc.anchorAt:0)||a.index-b.index;
    });
    slots.forEach(function(index,run){entries[index].card=runs[run].card;});
  });
  return entries
    .sort(function(a,b){
      var at=terminal(a.card),bt=terminal(b.card);if(at!==bt){return at?1:-1;}
      var ar=prefs.order.indexOf(a.key),br=prefs.order.indexOf(b.key);ar=ar<0?prefs.order.length:ar;br=br<0?prefs.order.length:br;
      if(ar!==br){return ar-br;}
      return a.index-b.index;
    }).slice(0,limit).map(function(entry){return entry.card;});
}
module.exports={select:select,normalizePreferences:normalizePreferences,providerKey:providerKey,MUSIC_KEY:MUSIC,NOTIFICATIONS_KEY:NOTIFICATIONS};

},
function(module,exports,require){
'use strict';

var wire=require(6);
var view=require(7);
var activity=require(5);
var summary=require(8),summaryView=require(9);
var PROPERTIES=['schema_version','kind','state','clock','revision','name','main','footer','observed_at','valid_until','deadline','duration','clock_at','private','unconfirmed','value','artwork'];
function scalar(p,name,shape,field) {return p && p[name] && p[name][shape] ? p[name][shape][field||'value'] : undefined;}
function string(p,name) {var v=scalar(p,name,'longText','text');return v===undefined?scalar(p,name,'shortText','text'):v;}
function sourceCard(instance,provider) {
  if(!instance || !wire.object(instance.properties)) {return null;}
  var p=instance.properties;
  if(scalar(p,'schema_version','numericValue')!==1) {return null;}
  var number=p.value && p.value.numericValue;
  return wire.normalize({id:instance.instanceId,kind:string(p,'kind'),state:string(p,'state'),clock:string(p,'clock'),
    revision:scalar(p,'revision','numericValue'),observedAt:scalar(p,'observed_at','timestamp'),validUntil:scalar(p,'valid_until','timestamp'),
    deadline:scalar(p,'deadline','timestamp'),duration:scalar(p,'duration','numericValue'),clockAt:scalar(p,'clock_at','timestamp'),
    main:string(p,'main')===undefined?string(p,'value'):string(p,'main'),footer:string(p,'footer')===undefined?string(p,'name'):string(p,'footer'),
    private:scalar(p,'private','boolean')!==false,unconfirmed:scalar(p,'unconfirmed','boolean')===true,value:number && number.value,unit:number && number.unit,
    image:p.artwork && (p.artwork.image || p.artwork.icon)},provider);
}
function sourceItem(plugin,format) {
  if(!plugin||!wire.uuid(plugin.uuid)||!Array.isArray(plugin.sources)){return null;}
  var items=[];
  plugin.sources.forEach(function(source){if(wire.object(source)&&source.category===wire.CATEGORY&&Array.isArray(source.items)&&source.properties&&
    Array.isArray(source.properties.schema_version)&&source.properties.schema_version.indexOf('numericValue')>=0){items=items.concat(source.items);}});
  return format>=3&&items.indexOf(summary.ITEM)>=0?summary.ITEM:
    format>=2&&items.indexOf(activity.ITEM)>=0?activity.ITEM:
    format>=2&&items.indexOf(view.ITEM)>=0?view.ITEM:items.indexOf(wire.ITEM)>=0?wire.ITEM:null;
}
function compatible(plugin,format) {
  return !!sourceItem(plugin,format);
}
function errorCode(error) {return error && typeof error.code==='string' && /^[A-Z0-9_]{1,48}$/.test(error.code)?error.code:'UNKNOWN';}
function clone(value) {return JSON.parse(JSON.stringify(value));}
function sourceFingerprint(source) {
  // Omit mutable capabilities without first copying the complete bitmap and
  // parsing it back. The source has already passed its format's validation.
  var copy={};
  Object.keys(source).forEach(function(name){if(name!=='unconfirmed'&&name!=='displayName'){copy[name]=source[name];}});
  if(source.record){
    copy.record={};Object.keys(source.record).forEach(function(name){
      if(name!=='actions'&&name!=='entityRef'&&name!=='openApp'){copy.record[name]=source.record[name];}
    });
  }
  return JSON.stringify(copy);
}
module.exports=function createActivities(options) {
  options=options||{};
  var nativeFormat=options.nativeFormat===3?3:options.nativeFormat===2?2:1,codec=nativeFormat===3?summaryView:nativeFormat===2?view:wire;
  var pebble=options.pebble||{}, now=options.now||Date.now, later=options.later||setTimeout, cancel=options.cancelLater||clearTimeout;
  var keys=options.keys||{}, send=options.send, groups=Object.create(null), session=0, sequence=0, generation=0;
  var stopped=false,connected=true,enabled=true,available=typeof pebble.enumeratePlugins==='function' && typeof pebble.subscribeToSource==='function';
  var expiryTimer=null,expiryAt=Infinity,discoveryTimer=null,retryTimer=null,bootTimer=null,deliveryEpoch=0,lastError='',bootRequested=false,bootAttempts=0,failureCount=0,seenOrder=0,enumerated=false;
  var revisions=Object.create(null), orders=Object.create(null), lastSignature='',currentSettings={},installed=[],providerMetadata=Object.create(null),lastView=null;
  function seconds(){return Math.max(1,Math.floor(now()/1000));}
  function key(name){return keys[name]===undefined?name:keys[name];}
  function readSettings(){var s=typeof options.getSettings==='function'?options.getSettings():{};return s&&typeof s==='object'?s:{};}
  function isEnabled(s){return s.enabled!==false && s.showActivities!==false;}
  function allowed(provider){return (!Array.isArray(currentSettings.providers)||currentSettings.providers.indexOf(provider)>=0) &&
    (!Array.isArray(currentSettings.disabledProviders)||currentSettings.disabledProviders.indexOf(provider)<0);}
  function stopGroup(group){group.generation++;var handle=group.handle;group.handle=null;if(handle && typeof handle.unsubscribe==='function'){try{handle.unsubscribe();}catch(ignored){}}}
  function accepted(card){try{return typeof options.acceptActivity!=='function'||options.acceptActivity(clone(card))!==false;}catch(ignored){return false;}}
  function visible(card,t){return card.validUntil>t&&
    (nativeFormat<2||card.main.validUntil>t&&(!card.unconfirmed||!card.private&&card.main.retain))&&
    ((card.state!=='completed'&&card.state!=='cancelled')||nativeFormat>=2&&card.showTerminal);}
  function cleanGroup(provider){var group=groups[provider];if(!group){return;}stopGroup(group);group.cards=[];delete groups[provider];}
  function catalogue(defensive){
    var t=seconds(), result=[];
    Object.keys(groups).forEach(function(provider){
      var metadata=providerMetadata[provider];
      groups[provider].cards.forEach(function(card){if(visible(card,t)&&accepted(card)){
        // Internal default selection can borrow immutable cards: normalize()
        // below owns the resulting copy. User callbacks/public reads get deep
        // copies, including nested artwork and capabilities.
        var copy=defensive?clone(card):card;
        if(metadata&&metadata.name){
          if(!defensive){copy={};Object.keys(card).forEach(function(k){copy[k]=card[k];});}
          copy.providerName=metadata.name;
        }
        result.push(copy);
      }});
    });
    result.sort(function(a,b){return orders[a.provider+'|'+a.id]-orders[b.provider+'|'+b.id];});
    return result;
  }
  function catalogueCount(){
    var t=seconds(),count=0;
    Object.keys(groups).forEach(function(provider){groups[provider].cards.forEach(function(card){if(visible(card,t)&&accepted(card)){count++;}});});
    return count;
  }
  function projection(){
    var custom=typeof options.select==='function',all=catalogue(custom),result=custom?options.select(all):all.slice(0,2);
    if(!Array.isArray(result)){result=[];}
    return result.slice(0,2).map(function(card){return codec.normalize(card);}).filter(Boolean);
  }
  function notify(){if(typeof options.onChanged==='function'){options.onChanged();}}
  function deliveryCurrent(epoch,token){return epoch===deliveryEpoch&&token===session&&!stopped&&connected&&enabled;}
  function invalidateDelivery(){
    deliveryEpoch++;lastView=null;bootRequested=false;bootAttempts=0;
    [retryTimer,bootTimer].forEach(function(timer){if(timer!==null){cancel(timer);}});retryTimer=bootTimer=null;
  }
  function requestBootstrap(){
    if(bootRequested || typeof send!=='function' || !connected || !enabled || stopped){return;}
    if(bootAttempts>=3){return;}bootRequested=true;bootAttempts++;var attempt=bootAttempts,epoch=deliveryEpoch,payload={};payload[key('REQUEST_ACTIVITIES')]=1;
    function live(){return deliveryCurrent(epoch,0)&&attempt===bootAttempts;}
    function retry(){if(!live()){return;}if(bootTimer!==null){cancel(bootTimer);}bootTimer=later(function(){bootTimer=null;if(live()){bootRequested=false;requestBootstrap();}},2000);}
    function failed(){if(!live()){return;}bootRequested=false;retry();}
    try{send(payload,retry,failed);}catch(ignored){failed();}
  }
  function publish(force,afterAccepted){
    if(stopped || !connected || !enabled){return;}
    scheduleExpiry();notify();
    if(!session){requestBootstrap();return;}
    var cards=projection(),signature=JSON.stringify(cards);
    if(!force && signature===lastSignature){return;}
    if(signature!==lastSignature){failureCount=0;}lastSignature=signature;
    sequence=sequence===wire.MAX_EPOCH?1:sequence+1;
    if(typeof send!=='function'){return;}
    var revision=sequence,epoch=deliveryEpoch,token=session,payload={},barriers=[];
    Object.keys(groups).forEach(function(provider){var group=groups[provider];
      if(group.rebinding&&!cards.some(function(card){return card.provider===provider;})){barriers.push({group:group,generation:group.generation});}
    });
    var sentAt=seconds();payload[key('ACTIVITY_DATA')]=codec.encode(cards,{session:session,revision:revision,sentAt:sentAt});
    // projection() owns these normalized records. Only copied snapshots leave
    // the consumer, so retaining them needs no second JSON round trip.
    lastView={session:session,viewSequence:revision,sequence:revision,sentAt:sentAt,cards:cards};
    if(typeof options.onView==='function'){options.onView(clone(lastView));}
    if(!deliveryCurrent(epoch,token)){return;}
    if(retryTimer!==null){cancel(retryTimer);retryTimer=null;}
    try{send(payload,function(){
      if(!deliveryCurrent(epoch,token)){return;}
      if(revision===sequence){failureCount=0;}
      // Any acknowledged view excluding a resetting provider is a valid clear
      // barrier, including one that superseded the original queued clear.
      barriers.forEach(function(barrier){
        var group=barrier.group,provider=group.provider;
        if(groups[provider]!==group||group.generation!==barrier.generation||!group.rebinding){return;}
        var pending=group.pendingReset;group.pendingReset=null;group.rebinding=false;
        var needsRebind=group.pendingRebind;group.pendingRebind=false;
        if(group.pendingMode!=='snapshot'){Object.keys(revisions).forEach(function(id){if(id.indexOf(provider+'|')===0){delete revisions[id];}});}
        if(needsRebind){bind(provider,group.item);}
        else if(pending){receive(group,pending,true);}
      });
      if(typeof afterAccepted==='function'){afterAccepted();}
    },function(error){
      if(!deliveryCurrent(epoch,token)||revision!==sequence||error && error.code==='SUPERSEDED'){return;}
      if(++failureCount<3){retryTimer=later(function(){retryTimer=null;publish(true);},2000);}
    });}catch(ignored){if(deliveryCurrent(epoch,token)&&++failureCount<3){retryTimer=later(function(){retryTimer=null;publish(true);},2000);}}
  }
  function uncertain(group){
    var before=group.cards.length,changed=false,t=seconds();
    group.cards=group.cards.filter(function(card){return !card.private&&card.validUntil>t&&
      (nativeFormat>=2?card.main.retain&&card.main.validUntil>t:card.clock!=='none');}).map(function(card){
        if(card.unconfirmed){return card;}
        changed=true;var copy={};Object.keys(card).forEach(function(k){copy[k]=card[k];});copy.unconfirmed=true;return copy;
      });
    return changed||before!==group.cards.length;
  }
  function expire(){
    var t=seconds(), changed=false;
    Object.keys(groups).forEach(function(provider){
      var group=groups[provider],before=group.cards.length;
      group.cards=group.cards.filter(function(card){return card.validUntil>t&&(nativeFormat<2||card.main.validUntil>t);});
      if(group.expiresAt!==null && group.expiresAt<=t){group.expiresAt=null;group.error='SOURCE_EXPIRED';if(uncertain(group)){changed=true;}}
      if(before!==group.cards.length){changed=true;}
    });
    if(changed){publish();}else{scheduleExpiry();}
  }
  function scheduleExpiry(){
    if(stopped||!connected||!enabled){if(expiryTimer!==null){cancel(expiryTimer);}expiryTimer=null;expiryAt=Infinity;return;}
    var t=seconds(),end=Infinity;
    Object.keys(groups).forEach(function(provider){var group=groups[provider];if(group.expiresAt!==null && group.expiresAt>t){end=Math.min(end,group.expiresAt);}group.cards.forEach(function(card){if(card.validUntil>t){end=Math.min(end,card.validUntil);}if(nativeFormat>=2){[card.main,card.support].forEach(function(d){if(d&&d.validUntil>t){end=Math.min(end,d.validUntil);}});}});});
    if(expiryTimer!==null&&expiryAt===end){return;}
    if(expiryTimer!==null){cancel(expiryTimer);expiryTimer=null;}
    expiryAt=end;
    if(end!==Infinity){expiryTimer=later(function(){expiryTimer=null;expiryAt=Infinity;expire();},Math.max(1,end*1000-now()));}
  }
  function receive(group,envelope,rebound){
    if(!envelope || envelope.pluginUuid!==group.provider || !Array.isArray(envelope.instances) || envelope.instances.length>(group.item===summary.ITEM?17:wire.LIMITS.instances)){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
    var t=seconds(),expiry=envelope.validUntilMs===undefined?null:Math.floor(envelope.validUntilMs/1000);
    if(expiry!==null && !wire.integer(expiry,1,wire.MAX_EPOCH)){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
    var snapshotHeader=null;
    if(group.item===summary.ITEM){
      snapshotHeader=summary.header(envelope);
      if(!snapshotHeader){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
      if(!rebound&&group.incarnation&&group.incarnation!==snapshotHeader.incarnation){
        group.cards=[];group.incarnation=null;group.snapshotSequence=0;
        // The source-floor clear must reach native before a reset managed
        // revision. Queue only this cleared view until the send completes.
        group.rebinding=true;group.pendingReset=null;group.pendingMode=snapshotHeader.mode;group.pendingRebind=true;
        stopGroup(group);
        publish(true);return;
      }
      if(group.rebinding&&!rebound){
        var pendingHeader=summary.header(group.pendingReset);
        if(!pendingHeader||pendingHeader.incarnation!==snapshotHeader.incarnation||snapshotHeader.sequence>pendingHeader.sequence){group.pendingReset=envelope;group.pendingMode=snapshotHeader.mode;}
        return;
      }
      if(group.incarnation===snapshotHeader.incarnation&&group.publisherMode!==snapshotHeader.mode){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
      if(group.incarnation===snapshotHeader.incarnation&&snapshotHeader.sequence<group.snapshotSequence){return;}
      var responseSignature=JSON.stringify(envelope.instances);
      if(group.incarnation===snapshotHeader.incarnation&&snapshotHeader.sequence===group.snapshotSequence){
        if(group.responseSignature!==responseSignature){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
        // A source can recover on the same handle or immediately deliver its
        // cached response on a new binding. Its outer availability can also
        // change independently. Revalidate those cases without renewing any
        // owner observation/validity; healthy exact duplicates remain inert.
        if(group.ready&&!group.error&&expiry===group.expiresAt){return;}
      }
      group.incarnation=snapshotHeader.incarnation;group.publisherMode=snapshotHeader.mode;group.snapshotSequence=snapshotHeader.sequence;group.responseSignature=responseSignature;
    }
    var next=[],seen=Object.create(null),pendingRevisions=Object.create(null),pendingOrders=[],malformed=false;
    envelope.instances.forEach(function(instance){
      if(group.item===summary.ITEM&&instance&&instance.instanceId==='@snapshot'){return;}

      var source=group.item===summary.ITEM?summary.sourceCard(instance,group.provider):group.item===activity.ITEM?activity.sourceCard(instance,group.provider):
        group.item===view.ITEM?view.sourceCard(instance,group.provider):sourceCard(instance,group.provider);
      if(!source){malformed=true;return;}
      if(group.item===summary.ITEM&&!source.displayName){
        var metadataEntry=providerMetadata[group.provider];
        if(metadataEntry&&metadataEntry.name){source.displayName=metadataEntry.name;}
      }
      var card=group.item===summary.ITEM?summary.toView(source):group.item===activity.ITEM?activity.toView(source):nativeFormat>=2&&group.item!==view.ITEM?view.fromLegacy(source):source;
      if(nativeFormat===3&&group.item!==summary.ITEM&&card){card=summaryView.fromLegacy(card);}
      if(!card&&group.item!==summary.ITEM){malformed=true;return;}
      if(card&&!accepted(card)){return;}
      var fingerprint=sourceFingerprint(source),identity=source.provider+'|'+source.id;
      var state=source.record?(source.record.state||'active'):source.state;
      var metadata=JSON.stringify([source.kind||source.type,state,source.observedAt,source.validUntil,source.private]);

      if(seen[identity]){malformed=true;return;}seen[identity]=true;
      var previous=revisions[identity];
      if(previous && source.revision<previous.revision){
        var retained=group.cards.filter(function(old){return old.id===source.id && old.revision===previous.revision;})[0];
        if(retained && retained.validUntil>t){next.push(retained);}return;
      }
      if(previous && (source.revision===previous.revision && (metadata!==previous.metadata || group.item===previous.item&&fingerprint!==previous.fingerprint) || previous.terminal && state!=='completed' && state!=='cancelled')){malformed=true;return;}
      pendingRevisions[identity]={revision:source.revision,fingerprint:fingerprint,metadata:metadata,item:group.item,terminal:state==='completed'||state==='cancelled'};
      if(!card){return;}
      card.sourceFormat=group.item===summary.ITEM?4:group.item===activity.ITEM?3:group.item===view.ITEM?2:1;
      if(card.kind==='music'){
        card.validUntil=Math.min(card.validUntil,card.observedAt+120);
        if(nativeFormat>=2){card.main.validUntil=Math.min(card.main.validUntil,card.validUntil);if(card.support){card.support.validUntil=Math.min(card.support.validUntil,card.validUntil);}}
      }
      if(!Object.prototype.hasOwnProperty.call(orders,identity)){pendingOrders.push(identity);}
      if(card.validUntil>t&&((card.state!=='completed'&&card.state!=='cancelled')||nativeFormat>=2&&card.showTerminal)){next.push(card);}
    });
    // A malformed/redacted entry cannot leave an older private preview alive.
    if(malformed){next=[];}
    else{
      // A rejected complete response cannot advance another record's source
      // floor or install a terminal tombstone through its valid-looking rows.
      Object.keys(pendingRevisions).forEach(function(identity){revisions[identity]=pendingRevisions[identity];});
      pendingOrders.forEach(function(identity){orders[identity]=++seenOrder;});
    }
    group.cards=next;group.receivedAt=t;group.expiresAt=expiry;group.error=malformed?'INVALID_SOURCE':'';group.ready=true;
    if(expiry!==null && expiry<=t){uncertain(group);group.error='SOURCE_EXPIRED';}
    // Bound revision/ordering tombstones independently of untrusted source churn.
    var identities=Object.keys(revisions);
    if(identities.length>1024){var live=Object.create(null);Object.keys(groups).forEach(function(provider){groups[provider].cards.forEach(function(card){live[card.provider+'|'+card.id]=true;});});identities.filter(function(id){return !live[id];}).slice(0,identities.length-1024).forEach(function(id){delete revisions[id];delete orders[id];});}
    publish();
  }
  function bind(provider,item){
    var group=groups[provider]||{provider:provider,generation:0,handle:null,cards:[],error:'',receivedAt:null,expiresAt:null,ready:false};
    groups[provider]=group;stopGroup(group);group.item=item;group.ready=false;group.settled=false;group.error='';var run=group.generation;
    function live(){return !stopped && connected && enabled && groups[provider]===group && run===group.generation;}
    try{
      var handle=pebble.subscribeToSource({plugin:provider,category:wire.CATEGORY,item:item,properties:(item===summary.ITEM?summary.PROPERTIES:item===activity.ITEM?activity.PROPERTIES:item===view.ITEM?view.PROPERTIES:PROPERTIES).slice(),iconPixelSize:{w:40,h:40},
        onData:function(envelope){if(live()){group.settled=true;receive(group,envelope);}},
        onError:function(error){if(!live()){return;}group.settled=true;group.error=errorCode(error);if(group.error==='TIMEOUT'||group.error==='PLUGIN_UNAVAILABLE'||group.error==='RATE_LIMITED'){uncertain(group);}else{group.cards=[];}publish();}});
      if(live()){group.handle=handle;}else if(handle && typeof handle.unsubscribe==='function'){handle.unsubscribe();}
    }catch(error){group.settled=true;group.error=errorCode(error);group.cards=[];publish();}
  }
  function discover(rebind){
    if(stopped||!connected||!enabled){return;}
    available=typeof pebble.enumeratePlugins==='function' && typeof pebble.subscribeToSource==='function';
    if(!available){Object.keys(groups).forEach(cleanGroup);lastError='API_UNAVAILABLE';publish();return;}
    var run=++generation;enumerated=false;
    function apply(plugins){
      if(run!==generation||stopped||!connected||!enabled){return;}
      if(!Array.isArray(plugins)){lastError='INVALID_CATALOGUE';Object.keys(groups).forEach(cleanGroup);publish();return;}
      var items=Object.create(null),metadata=Object.create(null);
      plugins.filter(function(p){return compatible(p,nativeFormat);}).forEach(function(p){
        // The official plugin-test app reads enumeratePlugins().name. Treat it
        // as untrusted display metadata, never as source/revision identity.
        if(!metadata[p.uuid]){metadata[p.uuid]={uuid:p.uuid,name:wire.text(p.name,64),item:sourceItem(p,nativeFormat),available:true};}
      });
      installed=Object.keys(metadata).sort().slice(0,wire.LIMITS.providers).map(function(uuid){return metadata[uuid];});
      providerMetadata=Object.create(null);installed.forEach(function(p){providerMetadata[p.uuid]=p;});
      var providers=installed.filter(function(p){return allowed(p.uuid);}).map(function(p){items[p.uuid]=p.item;return p.uuid;});
      enumerated=true;
      Object.keys(groups).forEach(function(provider){if(providers.indexOf(provider)<0){cleanGroup(provider);}});
      providers.forEach(function(provider){var group=groups[provider];if(rebind||!group||group.item!==items[provider]||
        !group.rebinding&&(group.error||!group.handle)){bind(provider,items[provider]);}});
      lastError='';publish();
    }
    try{var result=pebble.enumeratePlugins();if(result && typeof result.then==='function'){result.then(apply,function(){if(run===generation){lastError='CATALOGUE_UNAVAILABLE';Object.keys(groups).forEach(cleanGroup);publish();}});}else{apply(result);}}
    catch(ignored){lastError='CATALOGUE_UNAVAILABLE';Object.keys(groups).forEach(cleanGroup);publish();}
    if(discoveryTimer!==null){cancel(discoveryTimer);}
    discoveryTimer=later(function(){discoveryTimer=null;discover(false);},60000);
  }
  function configure(){
    if(stopped){return;}
    var next=readSettings(),previous=enabled;currentSettings=next;enabled=isEnabled(next);
    if(!enabled){invalidateDelivery();Object.keys(groups).forEach(cleanGroup);lastSignature='';if(expiryTimer!==null){cancel(expiryTimer);expiryTimer=null;}if(discoveryTimer!==null){cancel(discoveryTimer);discoveryTimer=null;}
      if(previous && connected && session && typeof send==='function'){sequence=sequence===wire.MAX_EPOCH?1:sequence+1;var payload={};payload[key('ACTIVITY_DATA')]=codec.encode([],{session:session,revision:sequence,sentAt:seconds()});try{send(payload,function(){},function(){});}catch(ignored){}}
      notify();return;
    }
    // Apply known policy immediately: asynchronous discovery may be slow or
    // never settle, and cannot be the boundary for withdrawing private data.
    var removed=false;
    Object.keys(groups).forEach(function(provider){if(!allowed(provider)){cleanGroup(provider);removed=true;}});
    if(removed){publish();}
    discover(false);
  }
  function refresh(rebaseline,token){
    if(stopped){return;}
    if(typeof rebaseline==='number'){token=rebaseline;rebaseline=true;}
    if(wire.integer(token,2,wire.MAX_EPOCH) && token!==session){invalidateDelivery();session=token;sequence=0;lastSignature='';failureCount=0;}
    else if(rebaseline && !token){bootRequested=false;bootAttempts=0;}failureCount=0;
    currentSettings=readSettings();enabled=isEnabled(currentSettings);
    if(!enabled){configure();return;}
    discover(true);publish(true);
  }
  function connectionChanged(value,token){
    if(stopped || typeof value!=='boolean'){return;}
    connected=value;generation++;
    if(!connected){invalidateDelivery();Object.keys(groups).forEach(cleanGroup);session=0;sequence=0;lastSignature='';
      [expiryTimer,discoveryTimer,retryTimer,bootTimer].forEach(function(timer){if(timer!==null){cancel(timer);}});expiryTimer=discoveryTimer=retryTimer=bootTimer=null;notify();}
    else{refresh(true,token);}
  }
  return {refresh:refresh,configure:configure,connectionChanged:connectionChanged,reproject:function(){publish(true);},
    providers:function(){return clone(installed);},
    catalogue:function(){return catalogue(true);},
    view:function(){return lastView?clone(lastView):null;},
    status:function(){var providers=Object.keys(groups).map(function(provider){var group=groups[provider];return {pluginUuid:provider,state:group.error?'unavailable':group.ready?'ready':'waiting',error:group.error,receivedAt:group.receivedAt};});var count=catalogueCount(),complete=enumerated&&Object.keys(groups).every(function(provider){return groups[provider].settled;});var ready=enabled&&available&&connected&&enumerated&&providers.every(function(p){return p.state==='ready';});return {available:available,connected:connected,enabled:enabled,ready:ready,complete:complete,phase:ready?'ready':count?'partial':complete||lastError||!connected||!available?'unavailable':'loading',error:lastError||providers.map(function(p){return p.error;}).filter(Boolean)[0]||'',providers:providers,count:count};},
    stop:function(){stopped=true;generation++;invalidateDelivery();Object.keys(groups).forEach(cleanGroup);[expiryTimer,discoveryTimer,retryTimer,bootTimer].forEach(function(timer){if(timer!==null){cancel(timer);}});expiryTimer=discoveryTimer=retryTimer=bootTimer=null;revisions=Object.create(null);orders=Object.create(null);}}
};
module.exports.sourceCard=sourceCard;
module.exports.compatible=compatible;
module.exports.PROPERTIES=PROPERTIES;

},
function(module,exports,require){
'use strict';

var wire = require(13);
var activityWire = require(6);
var activity = require(5);
var summary = require(8);
// Namespace of this host adapter only; never claim an unknown SDK provider UUID.
var MUSIC_ADAPTER_UUID = '718089b7-d9d4-4d6b-81c0-915dcd4c7e4a';
var NOTIFICATION_ADAPTER_UUID = 'cdb6d497-547a-4940-8026-f7c97ea73a9d';
var NOTIFICATIONS_APP_UUID = 'b2cae818-10f8-46df-ad2b-98ad2254a3c1';
var KIND = wire.SEMANTIC_KIND;
var SOURCE = wire.SOURCE_KIND;
var LEASE = 120;
var NOTICE_SUMMARY_LIFE = 3;
var NOTICE_MESSAGE_LIFE = 8;
var NOTICE_QUIET = 3;
var NOTICE_STABLE_MS = 900;
var PAUSED_GRACE = 5;
var HEARTBEAT = 60000;
var MAX_EPOCH = 4294967295;
var DEFINITIONS = {
  music:{category:'music', item:'track', properties:['title','artist','playing','artwork']},
  notifications:{category:'notifications', item:'notification', properties:['name','body','app','package','app_icon']},
  phone:{category:'phone', item:'phone_state', properties:['battery_level']}
};

function object(value) { return value && typeof value === 'object' && !Array.isArray(value); }
function finite(value) { return typeof value === 'number' && isFinite(value); }
function tokenOf(value) {
  return finite(value) && Math.floor(value) === value && value>=2 && value<=2147483647 ? value : null;
}
function textOf(value) {
  if (!object(value)) { return ''; }
  return object(value.shortText) && typeof value.shortText.text === 'string' ? value.shortText.text :
    object(value.longText) && typeof value.longText.text === 'string' ? value.longText.text : '';
}
function clean(value) {
  return wire.normalizeText(typeof value === 'string' ? value.slice(0,4096)
    .replace(/[\u00ad\u061c\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff\ufff9-\ufffb]/g,' ') : '',128);
}
function codeOf(error) {
  return error && typeof error.code === 'string' && /^[A-Z0-9_]{1,48}$/.test(error.code) ? error.code : 'UNKNOWN';
}
function bytesOf(value, max) {
  if (typeof value !== 'string' || value.length > Math.ceil(max / 3) * 4 ||
      !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) { return null; }
  var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  var out = [];
  for (var i=0; i<value.length; i+=4) {
    var a=alphabet.indexOf(value[i]), b=alphabet.indexOf(value[i+1]);
    var c=value[i+2] === '=' ? 0 : alphabet.indexOf(value[i+2]);
    var d=value[i+3] === '=' ? 0 : alphabet.indexOf(value[i+3]);
    if (value[i+2] === '=' && (b & 15) || value[i+3] === '=' && value[i+2] !== '=' && (c & 3)) { return null; }
    out.push((a << 2) | (b >> 4));
    if (value[i+2] !== '=') { out.push(((b & 15) << 4) | (c >> 2)); }
    if (value[i+3] !== '=') { out.push(((c & 3) << 6) | d); }
  }
  return out.length <= max ? out : null;
}
// The source bitmap has tightly packed rows; the existing watch packet uses
// four-byte aligned rows. Do not assume that every source returns a 24px square.
function bitmapOf(shape,image,maxSize) {
  maxSize=maxSize || 24;
  if (!object(shape) || !Number.isInteger(shape.width) || !Number.isInteger(shape.height) ||
      shape.width<1 || shape.width>maxSize || shape.height<1 || shape.height>maxSize) { return null; }
  var palette=bytesOf(shape.palette,16), source=bytesOf(shape.pixels,Math.ceil(maxSize/2)*maxSize);
  var sourceStride=Math.ceil(shape.width/2), stride=((shape.width+7)>>3)*4;
  if (!palette || !palette.length || !source || source.length !== sourceStride*shape.height) { return null; }
  var pixels=[];
  for (var i=0; i<stride*shape.height; i++) { pixels.push(0); }
  for (var y=0; y<shape.height; y++) {
    for (var x=0; x<shape.width; x++) {
      var pair=source[y*sourceStride+(x>>1)], value=x&1 ? pair&15 : pair>>4;
      if (value>=palette.length) { return null; }
      pixels[y*stride+(x>>1)] |= x&1 ? value : value<<4;
    }
  }
  return {width:shape.width,height:shape.height,palette:palette,pixels:pixels,image:image};
}
function pictureOf(property,maxSize) {
  return object(property) ? bitmapOf(property.image,true,maxSize) || bitmapOf(property.icon,false,maxSize) : null;
}
function activityImage(bitmap) {
  if (!bitmap) { return undefined; }
  var pixels=[],stride=((bitmap.width+7)>>3)*4,row=Math.ceil(bitmap.width/2);
  for (var y=0;y<bitmap.height;y++) { pixels=pixels.concat(bitmap.pixels.slice(y*stride,y*stride+row)); }
  return {width:bitmap.width,height:bitmap.height,palette:bitmap.palette.slice(),pixels:pixels};
}
function keyOf(instance) {
  return object(instance) && typeof instance.instanceId === 'string' && instance.instanceId.length>0 &&
    instance.instanceId.length<=1024 && !/[\x00-\x1f\x7f]/.test(instance.instanceId) ? instance.instanceId : null;
}
function filterNames(value) {
  return (typeof value === 'string' ? value.slice(0,2048) : '').split(',').map(function(name) {
    return name.trim().toLowerCase();
  }).filter(function(name,index,names) { return name && names.indexOf(name) === index; }).slice(0,64);
}
function fingerprintOf(instance) {
  var p=instance.properties;
  // Android conversation notifications often reuse the same notification key.
  // Observe their text too, but exclude late artwork or an unchanged redelivery.
  // Keep only bounded text digests in the baseline, rather than retaining bodies.
  var hash=2166136261, second=5381;
  ['app','name','body'].forEach(function(name) {
    var source=textOf(p[name]);
    var value=(source.slice(0,1024)+'\u001f'+source.slice(-1024))
      .replace(/[\x00-\x1f\x7f-\x9f\u00ad\u061c\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/g,' ')
      .replace(/ +/g,' ').trim();
    value=value.length+':'+value+'\u001f';
    for (var i=0; i<value.length; i++) {
      var point=value.charCodeAt(i);
      hash=Math.imul(hash ^ point,16777619);
      second=((second << 5)+second) ^ point;
    }
  });
  return (hash>>>0).toString(16)+':'+(second>>>0).toString(16);
}
function digest(value) {
  var hash=2166136261,second=5381;
  for (var i=0;i<value.length;i++) {
    var point=value.charCodeAt(i);hash=Math.imul(hash ^ point,16777619);second=((second << 5)+second) ^ point;
  }
  return (hash>>>0).toString(16)+':'+(second>>>0).toString(16);
}

/** Ephemeral context only: sends to the watch, never persists or logs content. */
module.exports = function createContext(options) {
  var pebble=options.pebble || {};
  var groups={};
  Object.keys(DEFINITIONS).forEach(function(name) {
    groups[name]={handle:null,generation:0,error:'',hasData:false,receivedAt:null,recovery:null,attempt:0};
  });
  var settings=null;
  var connected=true;
  var stopped=false;
  var available=typeof pebble.subscribeToSource === 'function';
  var records=[null,null,null,null,null];
  var playing=false;
  var pausedUntil=0;
  var musicCard=null, musicRun=0, musicRevision=0, musicIdentity='';
  var baseline=false;
  var notificationIds=Object.create(null);
  var activeNotice=null;
  var noticeMetadata=null, notificationCard=null, notificationRun=0, notificationRevision=0;
  var notificationIdentity='', notificationSignature='';
  var noticeWindowEnd=0, lastNoticeAt=0;
  var burstSequence=0, noticeBurst=0;
  var noticeShownAt=0, pendingNotice=null, noticeUpdateTimer=null;
  var markerNeeded=false, baselineGeneration=0, baselineToken=null;
  var heartbeat=null, expiryTimer=null;
  var pending=false, sending=false, deliveryTimer=null, deliveryGeneration=0;
  var revision=0;

  function now() { return Math.floor(options.now()/1000); }
  function readSettings() {
    var value={};
    try { value=options.getSettings() || {}; } catch (ignored) {}
    return {showMusic:value.showMusic !== false,showNotifications:value.showNotifications === true,
      notificationPreview:value.notificationPreview === true,notificationAppOnly:value.notificationAppOnly === true,
      notificationApps:filterNames(value.notificationApps),
      showStatus:value.showStatus !== false};
  }
  function enabled(name) {
    return settings && (name === 'music' ? settings.showMusic : name === 'phone' ? settings.showStatus : settings.showNotifications);
  }
  function fresh(record) {
    return record && Number.isInteger(record.confirmedAt) && record.confirmedAt>0 && record.confirmedAt<=now() &&
      Number.isInteger(record.validUntil) && now()<record.validUntil && record.validUntil<=MAX_EPOCH;
  }
  function until(envelope, seconds) {
    var end=now()+seconds;
    if (envelope.validUntilMs !== undefined && envelope.validUntilMs !== null) {
      if (!finite(envelope.validUntilMs)) { return 0; }
      end=Math.min(end,Math.floor(envelope.validUntilMs/1000));
    }
    return end>now() && end<=MAX_EPOCH ? end : 0;
  }
  function record(text, bitmap, end, semantic) {
    text=clean(text);
    return (text || bitmap) && end>now() ? {status:2,text:text,bitmap:bitmap || undefined,
      confirmedAt:now(),validUntil:end,semantic:semantic} : null;
  }
  function clearNotice() {
    records[2]=records[3]=null;
    activeNotice=null;
    noticeMetadata=notificationCard=null;
    pendingNotice=null; noticeShownAt=0;
    if (noticeUpdateTimer !== null) { options.cancelLater(noticeUpdateTimer); noticeUpdateTimer=null; }
  }
  function clearGroup(name) {
    if (name === 'music') { records[0]=records[1]=null; playing=false; pausedUntil=0; musicCard=null; musicIdentity=''; }
    else if (name === 'phone') { records[4]=null; }
    else { clearNotice(); baseline=false; notificationIds=Object.create(null); noticeWindowEnd=lastNoticeAt=noticeBurst=0; }
  }
  function markBaseline(token, replaceToken) {
    if (replaceToken) {
      var nextToken=tokenOf(token);
      if (nextToken !== baselineToken) { burstSequence=0; }
      baselineToken=nextToken;
    }
    baselineGeneration++;
    markerNeeded=true;
    clearGroup('notifications');
    groups.notifications.hasData=false;
  }
  function currentSlots() {
    return records.map(function(value,i) {
      if (fresh(value)) { return value; }
      if (value) { records[i]=null; }
      return null;
    });
  }
  function payload() {
    var result={};
    var slots=currentSlots();
    // Opt-in hosts render this same ephemeral record in their activity slots.
    // Do not let the compatibility footer defeat their hide/order preferences.
    if (options.musicAsActivity === true && musicActivity()) { slots[0]=slots[1]=null; }
    if (options.notificationAsActivity === true) { slots[2]=slots[3]=null; }
    if (markerNeeded) {
      // A boundary may itself have been queued before a second reconnect.
      // Boundaries never contain private notification data. A fresh notice is
      // sent only after this baseline's boundary has actually been acknowledged.
      slots[2]=slots[3]=null;
      // Startup may precede the watch's unique launch/reconnect token. An old
      // token must never open that native notification gate, so wait for it.
      if (baselineToken !== null && options.keys.REQUEST_CONTEXT !== undefined) {
        result[options.keys.REQUEST_CONTEXT]=baselineToken;
      }
    }
    result[options.keys.CONTEXT_DATA]=wire.packComplications(slots,now());
    if (options.keys.CONTEXT_STATE !== undefined) {
      // This sidecar travels atomically with its snapshot. It contains no
      // provider identity or content, and is never persisted. The native host
      // must check the session and notification gate before acting on it.
      var notice=options.notificationAsActivity === true ? notificationActivity() : null;
      var session=baselineToken || 0, event=!markerNeeded && (notice || slots[2]) ? noticeBurst : 0;
      var state=[0,0,0,0,0,0,0,0,slots[0] && !playing ? 1 : 0];
      for (var i=0; i<4; i++) { state[i]=(session >>> (i*8)) & 255; state[i+4]=(event >>> (i*8)) & 255; }
      // Opt-in hosts no longer receive notification slots. Preserve the original
      // deadline beside the event so a delayed queue cannot vibrate after expiry.
      if (options.notificationAsActivity === true) {
        var expiry=notice ? notice.validUntil : 0;
        for (i=0;i<4;i++) { state[9+i]=(expiry >>> (i*8)) & 255; }
      }
      result[options.keys.CONTEXT_STATE]=state;
    }
    return result;
  }
  function cancelDelivery() {
    deliveryGeneration++;
    if (deliveryTimer !== null) { options.cancelLater(deliveryTimer); }
    deliveryTimer=null; sending=false; pending=false;
  }
  function pump() {
    if (stopped || !connected || sending || !pending) { return; }
    pending=false; sending=true;
    var generation=deliveryGeneration;
    function attempt(number) {
      if (generation !== deliveryGeneration || stopped || !connected) { return; }
      var sentRevision=revision, sentBaselineGeneration=baselineGeneration, sentToken=baselineToken;
      var sentMarker=markerNeeded && sentToken !== null && options.keys.REQUEST_CONTEXT !== undefined, done=false;
      function finish(ok,error) {
        if (done || generation !== deliveryGeneration) { return; }
        done=true;
        // Only this baseline's acknowledged boundary can release its marker.
        // A packet copied into the shared queue before reconnect cannot do so.
        if (ok && sentMarker && sentBaselineGeneration === baselineGeneration && sentToken === baselineToken) {
          markerNeeded=false;
          if (fresh(records[2])) { pending=true; }
          if (options.notificationAsActivity === true) { notify(); }
        }
        if (deliveryTimer !== null) { options.cancelLater(deliveryTimer); }
        deliveryTimer=null;
        if (!ok && (!error || error.code !== 'SUPERSEDED') && !pending && revision === sentRevision && number<3) {
          deliveryTimer=options.later(function() { deliveryTimer=null; attempt(number+1); },number*1000);
          return;
        }
        sending=false;
        pump();
      }
      // The shared transport can wait behind another bounded transfer. Its
      // own watchdog owns a stuck native send; leave room for that queue here.
      deliveryTimer=options.later(function() { finish(false); },45000);
      try { options.send(payload(),function() { finish(true); },function(error) { finish(false,error); }); }
      catch (ignored) { finish(false); }
    }
    attempt(1);
  }
  function publish() {
    revision++;
    if (options.send.supersedesSnapshots && sending) { cancelDelivery(); }
    pending=true;
    pump();
    scheduleExpiry();
    notify();
  }
  function notify() { if (typeof options.onChanged === 'function') { options.onChanged(); } }
  function musicActivity() {
    if (stopped || !connected || !enabled('music') || !fresh(records[0]) || !musicCard || musicCard.validUntil<=now()) { return null; }
    // Reading a projection never changes the authoritative receipt or revision.
    var result=JSON.parse(JSON.stringify(musicCard));
    result.selectionKey='builtin:music'; result.providerName='Music';
    return result;
  }
  function notificationActivity() {
    if (stopped || !connected || markerNeeded || !enabled('notifications') || !fresh(records[2]) ||
        !notificationCard || notificationCard.validUntil<=now()) { return null; }
    return JSON.parse(JSON.stringify(notificationCard));
  }
  function syncNotificationActivity() {
    if (!noticeMetadata || !noticeMetadata.provider || !fresh(records[2])) { notificationCard=null; return; }
    var identity=digest(JSON.stringify([noticeMetadata.provider,activeNotice,noticeMetadata.burst]));
    var source={provider:noticeMetadata.provider,observedAt:records[2].confirmedAt,validUntil:records[2].validUntil,
      private:true,displayName:'Notifications',record:{id:'notification',type:'standard',icon:activityImage(records[2].bitmap)||'message',
        name:noticeMetadata.appName,headline:{type:'text',text:records[2].text},
        openApp:{watchAppUuid:NOTIFICATIONS_APP_UUID}}};
    if (fresh(records[3])) { source.record.detail={type:'text',text:records[3].text}; }
    // Retain only digests across a redaction, never an earlier body or source ID.
    var signature=digest(JSON.stringify(source));
    if (identity !== notificationIdentity || notificationRevision===MAX_EPOCH) {
      notificationIdentity=identity; notificationRun++; notificationRevision=0; notificationSignature='';
    }
    if (signature !== notificationSignature) { notificationRevision++; notificationSignature=signature; }
    source.revision=notificationRevision; source.record.id='legacy-notification-'+notificationRun;
    notificationCard=summary.toView(source);
    if (notificationCard) { notificationCard.selectionKey='builtin:notifications'; }
  }
  function activateNotice(next) {
    records[2]=next.title; records[3]=next.body; activeNotice=next.id;
    noticeMetadata={provider:next.provider,appName:next.appName,burst:next.burst};
    noticeShownAt=options.now(); syncNotificationActivity();
  }
  function scheduleExpiry() {
    if (expiryTimer !== null) { options.cancelLater(expiryTimer); }
    expiryTimer=null;
    var end=Infinity;
    records.forEach(function(value) { if (fresh(value)) { end=Math.min(end,value.validUntil); } });
    if (pendingNotice && fresh(pendingNotice.title)) { end=Math.min(end,pendingNotice.title.validUntil); }
    if (end !== Infinity && !stopped) {
      expiryTimer=options.later(function() {
        expiryTimer=null;
        if (!fresh(records[2])) { clearNotice(); }
        if (pendingNotice && !fresh(pendingNotice.title)) {
          pendingNotice=null;
          if (noticeUpdateTimer !== null) { options.cancelLater(noticeUpdateTimer); noticeUpdateTimer=null; }
        }
        currentSlots(); publish();
      },Math.max(1,end*1000-options.now()));
    }
  }
  function cancelRecovery(name, reset) {
    var group=groups[name];
    if (group.recovery !== null) { options.cancelLater(group.recovery); }
    group.recovery=null;
    if (reset) { group.attempt=0; }
  }
  function recover(name) {
    var group=groups[name];
    if (stopped || !connected || !enabled(name) || !available ||
        ['PLUGIN_UNAVAILABLE','TIMEOUT','UNKNOWN'].indexOf(group.error)<0) { cancelRecovery(name,true); return; }
    if (group.recovery !== null) { return; }
    var generation=group.generation;
    group.recovery=options.later(function() {
      group.recovery=null;
      if (generation !== group.generation || stopped || !connected || !enabled(name)) { return; }
      group.attempt=Math.min(group.attempt+1,3);
      bind(name); recover(name);
    },[5000,15000,60000,120000][group.attempt]);
  }
  function sourceError(name,error) {
    groups[name].error=codeOf(error);
    groups[name].hasData=false;
    clearGroup(name);
    publish(); recover(name);
  }
  function sourceData(name,envelope) {
    if (!object(envelope) || !Array.isArray(envelope.instances) || envelope.instances.length>512) {
      sourceError(name,{code:'INVALID_DATA'}); return;
    }
    groups[name].error=''; groups[name].hasData=true; cancelRecovery(name,true);
    var valid;
    if (name === 'music') { valid=musicData(envelope); }
    else if (name === 'phone') { valid=phoneData(envelope); }
    else { valid=notificationData(envelope); }
    if (valid === false) { sourceError(name,{code:'INVALID_DATA'}); return; }
    groups[name].receivedAt=now();
    if (valid !== 'deferred') { publish(); }
  }
  function musicData(envelope) {
    if (!envelope.instances.length) { clearGroup('music'); return; }
    var instance=envelope.instances[0], p=object(instance) && instance.properties;
    var isPlaying=object(p) && object(p.playing) && object(p.playing.boolean) ? p.playing.boolean.value : null;
    var title=object(p) ? clean(textOf(p.title)) : '';
    var end=until(envelope,LEASE);
    if (typeof isPlaying !== 'boolean' || !title || !end) { return false; }
    if (isPlaying) { playing=true; pausedUntil=0; }
    else {
      if (playing) { pausedUntil=now()+PAUSED_GRACE; }
      playing=false;
      if (!pausedUntil || now()>=pausedUntil) { clearGroup('music'); return; }
      end=Math.min(end,pausedUntil);
    }
    records[0]=record(title,pictureOf(p.artwork,40),end,{kind:KIND.GENERIC,source:SOURCE.MUSIC});
    records[1]=record(textOf(p.artist),null,end,{kind:KIND.GENERIC,source:SOURCE.MUSIC});
    var provider=envelope.pluginUuid===undefined?MUSIC_ADAPTER_UUID:activityWire.uuid(envelope.pluginUuid)?envelope.pluginUuid:null;
    if (!provider) { musicCard=null; return; }
    var artist=records[1] ? records[1].text : '', identity=JSON.stringify([provider,keyOf(instance),title,artist]);
    if (identity !== musicIdentity || musicRevision===MAX_EPOCH) { musicIdentity=identity; musicRun++; musicRevision=0; }
    musicRevision++;
    var image=activityImage(records[0].bitmap);
    // Missing optional metadata contributes no label or placeholder row.
    var detail=/^(?:\?|unknown|unknown artist)$/i.test(artist.trim())?'':artist;
    musicCard=activity.toView({provider:provider,id:'legacy-music-'+musicRun,kind:'music',revision:musicRevision,
      state:playing?'active':'paused',observedAt:records[0].confirmedAt,validUntil:end,private:true,appName:'Music',
      content:title,detail:detail||null,image:image});
  }
  function phoneData(envelope) {
    if (!envelope.instances.length) { records[4]=null; return; }
    var instance=envelope.instances[0], p=object(instance) && instance.properties;
    var property=object(p) && p.battery_level;
    var numeric=object(property) && property.numericValue;
    var level=object(numeric) && numeric.value;
    var end=until(envelope,LEASE);
    if (!object(p) || property !== undefined && (!object(numeric) || !finite(level) || level<0 || level>100 ||
        numeric.unit !== undefined && numeric.unit !== '%') || !end) { return false; }
    records[4]=finite(level) && level>=0 && level<=15 &&
      (numeric.unit === undefined || numeric.unit === '%') && end ? record(Math.round(level)+'%',null,end,
        {kind:KIND.BATTERY,source:SOURCE.PHONE,detail:wire.DETAIL_KIND.PHONE_BATTERY,value:level,min:0,max:100,unit:'%'}) : null;
  }
  function notificationContent(instance) {
    var p=object(instance) && instance.properties;
    if (!object(p)) { return null; }
    var app=textOf(p.app), packageName=textOf(p.package);
    var allowed=!settings.notificationApps.length || settings.notificationApps.indexOf(app.trim().toLowerCase())>=0 ||
      settings.notificationApps.indexOf(packageName.trim().toLowerCase())>=0;
    var title=clean(textOf(p.name)), appTitle=wire.normalizeText(clean(app),24);
    var heading=settings.notificationAppOnly ? clean(app) || clean(packageName) : title || clean(app);
    if (!allowed || !heading) { return null; }
    return {title:title,appTitle:appTitle,
      appName:settings.notificationAppOnly || heading===clean(app) ? 'Notifications' :
        wire.normalizeText(clean(app)||clean(packageName)||'Notifications',64),heading:heading,
      body:settings.notificationPreview && !settings.notificationAppOnly ? clean(textOf(p.body)) : ''};
  }
  function notificationData(envelope) {
    var incoming=Object.create(null), candidates=[], activeInstance=null, pendingInstance=null, deferred=false, changed=false;
    var provider=envelope.pluginUuid===undefined?NOTIFICATION_ADAPTER_UUID:activityWire.uuid(envelope.pluginUuid)?envelope.pluginUuid:null;
    envelope.instances.forEach(function(instance) {
      var id=keyOf(instance);
      if (id === null || incoming[id]) { return; }
      incoming[id]=object(instance.properties) ? fingerprintOf(instance) : 'invalid';
      if (id === activeNotice) { activeInstance=instance; }
      if (pendingNotice && id === pendingNotice.id) { pendingInstance=instance; }
      if (baseline && notificationIds[id] !== incoming[id] && object(instance.properties)) { candidates.push(instance); }
    });
    if (envelope.instances.length && !Object.keys(incoming).length) { return false; }
    // A retained source ID does not mean its earlier private content is still
    // available. Full redaction, malformed properties and a newly excluded app
    // must clear both visible and queued text before the stable-reading delay.
    if (activeNotice && !notificationContent(activeInstance)) { clearNotice(); }
    if (pendingNotice && !notificationContent(pendingInstance)) {
      pendingNotice=null;
      if (noticeUpdateTimer !== null) { options.cancelLater(noticeUpdateTimer); noticeUpdateTimer=null; }
    }
    // Late artwork is not a new notice and must not renew its original lease.
    if (activeInstance && fresh(records[2]) && notificationIds[activeNotice] === incoming[activeNotice]) {
      var refreshedIcon=pictureOf(activeInstance.properties.app_icon,24);
      if (refreshedIcon) { records[2].bitmap=refreshedIcon; }
      if (noticeMetadata) { noticeMetadata.provider=provider; }
    }
    // First delivery is a snapshot of the existing phone shade, not a new
    // notification. Reconnects, errors and settings changes establish it again.
    notificationIds=incoming;
    if (!baseline) { baseline=true; return; }
    var availableEnd=until(envelope,NOTICE_MESSAGE_LIFE);
    if (!availableEnd) { clearNotice(); return; }
    // An unchanged redelivery may shorten the authoritative source lease. Cap
    // visible AND queued text without changing its original observation time.
    function cap(record) {
      if (record && record.validUntil>availableEnd) { record.validUntil=availableEnd; changed=true; }
    }
    cap(records[2]); cap(records[3]);
    if (pendingNotice) { cap(pendingNotice.title); cap(pendingNotice.body); }
    if (noticeWindowEnd>availableEnd) { noticeWindowEnd=availableEnd; }
    for (var i=0; i<candidates.length; i++) {
      var instance=candidates[i], p=instance.properties;
      var content=notificationContent(instance);
      if (!content) { continue; }
      var title=content.title, appTitle=content.appTitle, heading=content.heading, body=content.body;
      var lifetime=options.notificationAsActivity === true || body ? NOTICE_MESSAGE_LIFE : NOTICE_SUMMARY_LIFE;
      var end=Math.min(availableEnd,now()+lifetime);
      var received=now();
      if (received>=noticeWindowEnd) {
        var quiet=lastNoticeAt === 0 || received-lastNoticeAt>=NOTICE_QUIET;
        lastNoticeAt=received;
        // A continuous burst gets one bounded interruption, not another
        // lifetime on every message. New arrivals still advance the baseline,
        // and a later independent burst can start after a short quiet gap.
        if (!quiet) { break; }
        noticeWindowEnd=end;
        burstSequence=(burstSequence+1)>>>0 || 1;
        noticeBurst=burstSequence;
      } else { lastNoticeAt=received; }
      end=Math.min(end,noticeWindowEnd);
      var next={id:keyOf(instance),provider:provider,appName:content.appName,burst:noticeBurst,title:record(heading,pictureOf(p.app_icon,24),end,
        {kind:KIND.GENERIC,source:SOURCE.NOTIFICATION,label:settings.notificationAppOnly ? '' : appTitle}),
        body:body ? record(body,null,end,{kind:KIND.GENERIC,source:SOURCE.NOTIFICATION}) : null};
      // A stable reading interval must never postpone a source redaction.
      var removesPrivateText=fresh(records[3]) && !next.body ||
        !title && fresh(records[2]) && records[2].text !== heading;
      if (!removesPrivateText && fresh(records[2]) && options.now()<noticeShownAt+NOTICE_STABLE_MS) {
        pendingNotice=next; deferred=true;
        if (noticeUpdateTimer === null) {
          noticeUpdateTimer=options.later(function() {
            noticeUpdateTimer=null;
            var pending=pendingNotice; pendingNotice=null;
            if (!pending || stopped || !connected || !baseline || !enabled('notifications') || !fresh(pending.title)) { return; }
            activateNotice(pending); publish();
          },Math.max(1,noticeShownAt+NOTICE_STABLE_MS-options.now()));
        }
      } else {
        if (noticeUpdateTimer !== null) { options.cancelLater(noticeUpdateTimer); noticeUpdateTimer=null; }
        pendingNotice=null;
        activateNotice(next);
      }
      break; // The native source orders instances newest first.
    }
    syncNotificationActivity();
    return deferred && !changed ? 'deferred' : undefined;
  }
  function close(name) {
    var group=groups[name];
    group.generation++;
    if (group.handle && typeof group.handle.unsubscribe === 'function') {
      try { group.handle.unsubscribe(); } catch (ignored) {}
    }
    group.handle=null;
    cancelRecovery(name,false);
  }
  function updateAvailability() {
    var current=typeof pebble.subscribeToSource === 'function';
    if (current === available) { return false; }
    available=current;
    markBaseline();
    // The phone can enable or disable the preview API while PKJS remains
    // loaded. Neither old handles nor an old notification baseline survive it.
    Object.keys(groups).forEach(function(name) {
      close(name); clearGroup(name);
      groups[name].error=''; groups[name].hasData=false; groups[name].receivedAt=null; groups[name].attempt=0;
    });
    return true;
  }
  function bind(name) {
    close(name);
    if (!connected || stopped || !available || !enabled(name)) { return; }
    var group=groups[name], generation=group.generation, definition=DEFINITIONS[name];
    var request={category:definition.category,item:definition.item,properties:definition.properties.slice(),
      onData:function(envelope) { if (generation === group.generation && !stopped && connected) { sourceData(name,envelope); } },
      onError:function(error) { if (generation === group.generation && !stopped && connected) { sourceError(name,error); } }};
    if (name !== 'phone') { request.iconPixelSize=name === 'music' ? {w:40,h:40} : {w:24,h:24}; }
    try {
      var handle=pebble.subscribeToSource(request);
      if (generation === group.generation && !stopped && connected) { group.handle=handle; }
      else if (handle && typeof handle.unsubscribe === 'function') { handle.unsubscribe(); }
    } catch (error) { if (generation === group.generation) { sourceError(name,error); } }
  }
  function scheduleHeartbeat() {
    if (heartbeat !== null) { options.cancelLater(heartbeat); }
    heartbeat=null;
    if (!stopped && connected && available && (enabled('music') || enabled('phone'))) {
      heartbeat=options.later(function() {
        heartbeat=null;
        // Native sources expose current state immediately on subscription.
        // Rebinding renews a lease only when that authoritative delivery occurs.
        var changed=updateAvailability();
        if (enabled('music')) { bind('music'); }
        if (enabled('phone')) { bind('phone'); }
        if (changed && available && enabled('notifications')) { bind('notifications'); }
        if (changed) { publish(); }
        scheduleHeartbeat();
      },HEARTBEAT);
    }
  }
  function configure() {
    if (stopped) { return; }
    var availabilityChanged=updateAvailability();
    var previous=settings;
    settings=readSettings();
    Object.keys(groups).forEach(function(name) {
      var changed=availabilityChanged || !previous || name === 'music' && previous.showMusic !== settings.showMusic ||
        name === 'phone' && previous.showStatus !== settings.showStatus || name === 'notifications' &&
        (previous.showNotifications !== settings.showNotifications || previous.notificationPreview !== settings.notificationPreview ||
          previous.notificationAppOnly !== settings.notificationAppOnly ||
          JSON.stringify(previous.notificationApps) !== JSON.stringify(settings.notificationApps));
      if (changed) { clearGroup(name); groups[name].error=''; groups[name].hasData=false; groups[name].receivedAt=null; groups[name].attempt=0; bind(name); }
    });
    publish(); scheduleHeartbeat();
  }
  function refresh(rebaseline, token) {
    if (stopped) { return; }
    // Set the boundary before configure/bind can synchronously publish data.
    if (rebaseline) { markBaseline(token,true); }
    if (!settings) { configure(); return; }
    updateAvailability();
    if (rebaseline) { bind('notifications'); }
    else if (enabled('notifications') && !groups.notifications.handle) { bind('notifications'); }
    if (enabled('music')) { bind('music'); }
    if (enabled('phone')) { bind('phone'); }
    publish(); scheduleHeartbeat();
  }
  function connectionChanged(value, token) {
    if (stopped || typeof value !== 'boolean') { return; }
    if (!value) {
      connected=false;
      baselineToken=null;
      Object.keys(groups).forEach(function(name) { close(name); clearGroup(name); groups[name].error=''; groups[name].hasData=false; groups[name].receivedAt=null; groups[name].attempt=0; });
      cancelDelivery();
      if (heartbeat !== null) { options.cancelLater(heartbeat); }
      if (expiryTimer !== null) { options.cancelLater(expiryTimer); }
      heartbeat=expiryTimer=null;
      notify();
    } else { connected=true; refresh(true,token); }
  }
  return {refresh:refresh,configure:configure,connectionChanged:connectionChanged,musicActivity:musicActivity,notificationActivity:notificationActivity,
    musicProvider:function(){var card=musicActivity();return card?{uuid:card.provider,name:'Music',item:'track',available:true}:null;},
    notificationProvider:function(){var card=notificationActivity();return card?{uuid:card.provider,name:'Notifications',item:'notification',available:true}:null;},
    status:function() {
      var sources={}, sourceStates={}, error='';
      Object.keys(groups).forEach(function(name) { sources[name]=groups[name].error; });
      Object.keys(groups).some(function(name) { if (enabled(name) && groups[name].error) { error=groups[name].error; return true; } return false; });
      if (!available && Object.keys(groups).some(enabled)) { error='API_UNAVAILABLE'; }
      var ready=!!settings && connected && (available || !Object.keys(groups).some(enabled)) &&
        Object.keys(groups).every(function(name) { return !enabled(name) || groups[name].hasData; });
      Object.keys(groups).forEach(function(name) {
        var group=groups[name], state='ready', message=group.error;
        if (!enabled(name)) { state='off'; message=''; }
        else if (!connected || !available) { state='unavailable'; message=!connected ? 'DISCONNECTED' : 'API_UNAVAILABLE'; }
        else if (group.error) { state=group.error === 'PERMISSION_DENIED' ? 'denied' : 'unavailable'; }
        else if (!group.hasData) { state='waiting'; }
        else if (name === 'music') {
          if (fresh(records[0])) { state=playing ? 'playing' : 'paused'; }
          else if (playing) { state='unavailable'; message='SOURCE_EXPIRED'; }
          else { state='idle'; }
        } else if (name === 'phone' && group.receivedAt !== null && now()-group.receivedAt>=LEASE) {
          state='unavailable'; message='SOURCE_EXPIRED';
        } else if (name === 'notifications' && !fresh(records[2])) { state='idle'; }
        sourceStates[name]={state:state,message:message,receivedAt:group.receivedAt,
          receivedAgeSec:group.receivedAt === null ? null : Math.max(0,now()-group.receivedAt),
          observedAt:null,observationAgeSec:null};
      });
      return {available:available,connected:connected,ready:ready,error:error,music:!!fresh(records[0]),notification:!!fresh(records[2]),
        phoneBattery:!!fresh(records[4]),sources:sources,sourceStates:sourceStates};
    },
    stop:function() {
      Object.keys(groups).forEach(function(name) { close(name); clearGroup(name); });
      stopped=true; cancelDelivery();
      if (heartbeat !== null) { options.cancelLater(heartbeat); }
      if (expiryTimer !== null) { options.cancelLater(expiryTimer); }
      heartbeat=expiryTimer=null;
      notify();
    }};
};

},
function(module,exports,require){
'use strict';

var VERSION = 4;
var HEADER_BYTES = 56;
var SEMANTIC_KIND = {GENERIC:0,TEMPERATURE:1,PRECIPITATION:2,BATTERY:3,HUMIDITY:4,WIND:5,UV:6,CONDITION:7,RANGE:8,NUMBER:9,BOOLEAN:10,TIMESTAMP:11};
var SOURCE_KIND = {GENERIC:0,WEATHER:1,PHONE:2,MUSIC:3,NOTIFICATION:4,OTHER:5};
var DETAIL_KIND = {NONE:0,TEMPERATURE:1,FEELS_LIKE:2,HIGH:3,LOW:4,PRECIPITATION:5,HUMIDITY:6,WIND_SPEED:7,WIND_DIRECTION:8,UV:9,CONDITION:10,PHONE_BATTERY:11};
var QUALIFIERS = {FORECAST:1};
var DETAIL_SEMANTIC = [0,1,1,1,1,2,4,5,5,6,7,3];
var SLOT_COUNT = 5;
var TEXT = 1;
var BITMAP = 2;
var IMAGE = 4;
var TIMESTAMP = 8;
var EMPTY = 0;
var READY = 2;
var UNAVAILABLE = 3;
var UNSUPPORTED = 5;
var EXPIRED = 7;
var MAX_EPOCH = 4294967295;
var MAX_AGE = 7200;
var MAX_TEXT_BYTES = 128;

function object(value) { return value && typeof value === 'object' && !Array.isArray(value); }
function integer(value, minimum, maximum) {
  return typeof value === 'number' && isFinite(value) && value >= minimum &&
    value <= maximum && Math.floor(value) === value;
}
function bytes(value) {
  return Array.isArray(value) || Object.prototype.toString.call(value) === '[object Uint8Array]';
}
function byteArray(value, length) {
  if (!bytes(value) || value.length !== length) { return false; }
  for (var i = 0; i < length; i++) { if (!integer(value[i], 0, 255)) { return false; } }
  return true;
}
function scalar(text, at) {
  var first = text.charCodeAt(at);
  if (first >= 0xD800 && first <= 0xDBFF) {
    var second = text.charCodeAt(at + 1);
    if (second >= 0xDC00 && second <= 0xDFFF) {
      return {value:0x10000 + (first - 0xD800) * 1024 + second - 0xDC00, length:2};
    }
    return {value:0xFFFD, length:1};
  }
  return {value:first >= 0xDC00 && first <= 0xDFFF ? 0xFFFD : first, length:1};
}
function scalarText(value) {
  if (value <= 0xFFFF) { return String.fromCharCode(value); }
  value -= 0x10000;
  return String.fromCharCode(0xD800 + Math.floor(value / 1024), 0xDC00 + value % 1024);
}
function utf8Length(value) { return value < 0x80 ? 1 : value < 0x800 ? 2 : value < 0x10000 ? 3 : 4; }

// The native decoder rejects control characters. Keep ordinary word boundaries
// when sanitizing them, repair orphan surrogates and truncate only whole UTF-8
// scalars, reserving an ellipsis when content exceeds the byte limit. The
// bounded returned string is also suitable for coordinator storage and replay.
function normalizeText(value, maxBytes) {
  maxBytes = integer(maxBytes, 3, MAX_TEXT_BYTES) ? maxBytes : MAX_TEXT_BYTES;
  if (typeof value !== 'string') { return ''; }
  var result = '';
  var ellipsisPrefix = '';
  var count = 0;
  var pendingSpace = false;
  for (var i = 0; i < value.length;) {
    var next = scalar(value, i);
    i += next.length;
    var code = next.value;
    if (code < 0x20 || (code >= 0x7F && code <= 0x9F) || code === 0x2028 || code === 0x2029) { code = 0x20; }
    // Defer spaces until another scalar arrives: trailing controls or spaces
    // alone do not make an otherwise fitting string require an ellipsis.
    if (code === 0x20) { pendingSpace = result.length > 0; continue; }
    var length = utf8Length(code) + (pendingSpace ? 1 : 0);
    if (count + length > maxBytes) { return ellipsisPrefix + '\u2026'; }
    result += (pendingSpace ? ' ' : '') + scalarText(code);
    count += length;
    pendingSpace = false;
    if (count <= maxBytes - 3) { ellipsisPrefix = result; }
  }
  return result;
}
function utf8(text) {
  var out = [];
  for (var i = 0; i < text.length;) {
    var next = scalar(text, i);
    var code = next.value;
    i += next.length;
    if (code < 0x80) { out.push(code); }
    else if (code < 0x800) { out.push(0xC0 | (code >> 6), 0x80 | (code & 63)); }
    else if (code < 0x10000) { out.push(0xE0 | (code >> 12), 0x80 | ((code >> 6) & 63), 0x80 | (code & 63)); }
    else { out.push(0xF0 | (code >> 18), 0x80 | ((code >> 12) & 63), 0x80 | ((code >> 6) & 63), 0x80 | (code & 63)); }
  }
  return out;
}
function u16(out, at, value) { out[at] = value & 255; out[at + 1] = Math.floor(value / 256) & 255; }
function u32(out, at, value) {
  for (var i = 0; i < 4; i++) { out[at + i] = Math.floor(value / Math.pow(256, i)) % 256; }
}
function crc16Xmodem(value) {
  var crc = 0;
  for (var i = 0; i < value.length; i++) {
    crc ^= value[i] << 8;
    for (var bit = 0; bit < 8; bit++) { crc = ((crc << 1) ^ (crc & 0x8000 ? 0x1021 : 0)) & 0xFFFF; }
  }
  return crc;
}
function statusRecord(status, headerBytes) {
  headerBytes = headerBytes || HEADER_BYTES;
  var result = [];
  for (var i = 0; i < headerBytes; i++) { result.push(0); }
  result[1] = status;
  return result;
}
function bitmapOf(value, maxSize) {
  maxSize = maxSize || 40;
  if (!object(value) || !integer(value.width, 1, maxSize) || !integer(value.height, 1, maxSize) ||
      !bytes(value.palette) || !integer(value.palette.length, 1, 16)) { return null; }
  var stride = ((value.width + 7) >> 3) * 4;
  var count = stride * value.height;
  if (!byteArray(value.palette, value.palette.length) || !byteArray(value.pixels, count)) { return null; }
  // The original palette length matters before padding to the 16-byte wire
  // palette. Ignore row padding and the unused low nibble of odd-width rows.
  for (var y = 0; y < value.height; y++) {
    for (var x = 0; x < value.width; x++) {
      var pair = value.pixels[y * stride + (x >> 1)];
      var index = x & 1 ? pair & 15 : pair >> 4;
      if (index >= value.palette.length) { return null; }
    }
  }
  var palette = [];
  for (var i = 0; i < 16; i++) { palette.push(i < value.palette.length ? value.palette[i] : 0); }
  return {width:value.width, height:value.height, palette:palette,
    pixels:Array.prototype.slice.call(value.pixels), image:value.image === true};
}
function f64(out, at, value) {
  var buffer = new ArrayBuffer(8), view = new DataView(buffer);
  view.setFloat64(0, value, true);
  for (var i = 0; i < 8; ++i) { out[at + i] = view.getUint8(i); }
}
function semanticOf(slot, version, identityOnly) {
  var value = slot.semantic;
  if (!object(value)) { return null; }
  var kind = value.kind === undefined ? 0 : value.kind;
  var source = value.source === undefined ? 0 : value.source;
  if (!integer(kind, 0, 11) || !integer(source, 0, 5)) { return null; }
  var result = {kind:kind,source:source,flags:0,unit:[],label:[],detail:0,qualifiers:0,observedAt:0};
  if (version === 4) {
    var detail = value.detail === undefined ? 0 : value.detail;
    var qualifiers = value.qualifiers === undefined ? 0 : value.qualifiers;
    var observedAt = identityOnly || value.observedAt === undefined ? 0 : value.observedAt;
    if (!integer(detail,0,11) || detail && DETAIL_SEMANTIC[detail] !== kind &&
        !(detail === DETAIL_KIND.PRECIPITATION && (kind === SEMANTIC_KIND.GENERIC || kind === SEMANTIC_KIND.NUMBER)) ||
        !integer(qualifiers,0,1) || qualifiers && source !== SOURCE_KIND.WEATHER ||
        !integer(observedAt,0,MAX_EPOCH) || observedAt &&
          (observedAt > slot.confirmedAt || qualifiers & QUALIFIERS.FORECAST)) { return null; }
    result.detail=detail; result.qualifiers=qualifiers; result.observedAt=observedAt;
  }
  var fields = ['value','min','max'];
  for (var i = 0; i < fields.length; ++i) {
    if (!identityOnly && value[fields[i]] !== undefined) {
      var numeric = value[fields[i]];
      if (typeof numeric !== 'number' || !isFinite(numeric)) { return null; }
      result[fields[i]] = numeric; result.flags |= 1 << i;
    }
  }
  if ((result.flags & 6) === 6 && result.min > result.max) { return null; }
  if (value.unit !== undefined) {
    if (typeof value.unit !== 'string') { return null; }
    result.unit = utf8(normalizeText(value.unit));
    // A shortened unit could change its meaning. Omit invalid optional metadata.
    if (result.unit.length > 16) { return null; }
  }
  if (value.label !== undefined) {
    if (typeof value.label !== 'string') { return null; }
    result.label = utf8(normalizeText(value.label,24));
  }
  return result;
}

function unavailableRecord(slot,status,version,header) {
  if (version !== 4 || status === EMPTY) { return statusRecord(status === EXPIRED ? UNAVAILABLE : status,header); }
  var metadata=semanticOf(slot,version,true), out=statusRecord(status,header);
  // Identity may survive a public source failure, but private source names,
  // old content, numbers and observation times never survive this path.
  if (!metadata || metadata.source === SOURCE_KIND.MUSIC || metadata.source === SOURCE_KIND.NOTIFICATION) { return out; }
  out[20]=metadata.kind; out[22]=metadata.unit.length; out[23]=metadata.label.length;
  out[24]=metadata.source; out[25]=metadata.detail; out[26]=metadata.qualifiers;
  return out.concat(metadata.unit,metadata.label);
}
function record(slot, nowSec, version) {
  var header = version === 4 ? HEADER_BYTES : version === 3 ? 52 : 20;
  if (slot === undefined || slot === null) { return statusRecord(EMPTY,header); }
  if (!object(slot) || !integer(slot.status, 0, 7)) { return statusRecord(UNSUPPORTED,header); }
  if (slot.status !== READY) { return unavailableRecord(slot,slot.status,version,header); }
  if (!integer(nowSec, 1, MAX_EPOCH) || !integer(slot.confirmedAt, 1, MAX_EPOCH) ||
      !integer(slot.validUntil, 1, MAX_EPOCH) || slot.confirmedAt > nowSec) { return statusRecord(UNAVAILABLE,header); }
  var until = Math.min(slot.validUntil, slot.confirmedAt + MAX_AGE, MAX_EPOCH);
  if (nowSec >= until) { return unavailableRecord(slot,version === 4 ? EXPIRED : UNAVAILABLE,version,header); }
  var text = utf8(normalizeText(slot.text,version >= 3 ? 128 : 48));
  var event = !text.length && integer(slot.timestamp, 1, MAX_EPOCH) ? slot.timestamp : null;
  var bitmap = bitmapOf(slot.bitmap,version >= 3 ? 40 : 24);
  var flags = (text.length ? TEXT : event !== null ? TIMESTAMP : 0) |
    (bitmap ? BITMAP | (bitmap.image ? IMAGE : 0) : 0);
  if (!flags) { return statusRecord(slot.timestamp === 0 ? UNAVAILABLE : UNSUPPORTED,header); }
  var out = statusRecord(READY,header);
  out[0] = flags;
  out[2] = text.length;
  out[3] = bitmap ? bitmap.width : 0;
  out[4] = bitmap ? bitmap.height : 0;
  // V2 uses the former reserved byte for a provider-aware presentation hint.
  // Generic percentages (battery, humidity) never acquire precipitation art.
  out[5] = version !== 1 && slot.displayKind === 1 && text.length ? 1 : 0;
  u32(out, 6, slot.confirmedAt);
  u32(out, 10, until);
  u16(out, 14, bitmap ? bitmap.pixels.length : 0);
  if (event !== null) { u32(out, 16, event); }
  var semantic = version >= 3 ? semanticOf(slot,version,false) : null;
  if (semantic) {
    out[20] = semantic.kind; out[21] = semantic.flags;
    out[22] = semantic.unit.length; out[23] = semantic.label.length; out[24] = semantic.source;
    if (version === 4) {
      out[25]=semantic.detail; out[26]=semantic.qualifiers; u32(out,52,semantic.observedAt);
    }
    if (semantic.flags & 1) { f64(out,28,semantic.value); }
    if (semantic.flags & 2) { f64(out,36,semantic.min); }
    if (semantic.flags & 4) { f64(out,44,semantic.max); }
  }
  out = out.concat(text,semantic ? semantic.unit : [],semantic ? semantic.label : []);
  if (bitmap) { out = out.concat(bitmap.palette, bitmap.pixels); }
  return out;
}

/** Five fixed slots, including holes. No fetching, cache mutation or inference. */
function packComplications(slots, nowSec, version) {
  version = version === 1 || version === 2 || version === 3 ? version : VERSION;
  var out = [version, 0, 0, 0, 0, 0];
  var values = Array.isArray(slots) ? slots : [];
  for (var i = 0; i < SLOT_COUNT; i++) { out = out.concat(record(values[i], nowSec,version)); }
  u16(out, 2, out.length);
  // CRC bytes stay zero while calculating the checksum over the whole packet.
  u16(out, 4, crc16Xmodem(out));
  return out;
}

module.exports = {packComplications:packComplications, normalizeText:normalizeText, crc16Xmodem:crc16Xmodem, SEMANTIC_KIND:SEMANTIC_KIND, SOURCE_KIND:SOURCE_KIND, DETAIL_KIND:DETAIL_KIND, QUALIFIERS:QUALIFIERS};

},
function(module,exports,require){
'use strict';

var settings=require(2);
var KEY='dynamic-settings-delivery-v1';
var fields=['BACKGROUND_COLOR','TEXT_COLOR','ACCENT_COLOR','NIGHT_BACKGROUND_COLOR','NIGHT_TEXT_COLOR','NIGHT_ACCENT_COLOR','CLOCK_FORMAT','SHOW_STATUS','ANIMATIONS','NOTIFICATION_VIBRATION','TEXT_SIZE','APPEARANCE_MODE','MANUAL_APPEARANCE','SCREEN_SPLIT','READING_LAYOUT','HIDE_READING_TITLES','SHAKE_READINGS','LOWER_BACKGROUND_COLOR','LOWER_TEXT_COLOR','NIGHT_LOWER_BACKGROUND_COLOR','NIGHT_LOWER_TEXT_COLOR'];
function equal(a,b){return JSON.stringify(a)===JSON.stringify(b);}
function values(value){return fields.map(function(key){return Number(value[key]);});}
function valid(v){return Array.isArray(v)&&(v.length===13||v.length===21)&&v.every(function(n,i){return Number.isInteger(n)&&n>=0&&(i<6||i>=17?n<=0xffffff:i===6?[0,12,24].indexOf(n)>=0:i===9||i===11||i===14?n<=2:i===10?n<=3:n<=1);});}
function put(b,at,n){for(var i=0;i<4;i++)b[at+i]=(n>>>(8*i))&255;}
function get(b,at){return (b[at]|b[at+1]<<8|b[at+2]<<16|b[at+3]<<24)>>>0;}
function encode(v,revision,status,hello){var b=[v.length===13?1:2,v.length,status||0,hello?1:0];put(b,4,revision);v.forEach(function(n,i){put(b,8+4*i,n);});return b;}
function decode(input){
  if(!input||input.length!==60&&input.length!==92)return null;
  var b=Array.prototype.slice.call(input);
  if(!b.every(function(n){return Number.isInteger(n)&&n>=0&&n<=255;})||!((b[0]===1&&b[1]===13&&b.length===60)||(b[0]===2&&b[1]===21&&b.length===92))||b[2]>1||b[3]>1)return null;
  var v=fields.slice(0,b[1]).map(function(_,i){return get(b,8+4*i);});
  return valid(v)?{values:v,revision:get(b,4),status:b[2],hello:b[3]===1}:null;
}
function next(n){return ((n+1)>>>0)||1;}
function matches(receipt,record){var r=decode(receipt);return !!r&&!r.status&&r.revision===record.revision&&equal(r.values,record.values);}
function read(storage){
  var desired=settings.read(storage);if(!desired)return null;
  var v=values(desired),record;
  try{record=JSON.parse(storage.getItem(KEY));}catch(ignored){}
  var healthy=!!record&&record.version===2&&Number.isInteger(record.revision)&&record.revision>0&&record.revision<=0xffffffff&&valid(record.values)&&
    (record.applied===null||!!decode(record.applied))&&(record.error===null||typeof record.error==='string');
  if(!healthy)record={version:2,revision:1,values:v,applied:null,error:null};
  var stored=healthy&&equal(record.values,v);
  if(!equal(record.values,v))record={version:2,revision:next(record.revision),values:v,applied:null,error:null};
  return {settings:desired,record:record,stored:stored};
}
function commit(storage,record){try{var text=JSON.stringify(record);storage.setItem(KEY,text);return storage.getItem(KEY)===text;}catch(ignored){return false;}}
function status(storage){
  try{var state=read(storage);if(!state)return {ok:false};
    var applied=state.stored&&matches(state.record.applied,state.record);
    return {ok:true,settings:state.settings,delivery:{applied:applied,pending:!applied,error:state.record.error,state:applied?'saved':!hasNative(storage)?'none':state.record.error?'failed':'pending'}};
  }catch(ignored){return {ok:false};}
}
function hasNative(storage){
  var raw=JSON.parse(storage.getItem('clay-settings')||'{}');
  return fields.concat(['NIGHT_PALETTE','USE_12_HOUR']).some(function(key){return raw[key]!==undefined||raw[10000+settings.names.indexOf(key)]!==undefined||raw[settings.names.indexOf(key)]!==undefined;});
}
function adopt(storage,v){
  var current=settings.read(storage);if(!current)return false;
  fields.slice(0,v.length).forEach(function(key,i){current[key]=typeof settings.defaults[key]==='boolean'?!!v[i]:v[i];});
  current.NIGHT_PALETTE=current.APPEARANCE_MODE===1;
  return settings.save(storage,current).ok;
}
module.exports={key:KEY,fields:fields,values:values,valid:valid,equal:equal,encode:encode,decode:decode,next:next,matches:matches,read:read,commit:commit,status:status,hasNative:hasNative,adopt:adopt};

},
function(module,exports,require){
'use strict';
var state = require(2);
var localization = require(16);
var sourceConfig = require(18);
function html(value) { return String(value).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
function page(settings,language,metadata,systemFormat) {
  var platform = null;
  try { var watch = typeof Pebble !== 'undefined' && typeof Pebble.getActiveWatchInfo === 'function' && Pebble.getActiveWatchInfo();
    if (watch && (watch.platform === 'emery' || watch.platform === 'gabbro')) platform = watch.platform;
  } catch (ignored) {}
  language = localization.resolveLanguage(language,'en');
  var normalized = state.normalize(settings,false);
  if (!normalized) return null;
  var data = metadata || {slots:[{},{}],sources:{},activityProviders:[],save:{state:'none'}};
  data.language = language;
  data.activityPreferences = metadata && metadata.activityPreferences || normalized[state.preferencesKey];
  var config = localization.translateConfig(sourceConfig,language);
  function visit(items) { items.forEach(function(item) {
    if (item.items) visit(item.items);
    if (item.messageKey && normalized[item.messageKey] !== undefined && item.messageKey !== state.preferencesKey) item.defaultValue = normalized[item.messageKey];
    if (item.messageKey === state.preferencesKey) item.defaultValue = JSON.stringify(normalized[state.preferencesKey]);
    if (item.id === 'dynamic-settings-data') item.defaultValue = html(JSON.stringify(data));
    if (item.id === 'dynamic-settings-strings') item.defaultValue = html(JSON.stringify(localization.settingsStrings(language)));
  }); }
  visit(config);
  var values = {}; Object.keys(normalized).forEach(function(key){if(key!==state.preferencesKey)values[key]=normalized[key];});
  return {ok:true,platform:platform,settings:normalized,config:config,values:values,language:language,systemFormat:systemFormat === 12 || systemFormat === 24 ? systemFormat : null};
}
module.exports = page;

},
function(module,exports,require){
'use strict';

// Dynamic settings and source-status framing are translated here.
// Provider names, values and units remain as received from Pebble.
var MESSAGES = {
  "en": {
    "title": "Dynamic Settings",
    "appearance": "Appearance",
    "background": "Background color",
    "textColor": "Text color",
    "time12": "12-hour time",
    "largeText": "Big text",
    "largeTextHelp": "Larger date, readings and messages. The clock fits the available width.",
    "showStatus": "Status indicators",
    "statusIndicatorsHelp": "Low watch or phone battery and lost connection.",
    "complications": "Complications",
    "complicationsHelp": "Choose slots 1 and 2 in Pebble → Settings → Complications.",
    "adaptiveHelp": "Complications 1 and 2 sit side by side. Both shrink above music or notifications.",
    "complicationsUnits": "Units come from Pebble and the selected plugin.",
    "dynamicContent": "Dynamic content",
    "showMusic": "Show music while playing",
    "showNotifications": "New notifications",
    "notificationsHelp": "Allow notification access in Pebble. Only new notifications appear.",
    "notificationPreview": "Include message text",
    "notificationApps": "Apps to show",
    "notificationAppsHelp": "Separate app names with commas. Empty means all allowed apps.",
    "statusHelp": "Status & help",
    "complicationsWaiting": "Complications: waiting for Pebble",
    "contextWaiting": "Dynamic content: waiting for Pebble",
    "adaptivePeek": "Timeline Peek keeps the clock and complications. Its event panel takes priority over music and notifications.",
    "save": "Save settings",
    "complicationsStatus": "Complications: {ready}/{configured} ready",
    "complicationsDisabled": "Enable plugins in Pebble to use complications.",
    "complicationsError": "Complication error: {error}",
    "contextReady": "Dynamic content: ready",
    "contextError": "Dynamic content: {error}",
    "stateOn": "On",
    "stateOff": "Off",
    "accentColor": "Accent color",
    "accentHelp": "Color for reading symbols and rain gauges.",
    "animations": "Animations",
    "animationsHelp": "Short transitions when music or notifications change."
  },
  "cs": {
    "title": "Nastavení Dynamic",
    "appearance": "Vzhled",
    "background": "Barva pozadí",
    "textColor": "Barva textu",
    "time12": "12hodinový čas",
    "largeText": "Velký text",
    "largeTextHelp": "Větší datum, údaje a zprávy. Čas se přizpůsobí dostupné šířce.",
    "showStatus": "Ukazatele stavu",
    "statusIndicatorsHelp": "Slabá baterie hodinek nebo telefonu a ztráta připojení.",
    "complications": "Komplikace",
    "complicationsHelp": "Vyberte pozice 1 a 2 v Pebble → Nastavení → Komplikace.",
    "adaptiveHelp": "Komplikace 1 a 2 jsou vedle sebe. Obě se zmenší nad hudbou nebo oznámením.",
    "complicationsUnits": "Jednotky se přebírají z Pebble a vybraného pluginu.",
    "dynamicContent": "Dynamický obsah",
    "showMusic": "Zobrazit hudbu při přehrávání",
    "showNotifications": "Nová oznámení",
    "notificationsHelp": "Povolte přístup k oznámením v Pebble. Zobrazí se jen nová oznámení.",
    "notificationPreview": "Zahrnout text zprávy",
    "notificationApps": "Zobrazené aplikace",
    "notificationAppsHelp": "Názvy aplikací oddělte čárkami. Prázdné pole povolí všechny povolené aplikace.",
    "statusHelp": "Stav a nápověda",
    "complicationsWaiting": "Komplikace: čeká se na Pebble",
    "contextWaiting": "Dynamický obsah: čeká se na Pebble",
    "adaptivePeek": "Timeline Peek zachová čas a komplikace. Panel události má přednost před hudbou a oznámeními.",
    "save": "Uložit nastavení",
    "complicationsStatus": "Komplikace: připraveno {ready}/{configured}",
    "complicationsDisabled": "Pro používání komplikací zapněte pluginy v Pebble.",
    "complicationsError": "Chyba komplikace: {error}",
    "contextReady": "Dynamický obsah: připraveno",
    "contextError": "Dynamický obsah: {error}",
    "stateOn": "Zapnuto",
    "stateOff": "Vypnuto",
    "accentColor": "Barva zvýraznění",
    "accentHelp": "Barva symbolů u údajů a ukazatelů deště.",
    "animations": "Animace",
    "animationsHelp": "Krátké přechody při změně hudby nebo oznámení."
  },
  "sk": {
    "title": "Nastavenia Dynamic",
    "appearance": "Vzhľad",
    "background": "Farba pozadia",
    "textColor": "Farba textu",
    "time12": "12-hodinový čas",
    "largeText": "Veľký text",
    "largeTextHelp": "Väčší dátum, údaje a správy. Čas sa prispôsobí dostupnej šírke.",
    "showStatus": "Ukazovatele stavu",
    "statusIndicatorsHelp": "Slabá batéria hodiniek alebo telefónu a strata pripojenia.",
    "complications": "Komplikácie",
    "complicationsHelp": "Vyberte pozície 1 a 2 v Pebble → Nastavenia → Komplikácie.",
    "adaptiveHelp": "Komplikácie 1 a 2 sú vedľa seba. Obe sa zmenšia nad hudbou alebo oznámením.",
    "complicationsUnits": "Jednotky sa preberajú z Pebble a vybraného pluginu.",
    "dynamicContent": "Dynamický obsah",
    "showMusic": "Zobraziť hudbu počas prehrávania",
    "showNotifications": "Nové oznámenia",
    "notificationsHelp": "Povoľte prístup k oznámeniam v Pebble. Zobrazia sa iba nové oznámenia.",
    "notificationPreview": "Zahrnúť text správy",
    "notificationApps": "Zobrazené aplikácie",
    "notificationAppsHelp": "Názvy aplikácií oddeľte čiarkami. Prázdne pole povolí všetky povolené aplikácie.",
    "statusHelp": "Stav a pomocník",
    "complicationsWaiting": "Komplikácie: čaká sa na Pebble",
    "contextWaiting": "Dynamický obsah: čaká sa na Pebble",
    "adaptivePeek": "Timeline Peek zachová čas a komplikácie. Panel udalosti má prednosť pred hudbou a oznámeniami.",
    "save": "Uložiť nastavenia",
    "complicationsStatus": "Komplikácie: pripravených {ready}/{configured}",
    "complicationsDisabled": "Na používanie komplikácií zapnite pluginy v Pebble.",
    "complicationsError": "Chyba komplikácie: {error}",
    "contextReady": "Dynamický obsah: pripravený",
    "contextError": "Dynamický obsah: {error}",
    "stateOn": "Zapnuté",
    "stateOff": "Vypnuté",
    "accentColor": "Farba zvýraznenia",
    "accentHelp": "Farba symbolov pri údajoch a ukazovateľov dažďa.",
    "animations": "Animácie",
    "animationsHelp": "Krátke prechody pri zmene hudby alebo oznámení."
  },
  "de": {
    "title": "Dynamic-Einstellungen",
    "appearance": "Aussehen",
    "background": "Hintergrundfarbe",
    "textColor": "Textfarbe",
    "time12": "12-Stunden-Zeit",
    "largeText": "Großer Text",
    "largeTextHelp": "Größeres Datum, größere Werte und Nachrichten. Die Uhrzeit passt sich der verfügbaren Breite an.",
    "showStatus": "Statusanzeigen",
    "statusIndicatorsHelp": "Niedriger Akku von Uhr oder Telefon und unterbrochene Verbindung.",
    "complications": "Komplikationen",
    "complicationsHelp": "Wähle die Plätze 1 und 2 unter Pebble → Einstellungen → Komplikationen.",
    "adaptiveHelp": "Komplikationen 1 und 2 stehen nebeneinander. Über Musik oder Mitteilungen werden beide kleiner.",
    "complicationsUnits": "Die Einheiten kommen von Pebble und dem gewählten Plugin.",
    "dynamicContent": "Dynamische Inhalte",
    "showMusic": "Musik während der Wiedergabe anzeigen",
    "showNotifications": "Neue Mitteilungen",
    "notificationsHelp": "Erlaube Mitteilungszugriff in Pebble. Nur neue Mitteilungen werden angezeigt.",
    "notificationPreview": "Nachrichtentext einbeziehen",
    "notificationApps": "Anzuzeigende Apps",
    "notificationAppsHelp": "App-Namen durch Kommas trennen. Leer lassen für alle zugelassenen Apps.",
    "statusHelp": "Status und Hilfe",
    "complicationsWaiting": "Komplikationen: Warten auf Pebble",
    "contextWaiting": "Dynamische Inhalte: Warten auf Pebble",
    "adaptivePeek": "Timeline Peek behält die Uhr und die Komplikationen  bei. Das Ereignisfeld hat Vorrang vor Musik und Mitteilungen.",
    "save": "Einstellungen speichern",
    "complicationsStatus": "Komplikationen: {ready}/{configured} bereit",
    "complicationsDisabled": "Aktiviere Plugins in Pebble, um Komplikationen zu nutzen.",
    "complicationsError": "Komplikationsfehler: {error}",
    "contextReady": "Dynamische Inhalte: bereit",
    "contextError": "Dynamische Inhalte: {error}",
    "stateOn": "Ein",
    "stateOff": "Aus",
    "accentColor": "Akzentfarbe",
    "accentHelp": "Farbe der Messwertsymbole und Regenanzeigen.",
    "animations": "Animationen",
    "animationsHelp": "Kurze Übergänge bei Änderungen von Musik oder Benachrichtigungen."
  },
  "fr": {
    "title": "Réglages Dynamic",
    "appearance": "Apparence",
    "background": "Couleur de fond",
    "textColor": "Couleur du texte",
    "time12": "Format 12 heures",
    "largeText": "Grand texte",
    "largeTextHelp": "Date, valeurs et messages plus grands. L’heure s’adapte à la largeur disponible.",
    "showStatus": "Indicateurs d’état",
    "statusIndicatorsHelp": "Batterie faible de la montre ou du téléphone et perte de connexion.",
    "complications": "Complications",
    "complicationsHelp": "Choisissez les emplacements 1 et 2 dans Pebble → Réglages → Complications.",
    "adaptiveHelp": "Les complications 1 et 2 sont côte à côte. Elles rétrécissent au-dessus de la musique ou des notifications.",
    "complicationsUnits": "Les unités proviennent de Pebble et du plugin sélectionné.",
    "dynamicContent": "Contenu dynamique",
    "showMusic": "Afficher la musique pendant la lecture",
    "showNotifications": "Nouvelles notifications",
    "notificationsHelp": "Autorisez l’accès aux notifications dans Pebble. Seules les nouvelles apparaissent.",
    "notificationPreview": "Inclure le texte du message",
    "notificationApps": "Applications à afficher",
    "notificationAppsHelp": "Séparez les noms des apps par des virgules. Vide pour toutes les apps autorisées.",
    "statusHelp": "État et aide",
    "complicationsWaiting": "Complications : en attente de Pebble",
    "contextWaiting": "Contenu dynamique : en attente de Pebble",
    "adaptivePeek": "Timeline Peek conserve l’heure et les complications. Le panneau d’événement est prioritaire sur la musique et les notifications.",
    "save": "Enregistrer les réglages",
    "complicationsStatus": "Complications : {ready}/{configured} prêtes",
    "complicationsDisabled": "Activez les plugins dans Pebble pour utiliser les complications.",
    "complicationsError": "Erreur de complication : {error}",
    "contextReady": "Contenu dynamique : prêt",
    "contextError": "Contenu dynamique : {error}",
    "stateOn": "Activé",
    "stateOff": "Désactivé",
    "accentColor": "Couleur d’accentuation",
    "accentHelp": "Couleur des symboles des données et des jauges de pluie.",
    "animations": "Animations",
    "animationsHelp": "Transitions brèves lors des changements de musique ou de notifications."
  },
  "es": {
    "title": "Ajustes de Dynamic",
    "appearance": "Apariencia",
    "background": "Color de fondo",
    "textColor": "Color del texto",
    "time12": "Formato de 12 horas",
    "largeText": "Texto grande",
    "largeTextHelp": "Fecha, valores y mensajes más grandes. La hora se ajusta al ancho disponible.",
    "showStatus": "Indicadores de estado",
    "statusIndicatorsHelp": "Batería baja del reloj o teléfono y pérdida de conexión.",
    "complications": "Complicaciones",
    "complicationsHelp": "Elige las posiciones 1 y 2 en Pebble → Ajustes → Complicaciones.",
    "adaptiveHelp": "Las complicaciones 1 y 2 están una junto a otra. Ambas se reducen sobre la música o las notificaciones.",
    "complicationsUnits": "Las unidades proceden de Pebble y del plugin seleccionado.",
    "dynamicContent": "Contenido dinámico",
    "showMusic": "Mostrar música durante la reproducción",
    "showNotifications": "Nuevas notificaciones",
    "notificationsHelp": "Permite el acceso a notificaciones en Pebble. Solo aparecen las nuevas.",
    "notificationPreview": "Incluir el texto del mensaje",
    "notificationApps": "Aplicaciones que mostrar",
    "notificationAppsHelp": "Separa los nombres de las apps con comas. Vacío permite todas las apps autorizadas.",
    "statusHelp": "Estado y ayuda",
    "complicationsWaiting": "Complicaciones: esperando a Pebble",
    "contextWaiting": "Contenido dinámico: esperando a Pebble",
    "adaptivePeek": "Timeline Peek conserva el reloj y las complicaciones. El panel de eventos tiene prioridad sobre la música y las notificaciones.",
    "save": "Guardar ajustes",
    "complicationsStatus": "Complicaciones: {ready}/{configured} listas",
    "complicationsDisabled": "Activa los plugins en Pebble para usar complicaciones.",
    "complicationsError": "Error de complicación: {error}",
    "contextReady": "Contenido dinámico: listo",
    "contextError": "Contenido dinámico: {error}",
    "stateOn": "Activado",
    "stateOff": "Desactivado",
    "accentColor": "Color de acento",
    "accentHelp": "Color de los símbolos de las lecturas y los indicadores de lluvia.",
    "animations": "Animaciones",
    "animationsHelp": "Transiciones breves al cambiar la música o las notificaciones."
  },
  "it": {
    "title": "Impostazioni Dynamic",
    "appearance": "Aspetto",
    "background": "Colore dello sfondo",
    "textColor": "Colore del testo",
    "time12": "Formato a 12 ore",
    "largeText": "Testo grande",
    "largeTextHelp": "Data, valori e messaggi più grandi. L’ora si adatta alla larghezza disponibile.",
    "showStatus": "Indicatori di stato",
    "statusIndicatorsHelp": "Batteria scarica di orologio o telefono e connessione persa.",
    "complications": "Complicazioni",
    "complicationsHelp": "Scegli le posizioni 1 e 2 in Pebble → Impostazioni → Complicazioni.",
    "adaptiveHelp": "Le complicazioni 1 e 2 sono affiancate. Entrambe si riducono sopra musica o notifiche.",
    "complicationsUnits": "Le unità provengono da Pebble e dal plugin selezionato.",
    "dynamicContent": "Contenuti dinamici",
    "showMusic": "Mostra la musica durante la riproduzione",
    "showNotifications": "Nuove notifiche",
    "notificationsHelp": "Consenti l’accesso alle notifiche in Pebble. Appaiono solo quelle nuove.",
    "notificationPreview": "Includi il testo del messaggio",
    "notificationApps": "App da mostrare",
    "notificationAppsHelp": "Separa i nomi delle app con virgole. Lascia vuoto per tutte le app autorizzate.",
    "statusHelp": "Stato e aiuto",
    "complicationsWaiting": "Complicazioni: in attesa di Pebble",
    "contextWaiting": "Contenuti dinamici: in attesa di Pebble",
    "adaptivePeek": "Timeline Peek mantiene l’orologio e le complicazioni. Il pannello eventi ha la precedenza su musica e notifiche.",
    "save": "Salva impostazioni",
    "complicationsStatus": "Complicazioni: {ready}/{configured} pronte",
    "complicationsDisabled": "Abilita i plugin in Pebble per usare le complicazioni.",
    "complicationsError": "Errore della complicazione: {error}",
    "contextReady": "Contenuti dinamici: pronti",
    "contextError": "Contenuti dinamici: {error}",
    "stateOn": "Attivato",
    "stateOff": "Disattivato",
    "accentColor": "Colore accento",
    "accentHelp": "Colore dei simboli dei valori e degli indicatori di pioggia.",
    "animations": "Animazioni",
    "animationsHelp": "Brevi transizioni quando cambiano musica o notifiche."
  },
  "pt": {
    "title": "Configurações do Dynamic",
    "appearance": "Aparência",
    "background": "Cor de fundo",
    "textColor": "Cor do texto",
    "time12": "Formato de 12 horas",
    "largeText": "Texto grande",
    "largeTextHelp": "Data, valores e mensagens maiores. A hora adapta-se à largura disponível.",
    "showStatus": "Indicadores de estado",
    "statusIndicatorsHelp": "Bateria fraca do relógio ou telefone e perda de conexão.",
    "complications": "Complicações",
    "complicationsHelp": "Escolha as posições 1 e 2 em Pebble → Configurações → Complicações.",
    "adaptiveHelp": "As complicações 1 e 2 ficam lado a lado. Ambas diminuem acima da música ou das notificações.",
    "complicationsUnits": "As unidades vêm do Pebble e do plugin selecionado.",
    "dynamicContent": "Conteúdo dinâmico",
    "showMusic": "Mostrar música durante a reprodução",
    "showNotifications": "Novas notificações",
    "notificationsHelp": "Permita acesso às notificações no Pebble. Apenas as novas aparecem.",
    "notificationPreview": "Incluir o texto da mensagem",
    "notificationApps": "Aplicativos a mostrar",
    "notificationAppsHelp": "Separe os nomes dos apps por vírgulas. Vazio permite todos os apps autorizados.",
    "statusHelp": "Estado e ajuda",
    "complicationsWaiting": "Complicações: à espera do Pebble",
    "contextWaiting": "Conteúdo dinâmico: à espera do Pebble",
    "adaptivePeek": "O Timeline Peek mantém o relógio e as complicações. O painel de eventos tem prioridade sobre música e notificações.",
    "save": "Salvar configurações",
    "complicationsStatus": "Complicações: {ready}/{configured} prontas",
    "complicationsDisabled": "Ative os plugins no Pebble para usar complicações.",
    "complicationsError": "Erro de complicação: {error}",
    "contextReady": "Conteúdo dinâmico: pronto",
    "contextError": "Conteúdo dinâmico: {error}",
    "stateOn": "Ativado",
    "stateOff": "Desativado",
    "accentColor": "Cor de destaque",
    "accentHelp": "Cor dos símbolos dos valores e dos indicadores de chuva.",
    "animations": "Animações",
    "animationsHelp": "Transições curtas quando a música ou as notificações mudam."
  },
  "nl": {
    "title": "Dynamic-instellingen",
    "appearance": "Uiterlijk",
    "background": "Achtergrondkleur",
    "textColor": "Tekstkleur",
    "time12": "12-uursnotatie",
    "largeText": "Grote tekst",
    "largeTextHelp": "Grotere datum, waarden en berichten. De tijd past zich aan de beschikbare breedte aan.",
    "showStatus": "Statusindicatoren",
    "statusIndicatorsHelp": "Lage batterij van horloge of telefoon en verbroken verbinding.",
    "complications": "Complicaties",
    "complicationsHelp": "Kies posities 1 en 2 via Pebble → Instellingen → Complicaties.",
    "adaptiveHelp": "Complicaties 1 en 2 staan naast elkaar. Beide worden kleiner boven muziek of meldingen.",
    "complicationsUnits": "De eenheden komen van Pebble en de gekozen plugin.",
    "dynamicContent": "Dynamische inhoud",
    "showMusic": "Muziek tonen tijdens het afspelen",
    "showNotifications": "Nieuwe meldingen",
    "notificationsHelp": "Sta meldingentoegang toe in Pebble. Alleen nieuwe meldingen verschijnen.",
    "notificationPreview": "Berichttekst opnemen",
    "notificationApps": "Te tonen apps",
    "notificationAppsHelp": "Scheid app-namen met komma’s. Leeg betekent alle toegestane apps.",
    "statusHelp": "Status en hulp",
    "complicationsWaiting": "Complicaties: wachten op Pebble",
    "contextWaiting": "Dynamische inhoud: wachten op Pebble",
    "adaptivePeek": "Timeline Peek behoudt de klok en complicaties. Het afsprakenpaneel heeft voorrang op muziek en meldingen.",
    "save": "Instellingen opslaan",
    "complicationsStatus": "Complicaties: {ready}/{configured} gereed",
    "complicationsDisabled": "Schakel plugins in Pebble in om complicaties te gebruiken.",
    "complicationsError": "Complicatiefout: {error}",
    "contextReady": "Dynamische inhoud: gereed",
    "contextError": "Dynamische inhoud: {error}",
    "stateOn": "Aan",
    "stateOff": "Uit",
    "accentColor": "Accentkleur",
    "accentHelp": "Kleur voor meetsymbolen en regenmeters.",
    "animations": "Animaties",
    "animationsHelp": "Korte overgangen wanneer muziek of meldingen veranderen."
  },
  "pl": {
    "title": "Ustawienia Dynamic",
    "appearance": "Wygląd",
    "background": "Kolor tła",
    "textColor": "Kolor tekstu",
    "time12": "Format 12-godzinny",
    "largeText": "Duży tekst",
    "largeTextHelp": "Większa data, wartości i wiadomości. Godzina dopasowuje się do dostępnej szerokości.",
    "showStatus": "Wskaźniki stanu",
    "statusIndicatorsHelp": "Słaba bateria zegarka lub telefonu i utrata połączenia.",
    "complications": "Komplikacje",
    "complicationsHelp": "Wybierz pozycje 1 i 2 w Pebble → Ustawienia → Komplikacje.",
    "adaptiveHelp": "Komplikacje 1 i 2 są obok siebie. Obie zmniejszają się nad muzyką lub powiadomieniami.",
    "complicationsUnits": "Jednostki pochodzą z Pebble i wybranej wtyczki.",
    "dynamicContent": "Treść dynamiczna",
    "showMusic": "Pokazuj muzykę podczas odtwarzania",
    "showNotifications": "Nowe powiadomienia",
    "notificationsHelp": "Zezwól na dostęp do powiadomień w Pebble. Pojawiają się tylko nowe.",
    "notificationPreview": "Dołącz tekst wiadomości",
    "notificationApps": "Wyświetlane aplikacje",
    "notificationAppsHelp": "Oddziel nazwy aplikacji przecinkami. Puste pole oznacza wszystkie dozwolone aplikacje.",
    "statusHelp": "Stan i pomoc",
    "complicationsWaiting": "Komplikacje: oczekiwanie na Pebble",
    "contextWaiting": "Treść dynamiczna: oczekiwanie na Pebble",
    "adaptivePeek": "Timeline Peek zachowuje zegar i komplikacje. Panel wydarzenia ma pierwszeństwo przed muzyką i powiadomieniami.",
    "save": "Zapisz ustawienia",
    "complicationsStatus": "Komplikacje: gotowe {ready}/{configured}",
    "complicationsDisabled": "Włącz wtyczki w Pebble, aby korzystać z komplikacji.",
    "complicationsError": "Błąd komplikacji: {error}",
    "contextReady": "Treść dynamiczna: gotowa",
    "contextError": "Treść dynamiczna: {error}",
    "stateOn": "Wł.",
    "stateOff": "Wył.",
    "accentColor": "Kolor akcentu",
    "accentHelp": "Kolor symboli odczytów i wskaźników deszczu.",
    "animations": "Animacje",
    "animationsHelp": "Krótkie przejścia przy zmianie muzyki lub powiadomień."
  },
  "da": {
    "title": "Dynamic-indstillinger",
    "appearance": "Udseende",
    "background": "Baggrundsfarve",
    "textColor": "Tekstfarve",
    "time12": "12-timersformat",
    "largeText": "Stor tekst",
    "largeTextHelp": "Større dato, værdier og beskeder. Klokkeslættet tilpasses den tilgængelige bredde.",
    "showStatus": "Statusindikatorer",
    "statusIndicatorsHelp": "Lavt batteri på ur eller telefon og mistet forbindelse.",
    "complications": "Komplikationer",
    "complicationsHelp": "Vælg plads 1 og 2 i Pebble → Indstillinger → Komplikationer.",
    "adaptiveHelp": "Komplikation 1 og 2 står ved siden af hinanden. Begge bliver mindre over musik eller notifikationer.",
    "complicationsUnits": "Enhederne kommer fra Pebble og det valgte plugin.",
    "dynamicContent": "Dynamisk indhold",
    "showMusic": "Vis musik under afspilning",
    "showNotifications": "Nye notifikationer",
    "notificationsHelp": "Tillad adgang til notifikationer i Pebble. Kun nye vises.",
    "notificationPreview": "Medtag beskedtekst",
    "notificationApps": "Apps, der skal vises",
    "notificationAppsHelp": "Adskil appnavne med kommaer. Tomt felt tillader alle godkendte apps.",
    "statusHelp": "Status og hjælp",
    "complicationsWaiting": "Komplikationer: venter på Pebble",
    "contextWaiting": "Dynamisk indhold: venter på Pebble",
    "adaptivePeek": "Timeline Peek beholder uret og komplikation. Begivenhedspanelet har forrang over musik og notifikationer.",
    "save": "Gem indstillinger",
    "complicationsStatus": "Komplikationer: {ready}/{configured} klar",
    "complicationsDisabled": "Aktivér plugins i Pebble for at bruge komplikationer.",
    "complicationsError": "Komplikationsfejl: {error}",
    "contextReady": "Dynamisk indhold: klar",
    "contextError": "Dynamisk indhold: {error}",
    "stateOn": "Til",
    "stateOff": "Fra",
    "accentColor": "Accentfarve",
    "accentHelp": "Farve til symboler for målinger og regnmålere.",
    "animations": "Animationer",
    "animationsHelp": "Korte overgange, når musik eller notifikationer ændres."
  },
  "sv": {
    "title": "Dynamic-inställningar",
    "appearance": "Utseende",
    "background": "Bakgrundsfärg",
    "textColor": "Textfärg",
    "time12": "12-timmarsformat",
    "largeText": "Stor text",
    "largeTextHelp": "Större datum, värden och meddelanden. Klockslaget anpassas till den tillgängliga bredden.",
    "showStatus": "Statusindikatorer",
    "statusIndicatorsHelp": "Lågt batteri i klocka eller telefon och förlorad anslutning.",
    "complications": "Komplikationer",
    "complicationsHelp": "Välj plats 1 och 2 i Pebble → Inställningar → Komplikationer.",
    "adaptiveHelp": "Komplikation 1 och 2 ligger bredvid varandra. Båda krymper ovanför musik eller aviseringar.",
    "complicationsUnits": "Enheterna kommer från Pebble och det valda insticksprogrammet.",
    "dynamicContent": "Dynamiskt innehåll",
    "showMusic": "Visa musik under uppspelning",
    "showNotifications": "Nya aviseringar",
    "notificationsHelp": "Tillåt aviseringsåtkomst i Pebble. Endast nya aviseringar visas.",
    "notificationPreview": "Ta med meddelandetext",
    "notificationApps": "Appar att visa",
    "notificationAppsHelp": "Avgränsa appnamn med kommatecken. Tomt fält tillåter alla godkända appar.",
    "statusHelp": "Status och hjälp",
    "complicationsWaiting": "Komplikationer: väntar på Pebble",
    "contextWaiting": "Dynamiskt innehåll: väntar på Pebble",
    "adaptivePeek": "Timeline Peek behåller klockan och komplikation. Händelsepanelen har företräde framför musik och aviseringar.",
    "save": "Spara inställningar",
    "complicationsStatus": "Komplikationer: {ready}/{configured} klara",
    "complicationsDisabled": "Aktivera insticksprogram i Pebble för att använda komplikationer.",
    "complicationsError": "Komplikationsfel: {error}",
    "contextReady": "Dynamiskt innehåll: klart",
    "contextError": "Dynamiskt innehåll: {error}",
    "stateOn": "På",
    "stateOff": "Av",
    "accentColor": "Accentfärg",
    "accentHelp": "Färg för mätvärdessymboler och regnmätare.",
    "animations": "Animationer",
    "animationsHelp": "Korta övergångar när musik eller aviseringar ändras."
  },
  "no": {
    "title": "Dynamic-innstillinger",
    "appearance": "Utseende",
    "background": "Bakgrunnsfarge",
    "textColor": "Tekstfarge",
    "time12": "12-timersformat",
    "largeText": "Stor tekst",
    "largeTextHelp": "Større dato, verdier og meldinger. Klokkeslettet tilpasses den tilgjengelige bredden.",
    "showStatus": "Statusindikatorer",
    "statusIndicatorsHelp": "Lavt batteri på klokke eller telefon og mistet forbindelse.",
    "complications": "Komplikasjoner",
    "complicationsHelp": "Velg plass 1 og 2 i Pebble → Innstillinger → Komplikasjoner.",
    "adaptiveHelp": "Komplikasjon 1 og 2 står ved siden av hverandre. Begge krymper over musikk eller varsler.",
    "complicationsUnits": "Enhetene kommer fra Pebble og det valgte programtillegget.",
    "dynamicContent": "Dynamisk innhold",
    "showMusic": "Vis musikk under avspilling",
    "showNotifications": "Nye varsler",
    "notificationsHelp": "Tillat varseltilgang i Pebble. Bare nye varsler vises.",
    "notificationPreview": "Ta med meldingstekst",
    "notificationApps": "Apper som skal vises",
    "notificationAppsHelp": "Skill appnavn med komma. Tomt felt tillater alle godkjente apper.",
    "statusHelp": "Status og hjelp",
    "complicationsWaiting": "Komplikasjoner: venter på Pebble",
    "contextWaiting": "Dynamisk innhold: venter på Pebble",
    "adaptivePeek": "Timeline Peek beholder klokken og komplikasjon. Hendelsespanelet prioriteres fremfor musikk og varsler.",
    "save": "Lagre innstillinger",
    "complicationsStatus": "Komplikasjoner: {ready}/{configured} klare",
    "complicationsDisabled": "Aktiver programtillegg i Pebble for å bruke komplikasjoner.",
    "complicationsError": "Komplikasjonsfeil: {error}",
    "contextReady": "Dynamisk innhold: klart",
    "contextError": "Dynamisk innhold: {error}",
    "stateOn": "På",
    "stateOff": "Av",
    "accentColor": "Aksentfarge",
    "accentHelp": "Farge på målesymboler og regnmålere.",
    "animations": "Animasjoner",
    "animationsHelp": "Korte overganger når musikk eller varsler endres."
  },
  "fi": {
    "title": "Dynamic-asetukset",
    "appearance": "Ulkoasu",
    "background": "Taustaväri",
    "textColor": "Tekstin väri",
    "time12": "12 tunnin kellonaika",
    "largeText": "Suuri teksti",
    "largeTextHelp": "Suurempi päivämäärä, arvot ja viestit. Kellonaika mukautuu käytettävissä olevaan leveyteen.",
    "showStatus": "Tilailmaisimet",
    "statusIndicatorsHelp": "Kellon tai puhelimen vähäinen akku ja katkennut yhteys.",
    "complications": "Kellon lisätiedot",
    "complicationsHelp": "Valitse paikat 1 ja 2 kohdasta Pebble → Asetukset → Lisätiedot.",
    "adaptiveHelp": "Lisätiedot 1 ja 2 ovat vierekkäin. Molemmat pienenevät musiikin tai ilmoitusten yläpuolelle.",
    "complicationsUnits": "Yksiköt tulevat Pebblestä ja valitusta lisäosasta.",
    "dynamicContent": "Muuttuva sisältö",
    "showMusic": "Näytä musiikki toiston aikana",
    "showNotifications": "Uudet ilmoitukset",
    "notificationsHelp": "Salli ilmoitusten käyttö Pebblessä. Vain uudet ilmoitukset näkyvät.",
    "notificationPreview": "Sisällytä viestin teksti",
    "notificationApps": "Näytettävät sovellukset",
    "notificationAppsHelp": "Erota sovellusten nimet pilkuilla. Tyhjä kenttä sallii kaikki hyväksytyt sovellukset.",
    "statusHelp": "Tila ja ohje",
    "complicationsWaiting": "Lisätiedot: odotetaan Pebbleä",
    "contextWaiting": "Muuttuva sisältö: odotetaan Pebbleä",
    "adaptivePeek": "Timeline Peek säilyttää kellon ja lisätiedot. Tapahtumapaneeli on etusijalla musiikkiin ja ilmoituksiin nähden.",
    "save": "Tallenna asetukset",
    "complicationsStatus": "Lisätiedot: {ready}/{configured} valmiina",
    "complicationsDisabled": "Ota lisäosat käyttöön Pebblessä, jotta voit näyttää lisätietoja.",
    "complicationsError": "Lisätietovirhe: {error}",
    "contextReady": "Muuttuva sisältö: valmis",
    "contextError": "Muuttuva sisältö: {error}",
    "stateOn": "Päällä",
    "stateOff": "Pois",
    "accentColor": "Korostusväri",
    "accentHelp": "Arvojen symbolien ja sadeilmaisimien väri.",
    "animations": "Animaatiot",
    "animationsHelp": "Lyhyet siirtymät musiikin tai ilmoitusten vaihtuessa."
  },
  "hu": {
    "title": "Dynamic beállításai",
    "appearance": "Megjelenés",
    "background": "Háttérszín",
    "textColor": "Szövegszín",
    "time12": "12 órás időformátum",
    "largeText": "Nagy szöveg",
    "largeTextHelp": "Nagyobb dátum, értékek és üzenetek. Az idő a rendelkezésre álló szélességhez igazodik.",
    "showStatus": "Állapotjelzők",
    "statusIndicatorsHelp": "Az óra vagy telefon alacsony töltöttsége és megszakadt kapcsolat.",
    "complications": "Komplikációk",
    "complicationsHelp": "Válaszd az 1. és 2. helyet itt: Pebble → Beállítások → Komplikációk.",
    "adaptiveHelp": "Az 1. és 2. komplikáció egymás mellett látható. Mindkettő kisebb lesz a zene vagy értesítések felett.",
    "complicationsUnits": "A mértékegységeket a Pebble és a kiválasztott bővítmény adja meg.",
    "dynamicContent": "Változó tartalom",
    "showMusic": "Zene megjelenítése lejátszás közben",
    "showNotifications": "Új értesítések",
    "notificationsHelp": "Engedélyezd az értesítések elérését a Pebble-ben. Csak az új értesítések jelennek meg.",
    "notificationPreview": "Üzenetszöveg megjelenítése",
    "notificationApps": "Megjelenített alkalmazások",
    "notificationAppsHelp": "Az alkalmazásneveket vesszővel válaszd el. Üresen minden engedélyezett alkalmazás látszik.",
    "statusHelp": "Állapot és súgó",
    "complicationsWaiting": "Komplikációk: várakozás a Pebble-re",
    "contextWaiting": "Változó tartalom: várakozás a Pebble-re",
    "adaptivePeek": "A Timeline Peek megtartja az órát és az. komplikációt. Az eseménypanel elsőbbséget élvez a zenével és az értesítésekkel szemben.",
    "save": "Beállítások mentése",
    "complicationsStatus": "Komplikációk: {ready}/{configured} kész",
    "complicationsDisabled": "A komplikációk használatához engedélyezd a bővítményeket a Pebble-ben.",
    "complicationsError": "Komplikációhiba: {error}",
    "contextReady": "Változó tartalom: kész",
    "contextError": "Változó tartalom: {error}",
    "stateOn": "Be",
    "stateOff": "Ki",
    "accentColor": "Kiemelőszín",
    "accentHelp": "Az értékek szimbólumainak és az esőjelzőknek a színe.",
    "animations": "Animációk",
    "animationsHelp": "Rövid átmenetek a zene vagy az értesítések változásakor."
  },
  "ro": {
    "title": "Setări Dynamic",
    "appearance": "Aspect",
    "background": "Culoare fundal",
    "textColor": "Culoare text",
    "time12": "Format de 12 ore",
    "largeText": "Text mare",
    "largeTextHelp": "Dată, valori și mesaje mai mari. Ora se adaptează la lățimea disponibilă.",
    "showStatus": "Indicatori de stare",
    "statusIndicatorsHelp": "Baterie scăzută la ceas sau telefon și conexiune pierdută.",
    "complications": "Complicații",
    "complicationsHelp": "Alege pozițiile 1 și 2 în Pebble → Setări → Complicații.",
    "adaptiveHelp": "Complicațiile 1 și 2 sunt alăturate. Ambele se micșorează deasupra muzicii sau notificărilor.",
    "complicationsUnits": "Unitățile provin de la Pebble și de la extensia selectată.",
    "dynamicContent": "Conținut dinamic",
    "showMusic": "Arată muzica în timpul redării",
    "showNotifications": "Notificări noi",
    "notificationsHelp": "Permite accesul la notificări în Pebble. Apar doar cele noi.",
    "notificationPreview": "Include textul mesajului",
    "notificationApps": "Aplicații de afișat",
    "notificationAppsHelp": "Separă numele aplicațiilor prin virgule. Lasă gol pentru toate aplicațiile permise.",
    "statusHelp": "Stare și ajutor",
    "complicationsWaiting": "Complicații: se așteaptă Pebble",
    "contextWaiting": "Conținut dinamic: se așteaptă Pebble",
    "adaptivePeek": "Timeline Peek păstrează ceasul și complicațiile. Panoul evenimentului are prioritate față de muzică și notificări.",
    "save": "Salvează setările",
    "complicationsStatus": "Complicații: {ready}/{configured} pregătite",
    "complicationsDisabled": "Activează extensiile în Pebble pentru a folosi complicații.",
    "complicationsError": "Eroare de complicație: {error}",
    "contextReady": "Conținut dinamic: pregătit",
    "contextError": "Conținut dinamic: {error}",
    "stateOn": "Pornit",
    "stateOff": "Oprit",
    "accentColor": "Culoare de accent",
    "accentHelp": "Culoarea simbolurilor pentru valori și a indicatoarelor de ploaie.",
    "animations": "Animații",
    "animationsHelp": "Tranziții scurte când se schimbă muzica sau notificările."
  },
  "tr": {
    "title": "Dynamic Ayarları",
    "appearance": "Görünüm",
    "background": "Arka plan rengi",
    "textColor": "Metin rengi",
    "time12": "12 saat biçimi",
    "largeText": "Büyük metin",
    "largeTextHelp": "Daha büyük tarih, değerler ve mesajlar. Saat, kullanılabilir genişliğe uyum sağlar.",
    "showStatus": "Durum göstergeleri",
    "statusIndicatorsHelp": "Saat veya telefonun düşük pili ve kesilen bağlantı.",
    "complications": "Komplikasyonlar",
    "complicationsHelp": "Pebble → Ayarlar → Komplikasyonlar bölümünden 1 ve 2 yuvalarını seçin.",
    "adaptiveHelp": "1 ve 2. komplikasyon yan yana durur. İkisi de müzik veya bildirimlerin üstünde küçülür.",
    "complicationsUnits": "Birimler Pebble ve seçilen eklentiden alınır.",
    "dynamicContent": "Dinamik içerik",
    "showMusic": "Çalma sırasında müziği göster",
    "showNotifications": "Yeni bildirimler",
    "notificationsHelp": "Pebble’da bildirim erişimine izin verin. Yalnızca yeni bildirimler görünür.",
    "notificationPreview": "Mesaj metnini dahil et",
    "notificationApps": "Gösterilecek uygulamalar",
    "notificationAppsHelp": "Uygulama adlarını virgülle ayırın. Boş bırakmak izin verilen tüm uygulamaları gösterir.",
    "statusHelp": "Durum ve yardım",
    "complicationsWaiting": "Komplikasyonlar: Pebble bekleniyor",
    "contextWaiting": "Dinamik içerik: Pebble bekleniyor",
    "adaptivePeek": "Timeline Peek saati ve. komplikasyonları korur. Etkinlik paneli müzik ve bildirimlerden önce gelir.",
    "save": "Ayarları kaydet",
    "complicationsStatus": "Komplikasyonlar: {ready}/{configured} hazır",
    "complicationsDisabled": "Komplikasyonları kullanmak için Pebble’da eklentileri etkinleştirin.",
    "complicationsError": "Komplikasyon hatası: {error}",
    "contextReady": "Dinamik içerik: hazır",
    "contextError": "Dinamik içerik: {error}",
    "stateOn": "Açık",
    "stateOff": "Kapalı",
    "accentColor": "Vurgu rengi",
    "accentHelp": "Değer simgelerinin ve yağmur göstergelerinin rengi.",
    "animations": "Animasyonlar",
    "animationsHelp": "Müzik veya bildirimler değiştiğinde kısa geçişler."
  }
};
// Keep previous English literals translatable for stored Clay schemas.
var LEGACY_LITERALS = {
  'Color for reading symbols. Rain gauges and notification symbols use yellow.': 'accentHelp',
  'Settings delivered to watch.': 'saveSaved',
  'Waiting for watch.': 'savePending',
  'Could not reach watch. Reconnect and save again.': 'saveFailed'
};
var SETTINGS_MESSAGES = {
  en: {
    samplePreview: 'Sample preview',
    sampleHelp: 'Example screens, not live data.',
    previewIdle: 'Idle',
    previewMusic: 'Music',
    previewNotification: 'Notification',
    previewTimeline: 'Timeline',
    display: 'Display',
    theme: 'Theme',
    themeLight: 'Light',
    themeDark: 'Dark',
    themeCustom: 'Custom',
    timeFormat: 'Time format',
    followPebble: 'Follow Pebble',
    time24: '24-hour time',
    largerText: 'Larger text',
    languageHelp: 'Language follows your watch.',
    twoReadings: 'Your two readings',
    leftReading: 'Left',
    rightReading: 'Right',
    musicNotifications: 'Music & notifications',
    notifications: 'Notifications',
    notificationSummary: 'App and title',
    notificationAppsMode: 'Notification apps',
    allApps: 'All apps',
    selectedApps: 'Selected apps',
    appFilterHelp: 'Use exact app names or Android package names, separated by commas. For example: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Enter at least one app name or Android package.',
    helpConnection: 'Help & connection',
    snapshotHelp: 'Status when settings opened. Reopen settings to refresh.',
    permissionHelp: 'Allow access in Pebble, then reopen settings.',
    pluginHelp: 'Check that the matching plugin is enabled in Pebble.',
    connectionHelp: 'Connect your phone and watch, then reopen settings.',
    technicalDetails: 'Technical details',
    receivedAge: 'Received {age} min ago',
    observedAge: 'Observed {age} min ago',
    readingTemperature: 'Temperature',
    readingFeelsLike: 'Feels like',
    readingHigh: 'High',
    readingLow: 'Low',
    readingCondition: 'Condition',
    readingHumidity: 'Humidity',
    readingRain: 'Rain',
    readingUv: 'UV index',
    readingBattery: 'Battery',
    readingTitle: 'Title',
    readingArtist: 'Artist',
    readingName: 'Name',
    phoneSource: 'Phone battery',
    sourceEmpty: 'Not selected',
    sourceLoading: 'Loading',
    sourceReady: 'Ready',
    sourceUnavailable: 'Unavailable',
    sourceDenied: 'Permission needed',
    sourceUnsupported: 'Unsupported data',
    sourceDisabled: 'Plugin disabled',
    sourcePlaying: 'Playing',
    sourcePaused: 'Paused',
    sourceIdle: 'Not playing',
    sourceWaiting: 'Waiting for Pebble',
    saveSaved: 'Watch settings delivered.',
    savePending: 'Saved on phone; waiting for watch.',
    saveFailed: 'Saved on phone. Reconnect and save again to update the watch.',
    saveNone: 'Changes apply after you save.',
    saveSending: 'Saving…',
    contrastHelp: 'Text may be hard to read. Choose different text and background colors.',
    previewSettingsNote: 'Preview uses the watch’s 64-color palette.',
    previewCustomHelp: 'Custom colors are approximate. The layout uses native watch rendering.',
    previewTimelineHelp: 'The lower panel is reserved for Pebble Timeline.',
    noExample: 'No example available'
  },
  cs: {
    samplePreview: 'Ukázkový náhled',
    sampleHelp: 'Ukázkové obrazovky, nikoli živá data.',
    previewIdle: 'V klidu',
    previewMusic: 'Hudba',
    previewNotification: 'Oznámení',
    previewTimeline: 'Časová osa',
    display: 'Zobrazení',
    theme: 'Motiv',
    themeLight: 'Světlý',
    themeDark: 'Tmavý',
    themeCustom: 'Vlastní',
    timeFormat: 'Formát času',
    followPebble: 'Podle Pebble',
    time24: '24hodinový čas',
    largerText: 'Větší text',
    languageHelp: 'Jazyk se řídí hodinkami.',
    twoReadings: 'Vaše dva údaje',
    leftReading: 'Vlevo',
    rightReading: 'Vpravo',
    musicNotifications: 'Hudba a oznámení',
    notifications: 'Oznámení',
    notificationSummary: 'Aplikace a titulek',
    notificationAppsMode: 'Aplikace s oznámeními',
    allApps: 'Všechny aplikace',
    selectedApps: 'Vybrané aplikace',
    appFilterHelp: 'Zadejte přesné názvy aplikací nebo balíčků Android oddělené čárkami. Například: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Zadejte alespoň jeden název aplikace nebo balíčku Android.',
    helpConnection: 'Nápověda a připojení',
    snapshotHelp: 'Stav při otevření nastavení. Pro obnovení otevřete nastavení znovu.',
    permissionHelp: 'Povolte přístup v Pebble a znovu otevřete nastavení.',
    pluginHelp: 'Zkontrolujte, že je příslušný plugin v Pebble zapnutý.',
    connectionHelp: 'Připojte telefon a hodinky a znovu otevřete nastavení.',
    technicalDetails: 'Technické podrobnosti',
    receivedAge: 'Přijato před {age} min',
    observedAge: 'Zaznamenáno před {age} min',
    readingTemperature: 'Teplota',
    readingFeelsLike: 'Pocitová teplota',
    readingHigh: 'Maximum',
    readingLow: 'Minimum',
    readingCondition: 'Počasí',
    readingHumidity: 'Vlhkost',
    readingRain: 'Déšť',
    readingUv: 'UV index',
    readingBattery: 'Baterie',
    readingTitle: 'Titulek',
    readingArtist: 'Interpret',
    readingName: 'Název',
    phoneSource: 'Baterie telefonu',
    sourceEmpty: 'Nevybráno',
    sourceLoading: 'Načítání',
    sourceReady: 'Připraveno',
    sourceUnavailable: 'Nedostupné',
    sourceDenied: 'Je potřeba oprávnění',
    sourceUnsupported: 'Nepodporovaná data',
    sourceDisabled: 'Plugin je vypnutý',
    sourcePlaying: 'Přehrává se',
    sourcePaused: 'Pozastaveno',
    sourceIdle: 'Nepřehrává se',
    sourceWaiting: 'Čeká se na Pebble',
    saveSaved: 'Nastavení hodinek bylo doručeno.',
    savePending: 'Uloženo v telefonu; čeká se na hodinky.',
    saveFailed: 'Uloženo v telefonu. Pro aktualizaci hodinek obnovte připojení a uložte znovu.',
    saveNone: 'Změny se použijí po uložení.',
    saveSending: 'Ukládání…',
    contrastHelp: 'Text může být špatně čitelný. Zvolte jiné barvy textu a pozadí.',
    previewSettingsNote: 'Náhled používá paletu 64 barev hodinek.',
    previewCustomHelp: 'Vlastní barvy jsou přibližné. Rozložení používá nativní vykreslování hodinek.',
    previewTimelineHelp: 'Spodní panel je vyhrazen pro Pebble Timeline.',
    noExample: 'Ukázka není k dispozici'
  },
  sk: {
    samplePreview: 'Ukážkový náhľad',
    sampleHelp: 'Ukážkové obrazovky, nie živé údaje.',
    previewIdle: 'V pokoji',
    previewMusic: 'Hudba',
    previewNotification: 'Oznámenie',
    previewTimeline: 'Časová os',
    display: 'Zobrazenie',
    theme: 'Motív',
    themeLight: 'Svetlý',
    themeDark: 'Tmavý',
    themeCustom: 'Vlastný',
    timeFormat: 'Formát času',
    followPebble: 'Podľa Pebble',
    time24: '24-hodinový čas',
    largerText: 'Väčší text',
    languageHelp: 'Jazyk sa riadi hodinkami.',
    twoReadings: 'Vaše dva údaje',
    leftReading: 'Vľavo',
    rightReading: 'Vpravo',
    musicNotifications: 'Hudba a oznámenia',
    notifications: 'Oznámenia',
    notificationSummary: 'Aplikácia a nadpis',
    notificationAppsMode: 'Aplikácie s oznámeniami',
    allApps: 'Všetky aplikácie',
    selectedApps: 'Vybrané aplikácie',
    appFilterHelp: 'Zadajte presné názvy aplikácií alebo balíkov Android oddelené čiarkami. Napríklad: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Zadajte aspoň jeden názov aplikácie alebo balíka Android.',
    helpConnection: 'Pomoc a pripojenie',
    snapshotHelp: 'Stav pri otvorení nastavení. Na obnovenie otvorte nastavenia znova.',
    permissionHelp: 'Povoľte prístup v Pebble a znova otvorte nastavenia.',
    pluginHelp: 'Skontrolujte, či je príslušný plugin v Pebble zapnutý.',
    connectionHelp: 'Pripojte telefón a hodinky a znova otvorte nastavenia.',
    technicalDetails: 'Technické podrobnosti',
    receivedAge: 'Prijaté pred {age} min',
    observedAge: 'Zaznamenané pred {age} min',
    readingTemperature: 'Teplota',
    readingFeelsLike: 'Pocitová teplota',
    readingHigh: 'Maximum',
    readingLow: 'Minimum',
    readingCondition: 'Počasie',
    readingHumidity: 'Vlhkosť',
    readingRain: 'Dážď',
    readingUv: 'UV index',
    readingBattery: 'Batéria',
    readingTitle: 'Nadpis',
    readingArtist: 'Interpret',
    readingName: 'Názov',
    phoneSource: 'Batéria telefónu',
    sourceEmpty: 'Nevybrané',
    sourceLoading: 'Načítava sa',
    sourceReady: 'Pripravené',
    sourceUnavailable: 'Nedostupné',
    sourceDenied: 'Vyžaduje sa povolenie',
    sourceUnsupported: 'Nepodporované údaje',
    sourceDisabled: 'Plugin je vypnutý',
    sourcePlaying: 'Prehráva sa',
    sourcePaused: 'Pozastavené',
    sourceIdle: 'Neprehráva sa',
    sourceWaiting: 'Čaká sa na Pebble',
    saveSaved: 'Nastavenia hodiniek boli doručené.',
    savePending: 'Uložené v telefóne; čaká sa na hodinky.',
    saveFailed: 'Uložené v telefóne. Na aktualizáciu hodiniek obnovte pripojenie a uložte znova.',
    saveNone: 'Zmeny sa použijú po uložení.',
    saveSending: 'Ukladá sa…',
    contrastHelp: 'Text môže byť zle čitateľný. Zvoľte iné farby textu a pozadia.',
    previewSettingsNote: 'Náhľad používa paletu 64 farieb hodiniek.',
    previewCustomHelp: 'Vlastné farby sú približné. Rozloženie používa natívne vykresľovanie hodiniek.',
    previewTimelineHelp: 'Spodný panel je vyhradený pre Pebble Timeline.',
    noExample: 'Ukážka nie je k dispozícii'
  },
  de: {
    samplePreview: 'Beispielvorschau',
    sampleHelp: 'Beispielansichten ohne Live-Daten.',
    previewIdle: 'Ruhezustand',
    previewMusic: 'Musik',
    previewNotification: 'Mitteilung',
    previewTimeline: 'Zeitleiste',
    display: 'Anzeige',
    theme: 'Design',
    themeLight: 'Hell',
    themeDark: 'Dunkel',
    themeCustom: 'Eigene Farben',
    timeFormat: 'Zeitformat',
    followPebble: 'Wie in Pebble',
    time24: '24-Stunden-Zeit',
    largerText: 'Größerer Text',
    languageHelp: 'Die Sprache richtet sich nach deiner Uhr.',
    twoReadings: 'Deine zwei Messwerte',
    leftReading: 'Links',
    rightReading: 'Rechts',
    musicNotifications: 'Musik und Mitteilungen',
    notifications: 'Mitteilungen',
    notificationSummary: 'App und Titel',
    notificationAppsMode: 'Apps für Mitteilungen',
    allApps: 'Alle Apps',
    selectedApps: 'Ausgewählte Apps',
    appFilterHelp: 'Gib genaue App-Namen oder Android-Paketnamen durch Kommas getrennt ein. Zum Beispiel: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Gib mindestens einen App-Namen oder Android-Paketnamen ein.',
    helpConnection: 'Hilfe und Verbindung',
    snapshotHelp: 'Status beim Öffnen der Einstellungen. Zum Aktualisieren erneut öffnen.',
    permissionHelp: 'Erlaube den Zugriff in Pebble und öffne die Einstellungen erneut.',
    pluginHelp: 'Prüfe, ob das passende Plugin in Pebble aktiviert ist.',
    connectionHelp: 'Verbinde Telefon und Uhr und öffne die Einstellungen erneut.',
    technicalDetails: 'Technische Details',
    receivedAge: 'Vor {age} Min. empfangen',
    observedAge: 'Vor {age} Min. erfasst',
    readingTemperature: 'Temperatur',
    readingFeelsLike: 'Gefühlt',
    readingHigh: 'Höchstwert',
    readingLow: 'Tiefstwert',
    readingCondition: 'Wetterlage',
    readingHumidity: 'Luftfeuchtigkeit',
    readingRain: 'Regen',
    readingUv: 'UV-Index',
    readingBattery: 'Akku',
    readingTitle: 'Titel',
    readingArtist: 'Interpret',
    readingName: 'Name',
    phoneSource: 'Telefonakku',
    sourceEmpty: 'Nicht ausgewählt',
    sourceLoading: 'Wird geladen',
    sourceReady: 'Bereit',
    sourceUnavailable: 'Nicht verfügbar',
    sourceDenied: 'Berechtigung erforderlich',
    sourceUnsupported: 'Nicht unterstützte Daten',
    sourceDisabled: 'Plugin deaktiviert',
    sourcePlaying: 'Wiedergabe läuft',
    sourcePaused: 'Pausiert',
    sourceIdle: 'Keine Wiedergabe',
    sourceWaiting: 'Warten auf Pebble',
    saveSaved: 'Uhreinstellungen übermittelt.',
    savePending: 'Auf dem Telefon gespeichert; Warten auf die Uhr.',
    saveFailed: 'Auf dem Telefon gespeichert. Stelle die Verbindung wieder her und speichere erneut, um die Uhr zu aktualisieren.',
    saveNone: 'Änderungen werden nach dem Speichern übernommen.',
    saveSending: 'Wird gespeichert…',
    contrastHelp: 'Der Text könnte schwer lesbar sein. Wähle andere Text- und Hintergrundfarben.',
    previewSettingsNote: 'Die Vorschau verwendet die 64-Farben-Palette der Uhr.',
    previewCustomHelp: 'Eigene Farben werden näherungsweise dargestellt. Das Layout verwendet die native Darstellung der Uhr.',
    previewTimelineHelp: 'Der untere Bereich ist für Pebble Timeline reserviert.',
    noExample: 'Kein Beispiel verfügbar'
  },
  fr: {
    samplePreview: 'Aperçu d’exemple',
    sampleHelp: 'Exemples d’écrans, sans données en direct.',
    previewIdle: 'Au repos',
    previewMusic: 'Musique',
    previewNotification: 'Notification',
    previewTimeline: 'Chronologie',
    display: 'Affichage',
    theme: 'Thème',
    themeLight: 'Clair',
    themeDark: 'Sombre',
    themeCustom: 'Personnalisé',
    timeFormat: 'Format de l’heure',
    followPebble: 'Suivre Pebble',
    time24: 'Format 24 heures',
    largerText: 'Texte plus grand',
    languageHelp: 'La langue suit celle de votre montre.',
    twoReadings: 'Vos deux données',
    leftReading: 'Gauche',
    rightReading: 'Droite',
    musicNotifications: 'Musique et notifications',
    notifications: 'Notifications',
    notificationSummary: 'Application et titre',
    notificationAppsMode: 'Applications de notification',
    allApps: 'Toutes les applications',
    selectedApps: 'Applications sélectionnées',
    appFilterHelp: 'Saisissez les noms exacts des applications ou des paquets Android, séparés par des virgules. Par exemple : Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Saisissez au moins un nom d’application ou de paquet Android.',
    helpConnection: 'Aide et connexion',
    snapshotHelp: 'État à l’ouverture des réglages. Rouvrez les réglages pour l’actualiser.',
    permissionHelp: 'Autorisez l’accès dans Pebble, puis rouvrez les réglages.',
    pluginHelp: 'Vérifiez que le plugin correspondant est activé dans Pebble.',
    connectionHelp: 'Connectez le téléphone et la montre, puis rouvrez les réglages.',
    technicalDetails: 'Détails techniques',
    receivedAge: 'Reçu il y a {age} min',
    observedAge: 'Observé il y a {age} min',
    readingTemperature: 'Température',
    readingFeelsLike: 'Ressenti',
    readingHigh: 'Maximale',
    readingLow: 'Minimale',
    readingCondition: 'Conditions',
    readingHumidity: 'Humidité',
    readingRain: 'Pluie',
    readingUv: 'Indice UV',
    readingBattery: 'Batterie',
    readingTitle: 'Titre',
    readingArtist: 'Artiste',
    readingName: 'Nom',
    phoneSource: 'Batterie du téléphone',
    sourceEmpty: 'Non sélectionné',
    sourceLoading: 'Chargement',
    sourceReady: 'Prêt',
    sourceUnavailable: 'Indisponible',
    sourceDenied: 'Autorisation requise',
    sourceUnsupported: 'Données non prises en charge',
    sourceDisabled: 'Plugin désactivé',
    sourcePlaying: 'Lecture en cours',
    sourcePaused: 'En pause',
    sourceIdle: 'Aucune lecture',
    sourceWaiting: 'En attente de Pebble',
    saveSaved: 'Réglages de la montre transmis.',
    savePending: 'Enregistré sur le téléphone ; en attente de la montre.',
    saveFailed: 'Enregistré sur le téléphone. Rétablissez la connexion et enregistrez à nouveau pour mettre à jour la montre.',
    saveNone: 'Les modifications s’appliquent après l’enregistrement.',
    saveSending: 'Enregistrement…',
    contrastHelp: 'Le texte risque d’être difficile à lire. Choisissez d’autres couleurs de texte et de fond.',
    previewSettingsNote: 'L’aperçu utilise la palette de 64 couleurs de la montre.',
    previewCustomHelp: 'Les couleurs personnalisées sont approximatives. La mise en page utilise le rendu natif de la montre.',
    previewTimelineHelp: 'Le panneau inférieur est réservé à Pebble Timeline.',
    noExample: 'Aucun exemple disponible'
  },
  es: {
    samplePreview: 'Vista previa de ejemplo',
    sampleHelp: 'Pantallas de ejemplo, sin datos en directo.',
    previewIdle: 'En reposo',
    previewMusic: 'Música',
    previewNotification: 'Notificación',
    previewTimeline: 'Cronología',
    display: 'Pantalla',
    theme: 'Tema',
    themeLight: 'Claro',
    themeDark: 'Oscuro',
    themeCustom: 'Personalizado',
    timeFormat: 'Formato de hora',
    followPebble: 'Seguir Pebble',
    time24: 'Formato de 24 horas',
    largerText: 'Texto más grande',
    languageHelp: 'El idioma sigue el de tu reloj.',
    twoReadings: 'Tus dos lecturas',
    leftReading: 'Izquierda',
    rightReading: 'Derecha',
    musicNotifications: 'Música y notificaciones',
    notifications: 'Notificaciones',
    notificationSummary: 'Aplicación y título',
    notificationAppsMode: 'Aplicaciones de notificaciones',
    allApps: 'Todas las aplicaciones',
    selectedApps: 'Aplicaciones seleccionadas',
    appFilterHelp: 'Introduce los nombres exactos de las aplicaciones o de los paquetes de Android, separados por comas. Por ejemplo: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Introduce al menos un nombre de aplicación o de paquete de Android.',
    helpConnection: 'Ayuda y conexión',
    snapshotHelp: 'Estado al abrir los ajustes. Vuelve a abrirlos para actualizarlo.',
    permissionHelp: 'Permite el acceso en Pebble y vuelve a abrir los ajustes.',
    pluginHelp: 'Comprueba que el plugin correspondiente esté activado en Pebble.',
    connectionHelp: 'Conecta el teléfono y el reloj y vuelve a abrir los ajustes.',
    technicalDetails: 'Detalles técnicos',
    receivedAge: 'Recibido hace {age} min',
    observedAge: 'Observado hace {age} min',
    readingTemperature: 'Temperatura',
    readingFeelsLike: 'Sensación térmica',
    readingHigh: 'Máxima',
    readingLow: 'Mínima',
    readingCondition: 'Estado del tiempo',
    readingHumidity: 'Humedad',
    readingRain: 'Lluvia',
    readingUv: 'Índice UV',
    readingBattery: 'Batería',
    readingTitle: 'Título',
    readingArtist: 'Artista',
    readingName: 'Nombre',
    phoneSource: 'Batería del teléfono',
    sourceEmpty: 'Sin seleccionar',
    sourceLoading: 'Cargando',
    sourceReady: 'Listo',
    sourceUnavailable: 'No disponible',
    sourceDenied: 'Se requiere permiso',
    sourceUnsupported: 'Datos no compatibles',
    sourceDisabled: 'Plugin desactivado',
    sourcePlaying: 'Reproduciendo',
    sourcePaused: 'En pausa',
    sourceIdle: 'Sin reproducción',
    sourceWaiting: 'Esperando a Pebble',
    saveSaved: 'El reloj ha recibido sus ajustes.',
    savePending: 'Guardado en el teléfono; esperando al reloj.',
    saveFailed: 'Guardado en el teléfono. Restablece la conexión y guarda de nuevo para actualizar el reloj.',
    saveNone: 'Los cambios se aplican después de guardar.',
    saveSending: 'Guardando…',
    contrastHelp: 'El texto puede ser difícil de leer. Elige otros colores de texto y fondo.',
    previewSettingsNote: 'La vista previa usa la paleta de 64 colores del reloj.',
    previewCustomHelp: 'Los colores personalizados son aproximados. El diseño usa el renderizado nativo del reloj.',
    previewTimelineHelp: 'El panel inferior está reservado para Pebble Timeline.',
    noExample: 'No hay ningún ejemplo disponible'
  },
  it: {
    samplePreview: 'Anteprima di esempio',
    sampleHelp: 'Schermate di esempio, senza dati in tempo reale.',
    previewIdle: 'A riposo',
    previewMusic: 'Musica',
    previewNotification: 'Notifica',
    previewTimeline: 'Cronologia',
    display: 'Schermo',
    theme: 'Tema',
    themeLight: 'Chiaro',
    themeDark: 'Scuro',
    themeCustom: 'Personalizzato',
    timeFormat: 'Formato dell’ora',
    followPebble: 'Segui Pebble',
    time24: 'Formato a 24 ore',
    largerText: 'Testo più grande',
    languageHelp: 'La lingua segue quella dell’orologio.',
    twoReadings: 'I tuoi due valori',
    leftReading: 'Sinistra',
    rightReading: 'Destra',
    musicNotifications: 'Musica e notifiche',
    notifications: 'Notifiche',
    notificationSummary: 'App e titolo',
    notificationAppsMode: 'App per le notifiche',
    allApps: 'Tutte le app',
    selectedApps: 'App selezionate',
    appFilterHelp: 'Inserisci i nomi esatti delle app o dei pacchetti Android, separati da virgole. Ad esempio: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Inserisci almeno un nome di app o di pacchetto Android.',
    helpConnection: 'Aiuto e connessione',
    snapshotHelp: 'Stato all’apertura delle impostazioni. Riaprile per aggiornarlo.',
    permissionHelp: 'Consenti l’accesso in Pebble, poi riapri le impostazioni.',
    pluginHelp: 'Verifica che il plugin corrispondente sia attivo in Pebble.',
    connectionHelp: 'Collega il telefono e l’orologio, poi riapri le impostazioni.',
    technicalDetails: 'Dettagli tecnici',
    receivedAge: 'Ricevuto {age} min fa',
    observedAge: 'Osservato {age} min fa',
    readingTemperature: 'Temperatura',
    readingFeelsLike: 'Percepita',
    readingHigh: 'Massima',
    readingLow: 'Minima',
    readingCondition: 'Condizioni',
    readingHumidity: 'Umidità',
    readingRain: 'Pioggia',
    readingUv: 'Indice UV',
    readingBattery: 'Batteria',
    readingTitle: 'Titolo',
    readingArtist: 'Artista',
    readingName: 'Nome',
    phoneSource: 'Batteria del telefono',
    sourceEmpty: 'Non selezionato',
    sourceLoading: 'Caricamento',
    sourceReady: 'Pronto',
    sourceUnavailable: 'Non disponibile',
    sourceDenied: 'Autorizzazione necessaria',
    sourceUnsupported: 'Dati non supportati',
    sourceDisabled: 'Plugin disattivato',
    sourcePlaying: 'In riproduzione',
    sourcePaused: 'In pausa',
    sourceIdle: 'Nessuna riproduzione',
    sourceWaiting: 'In attesa di Pebble',
    saveSaved: 'L’orologio ha ricevuto le sue impostazioni.',
    savePending: 'Salvato sul telefono; in attesa dell’orologio.',
    saveFailed: 'Salvato sul telefono. Ripristina la connessione e salva di nuovo per aggiornare l’orologio.',
    saveNone: 'Le modifiche si applicano dopo il salvataggio.',
    saveSending: 'Salvataggio…',
    contrastHelp: 'Il testo potrebbe essere difficile da leggere. Scegli colori diversi per testo e sfondo.',
    previewSettingsNote: 'L’anteprima usa la tavolozza di 64 colori dell’orologio.',
    previewCustomHelp: 'I colori personalizzati sono approssimativi. Il layout usa il rendering nativo dell’orologio.',
    previewTimelineHelp: 'Il pannello inferiore è riservato a Pebble Timeline.',
    noExample: 'Nessun esempio disponibile'
  },
  pt: {
    samplePreview: 'Pré-visualização de exemplo',
    sampleHelp: 'Ecrãs de exemplo, sem dados em tempo real.',
    previewIdle: 'Em repouso',
    previewMusic: 'Música',
    previewNotification: 'Notificação',
    previewTimeline: 'Cronologia',
    display: 'Ecrã',
    theme: 'Tema',
    themeLight: 'Claro',
    themeDark: 'Escuro',
    themeCustom: 'Personalizado',
    timeFormat: 'Formato da hora',
    followPebble: 'Seguir Pebble',
    time24: 'Formato de 24 horas',
    largerText: 'Texto maior',
    languageHelp: 'O idioma segue o do relógio.',
    twoReadings: 'Os seus dois valores',
    leftReading: 'Esquerda',
    rightReading: 'Direita',
    musicNotifications: 'Música e notificações',
    notifications: 'Notificações',
    notificationSummary: 'Aplicação e título',
    notificationAppsMode: 'Aplicações de notificações',
    allApps: 'Todas as aplicações',
    selectedApps: 'Aplicações selecionadas',
    appFilterHelp: 'Introduza os nomes exatos das aplicações ou dos pacotes Android, separados por vírgulas. Por exemplo: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Introduza pelo menos um nome de aplicação ou de pacote Android.',
    helpConnection: 'Ajuda e ligação',
    snapshotHelp: 'Estado ao abrir as definições. Volte a abri-las para atualizar.',
    permissionHelp: 'Permita o acesso no Pebble e volte a abrir as definições.',
    pluginHelp: 'Verifique se o plugin correspondente está ativado no Pebble.',
    connectionHelp: 'Ligue o telemóvel e o relógio e volte a abrir as definições.',
    technicalDetails: 'Detalhes técnicos',
    receivedAge: 'Recebido há {age} min',
    observedAge: 'Observado há {age} min',
    readingTemperature: 'Temperatura',
    readingFeelsLike: 'Sensação térmica',
    readingHigh: 'Máxima',
    readingLow: 'Mínima',
    readingCondition: 'Condições',
    readingHumidity: 'Humidade',
    readingRain: 'Chuva',
    readingUv: 'Índice UV',
    readingBattery: 'Bateria',
    readingTitle: 'Título',
    readingArtist: 'Artista',
    readingName: 'Nome',
    phoneSource: 'Bateria do telemóvel',
    sourceEmpty: 'Não selecionado',
    sourceLoading: 'A carregar',
    sourceReady: 'Pronto',
    sourceUnavailable: 'Indisponível',
    sourceDenied: 'Permissão necessária',
    sourceUnsupported: 'Dados não suportados',
    sourceDisabled: 'Plugin desativado',
    sourcePlaying: 'Em reprodução',
    sourcePaused: 'Em pausa',
    sourceIdle: 'Sem reprodução',
    sourceWaiting: 'A aguardar o Pebble',
    saveSaved: 'O relógio recebeu as suas definições.',
    savePending: 'Guardado no telemóvel; a aguardar o relógio.',
    saveFailed: 'Guardado no telemóvel. Volte a ligar e guarde novamente para atualizar o relógio.',
    saveNone: 'As alterações são aplicadas depois de guardar.',
    saveSending: 'A guardar…',
    contrastHelp: 'O texto pode ser difícil de ler. Escolha outras cores para o texto e o fundo.',
    previewSettingsNote: 'A pré-visualização usa a paleta de 64 cores do relógio.',
    previewCustomHelp: 'As cores personalizadas são aproximadas. A disposição usa a renderização nativa do relógio.',
    previewTimelineHelp: 'O painel inferior está reservado para o Pebble Timeline.',
    noExample: 'Nenhum exemplo disponível'
  },
  nl: {
    samplePreview: 'Voorbeeldweergave',
    sampleHelp: 'Voorbeeldschermen, zonder actuele gegevens.',
    previewIdle: 'In rust',
    previewMusic: 'Muziek',
    previewNotification: 'Melding',
    previewTimeline: 'Tijdlijn',
    display: 'Weergave',
    theme: 'Thema',
    themeLight: 'Licht',
    themeDark: 'Donker',
    themeCustom: 'Aangepast',
    timeFormat: 'Tijdnotatie',
    followPebble: 'Pebble volgen',
    time24: '24-uursnotatie',
    largerText: 'Grotere tekst',
    languageHelp: 'De taal volgt je horloge.',
    twoReadings: 'Je twee metingen',
    leftReading: 'Links',
    rightReading: 'Rechts',
    musicNotifications: 'Muziek en meldingen',
    notifications: 'Meldingen',
    notificationSummary: 'App en titel',
    notificationAppsMode: 'Apps voor meldingen',
    allApps: 'Alle apps',
    selectedApps: 'Geselecteerde apps',
    appFilterHelp: 'Voer de exacte appnamen of Android-pakketnamen in, gescheiden door komma’s. Bijvoorbeeld: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Voer minstens één appnaam of Android-pakketnaam in.',
    helpConnection: 'Hulp en verbinding',
    snapshotHelp: 'Status bij het openen van de instellingen. Open ze opnieuw om te vernieuwen.',
    permissionHelp: 'Sta toegang toe in Pebble en open de instellingen opnieuw.',
    pluginHelp: 'Controleer of de bijbehorende plugin is ingeschakeld in Pebble.',
    connectionHelp: 'Verbind je telefoon en horloge en open de instellingen opnieuw.',
    technicalDetails: 'Technische details',
    receivedAge: '{age} min geleden ontvangen',
    observedAge: '{age} min geleden waargenomen',
    readingTemperature: 'Temperatuur',
    readingFeelsLike: 'Gevoelstemperatuur',
    readingHigh: 'Maximum',
    readingLow: 'Minimum',
    readingCondition: 'Weersomstandigheden',
    readingHumidity: 'Luchtvochtigheid',
    readingRain: 'Regen',
    readingUv: 'UV-index',
    readingBattery: 'Batterij',
    readingTitle: 'Titel',
    readingArtist: 'Artiest',
    readingName: 'Naam',
    phoneSource: 'Telefoonbatterij',
    sourceEmpty: 'Niet geselecteerd',
    sourceLoading: 'Laden',
    sourceReady: 'Gereed',
    sourceUnavailable: 'Niet beschikbaar',
    sourceDenied: 'Toestemming nodig',
    sourceUnsupported: 'Niet-ondersteunde gegevens',
    sourceDisabled: 'Plugin uitgeschakeld',
    sourcePlaying: 'Wordt afgespeeld',
    sourcePaused: 'Gepauzeerd',
    sourceIdle: 'Speelt niet',
    sourceWaiting: 'Wachten op Pebble',
    saveSaved: 'Het horloge heeft zijn instellingen ontvangen.',
    savePending: 'Opgeslagen op de telefoon; wachten op het horloge.',
    saveFailed: 'Opgeslagen op de telefoon. Verbind opnieuw en sla nogmaals op om het horloge bij te werken.',
    saveNone: 'Wijzigingen worden toegepast na het opslaan.',
    saveSending: 'Opslaan…',
    contrastHelp: 'De tekst is mogelijk moeilijk leesbaar. Kies andere tekst- en achtergrondkleuren.',
    previewSettingsNote: 'De voorbeeldweergave gebruikt het palet met 64 kleuren van het horloge.',
    previewCustomHelp: 'Aangepaste kleuren zijn bij benadering. De indeling gebruikt de eigen weergave van het horloge.',
    previewTimelineHelp: 'Het onderste paneel is gereserveerd voor Pebble Timeline.',
    noExample: 'Geen voorbeeld beschikbaar'
  },
  pl: {
    samplePreview: 'Przykładowy podgląd',
    sampleHelp: 'Przykładowe ekrany, bez danych na żywo.',
    previewIdle: 'W spoczynku',
    previewMusic: 'Muzyka',
    previewNotification: 'Powiadomienie',
    previewTimeline: 'Oś czasu',
    display: 'Wyświetlanie',
    theme: 'Motyw',
    themeLight: 'Jasny',
    themeDark: 'Ciemny',
    themeCustom: 'Własny',
    timeFormat: 'Format godziny',
    followPebble: 'Według Pebble',
    time24: 'Format 24-godzinny',
    largerText: 'Większy tekst',
    languageHelp: 'Język jest zgodny z ustawieniem zegarka.',
    twoReadings: 'Twoje dwa odczyty',
    leftReading: 'Lewy',
    rightReading: 'Prawy',
    musicNotifications: 'Muzyka i powiadomienia',
    notifications: 'Powiadomienia',
    notificationSummary: 'Aplikacja i tytuł',
    notificationAppsMode: 'Aplikacje z powiadomieniami',
    allApps: 'Wszystkie aplikacje',
    selectedApps: 'Wybrane aplikacje',
    appFilterHelp: 'Wpisz dokładne nazwy aplikacji lub pakietów Android, oddzielone przecinkami. Na przykład: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Wpisz co najmniej jedną nazwę aplikacji lub pakietu Android.',
    helpConnection: 'Pomoc i połączenie',
    snapshotHelp: 'Stan w chwili otwarcia ustawień. Otwórz ustawienia ponownie, aby go odświeżyć.',
    permissionHelp: 'Zezwól na dostęp w Pebble i ponownie otwórz ustawienia.',
    pluginHelp: 'Sprawdź, czy odpowiednia wtyczka jest włączona w Pebble.',
    connectionHelp: 'Połącz telefon z zegarkiem i ponownie otwórz ustawienia.',
    technicalDetails: 'Szczegóły techniczne',
    receivedAge: 'Odebrano {age} min temu',
    observedAge: 'Zaobserwowano {age} min temu',
    readingTemperature: 'Temperatura',
    readingFeelsLike: 'Odczuwalna',
    readingHigh: 'Maksimum',
    readingLow: 'Minimum',
    readingCondition: 'Warunki pogodowe',
    readingHumidity: 'Wilgotność',
    readingRain: 'Deszcz',
    readingUv: 'Indeks UV',
    readingBattery: 'Bateria',
    readingTitle: 'Tytuł',
    readingArtist: 'Artysta',
    readingName: 'Nazwa',
    phoneSource: 'Bateria telefonu',
    sourceEmpty: 'Nie wybrano',
    sourceLoading: 'Ładowanie',
    sourceReady: 'Gotowe',
    sourceUnavailable: 'Niedostępne',
    sourceDenied: 'Wymagane uprawnienie',
    sourceUnsupported: 'Nieobsługiwane dane',
    sourceDisabled: 'Wtyczka wyłączona',
    sourcePlaying: 'Odtwarzanie',
    sourcePaused: 'Wstrzymano',
    sourceIdle: 'Brak odtwarzania',
    sourceWaiting: 'Oczekiwanie na Pebble',
    saveSaved: 'Ustawienia zegarka dostarczone.',
    savePending: 'Zapisano w telefonie; oczekiwanie na zegarek.',
    saveFailed: 'Zapisano w telefonie. Połącz ponownie i zapisz jeszcze raz, aby zaktualizować zegarek.',
    saveNone: 'Zmiany zostaną zastosowane po zapisaniu.',
    saveSending: 'Zapisywanie…',
    contrastHelp: 'Tekst może być trudny do odczytania. Wybierz inne kolory tekstu i tła.',
    previewSettingsNote: 'Podgląd używa palety 64 kolorów zegarka.',
    previewCustomHelp: 'Własne kolory są przybliżone. Układ korzysta z natywnego sposobu wyświetlania zegarka.',
    previewTimelineHelp: 'Dolny panel jest zarezerwowany dla Pebble Timeline.',
    noExample: 'Brak dostępnego przykładu'
  },
  da: {
    samplePreview: 'Eksempelvisning',
    sampleHelp: 'Eksempelskærme, uden livedata.',
    previewIdle: 'I ro',
    previewMusic: 'Musik',
    previewNotification: 'Notifikation',
    previewTimeline: 'Tidslinje',
    display: 'Visning',
    theme: 'Tema',
    themeLight: 'Lyst',
    themeDark: 'Mørkt',
    themeCustom: 'Tilpasset',
    timeFormat: 'Tidsformat',
    followPebble: 'Følg Pebble',
    time24: '24-timers ur',
    largerText: 'Større tekst',
    languageHelp: 'Sproget følger dit ur.',
    twoReadings: 'Dine to målinger',
    leftReading: 'Venstre',
    rightReading: 'Højre',
    musicNotifications: 'Musik og notifikationer',
    notifications: 'Notifikationer',
    notificationSummary: 'App og titel',
    notificationAppsMode: 'Apps med notifikationer',
    allApps: 'Alle apps',
    selectedApps: 'Valgte apps',
    appFilterHelp: 'Indtast nøjagtige appnavne eller Android-pakkenavne adskilt af kommaer. For eksempel: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Indtast mindst ét appnavn eller Android-pakkenavn.',
    helpConnection: 'Hjælp og forbindelse',
    snapshotHelp: 'Status, da indstillingerne blev åbnet. Åbn dem igen for at opdatere.',
    permissionHelp: 'Tillad adgang i Pebble, og åbn indstillingerne igen.',
    pluginHelp: 'Kontrollér, at det relevante plugin er aktiveret i Pebble.',
    connectionHelp: 'Forbind telefonen og uret, og åbn indstillingerne igen.',
    technicalDetails: 'Tekniske oplysninger',
    receivedAge: 'Modtaget for {age} min siden',
    observedAge: 'Observeret for {age} min siden',
    readingTemperature: 'Temperatur',
    readingFeelsLike: 'Føles som',
    readingHigh: 'Højeste',
    readingLow: 'Laveste',
    readingCondition: 'Vejrforhold',
    readingHumidity: 'Luftfugtighed',
    readingRain: 'Regn',
    readingUv: 'UV-indeks',
    readingBattery: 'Batteri',
    readingTitle: 'Titel',
    readingArtist: 'Kunstner',
    readingName: 'Navn',
    phoneSource: 'Telefonens batteri',
    sourceEmpty: 'Ikke valgt',
    sourceLoading: 'Indlæser',
    sourceReady: 'Klar',
    sourceUnavailable: 'Ikke tilgængelig',
    sourceDenied: 'Tilladelse kræves',
    sourceUnsupported: 'Data understøttes ikke',
    sourceDisabled: 'Plugin deaktiveret',
    sourcePlaying: 'Afspiller',
    sourcePaused: 'Sat på pause',
    sourceIdle: 'Afspiller ikke',
    sourceWaiting: 'Venter på Pebble',
    saveSaved: 'Urindstillingerne er leveret.',
    savePending: 'Gemt på telefonen; venter på uret.',
    saveFailed: 'Gemt på telefonen. Opret forbindelsen igen, og gem igen for at opdatere uret.',
    saveNone: 'Ændringerne anvendes, når du gemmer.',
    saveSending: 'Gemmer…',
    contrastHelp: 'Teksten kan være svær at læse. Vælg andre tekst- og baggrundsfarver.',
    previewSettingsNote: 'Eksempelvisningen bruger urets palet med 64 farver.',
    previewCustomHelp: 'Tilpassede farver er omtrentlige. Layoutet bruger urets egen gengivelse.',
    previewTimelineHelp: 'Det nederste panel er reserveret til Pebble Timeline.',
    noExample: 'Intet eksempel tilgængeligt'
  },
  sv: {
    samplePreview: 'Exempelförhandsvisning',
    sampleHelp: 'Exempelskärmar, utan livedata.',
    previewIdle: 'I vila',
    previewMusic: 'Musik',
    previewNotification: 'Avisering',
    previewTimeline: 'Tidslinje',
    display: 'Visning',
    theme: 'Tema',
    themeLight: 'Ljust',
    themeDark: 'Mörkt',
    themeCustom: 'Anpassat',
    timeFormat: 'Tidsformat',
    followPebble: 'Följ Pebble',
    time24: '24-timmarsformat',
    largerText: 'Större text',
    languageHelp: 'Språket följer din klocka.',
    twoReadings: 'Dina två mätvärden',
    leftReading: 'Vänster',
    rightReading: 'Höger',
    musicNotifications: 'Musik och aviseringar',
    notifications: 'Aviseringar',
    notificationSummary: 'App och rubrik',
    notificationAppsMode: 'Appar med aviseringar',
    allApps: 'Alla appar',
    selectedApps: 'Valda appar',
    appFilterHelp: 'Ange exakta appnamn eller Android-paketnamn, åtskilda med kommatecken. Till exempel: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Ange minst ett appnamn eller Android-paketnamn.',
    helpConnection: 'Hjälp och anslutning',
    snapshotHelp: 'Status när inställningarna öppnades. Öppna dem igen för att uppdatera.',
    permissionHelp: 'Tillåt åtkomst i Pebble och öppna sedan inställningarna igen.',
    pluginHelp: 'Kontrollera att rätt insticksprogram är aktiverat i Pebble.',
    connectionHelp: 'Anslut telefonen och klockan och öppna sedan inställningarna igen.',
    technicalDetails: 'Tekniska uppgifter',
    receivedAge: 'Mottaget för {age} min sedan',
    observedAge: 'Observerat för {age} min sedan',
    readingTemperature: 'Temperatur',
    readingFeelsLike: 'Känns som',
    readingHigh: 'Högsta',
    readingLow: 'Lägsta',
    readingCondition: 'Väderförhållanden',
    readingHumidity: 'Luftfuktighet',
    readingRain: 'Regn',
    readingUv: 'UV-index',
    readingBattery: 'Batteri',
    readingTitle: 'Titel',
    readingArtist: 'Artist',
    readingName: 'Namn',
    phoneSource: 'Telefonens batteri',
    sourceEmpty: 'Inte valt',
    sourceLoading: 'Läser in',
    sourceReady: 'Klar',
    sourceUnavailable: 'Inte tillgängligt',
    sourceDenied: 'Behörighet krävs',
    sourceUnsupported: 'Data stöds inte',
    sourceDisabled: 'Insticksprogrammet är avaktiverat',
    sourcePlaying: 'Spelar',
    sourcePaused: 'Pausad',
    sourceIdle: 'Spelar inte',
    sourceWaiting: 'Väntar på Pebble',
    saveSaved: 'Klockinställningarna har levererats.',
    savePending: 'Sparat på telefonen; väntar på klockan.',
    saveFailed: 'Sparat på telefonen. Anslut igen och spara på nytt för att uppdatera klockan.',
    saveNone: 'Ändringarna tillämpas när du sparar.',
    saveSending: 'Sparar…',
    contrastHelp: 'Texten kan vara svår att läsa. Välj andra färger för text och bakgrund.',
    previewSettingsNote: 'Förhandsvisningen använder klockans palett med 64 färger.',
    previewCustomHelp: 'Anpassade färger är ungefärliga. Layouten använder klockans egen rendering.',
    previewTimelineHelp: 'Den nedre panelen är reserverad för Pebble Timeline.',
    noExample: 'Inget exempel tillgängligt'
  },
  no: {
    samplePreview: 'Eksempelforhåndsvisning',
    sampleHelp: 'Eksempelskjermer, uten sanntidsdata.',
    previewIdle: 'I ro',
    previewMusic: 'Musikk',
    previewNotification: 'Varsel',
    previewTimeline: 'Tidslinje',
    display: 'Visning',
    theme: 'Tema',
    themeLight: 'Lyst',
    themeDark: 'Mørkt',
    themeCustom: 'Tilpasset',
    timeFormat: 'Tidsformat',
    followPebble: 'Følg Pebble',
    time24: '24-timersformat',
    largerText: 'Større tekst',
    languageHelp: 'Språket følger klokken din.',
    twoReadings: 'Dine to målinger',
    leftReading: 'Venstre',
    rightReading: 'Høyre',
    musicNotifications: 'Musikk og varsler',
    notifications: 'Varsler',
    notificationSummary: 'App og tittel',
    notificationAppsMode: 'Apper med varsler',
    allApps: 'Alle apper',
    selectedApps: 'Valgte apper',
    appFilterHelp: 'Skriv inn nøyaktige appnavn eller Android-pakkenavn, atskilt med komma. For eksempel: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Skriv inn minst ett appnavn eller Android-pakkenavn.',
    helpConnection: 'Hjelp og tilkobling',
    snapshotHelp: 'Status da innstillingene ble åpnet. Åpne dem igjen for å oppdatere.',
    permissionHelp: 'Tillat tilgang i Pebble, og åpne innstillingene igjen.',
    pluginHelp: 'Kontroller at riktig programtillegg er aktivert i Pebble.',
    connectionHelp: 'Koble sammen telefonen og klokken, og åpne innstillingene igjen.',
    technicalDetails: 'Tekniske detaljer',
    receivedAge: 'Mottatt for {age} min siden',
    observedAge: 'Observert for {age} min siden',
    readingTemperature: 'Temperatur',
    readingFeelsLike: 'Føles som',
    readingHigh: 'Høyeste',
    readingLow: 'Laveste',
    readingCondition: 'Værforhold',
    readingHumidity: 'Luftfuktighet',
    readingRain: 'Regn',
    readingUv: 'UV-indeks',
    readingBattery: 'Batteri',
    readingTitle: 'Tittel',
    readingArtist: 'Artist',
    readingName: 'Navn',
    phoneSource: 'Telefonbatteri',
    sourceEmpty: 'Ikke valgt',
    sourceLoading: 'Laster',
    sourceReady: 'Klar',
    sourceUnavailable: 'Utilgjengelig',
    sourceDenied: 'Tillatelse kreves',
    sourceUnsupported: 'Data støttes ikke',
    sourceDisabled: 'Programtillegg deaktivert',
    sourcePlaying: 'Spiller',
    sourcePaused: 'Satt på pause',
    sourceIdle: 'Spiller ikke',
    sourceWaiting: 'Venter på Pebble',
    saveSaved: 'Klokkeinnstillingene er levert.',
    savePending: 'Lagret på telefonen; venter på klokken.',
    saveFailed: 'Lagret på telefonen. Koble til igjen og lagre på nytt for å oppdatere klokken.',
    saveNone: 'Endringene tas i bruk etter at du lagrer.',
    saveSending: 'Lagrer…',
    contrastHelp: 'Teksten kan være vanskelig å lese. Velg andre tekst- og bakgrunnsfarger.',
    previewSettingsNote: 'Forhåndsvisningen bruker klokkens palett med 64 farger.',
    previewCustomHelp: 'Tilpassede farger er omtrentlige. Oppsettet bruker klokkens egen gjengivelse.',
    previewTimelineHelp: 'Det nederste panelet er reservert for Pebble Timeline.',
    noExample: 'Ingen eksempler tilgjengelig'
  },
  fi: {
    samplePreview: 'Esimerkkiesikatselu',
    sampleHelp: 'Esimerkkinäkymiä, ei reaaliaikaisia tietoja.',
    previewIdle: 'Lepotila',
    previewMusic: 'Musiikki',
    previewNotification: 'Ilmoitus',
    previewTimeline: 'Aikajana',
    display: 'Näyttö',
    theme: 'Teema',
    themeLight: 'Vaalea',
    themeDark: 'Tumma',
    themeCustom: 'Mukautettu',
    timeFormat: 'Ajan esitystapa',
    followPebble: 'Pebblen mukaan',
    time24: '24 tunnin kello',
    largerText: 'Suurempi teksti',
    languageHelp: 'Kieli määräytyy kellon mukaan.',
    twoReadings: 'Kaksi arvoasi',
    leftReading: 'Vasen',
    rightReading: 'Oikea',
    musicNotifications: 'Musiikki ja ilmoitukset',
    notifications: 'Ilmoitukset',
    notificationSummary: 'Sovellus ja otsikko',
    notificationAppsMode: 'Ilmoitussovellukset',
    allApps: 'Kaikki sovellukset',
    selectedApps: 'Valitut sovellukset',
    appFilterHelp: 'Kirjoita sovellusten tarkat nimet tai Android-pakettinimet pilkuilla erotettuina. Esimerkiksi: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Kirjoita vähintään yksi sovelluksen nimi tai Android-pakettinimi.',
    helpConnection: 'Ohje ja yhteys',
    snapshotHelp: 'Tila asetusten avaushetkellä. Avaa asetukset uudelleen päivittääksesi tilan.',
    permissionHelp: 'Salli käyttöoikeus Pebblessä ja avaa asetukset uudelleen.',
    pluginHelp: 'Tarkista, että vastaava lisäosa on käytössä Pebblessä.',
    connectionHelp: 'Yhdistä puhelin ja kello ja avaa asetukset uudelleen.',
    technicalDetails: 'Tekniset tiedot',
    receivedAge: 'Vastaanotettu {age} min sitten',
    observedAge: 'Havaittu {age} min sitten',
    readingTemperature: 'Lämpötila',
    readingFeelsLike: 'Tuntuu kuin',
    readingHigh: 'Ylin',
    readingLow: 'Alin',
    readingCondition: 'Sää',
    readingHumidity: 'Ilmankosteus',
    readingRain: 'Sade',
    readingUv: 'UV-indeksi',
    readingBattery: 'Akku',
    readingTitle: 'Otsikko',
    readingArtist: 'Esittäjä',
    readingName: 'Nimi',
    phoneSource: 'Puhelimen akku',
    sourceEmpty: 'Ei valittu',
    sourceLoading: 'Ladataan',
    sourceReady: 'Valmis',
    sourceUnavailable: 'Ei saatavilla',
    sourceDenied: 'Lupa tarvitaan',
    sourceUnsupported: 'Tietoja ei tueta',
    sourceDisabled: 'Lisäosa poistettu käytöstä',
    sourcePlaying: 'Toistetaan',
    sourcePaused: 'Keskeytetty',
    sourceIdle: 'Ei toistoa',
    sourceWaiting: 'Odotetaan Pebbleä',
    saveSaved: 'Kellon asetukset toimitettu.',
    savePending: 'Tallennettu puhelimeen; odotetaan kelloa.',
    saveFailed: 'Tallennettu puhelimeen. Muodosta yhteys uudelleen ja tallenna vielä kerran päivittääksesi kellon.',
    saveNone: 'Muutokset tulevat voimaan tallennuksen jälkeen.',
    saveSending: 'Tallennetaan…',
    contrastHelp: 'Tekstiä voi olla vaikea lukea. Valitse toiset teksti- ja taustavärit.',
    previewSettingsNote: 'Esikatselu käyttää kellon 64 värin palettia.',
    previewCustomHelp: 'Mukautetut värit ovat likimääräisiä. Asettelu käyttää kellon omaa piirtotapaa.',
    previewTimelineHelp: 'Alapaneeli on varattu Pebble Timeline -toiminnolle.',
    noExample: 'Esimerkkiä ei ole saatavilla'
  },
  hu: {
    samplePreview: 'Mintaelőnézet',
    sampleHelp: 'Példaképernyők, nem élő adatok.',
    previewIdle: 'Nyugalmi állapot',
    previewMusic: 'Zene',
    previewNotification: 'Értesítés',
    previewTimeline: 'Idővonal',
    display: 'Kijelző',
    theme: 'Téma',
    themeLight: 'Világos',
    themeDark: 'Sötét',
    themeCustom: 'Egyéni',
    timeFormat: 'Időformátum',
    followPebble: 'A Pebble szerint',
    time24: '24 órás időformátum',
    largerText: 'Nagyobb szöveg',
    languageHelp: 'A nyelv az óra beállítását követi.',
    twoReadings: 'A két értéked',
    leftReading: 'Bal',
    rightReading: 'Jobb',
    musicNotifications: 'Zene és értesítések',
    notifications: 'Értesítések',
    notificationSummary: 'Alkalmazás és cím',
    notificationAppsMode: 'Értesítést küldő alkalmazások',
    allApps: 'Minden alkalmazás',
    selectedApps: 'Kiválasztott alkalmazások',
    appFilterHelp: 'Add meg az alkalmazások pontos nevét vagy Android-csomagnevét, vesszővel elválasztva. Például: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Adj meg legalább egy alkalmazásnevet vagy Android-csomagnevet.',
    helpConnection: 'Súgó és kapcsolat',
    snapshotHelp: 'Állapot a beállítások megnyitásakor. A frissítéshez nyisd meg újra a beállításokat.',
    permissionHelp: 'Engedélyezd a hozzáférést a Pebble-ben, majd nyisd meg újra a beállításokat.',
    pluginHelp: 'Ellenőrizd, hogy a megfelelő bővítmény engedélyezve van-e a Pebble-ben.',
    connectionHelp: 'Csatlakoztasd a telefont és az órát, majd nyisd meg újra a beállításokat.',
    technicalDetails: 'Műszaki részletek',
    receivedAge: 'Beérkezett {age} perce',
    observedAge: 'Megfigyelve {age} perce',
    readingTemperature: 'Hőmérséklet',
    readingFeelsLike: 'Hőérzet',
    readingHigh: 'Legmagasabb',
    readingLow: 'Legalacsonyabb',
    readingCondition: 'Időjárás',
    readingHumidity: 'Páratartalom',
    readingRain: 'Eső',
    readingUv: 'UV-index',
    readingBattery: 'Akkumulátor',
    readingTitle: 'Cím',
    readingArtist: 'Előadó',
    readingName: 'Név',
    phoneSource: 'Telefon akkumulátora',
    sourceEmpty: 'Nincs kiválasztva',
    sourceLoading: 'Betöltés',
    sourceReady: 'Kész',
    sourceUnavailable: 'Nem érhető el',
    sourceDenied: 'Engedély szükséges',
    sourceUnsupported: 'Nem támogatott adatok',
    sourceDisabled: 'Bővítmény letiltva',
    sourcePlaying: 'Lejátszás folyamatban',
    sourcePaused: 'Szüneteltetve',
    sourceIdle: 'Nincs lejátszás',
    sourceWaiting: 'Várakozás a Pebble-re',
    saveSaved: 'Az óra beállításai megérkeztek.',
    savePending: 'Mentve a telefonon; várakozás az órára.',
    saveFailed: 'Mentve a telefonon. Csatlakoztasd újra, majd ments ismét az óra frissítéséhez.',
    saveNone: 'A módosítások mentés után lépnek életbe.',
    saveSending: 'Mentés…',
    contrastHelp: 'A szöveg nehezen olvasható lehet. Válassz más szöveg- és háttérszínt.',
    previewSettingsNote: 'Az előnézet az óra 64 színű palettáját használja.',
    previewCustomHelp: 'Az egyéni színek közelítőek. Az elrendezés az óra saját megjelenítését használja.',
    previewTimelineHelp: 'Az alsó panel a Pebble Timeline számára van fenntartva.',
    noExample: 'Nincs elérhető példa'
  },
  ro: {
    samplePreview: 'Previzualizare exemplificativă',
    sampleHelp: 'Ecrane de exemplu, fără date în timp real.',
    previewIdle: 'În repaus',
    previewMusic: 'Muzică',
    previewNotification: 'Notificare',
    previewTimeline: 'Cronologie',
    display: 'Afișaj',
    theme: 'Temă',
    themeLight: 'Luminoasă',
    themeDark: 'Întunecată',
    themeCustom: 'Personalizată',
    timeFormat: 'Formatul orei',
    followPebble: 'Conform Pebble',
    time24: 'Format de 24 de ore',
    largerText: 'Text mai mare',
    languageHelp: 'Limba urmează setarea ceasului.',
    twoReadings: 'Cele două valori ale tale',
    leftReading: 'Stânga',
    rightReading: 'Dreapta',
    musicNotifications: 'Muzică și notificări',
    notifications: 'Notificări',
    notificationSummary: 'Aplicație și titlu',
    notificationAppsMode: 'Aplicații pentru notificări',
    allApps: 'Toate aplicațiile',
    selectedApps: 'Aplicații selectate',
    appFilterHelp: 'Introdu numele exacte ale aplicațiilor sau ale pachetelor Android, separate prin virgule. De exemplu: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'Introdu cel puțin un nume de aplicație sau de pachet Android.',
    helpConnection: 'Ajutor și conexiune',
    snapshotHelp: 'Starea la deschiderea setărilor. Redeschide setările pentru a o actualiza.',
    permissionHelp: 'Permite accesul în Pebble, apoi redeschide setările.',
    pluginHelp: 'Verifică dacă extensia corespunzătoare este activată în Pebble.',
    connectionHelp: 'Conectează telefonul și ceasul, apoi redeschide setările.',
    technicalDetails: 'Detalii tehnice',
    receivedAge: 'Primit acum {age} min',
    observedAge: 'Observat acum {age} min',
    readingTemperature: 'Temperatură',
    readingFeelsLike: 'Resimțită',
    readingHigh: 'Maximă',
    readingLow: 'Minimă',
    readingCondition: 'Condiții',
    readingHumidity: 'Umiditate',
    readingRain: 'Ploaie',
    readingUv: 'Indice UV',
    readingBattery: 'Baterie',
    readingTitle: 'Titlu',
    readingArtist: 'Artist',
    readingName: 'Nume',
    phoneSource: 'Bateria telefonului',
    sourceEmpty: 'Neselectat',
    sourceLoading: 'Se încarcă',
    sourceReady: 'Pregătit',
    sourceUnavailable: 'Indisponibil',
    sourceDenied: 'Este necesară permisiunea',
    sourceUnsupported: 'Date neacceptate',
    sourceDisabled: 'Extensie dezactivată',
    sourcePlaying: 'Se redă',
    sourcePaused: 'În pauză',
    sourceIdle: 'Nu se redă',
    sourceWaiting: 'Se așteaptă Pebble',
    saveSaved: 'Setările ceasului au fost primite.',
    savePending: 'Salvat pe telefon; se așteaptă ceasul.',
    saveFailed: 'Salvat pe telefon. Reconectează și salvează din nou pentru a actualiza ceasul.',
    saveNone: 'Modificările se aplică după salvare.',
    saveSending: 'Se salvează…',
    contrastHelp: 'Textul poate fi greu de citit. Alege alte culori pentru text și fundal.',
    previewSettingsNote: 'Previzualizarea folosește paleta de 64 de culori a ceasului.',
    previewCustomHelp: 'Culorile personalizate sunt aproximative. Aspectul folosește redarea nativă a ceasului.',
    previewTimelineHelp: 'Panoul inferior este rezervat pentru Pebble Timeline.',
    noExample: 'Niciun exemplu disponibil'
  },
  tr: {
    samplePreview: 'Örnek önizleme',
    sampleHelp: 'Örnek ekranlar, canlı veri değildir.',
    previewIdle: 'Boşta',
    previewMusic: 'Müzik',
    previewNotification: 'Bildirim',
    previewTimeline: 'Zaman çizelgesi',
    display: 'Ekran',
    theme: 'Tema',
    themeLight: 'Açık',
    themeDark: 'Koyu',
    themeCustom: 'Özel',
    timeFormat: 'Saat biçimi',
    followPebble: 'Pebble’a göre',
    time24: '24 saat biçimi',
    largerText: 'Daha büyük metin',
    languageHelp: 'Dil, saatinizin ayarına göre belirlenir.',
    twoReadings: 'İki değeriniz',
    leftReading: 'Sol',
    rightReading: 'Sağ',
    musicNotifications: 'Müzik ve bildirimler',
    notifications: 'Bildirimler',
    notificationSummary: 'Uygulama ve başlık',
    notificationAppsMode: 'Bildirim uygulamaları',
    allApps: 'Tüm uygulamalar',
    selectedApps: 'Seçili uygulamalar',
    appFilterHelp: 'Tam uygulama adlarını veya Android paket adlarını virgülle ayırarak girin. Örneğin: Signal, org.thoughtcrime.securesms',
    appFilterRequired: 'En az bir uygulama adı veya Android paket adı girin.',
    helpConnection: 'Yardım ve bağlantı',
    snapshotHelp: 'Ayarlar açıldığındaki durum. Yenilemek için ayarları yeniden açın.',
    permissionHelp: 'Pebble’da erişime izin verin, ardından ayarları yeniden açın.',
    pluginHelp: 'İlgili eklentinin Pebble’da etkin olduğundan emin olun.',
    connectionHelp: 'Telefonunuzu ve saatinizi bağlayın, ardından ayarları yeniden açın.',
    technicalDetails: 'Teknik ayrıntılar',
    receivedAge: '{age} dk önce alındı',
    observedAge: '{age} dk önce gözlemlendi',
    readingTemperature: 'Sıcaklık',
    readingFeelsLike: 'Hissedilen',
    readingHigh: 'En yüksek',
    readingLow: 'En düşük',
    readingCondition: 'Hava durumu',
    readingHumidity: 'Nem',
    readingRain: 'Yağmur',
    readingUv: 'UV indeksi',
    readingBattery: 'Pil',
    readingTitle: 'Başlık',
    readingArtist: 'Sanatçı',
    readingName: 'Ad',
    phoneSource: 'Telefon pili',
    sourceEmpty: 'Seçilmedi',
    sourceLoading: 'Yükleniyor',
    sourceReady: 'Hazır',
    sourceUnavailable: 'Kullanılamıyor',
    sourceDenied: 'İzin gerekli',
    sourceUnsupported: 'Desteklenmeyen veri',
    sourceDisabled: 'Eklenti devre dışı',
    sourcePlaying: 'Çalıyor',
    sourcePaused: 'Duraklatıldı',
    sourceIdle: 'Çalmıyor',
    sourceWaiting: 'Pebble bekleniyor',
    saveSaved: 'Saat ayarları iletildi.',
    savePending: 'Telefona kaydedildi; saat bekleniyor.',
    saveFailed: 'Telefona kaydedildi. Saati güncellemek için yeniden bağlanıp tekrar kaydedin.',
    saveNone: 'Değişiklikler kaydettikten sonra uygulanır.',
    saveSending: 'Kaydediliyor…',
    contrastHelp: 'Metni okumak zor olabilir. Farklı metin ve arka plan renkleri seçin.',
    previewSettingsNote: 'Önizleme, saatin 64 renkli paletini kullanır.',
    previewCustomHelp: 'Özel renkler yaklaşık olarak gösterilir. Düzen, saatin yerel çizimini kullanır.',
    previewTimelineHelp: 'Alt panel Pebble Timeline için ayrılmıştır.',
    noExample: 'Örnek yok'
  }
};
// Coherent settings copy for Dynamic 0.5.0. Every active string is present
// in each supported locale; source names and Android package IDs stay literal.
var UX_MESSAGES = {
  "en": {
    "content": "Content",
    "layoutPreview": "Layout & colour preview",
    "previewBanner": "Summary",
    "previewMessage": "Message",
    "previewDisabled": "This feature is disabled in your settings.",
    "previewUnknownFormat": "Example uses 24-hour time; the watch format is not known yet.",
    "previewSafeHelp": "Examples do not change your privacy settings.",
    "sharedReadingsHelp": "These are shared Pebble slots. Changing them also affects other watchfaces that use them.",
    "saveUnsaved": "Unsaved changes",
    "saveLastDelivered": "Last save delivered",
    "savePhoneWaiting": "Saved on phone—will apply when the watch reconnects.",
    "appAdd": "Add",
    "appRemove": "Remove {app}",
    "appEntryLabel": "App name or Android package",
    "appEntryHelp": "Add exact names one at a time. Entries are matched ignoring case.",
    "appDuplicate": "This app is already listed.",
    "appInvalid": "Use one app name or package at a time.",
    "sourceExpired": "Expired",
    "justObserved": "Just measured",
    "justReceived": "Just received",
    "readingSetupHelp": "Choose this reading in Pebble → Settings → Complications.",
    "sourceNoUpdateHelp": "Check the selected plugin in Pebble.",
    "accentContrastHelp": "The watch will adjust secondary ink when needed for readability.",
    "notificationSummaryHelp": "App summaries can include the sender or notification title, but not the message body.",
    "helpConnection": "Connection & help",
    "notificationSummary": "App and sender/title",
    "saveSaved": "Last save delivered",
    "savePending": "Saved on phone—will apply when the watch reconnects.",
    "saveFailed": "Saved on phone—will apply when the watch reconnects.",
    "appLimit": "Keep the complete app list within 160 characters."
  },
  "cs": {
    "content": "Obsah",
    "layoutPreview": "Náhled rozložení a barev",
    "previewBanner": "Souhrn",
    "previewMessage": "Zpráva",
    "previewDisabled": "Tato funkce je v nastavení vypnutá.",
    "previewUnknownFormat": "Ukázka používá 24hodinový čas; formát hodinek zatím není známý.",
    "previewSafeHelp": "Prohlížení ukázek nemění nastavení soukromí.",
    "sharedReadingsHelp": "Jde o sdílené pozice Pebble. Změna ovlivní také ostatní ciferníky, které je používají.",
    "saveUnsaved": "Neuložené změny",
    "saveLastDelivered": "Poslední uložení doručeno",
    "savePhoneWaiting": "Uloženo v telefonu—použije se po opětovném připojení hodinek.",
    "appAdd": "Přidat",
    "appRemove": "Odebrat {app}",
    "appEntryLabel": "Název aplikace nebo balíčku Androidu",
    "appEntryHelp": "Přidávejte přesné názvy po jednom. Na velikosti písmen nezáleží.",
    "appDuplicate": "Tato aplikace už je v seznamu.",
    "appInvalid": "Zadejte vždy jeden název aplikace nebo balíčku.",
    "sourceExpired": "Vypršelo",
    "justObserved": "Právě změřeno",
    "justReceived": "Právě přijato",
    "readingSetupHelp": "Tento údaj vyberte v Pebble → Nastavení → Komplikace.",
    "sourceNoUpdateHelp": "Zkontrolujte vybraný plugin v Pebble.",
    "accentContrastHelp": "Hodinky podle potřeby upraví barvu vedlejšího textu kvůli čitelnosti.",
    "notificationSummaryHelp": "Souhrn může obsahovat odesílatele nebo titulek oznámení, ale ne text zprávy.",
    "helpConnection": "Připojení a nápověda",
    "notificationSummary": "Aplikace a odesílatel/titulek",
    "saveSaved": "Poslední uložení doručeno",
    "savePending": "Uloženo v telefonu—použije se po opětovném připojení hodinek.",
    "saveFailed": "Uloženo v telefonu—použije se po opětovném připojení hodinek.",
    "appLimit": "Celý seznam aplikací musí mít nejvýše 160 znaků."
  },
  "sk": {
    "content": "Obsah",
    "layoutPreview": "Náhľad rozloženia a farieb",
    "previewBanner": "Súhrn",
    "previewMessage": "Správa",
    "previewDisabled": "Táto funkcia je v nastaveniach vypnutá.",
    "previewUnknownFormat": "Ukážka používa 24-hodinový čas; formát hodiniek zatiaľ nie je známy.",
    "previewSafeHelp": "Prezeranie ukážok nemení nastavenia súkromia.",
    "sharedReadingsHelp": "Ide o zdieľané pozície Pebble. Zmena ovplyvní aj ostatné ciferníky, ktoré ich používajú.",
    "saveUnsaved": "Neuložené zmeny",
    "saveLastDelivered": "Posledné uloženie doručené",
    "savePhoneWaiting": "Uložené v telefóne—použije sa po opätovnom pripojení hodiniek.",
    "appAdd": "Pridať",
    "appRemove": "Odobrať {app}",
    "appEntryLabel": "Názov aplikácie alebo balíka Androidu",
    "appEntryHelp": "Pridávajte presné názvy po jednom. Na veľkosti písmen nezáleží.",
    "appDuplicate": "Táto aplikácia už je v zozname.",
    "appInvalid": "Zadajte vždy jeden názov aplikácie alebo balíka.",
    "sourceExpired": "Vypršalo",
    "justObserved": "Práve zmerané",
    "justReceived": "Práve prijaté",
    "readingSetupHelp": "Tento údaj vyberte v Pebble → Nastavenia → Komplikácie.",
    "sourceNoUpdateHelp": "Skontrolujte vybraný plugin v Pebble.",
    "accentContrastHelp": "Hodinky podľa potreby upravia farbu vedľajšieho textu pre lepšiu čitateľnosť.",
    "notificationSummaryHelp": "Súhrn môže obsahovať odosielateľa alebo titulok oznámenia, ale nie text správy.",
    "helpConnection": "Pripojenie a pomoc",
    "notificationSummary": "Aplikácia a odosielateľ/titulok",
    "saveSaved": "Posledné uloženie doručené",
    "savePending": "Uložené v telefóne—použije sa po opätovnom pripojení hodiniek.",
    "saveFailed": "Uložené v telefóne—použije sa po opätovnom pripojení hodiniek.",
    "appLimit": "Celý zoznam aplikácií musí mať najviac 160 znakov."
  },
  "de": {
    "content": "Inhalt",
    "layoutPreview": "Vorschau von Layout und Farben",
    "previewBanner": "Zusammenfassung",
    "previewMessage": "Nachricht",
    "previewDisabled": "Diese Funktion ist in deinen Einstellungen ausgeschaltet.",
    "previewUnknownFormat": "Das Beispiel zeigt das 24-Stunden-Format; das Uhrenformat ist noch unbekannt.",
    "previewSafeHelp": "Beispiele ändern deine Datenschutzeinstellungen nicht.",
    "sharedReadingsHelp": "Dies sind gemeinsame Pebble-Felder. Änderungen betreffen auch andere Zifferblätter, die sie nutzen.",
    "saveUnsaved": "Ungespeicherte Änderungen",
    "saveLastDelivered": "Letzte Speicherung übertragen",
    "savePhoneWaiting": "Auf dem Telefon gespeichert—wird bei erneuter Verbindung mit der Uhr angewendet.",
    "appAdd": "Hinzufügen",
    "appRemove": "{app} entfernen",
    "appEntryLabel": "App-Name oder Android-Paket",
    "appEntryHelp": "Genaue Namen einzeln hinzufügen. Groß- und Kleinschreibung wird nicht unterschieden.",
    "appDuplicate": "Diese App ist bereits aufgeführt.",
    "appInvalid": "Jeweils einen App-Namen oder ein Paket eingeben.",
    "sourceExpired": "Abgelaufen",
    "justObserved": "Gerade gemessen",
    "justReceived": "Gerade empfangen",
    "readingSetupHelp": "Diesen Wert in Pebble → Einstellungen → Komplikationen auswählen.",
    "sourceNoUpdateHelp": "Prüfe das ausgewählte Plugin in Pebble.",
    "accentContrastHelp": "Die Uhr passt bei Bedarf die Farbe nachrangiger Texte für bessere Lesbarkeit an.",
    "notificationSummaryHelp": "App-Zusammenfassungen können Absender oder Benachrichtigungstitel enthalten, aber keinen Nachrichtentext.",
    "helpConnection": "Verbindung und Hilfe",
    "notificationSummary": "App und Absender/Titel",
    "saveSaved": "Letzte Speicherung übertragen",
    "savePending": "Auf dem Telefon gespeichert—wird bei erneuter Verbindung mit der Uhr angewendet.",
    "saveFailed": "Auf dem Telefon gespeichert—wird bei erneuter Verbindung mit der Uhr angewendet.",
    "appLimit": "Die gesamte App-Liste darf höchstens 160 Zeichen enthalten."
  },
  "fr": {
    "content": "Contenu",
    "layoutPreview": "Aperçu de la disposition et des couleurs",
    "previewBanner": "Résumé",
    "previewMessage": "Texte du message",
    "previewDisabled": "Cette fonction est désactivée dans vos réglages.",
    "previewUnknownFormat": "L’exemple utilise le format 24 heures ; celui de la montre n’est pas encore connu.",
    "previewSafeHelp": "Les exemples ne modifient pas vos réglages de confidentialité.",
    "sharedReadingsHelp": "Ces emplacements Pebble sont partagés. Les modifier affecte aussi les autres cadrans qui les utilisent.",
    "saveUnsaved": "Modifications non enregistrées",
    "saveLastDelivered": "Dernier enregistrement transmis",
    "savePhoneWaiting": "Enregistré sur le téléphone—sera appliqué à la reconnexion de la montre.",
    "appAdd": "Ajouter",
    "appRemove": "Retirer {app}",
    "appEntryLabel": "Nom d’application ou paquet Android",
    "appEntryHelp": "Ajoutez les noms exacts un par un. La casse n’est pas prise en compte.",
    "appDuplicate": "Cette application figure déjà dans la liste.",
    "appInvalid": "Saisissez un seul nom d’application ou paquet à la fois.",
    "sourceExpired": "Expiré",
    "justObserved": "Mesuré à l’instant",
    "justReceived": "Reçu à l’instant",
    "readingSetupHelp": "Choisissez cette donnée dans Pebble → Réglages → Complications.",
    "sourceNoUpdateHelp": "Vérifiez le plugin sélectionné dans Pebble.",
    "accentContrastHelp": "La montre ajuste au besoin la couleur du texte secondaire pour préserver sa lisibilité.",
    "notificationSummaryHelp": "Les résumés peuvent inclure l’expéditeur ou le titre de la notification, mais pas le corps du message.",
    "helpConnection": "Connexion et aide",
    "notificationSummary": "Application et expéditeur/titre",
    "saveSaved": "Dernier enregistrement transmis",
    "savePending": "Enregistré sur le téléphone—sera appliqué à la reconnexion de la montre.",
    "saveFailed": "Enregistré sur le téléphone—sera appliqué à la reconnexion de la montre.",
    "appLimit": "La liste complète des applications doit rester dans la limite de 160 caractères."
  },
  "es": {
    "content": "Contenido",
    "layoutPreview": "Vista de distribución y colores",
    "previewBanner": "Resumen",
    "previewMessage": "Mensaje",
    "previewDisabled": "Esta función está desactivada en tus ajustes.",
    "previewUnknownFormat": "El ejemplo usa el formato de 24 horas; aún no se conoce el del reloj.",
    "previewSafeHelp": "Los ejemplos no cambian tus ajustes de privacidad.",
    "sharedReadingsHelp": "Estas posiciones de Pebble son compartidas. Cambiarlas también afecta a otras esferas que las utilizan.",
    "saveUnsaved": "Cambios sin guardar",
    "saveLastDelivered": "Último guardado entregado",
    "savePhoneWaiting": "Guardado en el teléfono—se aplicará cuando el reloj vuelva a conectarse.",
    "appAdd": "Añadir",
    "appRemove": "Quitar {app}",
    "appEntryLabel": "Nombre de aplicación o paquete Android",
    "appEntryHelp": "Añade los nombres exactos uno a uno. No se distinguen mayúsculas de minúsculas.",
    "appDuplicate": "Esta aplicación ya está en la lista.",
    "appInvalid": "Introduce un solo nombre de aplicación o paquete cada vez.",
    "sourceExpired": "Caducado",
    "justObserved": "Recién medido",
    "justReceived": "Recién recibido",
    "readingSetupHelp": "Elige este dato en Pebble → Ajustes → Complicaciones.",
    "sourceNoUpdateHelp": "Comprueba el plugin seleccionado en Pebble.",
    "accentContrastHelp": "El reloj ajustará el color del texto secundario cuando sea necesario para mejorar la lectura.",
    "notificationSummaryHelp": "Los resúmenes pueden incluir el remitente o el título de la notificación, pero no el texto del mensaje.",
    "helpConnection": "Conexión y ayuda",
    "notificationSummary": "Aplicación y remitente/título",
    "saveSaved": "Último guardado entregado",
    "savePending": "Guardado en el teléfono—se aplicará cuando el reloj vuelva a conectarse.",
    "saveFailed": "Guardado en el teléfono—se aplicará cuando el reloj vuelva a conectarse.",
    "appLimit": "La lista completa de aplicaciones debe tener como máximo 160 caracteres."
  },
  "it": {
    "content": "Contenuti",
    "layoutPreview": "Anteprima di disposizione e colori",
    "previewBanner": "Riepilogo",
    "previewMessage": "Messaggio",
    "previewDisabled": "Questa funzione è disattivata nelle impostazioni.",
    "previewUnknownFormat": "L’esempio usa il formato a 24 ore; quello dell’orologio non è ancora noto.",
    "previewSafeHelp": "Gli esempi non modificano le impostazioni di privacy.",
    "sharedReadingsHelp": "Queste posizioni Pebble sono condivise. Modificarle influisce anche sugli altri quadranti che le usano.",
    "saveUnsaved": "Modifiche non salvate",
    "saveLastDelivered": "Ultimo salvataggio consegnato",
    "savePhoneWaiting": "Salvato sul telefono—verrà applicato quando l’orologio si riconnetterà.",
    "appAdd": "Aggiungi",
    "appRemove": "Rimuovi {app}",
    "appEntryLabel": "Nome dell’app o pacchetto Android",
    "appEntryHelp": "Aggiungi i nomi esatti uno alla volta. Maiuscole e minuscole non fanno differenza.",
    "appDuplicate": "Questa app è già nell’elenco.",
    "appInvalid": "Inserisci un solo nome di app o pacchetto alla volta.",
    "sourceExpired": "Scaduto",
    "justObserved": "Appena misurato",
    "justReceived": "Appena ricevuto",
    "readingSetupHelp": "Scegli questo dato in Pebble → Impostazioni → Complicazioni.",
    "sourceNoUpdateHelp": "Controlla il plugin selezionato in Pebble.",
    "accentContrastHelp": "L’orologio adatterà il colore del testo secondario quando necessario per facilitarne la lettura.",
    "notificationSummaryHelp": "I riepiloghi possono includere il mittente o il titolo della notifica, ma non il testo del messaggio.",
    "helpConnection": "Connessione e aiuto",
    "notificationSummary": "App e mittente/titolo",
    "saveSaved": "Ultimo salvataggio consegnato",
    "savePending": "Salvato sul telefono—verrà applicato quando l’orologio si riconnetterà.",
    "saveFailed": "Salvato sul telefono—verrà applicato quando l’orologio si riconnetterà.",
    "appLimit": "L’elenco completo delle app deve rimanere entro 160 caratteri."
  },
  "pt": {
    "content": "Conteúdo",
    "layoutPreview": "Pré-visualização do esquema e das cores",
    "previewBanner": "Resumo",
    "previewMessage": "Mensagem",
    "previewDisabled": "Esta função está desativada nas definições.",
    "previewUnknownFormat": "O exemplo usa o formato de 24 horas; o formato do relógio ainda não é conhecido.",
    "previewSafeHelp": "Os exemplos não alteram as definições de privacidade.",
    "sharedReadingsHelp": "Estas posições Pebble são partilhadas. Alterá-las também afeta outros mostradores que as usam.",
    "saveUnsaved": "Alterações por guardar",
    "saveLastDelivered": "Última gravação entregue",
    "savePhoneWaiting": "Guardado no telefone—será aplicado quando o relógio voltar a ligar-se.",
    "appAdd": "Adicionar",
    "appRemove": "Remover {app}",
    "appEntryLabel": "Nome da aplicação ou pacote Android",
    "appEntryHelp": "Adicione os nomes exatos um de cada vez. Maiúsculas e minúsculas não fazem diferença.",
    "appDuplicate": "Esta aplicação já está na lista.",
    "appInvalid": "Introduza apenas um nome de aplicação ou pacote de cada vez.",
    "sourceExpired": "Expirado",
    "justObserved": "Acabado de medir",
    "justReceived": "Acabado de receber",
    "readingSetupHelp": "Escolha este dado em Pebble → Definições → Complicações.",
    "sourceNoUpdateHelp": "Verifique o plugin selecionado no Pebble.",
    "accentContrastHelp": "O relógio ajustará a cor do texto secundário quando necessário para melhorar a leitura.",
    "notificationSummaryHelp": "Os resumos podem incluir o remetente ou o título da notificação, mas não o texto da mensagem.",
    "helpConnection": "Ligação e ajuda",
    "notificationSummary": "Aplicação e remetente/título",
    "saveSaved": "Última gravação entregue",
    "savePending": "Guardado no telefone—será aplicado quando o relógio voltar a ligar-se.",
    "saveFailed": "Guardado no telefone—será aplicado quando o relógio voltar a ligar-se.",
    "appLimit": "A lista completa de aplicações deve ter no máximo 160 caracteres."
  },
  "nl": {
    "content": "Inhoud",
    "layoutPreview": "Voorbeeld van indeling en kleuren",
    "previewBanner": "Overzicht",
    "previewMessage": "Bericht",
    "previewDisabled": "Deze functie staat uit in je instellingen.",
    "previewUnknownFormat": "Het voorbeeld gebruikt de 24-uursnotatie; de notatie van het horloge is nog onbekend.",
    "previewSafeHelp": "Voorbeelden veranderen je privacyinstellingen niet.",
    "sharedReadingsHelp": "Dit zijn gedeelde Pebble-posities. Wijzigingen gelden ook voor andere wijzerplaten die ze gebruiken.",
    "saveUnsaved": "Niet-opgeslagen wijzigingen",
    "saveLastDelivered": "Laatste opslag afgeleverd",
    "savePhoneWaiting": "Op de telefoon opgeslagen—wordt toegepast zodra het horloge opnieuw verbinding maakt.",
    "appAdd": "Toevoegen",
    "appRemove": "{app} verwijderen",
    "appEntryLabel": "App-naam of Android-pakket",
    "appEntryHelp": "Voeg exacte namen één voor één toe. Hoofdletters en kleine letters worden gelijk behandeld.",
    "appDuplicate": "Deze app staat al in de lijst.",
    "appInvalid": "Voer één app-naam of pakket tegelijk in.",
    "sourceExpired": "Verlopen",
    "justObserved": "Zojuist gemeten",
    "justReceived": "Zojuist ontvangen",
    "readingSetupHelp": "Kies deze waarde in Pebble → Instellingen → Complicaties.",
    "sourceNoUpdateHelp": "Controleer de geselecteerde plug-in in Pebble.",
    "accentContrastHelp": "Het horloge past de kleur van secundaire tekst zo nodig aan voor betere leesbaarheid.",
    "notificationSummaryHelp": "App-overzichten kunnen de afzender of meldingstitel bevatten, maar niet de berichttekst.",
    "helpConnection": "Verbinding en hulp",
    "notificationSummary": "App en afzender/titel",
    "saveSaved": "Laatste opslag afgeleverd",
    "savePending": "Op de telefoon opgeslagen—wordt toegepast zodra het horloge opnieuw verbinding maakt.",
    "saveFailed": "Op de telefoon opgeslagen—wordt toegepast zodra het horloge opnieuw verbinding maakt.",
    "appLimit": "Houd de volledige applijst binnen 160 tekens."
  },
  "pl": {
    "content": "Treść",
    "layoutPreview": "Podgląd układu i kolorów",
    "previewBanner": "Podsumowanie",
    "previewMessage": "Wiadomość",
    "previewDisabled": "Ta funkcja jest wyłączona w ustawieniach.",
    "previewUnknownFormat": "Przykład używa formatu 24-godzinnego; format zegarka nie jest jeszcze znany.",
    "previewSafeHelp": "Podgląd przykładów nie zmienia ustawień prywatności.",
    "sharedReadingsHelp": "To wspólne pozycje Pebble. Ich zmiana wpływa też na inne tarcze, które z nich korzystają.",
    "saveUnsaved": "Niezapisane zmiany",
    "saveLastDelivered": "Ostatni zapis dostarczony",
    "savePhoneWaiting": "Zapisano w telefonie—zostanie zastosowane po ponownym połączeniu zegarka.",
    "appAdd": "Dodaj",
    "appRemove": "Usuń {app}",
    "appEntryLabel": "Nazwa aplikacji lub pakiet Androida",
    "appEntryHelp": "Dodawaj dokładne nazwy pojedynczo. Wielkość liter nie ma znaczenia.",
    "appDuplicate": "Ta aplikacja jest już na liście.",
    "appInvalid": "Wpisz jedną nazwę aplikacji lub pakietu naraz.",
    "sourceExpired": "Wygasło",
    "justObserved": "Właśnie zmierzono",
    "justReceived": "Właśnie odebrano",
    "readingSetupHelp": "Wybierz tę wartość w Pebble → Ustawienia → Komplikacje.",
    "sourceNoUpdateHelp": "Sprawdź wybraną wtyczkę w Pebble.",
    "accentContrastHelp": "Zegarek w razie potrzeby dostosuje kolor tekstu pomocniczego, aby zachować czytelność.",
    "notificationSummaryHelp": "Podsumowania mogą zawierać nadawcę lub tytuł powiadomienia, ale nie treść wiadomości.",
    "helpConnection": "Połączenie i pomoc",
    "notificationSummary": "Aplikacja i nadawca/tytuł",
    "saveSaved": "Ostatni zapis dostarczony",
    "savePending": "Zapisano w telefonie—zostanie zastosowane po ponownym połączeniu zegarka.",
    "saveFailed": "Zapisano w telefonie—zostanie zastosowane po ponownym połączeniu zegarka.",
    "appLimit": "Cała lista aplikacji może mieć najwyżej 160 znaków."
  },
  "da": {
    "content": "Indhold",
    "layoutPreview": "Forhåndsvisning af layout og farver",
    "previewBanner": "Oversigt",
    "previewMessage": "Besked",
    "previewDisabled": "Denne funktion er slået fra i dine indstillinger.",
    "previewUnknownFormat": "Eksemplet bruger 24-timers format; urets format er endnu ukendt.",
    "previewSafeHelp": "Eksempler ændrer ikke dine privatlivsindstillinger.",
    "sharedReadingsHelp": "Dette er delte Pebble-pladser. Ændringer påvirker også andre urskiver, der bruger dem.",
    "saveUnsaved": "Ikke-gemte ændringer",
    "saveLastDelivered": "Seneste gemning leveret",
    "savePhoneWaiting": "Gemt på telefonen—anvendes, når uret opretter forbindelse igen.",
    "appAdd": "Tilføj",
    "appRemove": "Fjern {app}",
    "appEntryLabel": "Appnavn eller Android-pakke",
    "appEntryHelp": "Tilføj præcise navne ét ad gangen. Der skelnes ikke mellem store og små bogstaver.",
    "appDuplicate": "Denne app er allerede på listen.",
    "appInvalid": "Indtast ét appnavn eller én pakke ad gangen.",
    "sourceExpired": "Udløbet",
    "justObserved": "Netop målt",
    "justReceived": "Netop modtaget",
    "readingSetupHelp": "Vælg denne værdi i Pebble → Indstillinger → Komplikationer.",
    "sourceNoUpdateHelp": "Kontrollér det valgte plugin i Pebble.",
    "accentContrastHelp": "Uret tilpasser farven på sekundær tekst efter behov, så den er læselig.",
    "notificationSummaryHelp": "Appoversigter kan indeholde afsenderen eller meddelelsens titel, men ikke beskedteksten.",
    "helpConnection": "Forbindelse og hjælp",
    "notificationSummary": "App og afsender/titel",
    "saveSaved": "Seneste gemning leveret",
    "savePending": "Gemt på telefonen—anvendes, når uret opretter forbindelse igen.",
    "saveFailed": "Gemt på telefonen—anvendes, når uret opretter forbindelse igen.",
    "appLimit": "Den samlede appliste må højst indeholde 160 tegn."
  },
  "sv": {
    "content": "Innehåll",
    "layoutPreview": "Förhandsvisning av layout och färger",
    "previewBanner": "Sammanfattning",
    "previewMessage": "Meddelande",
    "previewDisabled": "Den här funktionen är avstängd i dina inställningar.",
    "previewUnknownFormat": "Exemplet använder 24-timmarsformat; klockans format är ännu okänt.",
    "previewSafeHelp": "Exemplen ändrar inte dina integritetsinställningar.",
    "sharedReadingsHelp": "Detta är delade Pebble-platser. Ändringar påverkar också andra urtavlor som använder dem.",
    "saveUnsaved": "Osparade ändringar",
    "saveLastDelivered": "Senaste sparningen levererad",
    "savePhoneWaiting": "Sparat på telefonen—tillämpas när klockan ansluter igen.",
    "appAdd": "Lägg till",
    "appRemove": "Ta bort {app}",
    "appEntryLabel": "Appnamn eller Android-paket",
    "appEntryHelp": "Lägg till exakta namn ett i taget. Stora och små bokstäver behandlas lika.",
    "appDuplicate": "Den här appen finns redan i listan.",
    "appInvalid": "Ange ett appnamn eller paket i taget.",
    "sourceExpired": "Utgånget",
    "justObserved": "Nyss uppmätt",
    "justReceived": "Nyss mottaget",
    "readingSetupHelp": "Välj detta värde i Pebble → Inställningar → Komplikationer.",
    "sourceNoUpdateHelp": "Kontrollera valt plugin i Pebble.",
    "accentContrastHelp": "Klockan anpassar färgen på sekundär text vid behov för bättre läsbarhet.",
    "notificationSummaryHelp": "Appsammanfattningar kan innehålla avsändaren eller aviseringsrubriken, men inte meddelandetexten.",
    "helpConnection": "Anslutning och hjälp",
    "notificationSummary": "App och avsändare/rubrik",
    "saveSaved": "Senaste sparningen levererad",
    "savePending": "Sparat på telefonen—tillämpas när klockan ansluter igen.",
    "saveFailed": "Sparat på telefonen—tillämpas när klockan ansluter igen.",
    "appLimit": "Hela applistan får innehålla högst 160 tecken."
  },
  "no": {
    "content": "Innhold",
    "layoutPreview": "Forhåndsvisning av oppsett og farger",
    "previewBanner": "Sammendrag",
    "previewMessage": "Melding",
    "previewDisabled": "Denne funksjonen er slått av i innstillingene.",
    "previewUnknownFormat": "Eksemplet bruker 24-timersformat; klokkens format er ennå ukjent.",
    "previewSafeHelp": "Eksemplene endrer ikke personverninnstillingene dine.",
    "sharedReadingsHelp": "Dette er delte Pebble-plasser. Endringer påvirker også andre urskiver som bruker dem.",
    "saveUnsaved": "Ulagrede endringer",
    "saveLastDelivered": "Siste lagring levert",
    "savePhoneWaiting": "Lagret på telefonen—tas i bruk når klokken kobler til igjen.",
    "appAdd": "Legg til",
    "appRemove": "Fjern {app}",
    "appEntryLabel": "Appnavn eller Android-pakke",
    "appEntryHelp": "Legg til nøyaktige navn ett om gangen. Store og små bokstaver behandles likt.",
    "appDuplicate": "Denne appen finnes allerede i listen.",
    "appInvalid": "Skriv inn ett appnavn eller én pakke om gangen.",
    "sourceExpired": "Utløpt",
    "justObserved": "Nettopp målt",
    "justReceived": "Nettopp mottatt",
    "readingSetupHelp": "Velg denne verdien i Pebble → Innstillinger → Komplikasjoner.",
    "sourceNoUpdateHelp": "Kontroller valgt programtillegg i Pebble.",
    "accentContrastHelp": "Klokken tilpasser fargen på sekundær tekst ved behov for bedre lesbarhet.",
    "notificationSummaryHelp": "Appsammendrag kan inneholde avsenderen eller varseltittelen, men ikke meldingsteksten.",
    "helpConnection": "Tilkobling og hjelp",
    "notificationSummary": "App og avsender/tittel",
    "saveSaved": "Siste lagring levert",
    "savePending": "Lagret på telefonen—tas i bruk når klokken kobler til igjen.",
    "saveFailed": "Lagret på telefonen—tas i bruk når klokken kobler til igjen.",
    "appLimit": "Hele applisten kan inneholde høyst 160 tegn."
  },
  "fi": {
    "content": "Sisältö",
    "layoutPreview": "Asettelun ja värien esikatselu",
    "previewBanner": "Yhteenveto",
    "previewMessage": "Viesti",
    "previewDisabled": "Tämä toiminto on poistettu käytöstä asetuksissasi.",
    "previewUnknownFormat": "Esimerkki käyttää 24 tunnin aikaa; kellon aikamuoto ei ole vielä tiedossa.",
    "previewSafeHelp": "Esimerkit eivät muuta yksityisyysasetuksiasi.",
    "sharedReadingsHelp": "Nämä ovat yhteisiä Pebble-paikkoja. Muutokset vaikuttavat myös muihin niitä käyttäviin kellotauluihin.",
    "saveUnsaved": "Tallentamattomia muutoksia",
    "saveLastDelivered": "Viimeisin tallennus toimitettu",
    "savePhoneWaiting": "Tallennettu puhelimeen—otetaan käyttöön, kun kello muodostaa yhteyden uudelleen.",
    "appAdd": "Lisää",
    "appRemove": "Poista {app}",
    "appEntryLabel": "Sovelluksen nimi tai Android-paketti",
    "appEntryHelp": "Lisää tarkat nimet yksi kerrallaan. Kirjainkoolla ei ole merkitystä.",
    "appDuplicate": "Tämä sovellus on jo luettelossa.",
    "appInvalid": "Anna yksi sovelluksen tai paketin nimi kerrallaan.",
    "sourceExpired": "Vanhentunut",
    "justObserved": "Juuri mitattu",
    "justReceived": "Juuri vastaanotettu",
    "readingSetupHelp": "Valitse tämä arvo kohdassa Pebble → Asetukset → Komplikaatiot.",
    "sourceNoUpdateHelp": "Tarkista valittu liitännäinen Pebblessä.",
    "accentContrastHelp": "Kello säätää tarvittaessa toissijaisen tekstin väriä luettavuuden parantamiseksi.",
    "notificationSummaryHelp": "Sovellusyhteenvedot voivat sisältää lähettäjän tai ilmoituksen otsikon, mutta eivät viestin tekstiä.",
    "helpConnection": "Yhteys ja ohje",
    "notificationSummary": "Sovellus ja lähettäjä/otsikko",
    "saveSaved": "Viimeisin tallennus toimitettu",
    "savePending": "Tallennettu puhelimeen—otetaan käyttöön, kun kello muodostaa yhteyden uudelleen.",
    "saveFailed": "Tallennettu puhelimeen—otetaan käyttöön, kun kello muodostaa yhteyden uudelleen.",
    "appLimit": "Koko sovellusluettelo saa sisältää enintään 160 merkkiä."
  },
  "hu": {
    "content": "Tartalom",
    "layoutPreview": "Elrendezés és színek előnézete",
    "previewBanner": "Összegzés",
    "previewMessage": "Üzenet",
    "previewDisabled": "Ez a funkció ki van kapcsolva a beállításokban.",
    "previewUnknownFormat": "A példa 24 órás formátumot használ; az óra formátuma még nem ismert.",
    "previewSafeHelp": "A példák nem változtatják meg az adatvédelmi beállításokat.",
    "sharedReadingsHelp": "Ezek közös Pebble-helyek. Módosításuk a többi, ezeket használó számlapra is hat.",
    "saveUnsaved": "Nem mentett módosítások",
    "saveLastDelivered": "Legutóbbi mentés kézbesítve",
    "savePhoneWaiting": "A telefonon mentve—az óra újracsatlakozásakor lép érvénybe.",
    "appAdd": "Hozzáadás",
    "appRemove": "{app} eltávolítása",
    "appEntryLabel": "Alkalmazásnév vagy Android-csomag",
    "appEntryHelp": "A pontos neveket egyenként add hozzá. A kis- és nagybetűk nem számítanak.",
    "appDuplicate": "Ez az alkalmazás már szerepel a listában.",
    "appInvalid": "Egyszerre egy alkalmazás- vagy csomagnevet adj meg.",
    "sourceExpired": "Lejárt",
    "justObserved": "Most mérve",
    "justReceived": "Most érkezett",
    "readingSetupHelp": "Ezt az értéket itt válaszd ki: Pebble → Beállítások → Komplikációk.",
    "sourceNoUpdateHelp": "Ellenőrizd a kiválasztott bővítményt a Pebble-ben.",
    "accentContrastHelp": "Az óra szükség esetén módosítja a másodlagos szöveg színét az olvashatóság érdekében.",
    "notificationSummaryHelp": "Az alkalmazásösszegzések tartalmazhatják a feladót vagy az értesítés címét, de az üzenet szövegét nem.",
    "helpConnection": "Kapcsolat és súgó",
    "notificationSummary": "Alkalmazás és feladó/cím",
    "saveSaved": "Legutóbbi mentés kézbesítve",
    "savePending": "A telefonon mentve—az óra újracsatlakozásakor lép érvénybe.",
    "saveFailed": "A telefonon mentve—az óra újracsatlakozásakor lép érvénybe.",
    "appLimit": "A teljes alkalmazáslista legfeljebb 160 karakter lehet."
  },
  "ro": {
    "content": "Conținut",
    "layoutPreview": "Previzualizarea aspectului și culorilor",
    "previewBanner": "Rezumat",
    "previewMessage": "Mesaj",
    "previewDisabled": "Această funcție este dezactivată în setări.",
    "previewUnknownFormat": "Exemplul folosește formatul de 24 de ore; formatul ceasului nu este încă cunoscut.",
    "previewSafeHelp": "Exemplele nu modifică setările de confidențialitate.",
    "sharedReadingsHelp": "Aceste poziții Pebble sunt comune. Modificarea lor afectează și alte cadrane care le folosesc.",
    "saveUnsaved": "Modificări nesalvate",
    "saveLastDelivered": "Ultima salvare livrată",
    "savePhoneWaiting": "Salvat pe telefon—se va aplica atunci când ceasul se reconectează.",
    "appAdd": "Adaugă",
    "appRemove": "Elimină {app}",
    "appEntryLabel": "Numele aplicației sau pachetul Android",
    "appEntryHelp": "Adaugă numele exacte pe rând. Nu se face diferență între majuscule și minuscule.",
    "appDuplicate": "Această aplicație este deja în listă.",
    "appInvalid": "Introdu un singur nume de aplicație sau de pachet odată.",
    "sourceExpired": "Expirat",
    "justObserved": "Tocmai măsurat",
    "justReceived": "Tocmai primit",
    "readingSetupHelp": "Alege această valoare în Pebble → Setări → Complicații.",
    "sourceNoUpdateHelp": "Verifică pluginul selectat în Pebble.",
    "accentContrastHelp": "Ceasul va ajusta culoarea textului secundar când este necesar pentru lizibilitate.",
    "notificationSummaryHelp": "Rezumatele pot include expeditorul sau titlul notificării, dar nu și textul mesajului.",
    "helpConnection": "Conexiune și ajutor",
    "notificationSummary": "Aplicație și expeditor/titlu",
    "saveSaved": "Ultima salvare livrată",
    "savePending": "Salvat pe telefon—se va aplica atunci când ceasul se reconectează.",
    "saveFailed": "Salvat pe telefon—se va aplica atunci când ceasul se reconectează.",
    "appLimit": "Lista completă de aplicații trebuie să aibă cel mult 160 de caractere."
  },
  "tr": {
    "content": "İçerik",
    "layoutPreview": "Düzen ve renk önizlemesi",
    "previewBanner": "Özet",
    "previewMessage": "İleti",
    "previewDisabled": "Bu özellik ayarlarınızda kapalı.",
    "previewUnknownFormat": "Örnek 24 saat biçimini kullanır; saatin biçimi henüz bilinmiyor.",
    "previewSafeHelp": "Örnekler gizlilik ayarlarınızı değiştirmez.",
    "sharedReadingsHelp": "Bunlar paylaşılan Pebble alanlarıdır. Değişiklikler, bunları kullanan diğer saat yüzlerini de etkiler.",
    "saveUnsaved": "Kaydedilmemiş değişiklikler",
    "saveLastDelivered": "Son kayıt iletildi",
    "savePhoneWaiting": "Telefona kaydedildi—saat yeniden bağlandığında uygulanacak.",
    "appAdd": "Ekle",
    "appRemove": "{app} uygulamasını kaldır",
    "appEntryLabel": "Uygulama adı veya Android paketi",
    "appEntryHelp": "Tam adları birer birer ekleyin. Büyük ve küçük harfler aynı kabul edilir.",
    "appDuplicate": "Bu uygulama zaten listede.",
    "appInvalid": "Bir seferde tek bir uygulama veya paket adı girin.",
    "sourceExpired": "Süresi doldu",
    "justObserved": "Az önce ölçüldü",
    "justReceived": "Az önce alındı",
    "readingSetupHelp": "Bu değeri Pebble → Ayarlar → Komplikasyonlar bölümünden seçin.",
    "sourceNoUpdateHelp": "Pebble’da seçili eklentiyi kontrol edin.",
    "accentContrastHelp": "Saat, okunabilirlik için gerektiğinde ikincil metin rengini ayarlar.",
    "notificationSummaryHelp": "Uygulama özetleri göndereni veya bildirim başlığını içerebilir, ancak ileti metnini içermez.",
    "helpConnection": "Bağlantı ve yardım",
    "notificationSummary": "Uygulama ve gönderen/başlık",
    "saveSaved": "Son kayıt iletildi",
    "savePending": "Telefona kaydedildi—saat yeniden bağlandığında uygulanacak.",
    "saveFailed": "Telefona kaydedildi—saat yeniden bağlandığında uygulanacak.",
    "appLimit": "Tam uygulama listesi en fazla 160 karakter içermelidir."
  }
};

// Privacy, alerts and colour sharing are kept together so each locale expresses
// the same boundaries: app-only hides people and text; colour codes carry no
// alert or privacy preferences; Quiet Time belongs to the watch.
var ALERT_MESSAGES = {
  en: {
    notificationAppOnly: 'App name only',
    notificationAppOnlyHelp: 'Shows the app without sender or message text.',
    notificationVibration: "Additional vibration",
    vibrationShort: 'Short pulse',
    vibrationDouble: 'Double pulse',
    vibrationHelp: "One additional vibration per new notification burst, using your app filter. Respects Quiet Time. Turn this off if Pebble already vibrates for those notifications.",
    nightPalette: 'Quiet Time colours',
    nightPaletteHelp: 'Use these watch colours while Pebble Quiet Time is active.',
    nightBackground: 'Quiet Time background',
    nightText: 'Quiet Time text',
    nightAccent: 'Quiet Time accent',
    paletteCode: 'Share colours',
    paletteCodeHelp: 'This code contains only background, text and accent colours.',
    paletteCopy: 'Copy code',
    paletteApply: 'Apply code',
    paletteCopied: 'Colour code copied.',
    paletteSelectCopy: 'Select and copy the colour code.',
    paletteInvalid: 'Use a code like DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Colours applied. Save to send them to your watch.',
    paletteInput: 'Colour code',
    watchfaceBanners: "Notification activity",
    notificationsHelp: "New notifications use the same activity priority and primary/secondary layouts. Allow notification access in Pebble. Pebble’s system notifications remain separate.",
    previewPalette: "Preview colours",
    previewDay: "Daytime",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Preview only. Your watch switches palettes with Pebble Quiet Time."
  },
  cs: {
    notificationAppOnly: 'Jen název aplikace',
    notificationAppOnlyHelp: 'Zobrazí aplikaci bez odesílatele a textu zprávy.',
    notificationVibration: "Vibrace navíc",
    vibrationShort: 'Krátké zavibrování',
    vibrationDouble: 'Dvojité zavibrování',
    vibrationHelp: "Jedna vibrace navíc pro každou novou sérii oznámení podle filtru aplikací. Respektuje Quiet Time. Vypněte ji, pokud už pro tato oznámení vibruje Pebble.",
    nightPalette: 'Barvy pro Quiet Time',
    nightPaletteHelp: 'Tyto barvy hodinek se použijí, když je v Pebble aktivní Quiet Time.',
    nightBackground: 'Pozadí při Quiet Time',
    nightText: 'Text při Quiet Time',
    nightAccent: 'Zvýraznění při Quiet Time',
    paletteCode: 'Sdílet barvy',
    paletteCodeHelp: 'Kód obsahuje pouze barvy pozadí, textu a zvýraznění.',
    paletteCopy: 'Zkopírovat kód',
    paletteApply: 'Použít kód',
    paletteCopied: 'Kód barev zkopírován.',
    paletteSelectCopy: 'Označte a zkopírujte kód barev.',
    paletteInvalid: 'Použijte kód ve tvaru DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Barvy použity. Uložením je odešlete do hodinek.',
    paletteInput: 'Kód barev',
    watchfaceBanners: "Aktivita oznámení",
    notificationsHelp: "Nová oznámení používají stejné pořadí aktivit a hlavní i vedlejší zobrazení. Povolte přístup k oznámením v Pebble. Systémová oznámení Pebble zůstávají samostatná.",
    previewPalette: "Náhled barev",
    previewDay: "Denní",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Jen náhled. Hodinky přepínají palety podle režimu Quiet Time v Pebble."
  },
  sk: {
    notificationAppOnly: 'Iba názov aplikácie',
    notificationAppOnlyHelp: 'Zobrazí aplikáciu bez odosielateľa a textu správy.',
    notificationVibration: "Vibrácia navyše",
    vibrationShort: 'Krátke zavibrovanie',
    vibrationDouble: 'Dvojité zavibrovanie',
    vibrationHelp: "Jedna vibrácia navyše pre každú novú sériu oznámení podľa filtra aplikácií. Rešpektuje Quiet Time. Vypnite ju, ak už pre tieto oznámenia vibruje Pebble.",
    nightPalette: 'Farby pre Quiet Time',
    nightPaletteHelp: 'Tieto farby hodiniek sa použijú, keď je v Pebble aktívny Quiet Time.',
    nightBackground: 'Pozadie počas Quiet Time',
    nightText: 'Text počas Quiet Time',
    nightAccent: 'Zvýraznenie počas Quiet Time',
    paletteCode: 'Zdieľať farby',
    paletteCodeHelp: 'Kód obsahuje iba farby pozadia, textu a zvýraznenia.',
    paletteCopy: 'Skopírovať kód',
    paletteApply: 'Použiť kód',
    paletteCopied: 'Kód farieb skopírovaný.',
    paletteSelectCopy: 'Označte a skopírujte kód farieb.',
    paletteInvalid: 'Použite kód v tvare DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Farby použité. Uložením ich odošlete do hodiniek.',
    paletteInput: 'Kód farieb',
    watchfaceBanners: "Aktivita oznámení",
    notificationsHelp: "Nové oznámenia používajú rovnaké poradie aktivít a hlavné aj vedľajšie zobrazenie. Povoľte prístup k oznámeniam v Pebble. Systémové oznámenia Pebble zostávajú samostatné.",
    previewPalette: "Náhľad farieb",
    previewDay: "Denné",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Iba náhľad. Hodinky prepínajú palety podľa režimu Quiet Time v Pebble."
  },
  de: {
    notificationAppOnly: 'Nur App-Name',
    notificationAppOnlyHelp: 'Zeigt die App ohne Absender oder Nachrichtentext.',
    notificationVibration: "Zusätzliche Vibration",
    vibrationShort: 'Kurzer Impuls',
    vibrationDouble: 'Doppelter Impuls',
    vibrationHelp: "Eine zusätzliche Vibration pro neuer Mitteilungsserie gemäß deinem App-Filter. Beachtet Quiet Time. Deaktiviere dies, wenn Pebble für diese Mitteilungen bereits vibriert.",
    nightPalette: 'Farben für Quiet Time',
    nightPaletteHelp: 'Diese Uhrfarben verwenden, während Quiet Time in Pebble aktiv ist.',
    nightBackground: 'Hintergrund bei Quiet Time',
    nightText: 'Text bei Quiet Time',
    nightAccent: 'Akzent bei Quiet Time',
    paletteCode: 'Farben teilen',
    paletteCodeHelp: 'Dieser Code enthält nur Hintergrund-, Text- und Akzentfarben.',
    paletteCopy: 'Code kopieren',
    paletteApply: 'Code anwenden',
    paletteCopied: 'Farbcode kopiert.',
    paletteSelectCopy: 'Wähle den Farbcode aus und kopiere ihn.',
    paletteInvalid: 'Verwende einen Code wie DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Farben übernommen. Speichere, um sie an deine Uhr zu senden.',
    paletteInput: 'Farbcode',
    watchfaceBanners: "Mitteilungsaktivität",
    notificationsHelp: "Neue Mitteilungen verwenden dieselbe Aktivitätsreihenfolge sowie die Haupt- und Nebenansicht. Erlaube den Mitteilungszugriff in Pebble. Systemmitteilungen von Pebble bleiben getrennt.",
    previewPalette: "Farbvorschau",
    previewDay: "Tagsüber",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Nur eine Vorschau. Die Uhr wechselt die Farbpaletten entsprechend Quiet Time in Pebble."
  },
  fr: {
    notificationAppOnly: 'Nom de l’application seul',
    notificationAppOnlyHelp: 'Affiche l’application sans expéditeur ni texte du message.',
    notificationVibration: "Vibration supplémentaire",
    vibrationShort: 'Impulsion courte',
    vibrationDouble: 'Double impulsion',
    vibrationHelp: "Une vibration supplémentaire par nouvelle série de notifications, selon votre filtre d’applications. Respecte Quiet Time. Désactivez cette option si Pebble vibre déjà pour ces notifications.",
    nightPalette: 'Couleurs pour Quiet Time',
    nightPaletteHelp: 'Utiliser ces couleurs sur la montre quand Quiet Time est actif dans Pebble.',
    nightBackground: 'Fond pendant Quiet Time',
    nightText: 'Texte pendant Quiet Time',
    nightAccent: 'Accent pendant Quiet Time',
    paletteCode: 'Partager les couleurs',
    paletteCodeHelp: 'Ce code contient uniquement les couleurs de fond, de texte et d’accentuation.',
    paletteCopy: 'Copier le code',
    paletteApply: 'Appliquer le code',
    paletteCopied: 'Code de couleurs copié.',
    paletteSelectCopy: 'Sélectionnez et copiez le code de couleurs.',
    paletteInvalid: 'Utilisez un code comme DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Couleurs appliquées. Enregistrez pour les envoyer à votre montre.',
    paletteInput: 'Code de couleurs',
    watchfaceBanners: "Activité de notification",
    notificationsHelp: "Les nouvelles notifications suivent le même ordre des activités et les mêmes vues principale et secondaire. Autorisez l’accès aux notifications dans Pebble. Les notifications système de Pebble restent distinctes.",
    previewPalette: "Aperçu des couleurs",
    previewDay: "En journée",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Aperçu uniquement. La montre change de palette selon Quiet Time dans Pebble."
  },
  es: {
    notificationAppOnly: 'Solo el nombre de la app',
    notificationAppOnlyHelp: 'Muestra la app sin remitente ni texto del mensaje.',
    notificationVibration: "Vibración adicional",
    vibrationShort: 'Pulso corto',
    vibrationDouble: 'Pulso doble',
    vibrationHelp: "Una vibración adicional por cada nueva serie de notificaciones, según tu filtro de apps. Respeta Quiet Time. Desactívala si Pebble ya vibra para esas notificaciones.",
    nightPalette: 'Colores para Quiet Time',
    nightPaletteHelp: 'Usar estos colores en el reloj mientras Quiet Time esté activo en Pebble.',
    nightBackground: 'Fondo en Quiet Time',
    nightText: 'Texto en Quiet Time',
    nightAccent: 'Acento en Quiet Time',
    paletteCode: 'Compartir colores',
    paletteCodeHelp: 'Este código solo contiene los colores de fondo, texto y acento.',
    paletteCopy: 'Copiar código',
    paletteApply: 'Aplicar código',
    paletteCopied: 'Código de colores copiado.',
    paletteSelectCopy: 'Selecciona y copia el código de colores.',
    paletteInvalid: 'Usa un código como DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Colores aplicados. Guarda para enviarlos a tu reloj.',
    paletteInput: 'Código de colores',
    watchfaceBanners: "Actividad de notificaciones",
    notificationsHelp: "Las nuevas notificaciones usan el mismo orden de actividades y las vistas principal y secundaria. Permite el acceso a notificaciones en Pebble. Las notificaciones del sistema de Pebble siguen siendo independientes.",
    previewPalette: "Vista previa de colores",
    previewDay: "De día",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Solo es una vista previa. El reloj cambia de paleta según Quiet Time en Pebble."
  },
  it: {
    notificationAppOnly: 'Solo nome dell’app',
    notificationAppOnlyHelp: 'Mostra l’app senza mittente o testo del messaggio.',
    notificationVibration: "Vibrazione aggiuntiva",
    vibrationShort: 'Impulso breve',
    vibrationDouble: 'Doppio impulso',
    vibrationHelp: "Una vibrazione aggiuntiva per ogni nuova serie di notifiche, secondo il filtro delle app. Rispetta Quiet Time. Disattivala se Pebble vibra già per queste notifiche.",
    nightPalette: 'Colori per Quiet Time',
    nightPaletteHelp: 'Usa questi colori sull’orologio quando Quiet Time è attivo in Pebble.',
    nightBackground: 'Sfondo durante Quiet Time',
    nightText: 'Testo durante Quiet Time',
    nightAccent: 'Accento durante Quiet Time',
    paletteCode: 'Condividi colori',
    paletteCodeHelp: 'Questo codice contiene solo i colori di sfondo, testo e accento.',
    paletteCopy: 'Copia codice',
    paletteApply: 'Applica codice',
    paletteCopied: 'Codice colori copiato.',
    paletteSelectCopy: 'Seleziona e copia il codice colori.',
    paletteInvalid: 'Usa un codice come DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Colori applicati. Salva per inviarli all’orologio.',
    paletteInput: 'Codice colori',
    watchfaceBanners: "Attività notifiche",
    notificationsHelp: "Le nuove notifiche usano lo stesso ordine delle attività e le viste principale e secondaria. Consenti l’accesso alle notifiche in Pebble. Le notifiche di sistema di Pebble restano separate.",
    previewPalette: "Anteprima colori",
    previewDay: "Di giorno",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Solo un’anteprima. L’orologio cambia palette in base a Quiet Time in Pebble."
  },
  pt: {
    notificationAppOnly: 'Só o nome da aplicação',
    notificationAppOnlyHelp: 'Mostra a aplicação sem remetente nem texto da mensagem.',
    notificationVibration: "Vibração adicional",
    vibrationShort: 'Pulso curto',
    vibrationDouble: 'Pulso duplo',
    vibrationHelp: "Uma vibração adicional por cada nova série de notificações, conforme o filtro de aplicações. Respeita o Quiet Time. Desative-a se o Pebble já vibrar para essas notificações.",
    nightPalette: 'Cores para Quiet Time',
    nightPaletteHelp: 'Usar estas cores no relógio enquanto o Quiet Time estiver ativo no Pebble.',
    nightBackground: 'Fundo durante Quiet Time',
    nightText: 'Texto durante Quiet Time',
    nightAccent: 'Destaque durante Quiet Time',
    paletteCode: 'Partilhar cores',
    paletteCodeHelp: 'Este código contém apenas as cores de fundo, texto e destaque.',
    paletteCopy: 'Copiar código',
    paletteApply: 'Aplicar código',
    paletteCopied: 'Código de cores copiado.',
    paletteSelectCopy: 'Selecione e copie o código de cores.',
    paletteInvalid: 'Use um código como DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Cores aplicadas. Guarde para as enviar para o relógio.',
    paletteInput: 'Código de cores',
    watchfaceBanners: "Atividade de notificações",
    notificationsHelp: "As novas notificações usam a mesma ordem das atividades e as vistas principal e secundária. Permita o acesso às notificações no Pebble. As notificações de sistema do Pebble continuam separadas.",
    previewPalette: "Pré-visualizar cores",
    previewDay: "Durante o dia",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Apenas uma pré-visualização. O relógio muda de paleta conforme o Quiet Time no Pebble."
  },
  nl: {
    notificationAppOnly: 'Alleen appnaam',
    notificationAppOnlyHelp: 'Toont de app zonder afzender of berichttekst.',
    notificationVibration: "Extra trilling",
    vibrationShort: 'Korte trilling',
    vibrationDouble: 'Dubbele trilling',
    vibrationHelp: "Eén extra trilling per nieuwe reeks meldingen, volgens je appfilter. Houdt rekening met Quiet Time. Schakel dit uit als Pebble al trilt voor deze meldingen.",
    nightPalette: 'Kleuren voor Quiet Time',
    nightPaletteHelp: 'Gebruik deze horlogekleuren wanneer Quiet Time in Pebble actief is.',
    nightBackground: 'Achtergrond tijdens Quiet Time',
    nightText: 'Tekst tijdens Quiet Time',
    nightAccent: 'Accent tijdens Quiet Time',
    paletteCode: 'Kleuren delen',
    paletteCodeHelp: 'Deze code bevat alleen de kleuren voor achtergrond, tekst en accenten.',
    paletteCopy: 'Code kopiëren',
    paletteApply: 'Code toepassen',
    paletteCopied: 'Kleurcode gekopieerd.',
    paletteSelectCopy: 'Selecteer en kopieer de kleurcode.',
    paletteInvalid: 'Gebruik een code zoals DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Kleuren toegepast. Sla op om ze naar je horloge te sturen.',
    paletteInput: 'Kleurcode',
    watchfaceBanners: "Meldingsactiviteit",
    notificationsHelp: "Nieuwe meldingen gebruiken dezelfde activiteitsvolgorde en hoofd- en nevenweergave. Sta meldingentoegang toe in Pebble. Systeemmeldingen van Pebble blijven apart.",
    previewPalette: "Kleurvoorbeeld",
    previewDay: "Overdag",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Alleen een voorbeeld. Het horloge wisselt van kleuren volgens Quiet Time in Pebble."
  },
  pl: {
    notificationAppOnly: 'Tylko nazwa aplikacji',
    notificationAppOnlyHelp: 'Pokazuje aplikację bez nadawcy i treści wiadomości.',
    notificationVibration: "Dodatkowa wibracja",
    vibrationShort: 'Krótka wibracja',
    vibrationDouble: 'Podwójna wibracja',
    vibrationHelp: "Jedna dodatkowa wibracja na każdą nową serię powiadomień, zgodnie z filtrem aplikacji. Uwzględnia Quiet Time. Wyłącz ją, jeśli Pebble już wibruje dla tych powiadomień.",
    nightPalette: 'Kolory w Quiet Time',
    nightPaletteHelp: 'Używaj tych kolorów zegarka, gdy Quiet Time jest aktywny w Pebble.',
    nightBackground: 'Tło w Quiet Time',
    nightText: 'Tekst w Quiet Time',
    nightAccent: 'Akcent w Quiet Time',
    paletteCode: 'Udostępnij kolory',
    paletteCodeHelp: 'Ten kod zawiera tylko kolory tła, tekstu i akcentu.',
    paletteCopy: 'Kopiuj kod',
    paletteApply: 'Zastosuj kod',
    paletteCopied: 'Kod kolorów skopiowany.',
    paletteSelectCopy: 'Zaznacz i skopiuj kod kolorów.',
    paletteInvalid: 'Użyj kodu w formacie DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Kolory zastosowane. Zapisz, aby wysłać je do zegarka.',
    paletteInput: 'Kod kolorów',
    watchfaceBanners: "Aktywność powiadomień",
    notificationsHelp: "Nowe powiadomienia używają tej samej kolejności aktywności oraz widoków głównego i dodatkowego. Zezwól na dostęp do powiadomień w Pebble. Powiadomienia systemowe Pebble pozostają osobne.",
    previewPalette: "Podgląd kolorów",
    previewDay: "W dzień",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Tylko podgląd. Zegarek zmienia palety zgodnie z trybem Quiet Time w Pebble."
  },
  da: {
    notificationAppOnly: 'Kun appnavn',
    notificationAppOnlyHelp: 'Viser appen uden afsender eller beskedtekst.',
    notificationVibration: "Ekstra vibration",
    vibrationShort: 'Kort vibration',
    vibrationDouble: 'Dobbelt vibration',
    vibrationHelp: "Én ekstra vibration for hver ny serie af notifikationer efter dit appfilter. Respekterer Quiet Time. Slå dette fra, hvis Pebble allerede vibrerer ved disse notifikationer.",
    nightPalette: 'Farver til Quiet Time',
    nightPaletteHelp: 'Brug disse urfarver, mens Quiet Time er aktiv i Pebble.',
    nightBackground: 'Baggrund under Quiet Time',
    nightText: 'Tekst under Quiet Time',
    nightAccent: 'Accent under Quiet Time',
    paletteCode: 'Del farver',
    paletteCodeHelp: 'Denne kode indeholder kun baggrunds-, tekst- og accentfarver.',
    paletteCopy: 'Kopiér kode',
    paletteApply: 'Anvend kode',
    paletteCopied: 'Farvekode kopieret.',
    paletteSelectCopy: 'Markér og kopiér farvekoden.',
    paletteInvalid: 'Brug en kode som DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Farver anvendt. Gem for at sende dem til dit ur.',
    paletteInput: 'Farvekode',
    watchfaceBanners: "Notifikationsaktivitet",
    notificationsHelp: "Nye notifikationer bruger samme aktivitetsrækkefølge og hoved- og sekundærvisning. Tillad adgang til notifikationer i Pebble. Pebbles systemnotifikationer forbliver adskilte.",
    previewPalette: "Farvevisning",
    previewDay: "Om dagen",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Kun en forhåndsvisning. Uret skifter palet efter Quiet Time i Pebble."
  },
  sv: {
    notificationAppOnly: 'Endast appnamn',
    notificationAppOnlyHelp: 'Visar appen utan avsändare eller meddelandetext.',
    notificationVibration: "Extra vibration",
    vibrationShort: 'Kort vibration',
    vibrationDouble: 'Dubbel vibration',
    vibrationHelp: "En extra vibration för varje ny serie aviseringar enligt ditt appfilter. Respekterar Quiet Time. Stäng av detta om Pebble redan vibrerar för dessa aviseringar.",
    nightPalette: 'Färger för Quiet Time',
    nightPaletteHelp: 'Använd dessa klockfärger när Quiet Time är aktivt i Pebble.',
    nightBackground: 'Bakgrund under Quiet Time',
    nightText: 'Text under Quiet Time',
    nightAccent: 'Accent under Quiet Time',
    paletteCode: 'Dela färger',
    paletteCodeHelp: 'Den här koden innehåller bara bakgrunds-, text- och accentfärger.',
    paletteCopy: 'Kopiera kod',
    paletteApply: 'Använd kod',
    paletteCopied: 'Färgkod kopierad.',
    paletteSelectCopy: 'Markera och kopiera färgkoden.',
    paletteInvalid: 'Använd en kod som DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Färger tillämpade. Spara för att skicka dem till klockan.',
    paletteInput: 'Färgkod',
    watchfaceBanners: "Aviseringsaktivitet",
    notificationsHelp: "Nya aviseringar använder samma aktivitetsordning och huvud- och sekundärvy. Tillåt åtkomst till aviseringar i Pebble. Pebbles systemaviseringar är fortsatt separata.",
    previewPalette: "Förhandsvisa färger",
    previewDay: "Dagtid",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Endast en förhandsvisning. Klockan byter palett enligt Quiet Time i Pebble."
  },
  no: {
    notificationAppOnly: 'Bare appnavn',
    notificationAppOnlyHelp: 'Viser appen uten avsender eller meldingstekst.',
    notificationVibration: "Ekstra vibrasjon",
    vibrationShort: 'Kort vibrasjon',
    vibrationDouble: 'Dobbel vibrasjon',
    vibrationHelp: "Én ekstra vibrasjon for hver nye varselserie etter appfilteret ditt. Respekterer Quiet Time. Slå dette av hvis Pebble allerede vibrerer for disse varslene.",
    nightPalette: 'Farger for Quiet Time',
    nightPaletteHelp: 'Bruk disse klokkefargene mens Quiet Time er aktiv i Pebble.',
    nightBackground: 'Bakgrunn under Quiet Time',
    nightText: 'Tekst under Quiet Time',
    nightAccent: 'Aksent under Quiet Time',
    paletteCode: 'Del farger',
    paletteCodeHelp: 'Denne koden inneholder bare bakgrunns-, tekst- og aksentfarger.',
    paletteCopy: 'Kopier kode',
    paletteApply: 'Bruk kode',
    paletteCopied: 'Fargekode kopiert.',
    paletteSelectCopy: 'Marker og kopier fargekoden.',
    paletteInvalid: 'Bruk en kode som DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Farger tatt i bruk. Lagre for å sende dem til klokken.',
    paletteInput: 'Fargekode',
    watchfaceBanners: "Varselaktivitet",
    notificationsHelp: "Nye varsler bruker samme aktivitetsrekkefølge og hoved- og sekundærvisning. Tillat varseltilgang i Pebble. Pebbles systemvarsler forblir separate.",
    previewPalette: "Forhåndsvis farger",
    previewDay: "På dagtid",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Bare en forhåndsvisning. Klokken bytter palett etter Quiet Time i Pebble."
  },
  fi: {
    notificationAppOnly: 'Vain sovelluksen nimi',
    notificationAppOnlyHelp: 'Näyttää sovelluksen ilman lähettäjää tai viestin tekstiä.',
    notificationVibration: "Lisävärinä",
    vibrationShort: 'Lyhyt värinä',
    vibrationDouble: 'Kaksinkertainen värinä',
    vibrationHelp: "Yksi lisävärinä kutakin uutta ilmoitussarjaa kohden sovellussuodattimen mukaan. Noudattaa Quiet Time -tilaa. Poista käytöstä, jos Pebble värisee jo näistä ilmoituksista.",
    nightPalette: 'Quiet Time -värit',
    nightPaletteHelp: 'Käytä näitä kellon värejä, kun Quiet Time on käytössä Pebblessä.',
    nightBackground: 'Quiet Time -tausta',
    nightText: 'Quiet Time -teksti',
    nightAccent: 'Quiet Time -korostus',
    paletteCode: 'Jaa värit',
    paletteCodeHelp: 'Tämä koodi sisältää vain taustan, tekstin ja korostuksen värit.',
    paletteCopy: 'Kopioi koodi',
    paletteApply: 'Käytä koodia',
    paletteCopied: 'Värikoodi kopioitu.',
    paletteSelectCopy: 'Valitse ja kopioi värikoodi.',
    paletteInvalid: 'Käytä koodia, kuten DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Värit otettu käyttöön. Lähetä ne kelloon tallentamalla.',
    paletteInput: 'Värikoodi',
    watchfaceBanners: "Ilmoitustoiminto",
    notificationsHelp: "Uudet ilmoitukset käyttävät samaa toimintojen järjestystä sekä pää- ja sivunäkymää. Salli ilmoitusten käyttö Pebblessä. Pebblen järjestelmäilmoitukset pysyvät erillisinä.",
    previewPalette: "Värien esikatselu",
    previewDay: "Päivällä",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Vain esikatselu. Kello vaihtaa väripalettia Pebblen Quiet Time -tilan mukaan."
  },
  hu: {
    notificationAppOnly: 'Csak az alkalmazás neve',
    notificationAppOnlyHelp: 'Az alkalmazást mutatja, feladó és üzenetszöveg nélkül.',
    notificationVibration: "Kiegészítő rezgés",
    vibrationShort: 'Rövid rezgés',
    vibrationDouble: 'Dupla rezgés',
    vibrationHelp: "Egy kiegészítő rezgés minden új értesítéssorozatnál, az alkalmazásszűrő szerint. Figyelembe veszi a Quiet Time módot. Kapcsold ki, ha a Pebble már rezeg ezeknél az értesítéseknél.",
    nightPalette: 'Quiet Time színek',
    nightPaletteHelp: 'Ezeket az óraszíneket használja, amikor a Pebble Quiet Time módja aktív.',
    nightBackground: 'Quiet Time háttér',
    nightText: 'Quiet Time szöveg',
    nightAccent: 'Quiet Time kiemelés',
    paletteCode: 'Színek megosztása',
    paletteCodeHelp: 'Ez a kód csak a háttér, a szöveg és a kiemelés színeit tartalmazza.',
    paletteCopy: 'Kód másolása',
    paletteApply: 'Kód alkalmazása',
    paletteCopied: 'Színkód másolva.',
    paletteSelectCopy: 'Jelöld ki és másold a színkódot.',
    paletteInvalid: 'Ilyen formátumú kódot használj: DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Színek alkalmazva. Mentsd az órára küldéshez.',
    paletteInput: 'Színkód',
    watchfaceBanners: "Értesítési tevékenység",
    notificationsHelp: "Az új értesítések ugyanazt a tevékenységsorrendet és elsődleges, illetve másodlagos nézetet használják. Engedélyezd az értesítések elérését a Pebble-ben. A Pebble rendszerértesítései külön maradnak.",
    previewPalette: "Színek előnézete",
    previewDay: "Nappal",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Csak előnézet. Az óra a Pebble Quiet Time módja szerint vált színpalettát."
  },
  ro: {
    notificationAppOnly: 'Doar numele aplicației',
    notificationAppOnlyHelp: 'Arată aplicația fără expeditor sau textul mesajului.',
    notificationVibration: "Vibrație suplimentară",
    vibrationShort: 'Impuls scurt',
    vibrationDouble: 'Impuls dublu',
    vibrationHelp: "O vibrație suplimentară pentru fiecare serie nouă de notificări, conform filtrului de aplicații. Respectă Quiet Time. Dezactiveaz-o dacă Pebble vibrează deja pentru aceste notificări.",
    nightPalette: 'Culori pentru Quiet Time',
    nightPaletteHelp: 'Folosește aceste culori pe ceas când Quiet Time este activ în Pebble.',
    nightBackground: 'Fundal în Quiet Time',
    nightText: 'Text în Quiet Time',
    nightAccent: 'Accent în Quiet Time',
    paletteCode: 'Partajează culorile',
    paletteCodeHelp: 'Acest cod conține doar culorile de fundal, text și accent.',
    paletteCopy: 'Copiază codul',
    paletteApply: 'Aplică codul',
    paletteCopied: 'Codul de culori a fost copiat.',
    paletteSelectCopy: 'Selectează și copiază codul de culori.',
    paletteInvalid: 'Folosește un cod precum DYN1-FFFFFF-000000-55AAFF.',
    paletteApplied: 'Culori aplicate. Salvează pentru a le trimite pe ceas.',
    paletteInput: 'Cod de culori',
    watchfaceBanners: "Activitate de notificări",
    notificationsHelp: "Notificările noi folosesc aceeași ordine a activităților și aceleași vizualizări principală și secundară. Permite accesul la notificări în Pebble. Notificările de sistem Pebble rămân separate.",
    previewPalette: "Previzualizează culorile",
    previewDay: "Ziua",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Doar previzualizare. Ceasul schimbă paletele în funcție de Quiet Time din Pebble."
  },
  tr: {
    notificationAppOnly: 'Yalnızca uygulama adı',
    notificationAppOnlyHelp: 'Göndereni veya ileti metnini göstermeden uygulamayı gösterir.',
    notificationVibration: "Ek titreşim",
    vibrationShort: 'Kısa titreşim',
    vibrationDouble: 'Çift titreşim',
    vibrationHelp: "Uygulama filtrenize göre her yeni bildirim serisi için bir ek titreşim. Quiet Time’a uyar. Pebble bu bildirimler için zaten titreşiyorsa bunu kapatın.",
    nightPalette: 'Quiet Time renkleri',
    nightPaletteHelp: 'Pebble Quiet Time etkinken saatte bu renkleri kullan.',
    nightBackground: 'Quiet Time arka planı',
    nightText: 'Quiet Time metni',
    nightAccent: 'Quiet Time vurgu rengi',
    paletteCode: 'Renkleri paylaş',
    paletteCodeHelp: 'Bu kod yalnızca arka plan, metin ve vurgu renklerini içerir.',
    paletteCopy: 'Kodu kopyala',
    paletteApply: 'Kodu uygula',
    paletteCopied: 'Renk kodu kopyalandı.',
    paletteSelectCopy: 'Renk kodunu seçip kopyalayın.',
    paletteInvalid: 'DYN1-FFFFFF-000000-55AAFF gibi bir kod kullanın.',
    paletteApplied: 'Renkler uygulandı. Saatinize göndermek için kaydedin.',
    paletteInput: 'Renk kodu',
    watchfaceBanners: "Bildirim etkinliği",
    notificationsHelp: "Yeni bildirimler aynı etkinlik sırasını, birincil ve ikincil görünümleri kullanır. Pebble’da bildirim erişimine izin verin. Pebble sistem bildirimleri ayrı kalır.",
    previewPalette: "Renk önizlemesi",
    previewDay: "Gündüz",
    previewQuietTime: "Quiet Time",
    previewPaletteHelp: "Yalnızca önizleme. Saat, Pebble Quiet Time durumuna göre palet değiştirir."
  }
};

Object.keys(SETTINGS_MESSAGES).forEach(function(language) {
  var row = MESSAGES[language];
  Object.keys(SETTINGS_MESSAGES[language]).forEach(function(key) {
    row[key] = SETTINGS_MESSAGES[language][key];
  });
  Object.keys(UX_MESSAGES[language]).forEach(function(key) {
    row[key] = UX_MESSAGES[language][key];
  });
  Object.keys(ALERT_MESSAGES[language]).forEach(function(key) {
    row[key] = ALERT_MESSAGES[language][key];
  });
  row.vibrationOff = row.stateOff;
  row.musicSource = row.previewMusic;
  row.notificationsSource = row.notifications;
  row.sourceOff = row.stateOff;
  row.sourcePermission = row.sourceDenied;
});
var ACTIVITY_MESSAGES = {
  "en": {
    "showActivities": "Show activity plugins",
    "activitiesHelp": "Compatible activity plugins connect automatically. Manage access permissions in Pebble.",
    "activitiesSource": "Activity plugins"
  },
  "cs": {
    "showActivities": "Zobrazovat pluginy aktivit",
    "activitiesHelp": "Kompatibilní pluginy aktivit se připojí automaticky. Přístupová oprávnění spravujte v Pebble.",
    "activitiesSource": "Pluginy aktivit"
  },
  "sk": {
    "showActivities": "Zobrazovať pluginy aktivít",
    "activitiesHelp": "Kompatibilné pluginy aktivít sa pripoja automaticky. Prístupové oprávnenia spravujte v Pebble.",
    "activitiesSource": "Pluginy aktivít"
  },
  "de": {
    "showActivities": "Aktivitätsplugins anzeigen",
    "activitiesHelp": "Kompatible Aktivitätsplugins verbinden sich automatisch. Zugriffsrechte werden in Pebble verwaltet.",
    "activitiesSource": "Aktivitätsplugins"
  },
  "fr": {
    "showActivities": "Afficher les plugins d’activité",
    "activitiesHelp": "Les plugins d’activité compatibles se connectent automatiquement. Gérez les autorisations dans Pebble.",
    "activitiesSource": "Plugins d’activité"
  },
  "es": {
    "showActivities": "Mostrar plugins de actividad",
    "activitiesHelp": "Los plugins de actividad compatibles se conectan automáticamente. Gestiona los permisos en Pebble.",
    "activitiesSource": "Plugins de actividad"
  },
  "it": {
    "showActivities": "Mostra plugin attività",
    "activitiesHelp": "I plugin attività compatibili si collegano automaticamente. Gestisci le autorizzazioni in Pebble.",
    "activitiesSource": "Plugin attività"
  },
  "pt": {
    "showActivities": "Mostrar plugins de atividade",
    "activitiesHelp": "Os plugins de atividade compatíveis ligam-se automaticamente. Gere as permissões no Pebble.",
    "activitiesSource": "Plugins de atividade"
  },
  "nl": {
    "showActivities": "Activiteitsplugins tonen",
    "activitiesHelp": "Compatibele activiteitsplugins verbinden automatisch. Beheer toegangsrechten in Pebble.",
    "activitiesSource": "Activiteitsplugins"
  },
  "pl": {
    "showActivities": "Pokaż wtyczki aktywności",
    "activitiesHelp": "Zgodne wtyczki aktywności łączą się automatycznie. Uprawnieniami zarządzaj w Pebble.",
    "activitiesSource": "Wtyczki aktywności"
  },
  "da": {
    "showActivities": "Vis aktivitetsplugins",
    "activitiesHelp": "Kompatible aktivitetsplugins forbindes automatisk. Administrer adgangstilladelser i Pebble.",
    "activitiesSource": "Aktivitetsplugins"
  },
  "sv": {
    "showActivities": "Visa aktivitetsplugin",
    "activitiesHelp": "Kompatibla aktivitetsplugin ansluts automatiskt. Hantera åtkomstbehörigheter i Pebble.",
    "activitiesSource": "Aktivitetsplugin"
  },
  "fi": {
    "showActivities": "Näytä toimintolisäosat",
    "activitiesHelp": "Yhteensopivat toimintolisäosat yhdistetään automaattisesti. Hallitse käyttöoikeuksia Pebblessä.",
    "activitiesSource": "Toimintolisäosat"
  },
  "no": {
    "showActivities": "Vis aktivitetsprogramtillegg",
    "activitiesHelp": "Kompatible aktivitetsprogramtillegg kobles til automatisk. Administrer tilgangstillatelser i Pebble.",
    "activitiesSource": "Aktivitetsprogramtillegg"
  },
  "hu": {
    "showActivities": "Tevékenységbővítmények megjelenítése",
    "activitiesHelp": "A kompatibilis tevékenységbővítmények automatikusan csatlakoznak. Az engedélyeket a Pebble-ben kezelheted.",
    "activitiesSource": "Tevékenységbővítmények"
  },
  "ro": {
    "showActivities": "Afișează pluginurile de activitate",
    "activitiesHelp": "Pluginurile de activitate compatibile se conectează automat. Gestionează permisiunile în Pebble.",
    "activitiesSource": "Pluginuri de activitate"
  },
  "tr": {
    "showActivities": "Etkinlik eklentilerini göster",
    "activitiesHelp": "Uyumlu etkinlik eklentileri otomatik bağlanır. Erişim izinlerini Pebble’da yönet.",
    "activitiesSource": "Etkinlik eklentileri"
  }
};
Object.keys(ACTIVITY_MESSAGES).forEach(function(language) {
  Object.keys(ACTIVITY_MESSAGES[language]).forEach(function(key) {
    MESSAGES[language][key]=ACTIVITY_MESSAGES[language][key];
  });
});
var ACTIVITY_PRIORITY_MESSAGES = {
  en:['Activity priority','Drag or use the arrows. The first available activity is large; the next is smaller. Any app can appear in either place. This order applies only to Dynamic.','Move up','Move down','Show','Show {name}','Move {name}','{name}: position {position}','Unavailable app','Not installed or unavailable. Its position is saved.'],
  cs:['Pořadí aktivit','Přetáhněte aplikace nebo použijte šipky. První dostupná aktivita je velká, další menší. Kterákoli aplikace může být na obou místech. Pořadí platí jen pro Dynamic.','Posunout výš','Posunout níž','Zobrazit','Zobrazit {name}','Přesunout {name}','{name}: pozice {position}','Nedostupná aplikace','Není nainstalovaná nebo je nedostupná. Její pořadí zůstává uložené.'],
  sk:['Poradie aktivít','Presuňte aplikácie alebo použite šípky. Prvá dostupná aktivita je veľká, ďalšia menšia. Ktorákoľvek aplikácia môže byť na oboch miestach. Poradie platí iba pre Dynamic.','Posunúť vyššie','Posunúť nižšie','Zobraziť','Zobraziť {name}','Presunúť {name}','{name}: pozícia {position}','Nedostupná aplikácia','Nie je nainštalovaná alebo je nedostupná. Jej poradie zostáva uložené.'],
  de:['Reihenfolge der Aktivitäten','Ziehen oder die Pfeile verwenden. Die erste verfügbare Aktivität erscheint groß, die nächste kleiner. Jede App kann an beiden Stellen erscheinen. Die Reihenfolge gilt nur für Dynamic.','Nach oben','Nach unten','Anzeigen','{name} anzeigen','{name} verschieben','{name}: Position {position}','Nicht verfügbare App','Nicht installiert oder nicht verfügbar. Ihre Position bleibt gespeichert.'],
  fr:['Priorité des activités','Faites glisser les apps ou utilisez les flèches. La première activité disponible est grande, la suivante plus petite. Chaque app peut occuper les deux places. Cet ordre concerne uniquement Dynamic.','Monter','Descendre','Afficher','Afficher {name}','Déplacer {name}','{name} : position {position}','Application indisponible','Non installée ou indisponible. Sa position est conservée.'],
  es:['Prioridad de actividades','Arrastra o usa las flechas. La primera actividad disponible se muestra grande y la siguiente más pequeña. Cualquier app puede ocupar ambos lugares. Este orden solo se aplica a Dynamic.','Subir','Bajar','Mostrar','Mostrar {name}','Mover {name}','{name}: posición {position}','Aplicación no disponible','No está instalada o no está disponible. Se conserva su posición.'],
  it:['Priorità delle attività','Trascina o usa le frecce. La prima attività disponibile è grande, la successiva più piccola. Ogni app può occupare entrambe le posizioni. Questo ordine vale solo per Dynamic.','Sposta su','Sposta giù','Mostra','Mostra {name}','Sposta {name}','{name}: posizione {position}','App non disponibile','Non installata o non disponibile. La posizione rimane salvata.'],
  pt:['Prioridade das atividades','Arraste ou use as setas. A primeira atividade disponível é grande e a seguinte mais pequena. Qualquer app pode ocupar ambos os lugares. Esta ordem aplica-se apenas ao Dynamic.','Mover para cima','Mover para baixo','Mostrar','Mostrar {name}','Mover {name}','{name}: posição {position}','Aplicação indisponível','Não instalada ou indisponível. A posição fica guardada.'],
  nl:['Prioriteit van activiteiten','Sleep of gebruik de pijlen. De eerste beschikbare activiteit is groot, de volgende kleiner. Elke app kan op beide plekken staan. Deze volgorde geldt alleen voor Dynamic.','Omhoog','Omlaag','Tonen','{name} tonen','{name} verplaatsen','{name}: positie {position}','App niet beschikbaar','Niet geïnstalleerd of niet beschikbaar. De positie blijft bewaard.'],
  pl:['Kolejność aktywności','Przeciągnij lub użyj strzałek. Pierwsza dostępna aktywność jest duża, kolejna mniejsza. Każda aplikacja może zająć obie pozycje. Ta kolejność dotyczy tylko Dynamic.','Przesuń wyżej','Przesuń niżej','Pokaż','Pokaż {name}','Przenieś {name}','{name}: pozycja {position}','Niedostępna aplikacja','Nie jest zainstalowana lub jest niedostępna. Jej pozycja pozostaje zapisana.'],
  da:['Aktivitetsrækkefølge','Træk eller brug pilene. Den første tilgængelige aktivitet er stor, den næste mindre. Alle apps kan stå begge steder. Rækkefølgen gælder kun for Dynamic.','Flyt op','Flyt ned','Vis','Vis {name}','Flyt {name}','{name} er på plads {position}','Utilgængelig app','Ikke installeret eller utilgængelig. Positionen gemmes.'],
  sv:['Aktivitetsordning','Dra eller använd pilarna. Den första tillgängliga aktiviteten är stor, nästa mindre. Alla appar kan visas på båda platserna. Ordningen gäller bara Dynamic.','Flytta upp','Flytta ned','Visa','Visa {name}','Flytta {name}','{name}: plats {position}','Otillgänglig app','Inte installerad eller otillgänglig. Platsen sparas.'],
  fi:['Toimintojen järjestys','Vedä tai käytä nuolia. Ensimmäinen saatavilla oleva toiminto on suuri, seuraava pienempi. Mikä tahansa sovellus voi olla kummassa tahansa paikassa. Järjestys koskee vain Dynamicia.','Siirrä ylös','Siirrä alas','Näytä','Näytä {name}','Siirrä {name}','{name}: paikka {position}','Sovellus ei saatavilla','Ei asennettu tai ei saatavilla. Sen paikka säilytetään.'],
  no:['Aktivitetsrekkefølge','Dra eller bruk pilene. Den første tilgjengelige aktiviteten er stor, den neste mindre. Alle apper kan vises begge steder. Rekkefølgen gjelder bare Dynamic.','Flytt opp','Flytt ned','Vis','Vis {name}','Flytt {name}','{name}: plass {position}','Utilgjengelig app','Ikke installert eller utilgjengelig. Plassen beholdes.'],
  hu:['Tevékenységek sorrendje','Húzd az alkalmazásokat, vagy használd a nyilakat. Az első elérhető tevékenység nagy, a következő kisebb. Bármely app megjelenhet mindkét helyen. Ez a sorrend csak a Dynamicra vonatkozik.','Feljebb','Lejjebb','Mutasd','{name} megjelenítése','{name} áthelyezése','{name}: {position}. hely','Nem elérhető alkalmazás','Nincs telepítve vagy nem érhető el. A helye megmarad.'],
  ro:['Prioritatea activităților','Trage sau folosește săgețile. Prima activitate disponibilă este mare, următoarea mai mică. Orice aplicație poate ocupa ambele locuri. Ordinea se aplică doar în Dynamic.','Mută în sus','Mută în jos','Arată','Arată {name}','Mută {name}','{name}: poziția {position}','Aplicație indisponibilă','Nu este instalată sau nu este disponibilă. Poziția ei rămâne salvată.'],
  tr:['Etkinlik önceliği','Sürükleyin veya okları kullanın. İlk kullanılabilir etkinlik büyük, sonraki daha küçük gösterilir. Her uygulama her iki yerde de görünebilir. Bu sıra yalnızca Dynamic için geçerlidir.','Yukarı taşı','Aşağı taşı','Göster','{name} göster','{name} taşı','{name}: {position}. sıra','Kullanılamayan uygulama','Yüklü değil veya kullanılamıyor. Sırası saklanır.']
};
Object.keys(ACTIVITY_PRIORITY_MESSAGES).forEach(function(language) {
  ['activityPriority','activityPriorityHelp','activityUp','activityDown','activityVisible','activityShow','activityMove','activityMoved','activityUnavailableApp','activityUnavailable'].forEach(function(key,index) {
    MESSAGES[language][key]=ACTIVITY_PRIORITY_MESSAGES[language][index];
  });
});
var SETTINGS_CLEANUP_MESSAGES = {
  en:['Content & priority','Title only','Short transitions when activities change.','Show activities from installed plugins. Music and Notifications have their own switches in the list below.','Notification details','Enable Notifications in the activity list to change its details.','Turn on activity plugins to show this app.'],
  cs:['Obsah a pořadí','Jen titulek','Krátké přechody při změně aktivit.','Zobrazuje aktivity nainstalovaných pluginů. Hudba a Oznámení mají vlastní přepínače v seznamu níže.','Podrobnosti oznámení','Podrobnosti upravíte po zapnutí Oznámení v seznamu aktivit.','Pro zobrazení této aplikace zapněte pluginy aktivit.'],
  sk:['Obsah a poradie','Iba nadpis','Krátke prechody pri zmene aktivít.','Zobrazuje aktivity nainštalovaných pluginov. Hudba a Oznámenia majú vlastné prepínače v zozname nižšie.','Podrobnosti oznámení','Podrobnosti upravíte po zapnutí Oznámení v zozname aktivít.','Na zobrazenie tejto aplikácie zapnite pluginy aktivít.'],
  de:['Inhalte & Reihenfolge','Nur Titel','Kurze Übergänge bei Aktivitätswechseln.','Aktivitäten installierter Plugins anzeigen. Musik und Mitteilungen haben eigene Schalter in der Liste unten.','Mitteilungsdetails','Aktiviere Mitteilungen in der Aktivitätsliste, um die Details zu ändern.','Aktiviere Aktivitätsplugins, um diese App anzuzeigen.'],
  fr:['Contenu et priorité','Titre seul','Transitions courtes lors des changements d’activité.','Affiche les activités des plugins installés. Musique et Notifications ont leurs propres commandes dans la liste ci-dessous.','Détails des notifications','Activez Notifications dans la liste des activités pour modifier les détails.','Activez les plugins d’activité pour afficher cette application.'],
  es:['Contenido y prioridad','Solo título','Transiciones breves al cambiar las actividades.','Muestra actividades de los plugins instalados. Música y Notificaciones tienen sus propios interruptores en la lista inferior.','Detalles de notificaciones','Activa Notificaciones en la lista de actividades para cambiar sus detalles.','Activa los plugins de actividad para mostrar esta aplicación.'],
  it:['Contenuti e priorità','Solo titolo','Brevi transizioni quando cambiano le attività.','Mostra le attività dei plugin installati. Musica e Notifiche hanno interruttori propri nell’elenco sotto.','Dettagli notifiche','Attiva Notifiche nell’elenco delle attività per modificarne i dettagli.','Attiva i plugin attività per mostrare questa app.'],
  pt:['Conteúdo e prioridade','Só título','Transições curtas quando as atividades mudam.','Mostra atividades dos plugins instalados. Música e Notificações têm os seus próprios interruptores na lista abaixo.','Detalhes das notificações','Ative Notificações na lista de atividades para alterar os detalhes.','Ative os plugins de atividade para mostrar esta aplicação.'],
  nl:['Inhoud en prioriteit','Alleen titel','Korte overgangen bij wijzigingen in activiteiten.','Toon activiteiten van geïnstalleerde plugins. Muziek en Meldingen hebben eigen schakelaars in de lijst hieronder.','Meldingsdetails','Schakel Meldingen in de activiteitenlijst in om de details te wijzigen.','Schakel activiteitsplugins in om deze app te tonen.'],
  pl:['Treść i kolejność','Tylko tytuł','Krótkie przejścia przy zmianie aktywności.','Pokazuje aktywności zainstalowanych wtyczek. Muzyka i Powiadomienia mają osobne przełączniki na liście poniżej.','Szczegóły powiadomień','Włącz Powiadomienia na liście aktywności, aby zmienić ich szczegóły.','Włącz wtyczki aktywności, aby pokazać tę aplikację.'],
  da:['Indhold og rækkefølge','Kun titel','Korte overgange, når aktiviteter ændres.','Vis aktiviteter fra installerede plugins. Musik og Notifikationer har egne kontakter på listen nedenfor.','Notifikationsdetaljer','Slå Notifikationer til på aktivitetslisten for at ændre detaljerne.','Slå aktivitetsplugins til for at vise denne app.'],
  sv:['Innehåll och ordning','Bara rubrik','Korta övergångar när aktiviteter ändras.','Visa aktiviteter från installerade plugin. Musik och Aviseringar har egna reglage i listan nedan.','Aviseringsdetaljer','Aktivera Aviseringar i aktivitetslistan för att ändra detaljerna.','Aktivera aktivitetsplugin för att visa den här appen.'],
  no:['Innhold og rekkefølge','Bare tittel','Korte overganger når aktiviteter endres.','Vis aktiviteter fra installerte programtillegg. Musikk og Varsler har egne brytere i listen nedenfor.','Varseldetaljer','Slå på Varsler i aktivitetslisten for å endre detaljene.','Slå på aktivitetsprogramtillegg for å vise denne appen.'],
  fi:['Sisältö ja järjestys','Vain otsikko','Lyhyet siirtymät toimintojen vaihtuessa.','Näytä asennettujen lisäosien toiminnot. Musiikilla ja Ilmoituksilla on omat kytkimensä alla olevassa luettelossa.','Ilmoitusten tiedot','Ota Ilmoitukset käyttöön toimintoluettelossa muuttaaksesi tietoja.','Ota toimintolisäosat käyttöön näyttääksesi tämän sovelluksen.'],
  hu:['Tartalom és sorrend','Csak cím','Rövid átmenetek a tevékenységek változásakor.','A telepített bővítmények tevékenységeinek megjelenítése. A Zene és az Értesítések külön kapcsolót kap az alábbi listában.','Értesítések részletei','A részletek módosításához kapcsold be az Értesítéseket a tevékenységlistában.','Az alkalmazás megjelenítéséhez kapcsold be a tevékenységbővítményeket.'],
  ro:['Conținut și prioritate','Doar titlul','Tranziții scurte când se schimbă activitățile.','Arată activitățile pluginurilor instalate. Muzica și Notificările au comutatoare proprii în lista de mai jos.','Detalii notificări','Activează Notificări în lista de activități pentru a modifica detaliile.','Activează pluginurile de activitate pentru a afișa această aplicație.'],
  tr:['İçerik ve öncelik','Yalnızca başlık','Etkinlikler değiştiğinde kısa geçişler.','Yüklü eklentilerin etkinliklerini gösterir. Müzik ve Bildirimler için aşağıdaki listede ayrı anahtarlar vardır.','Bildirim ayrıntıları','Ayrıntıları değiştirmek için etkinlik listesinde Bildirimleri açın.','Bu uygulamayı göstermek için etkinlik eklentilerini açın.']
};
Object.keys(SETTINGS_CLEANUP_MESSAGES).forEach(function(language) {
  ['content','previewBanner','animationsHelp','activitiesHelp','notificationDetails','notificationDisabledHelp','activityPluginsOffHelp'].forEach(function(key,index) {
    MESSAGES[language][key]=SETTINGS_CLEANUP_MESSAGES[language][index];
  });
});
var PREVIEW_TIMER_MESSAGES = {"en":"Timer","cs":"Časovač","sk":"Časovač","de":"Timer","fr":"Minuteur","es":"Temporizador","it":"Timer","pt":"Temporizador","nl":"Timer","pl":"Minutnik","da":"Timer","sv":"Timer","no":"Tidtaker","fi":"Ajastin","hu":"Időzítő","ro":"Temporizator","tr":"Zamanlayıcı"};
Object.keys(PREVIEW_TIMER_MESSAGES).forEach(function(language) { MESSAGES[language].previewTimer=PREVIEW_TIMER_MESSAGES[language]; });
var displayWords=require(17);
Object.keys(displayWords).forEach(function(language){Object.assign(MESSAGES[language],displayWords[language]);});
var LANGUAGES = Object.keys(MESSAGES);
var LITERALS = Object.create(null);
Object.keys(MESSAGES.en).forEach(function(key) { LITERALS[MESSAGES.en[key]] = key; });
Object.keys(LEGACY_LITERALS).forEach(function(text) { LITERALS[text] = LEGACY_LITERALS[text]; });
[
  ['Help & connection','helpConnection'],
  ['Watch settings delivered.','saveSaved'],
  ['Saved on phone; waiting for watch.','savePending'],
  ['Saved on phone. Reconnect and save again to update the watch.','saveFailed'],
  ['App and title','notificationSummary'],
  ['Notification vibration','notificationVibration'],
  ['Content','content'],
  ['Notification details','notificationDetails'],
  ['Enable Notifications in the activity list to change its details.','notificationDisabledHelp'],
  ['Short transitions when music or notifications change.','animationsHelp'],
  ['Watchface banners','watchfaceBanners'],
  ['Allow notification access in Pebble. Only new notifications appear.','notificationsHelp'],
  ['One vibration per new notification burst. Respects Quiet Time and your app filter. Pebble may also vibrate for the same notification.','vibrationHelp']
].forEach(function(pair) { LITERALS[pair[0]] = pair[1]; });

function normalizeLanguage(locale) {
  if (typeof locale !== 'string') { return ''; }
  var base = locale.trim().toLowerCase().split(/[.@]/)[0].replace(/_/g, '-').split('-')[0];
  if (base === 'nb' || base === 'nn') { base = 'no'; }
  return LANGUAGES.indexOf(base) >= 0 ? base : '';
}
function resolveLanguage(watchLanguage, phoneLanguage) {
  return normalizeLanguage(watchLanguage) || normalizeLanguage(phoneLanguage) || 'en';
}
function t(key, language, params) {
  var resolved = Object.prototype.hasOwnProperty.call(MESSAGES.en, key) ? key :
      Object.prototype.hasOwnProperty.call(LITERALS, key) ? LITERALS[key] : null;
  var row = MESSAGES[resolveLanguage(language)];
  var text = resolved ? row[resolved] || MESSAGES.en[resolved] : String(key);
  return text.replace(/\{([a-zA-Z][a-zA-Z0-9_]*)\}/g, function(match, name) {
    return params && Object.prototype.hasOwnProperty.call(params, name) ? String(params[name]) : match;
  });
}
function translateConfig(config, language) {
  function clone(value, type) {
    if (Array.isArray(value)) { return value.map(function(item) { return clone(item, type); }); }
    if (!value || typeof value !== 'object') { return value; }
    var result = {};
    type = value.type || type;
    Object.keys(value).forEach(function(key) {
      if ((key === 'label' || key === 'description' || key === 'defaultValue' &&
          ['text','heading','submit'].indexOf(type) >= 0) && typeof value[key] === 'string') {
        result[key] = t(value[key], language);
      } else { result[key] = clone(value[key], type); }
    });
    return result;
  }
  return clone(config, '');
}
// Shared Save-and-stay wording. Existing page translations remain intact.
var PHONE_SAVE = {
  en:['✓ Saved','No changes to save.','Couldn’t save. Try again.','Save not confirmed. Reload saved settings or try again.','Could not load saved settings. Retry before editing.','Retry','Reload saved','Discard','Loading settings…','Save'],
  cs:['✓ Uloženo','Žádné změny k uložení.','Nepodařilo se uložit. Zkuste to znovu.','Uložení není potvrzeno. Načtěte uložené nastavení nebo to zkuste znovu.','Uložené nastavení nelze načíst. Před úpravami to zkuste znovu.','Zkusit znovu','Načíst uložené','Zahodit změny','Načítání nastavení…','Uložit'],
  sk:['✓ Uložené','Žiadne zmeny na uloženie.','Nepodarilo sa uložiť. Skúste to znova.','Uloženie nie je potvrdené. Načítajte uložené nastavenia alebo skúste znova.','Uložené nastavenia sa nepodarilo načítať. Skúste znova.','Skúsiť znova','Načítať uložené','Zahodiť zmeny','Načítavajú sa nastavenia…','Uložiť'],
  de:['✓ Gespeichert','Keine Änderungen zu speichern.','Speichern fehlgeschlagen. Erneut versuchen.','Speichern nicht bestätigt. Gespeicherte Einstellungen laden oder erneut versuchen.','Gespeicherte Einstellungen konnten nicht geladen werden. Erneut versuchen.','Erneut versuchen','Gespeicherte laden','Verwerfen','Einstellungen werden geladen…','Speichern'],
  fr:['✓ Enregistré','Aucune modification à enregistrer.','Échec de l’enregistrement. Réessayez.','Enregistrement non confirmé. Rechargez les réglages ou réessayez.','Impossible de charger les réglages enregistrés. Réessayez.','Réessayer','Recharger','Annuler les modifications','Chargement des réglages…','Enregistrer'],
  es:['✓ Guardado','No hay cambios para guardar.','No se pudo guardar. Inténtalo de nuevo.','Guardado sin confirmar. Recarga los ajustes o inténtalo de nuevo.','No se pudieron cargar los ajustes guardados. Reinténtalo.','Reintentar','Recargar guardados','Descartar','Cargando ajustes…','Guardar'],
  it:['✓ Salvato','Nessuna modifica da salvare.','Salvataggio non riuscito. Riprova.','Salvataggio non confermato. Ricarica le impostazioni o riprova.','Impossibile caricare le impostazioni salvate. Riprova.','Riprova','Ricarica salvate','Scarta','Caricamento impostazioni…','Salva'],
  pt:['✓ Guardado','Não há alterações para guardar.','Não foi possível guardar. Tente novamente.','Gravação não confirmada. Recarregue as definições ou tente novamente.','Não foi possível carregar as definições guardadas. Tente novamente.','Tentar novamente','Recarregar guardadas','Descartar','A carregar definições…','Guardar'],
  nl:['✓ Opgeslagen','Geen wijzigingen om op te slaan.','Opslaan mislukt. Probeer opnieuw.','Opslaan niet bevestigd. Laad opgeslagen instellingen of probeer opnieuw.','Opgeslagen instellingen konden niet worden geladen. Probeer opnieuw.','Opnieuw proberen','Opgeslagen laden','Verwerpen','Instellingen laden…','Opslaan'],
  pl:['✓ Zapisano','Brak zmian do zapisania.','Nie udało się zapisać. Spróbuj ponownie.','Zapis niepotwierdzony. Wczytaj zapisane ustawienia lub spróbuj ponownie.','Nie można wczytać zapisanych ustawień. Spróbuj ponownie.','Spróbuj ponownie','Wczytaj zapisane','Odrzuć','Wczytywanie ustawień…','Zapisz'],
  da:['✓ Gemt','Ingen ændringer at gemme.','Kunne ikke gemme. Prøv igen.','Lagring ikke bekræftet. Indlæs gemte indstillinger eller prøv igen.','Kunne ikke indlæse gemte indstillinger. Prøv igen.','Prøv igen','Indlæs gemte','Kassér','Indlæser indstillinger…','Gem'],
  sv:['✓ Sparat','Inga ändringar att spara.','Kunde inte spara. Försök igen.','Sparandet är inte bekräftat. Läs in sparade inställningar eller försök igen.','Kunde inte läsa in sparade inställningar. Försök igen.','Försök igen','Läs in sparade','Kasta ändringar','Läser in inställningar…','Spara'],
  no:['✓ Lagret','Ingen endringer å lagre.','Kunne ikke lagre. Prøv igjen.','Lagring er ikke bekreftet. Last lagrede innstillinger eller prøv igjen.','Kunne ikke laste lagrede innstillinger. Prøv igjen.','Prøv igjen','Last lagrede','Forkast','Laster innstillinger…','Lagre'],
  fi:['✓ Tallennettu','Ei tallennettavia muutoksia.','Tallennus epäonnistui. Yritä uudelleen.','Tallennusta ei vahvistettu. Lataa tallennetut asetukset tai yritä uudelleen.','Tallennettuja asetuksia ei voitu ladata. Yritä uudelleen.','Yritä uudelleen','Lataa tallennetut','Hylkää','Ladataan asetuksia…','Tallenna'],
  hu:['✓ Mentve','Nincs mentendő módosítás.','Nem sikerült menteni. Próbálja újra.','A mentés nincs megerősítve. Töltse be a mentett beállításokat vagy próbálja újra.','A mentett beállítások nem tölthetők be. Próbálja újra.','Újra','Mentettek betöltése','Elvetés','Beállítások betöltése…','Mentés'],
  ro:['✓ Salvat','Nu sunt modificări de salvat.','Salvarea a eșuat. Încercați din nou.','Salvare neconfirmată. Reîncărcați setările sau încercați din nou.','Setările salvate nu pot fi încărcate. Încercați din nou.','Reîncercați','Reîncărcați salvate','Renunțați','Se încarcă setările…','Salvați'],
  tr:['✓ Kaydedildi','Kaydedilecek değişiklik yok.','Kaydedilemedi. Tekrar deneyin.','Kayıt onaylanmadı. Kayıtlı ayarları yükleyin veya tekrar deneyin.','Kayıtlı ayarlar yüklenemedi. Tekrar deneyin.','Tekrar dene','Kayıtlı ayarları yükle','Vazgeç','Ayarlar yükleniyor…','Kaydet']
};
var PHONE_SAVE_KEYS = ['phoneSaved','phoneNoChanges','phoneSaveFailed','phoneSaveUncertain','phoneLoadFailed','phoneRetry','phoneReload','phoneDiscard','phoneLoading','save'];
Object.keys(PHONE_SAVE).forEach(function(language){PHONE_SAVE_KEYS.forEach(function(key,index){MESSAGES[language][key]=PHONE_SAVE[language][index];});});
LITERALS.Save = 'save';
// The product name stays the same in every locale; introductory copy explains
// this page without repeating a translated "Settings" suffix in its title.
var PHONE_INTRO = {
  en:'Choose colours and what appears on your watch.',
  cs:'Vyberte barvy a obsah zobrazený na hodinkách.',
  sk:'Vyberte farby a obsah zobrazený na hodinkách.',
  de:'Wähle Farben und Inhalte für deine Uhr.',
  fr:'Choisissez les couleurs et le contenu de votre montre.',
  es:'Elige los colores y el contenido de tu reloj.',
  it:'Scegli i colori e i contenuti del tuo orologio.',
  pt:'Escolha as cores e o conteúdo do seu relógio.',
  nl:'Kies de kleuren en inhoud van je horloge.',
  pl:'Wybierz kolory i treści na zegarku.',
  da:'Vælg farver og indhold på dit ur.',
  sv:'Välj färger och innehåll på din klocka.',
  no:'Velg farger og innhold på klokken.',
  fi:'Valitse kellosi värit ja sisältö.',
  hu:'Válassza ki az óra színeit és megjelenő tartalmát.',
  ro:'Alegeți culorile și conținutul afișat pe ceas.',
  tr:'Saatinizin renklerini ve gösterilecek içeriği seçin.'
};
Object.keys(PHONE_INTRO).forEach(function(language){
  MESSAGES[language].title='Dynamic';MESSAGES[language].phoneIntro=PHONE_INTRO[language];
});
LITERALS.Dynamic='title';
LITERALS[PHONE_INTRO.en]='phoneIntro';
// This choice belongs only to the current preview, never saved settings.
var PREVIEW_WATCH = {
  "en": [
    "Preview watch",
    "Preview only. Open the watchface to select your connected watch automatically."
  ],
  "cs": [
    "Hodinky v náhledu",
    "Pouze náhled. Otevřete ciferník pro automatický výběr připojených hodinek."
  ],
  "sk": [
    "Hodinky v náhľade",
    "Iba náhľad. Otvorte ciferník pre automatický výber pripojených hodiniek."
  ],
  "de": [
    "Uhr in der Vorschau",
    "Nur Vorschau. Öffne das Zifferblatt, um die verbundene Uhr automatisch auszuwählen."
  ],
  "fr": [
    "Montre de l’aperçu",
    "Aperçu uniquement. Ouvrez le cadran pour sélectionner automatiquement la montre connectée."
  ],
  "es": [
    "Reloj de la vista previa",
    "Solo vista previa. Abre la esfera para seleccionar automáticamente el reloj conectado."
  ],
  "it": [
    "Orologio in anteprima",
    "Solo anteprima. Apri il quadrante per selezionare automaticamente l’orologio connesso."
  ],
  "pt": [
    "Relógio na pré-visualização",
    "Apenas pré-visualização. Abra o mostrador para selecionar automaticamente o relógio ligado."
  ],
  "nl": [
    "Horloge in voorbeeld",
    "Alleen een voorbeeld. Open de wijzerplaat om het verbonden horloge automatisch te kiezen."
  ],
  "pl": [
    "Zegarek w podglądzie",
    "Tylko podgląd. Otwórz tarczę, aby automatycznie wybrać połączony zegarek."
  ],
  "da": [
    "Ur i forhåndsvisning",
    "Kun forhåndsvisning. Åbn urskiven for automatisk at vælge det tilsluttede ur."
  ],
  "sv": [
    "Klocka i förhandsvisning",
    "Endast förhandsvisning. Öppna urtavlan för att välja den anslutna klockan automatiskt."
  ],
  "no": [
    "Klokke i forhåndsvisning",
    "Bare forhåndsvisning. Åpne urskiven for å velge den tilkoblede klokken automatisk."
  ],
  "fi": [
    "Esikatselun kello",
    "Vain esikatselu. Avaa kellotaulu valitaksesi yhdistetyn kellon automaattisesti."
  ],
  "hu": [
    "Előnézeti óra",
    "Csak előnézet. Nyissa meg a számlapot a csatlakoztatott óra automatikus kiválasztásához."
  ],
  "ro": [
    "Ceas în previzualizare",
    "Doar previzualizare. Deschideți cadranul pentru a selecta automat ceasul conectat."
  ],
  "tr": [
    "Önizleme saati",
    "Yalnızca önizleme. Bağlı saati otomatik seçmek için saat yüzünü açın."
  ]
};
Object.keys(PREVIEW_WATCH).forEach(function(language){
  MESSAGES[language].previewWatch=PREVIEW_WATCH[language][0];
  MESSAGES[language].previewWatchHelp=PREVIEW_WATCH[language][1];
});
function settingsStrings(language) {
  language = resolveLanguage(language);
  var strings = {};
  Object.keys(MESSAGES.en).forEach(function(key) { strings[key] = t(key, language); });
  var keys = ['phoneSaved','phoneNoChanges','phoneSaveFailed','phoneSaveUncertain','phoneLoadFailed','phoneRetry','phoneReload','phoneDiscard','phoneLoading','save'];
  var values = PHONE_SAVE[language] || PHONE_SAVE.en;
  keys.forEach(function(key,index){strings[key]=values[index];});
  return strings;
}

// Inline activity education; copy only, with no settings or transport keys.
var ACTIVITY_INTRO = {
  "en": {
    "activityIntroTitle": "What is an activity?",
    "activityIntroDefinition": "Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.",
    "activityIntroExample": "Start a countdown in Timer, then return to Dynamic to see the time remaining. Timer still runs the countdown and alarm.",
    "activityIntroSetup": "Turn on activity plugins and show Timer in the activity list below, then save. Create and control your countdowns in Timer on the watch.",
    "activityIntroConnection": "Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing."
  },
  "cs": {
    "activityIntroTitle": "Co je aktivita?",
    "activityIntroDefinition": "Aktivity jsou průběžné informace, které zobrazují kompatibilní aplikace a ciferníky XOCE, například odpočet, hudba nebo nové oznámení.",
    "activityIntroExample": "Spusťte odpočet v Timer a vraťte se na Dynamic. Na ciferníku uvidíte zbývající čas. Odpočet i budík nadále zajišťuje Timer.",
    "activityIntroSetup": "Zapněte pluginy aktivit a zobrazování Timer v seznamu aktivit níže, pak nastavení uložte. Odpočty vytvářejte a ovládejte v Timer na hodinkách.",
    "activityIntroConnection": "Sdílení aktivit mezi aplikacemi vyžaduje podporu pluginů a připojený telefon. Timer funguje samostatně i bez sdílení."
  },
  "sk": {
    "activityIntroTitle": "Čo je aktivita?",
    "activityIntroDefinition": "Aktivity sú priebežné informácie, ktoré zobrazujú kompatibilné aplikácie a ciferníky XOCE, napríklad odpočet, hudba alebo nové oznámenie.",
    "activityIntroExample": "Spustite odpočet v Timer a vráťte sa na Dynamic. Na ciferníku uvidíte zostávajúci čas. Odpočet aj budík naďalej zaisťuje Timer.",
    "activityIntroSetup": "Zapnite pluginy aktivít a zobrazovanie Timer v zozname aktivít nižšie, potom nastavenia uložte. Odpočty vytvárajte a ovládajte v Timer na hodinkách.",
    "activityIntroConnection": "Zdieľanie aktivít medzi aplikáciami vyžaduje podporu pluginov a pripojený telefón. Timer funguje samostatne aj bez zdieľania."
  },
  "de": {
    "activityIntroTitle": "Was ist eine Aktivität?",
    "activityIntroDefinition": "Aktivitäten sind aktuelle Informationen in kompatiblen XOCE-Apps und Zifferblättern, etwa ein Countdown, Musik oder eine neue Mitteilung.",
    "activityIntroExample": "Starte einen Countdown in Timer und kehre zu Dynamic zurück, um die Restzeit zu sehen. Timer übernimmt weiterhin Countdown und Alarm.",
    "activityIntroSetup": "Aktiviere Aktivitätsplugins und Timer in der Aktivitätsliste unten und speichere. Erstelle und steuere Countdowns in Timer auf der Uhr.",
    "activityIntroConnection": "Das Teilen von Aktivitäten zwischen Apps benötigt Plugin-Unterstützung und ein verbundenes Telefon. Timer funktioniert auch ohne Teilen."
  },
  "fr": {
    "activityIntroTitle": "Qu’est-ce qu’une activité ?",
    "activityIntroDefinition": "Les activités sont des informations en cours affichées par les apps et cadrans XOCE compatibles : compte à rebours, musique ou nouvelle notification.",
    "activityIntroExample": "Lancez un compte à rebours dans Timer, puis revenez à Dynamic pour voir le temps restant. Timer gère toujours le décompte et l’alarme.",
    "activityIntroSetup": "Activez les plugins d’activité et Timer dans la liste ci-dessous, puis enregistrez. Créez et gérez vos comptes à rebours dans Timer sur la montre.",
    "activityIntroConnection": "Le partage d’activités entre apps nécessite les plugins et un téléphone connecté. Timer fonctionne aussi sans partage."
  },
  "es": {
    "activityIntroTitle": "¿Qué es una actividad?",
    "activityIntroDefinition": "Las actividades son información en curso que muestran las apps y esferas XOCE compatibles, como una cuenta atrás, música o una nueva notificación.",
    "activityIntroExample": "Inicia una cuenta atrás en Timer y vuelve a Dynamic para ver el tiempo restante. Timer sigue gestionando la cuenta atrás y la alarma.",
    "activityIntroSetup": "Activa los plugins de actividad y Timer en la lista de abajo, y guarda. Crea y controla las cuentas atrás en Timer en el reloj.",
    "activityIntroConnection": "Compartir actividades entre apps requiere compatibilidad con plugins y un teléfono conectado. Timer funciona por sí solo sin compartir."
  },
  "it": {
    "activityIntroTitle": "Che cos’è un’attività?",
    "activityIntroDefinition": "Le attività sono aggiornamenti mostrati dalle app e dai quadranti XOCE compatibili, come un conto alla rovescia, musica o una nuova notifica.",
    "activityIntroExample": "Avvia un conto alla rovescia in Timer, poi torna a Dynamic per vedere il tempo rimasto. Timer continua a gestire il conto e l’allarme.",
    "activityIntroSetup": "Attiva i plugin delle attività e Timer nell’elenco qui sotto, poi salva. Crea e gestisci i conti alla rovescia in Timer sull’orologio.",
    "activityIntroConnection": "La condivisione delle attività tra app richiede il supporto dei plugin e un telefono connesso. Timer funziona anche senza condivisione."
  },
  "pt": {
    "activityIntroTitle": "O que é uma atividade?",
    "activityIntroDefinition": "As atividades são informações em curso mostradas por apps e mostradores XOCE compatíveis, como uma contagem decrescente, música ou uma nova notificação.",
    "activityIntroExample": "Inicie uma contagem decrescente no Timer e volte ao Dynamic para ver o tempo restante. O Timer continua a gerir a contagem e o alarme.",
    "activityIntroSetup": "Ative os plugins de atividade e o Timer na lista abaixo e guarde. Crie e controle as contagens no Timer no relógio.",
    "activityIntroConnection": "Partilhar atividades entre apps requer suporte de plugins e um telemóvel ligado. O Timer também funciona sozinho, sem partilha."
  },
  "nl": {
    "activityIntroTitle": "Wat is een activiteit?",
    "activityIntroDefinition": "Activiteiten zijn actuele updates in compatibele XOCE-apps en wijzerplaten, zoals een aftelling, muziek of een nieuwe melding.",
    "activityIntroExample": "Start een aftelling in Timer en ga terug naar Dynamic om de resterende tijd te zien. Timer blijft de aftelling en het alarm regelen.",
    "activityIntroSetup": "Schakel activiteitsplugins en Timer in de onderstaande lijst in en sla op. Maak en bedien aftellingen in Timer op je horloge.",
    "activityIntroConnection": "Activiteiten delen tussen apps vereist pluginondersteuning en een verbonden telefoon. Timer werkt ook zelfstandig zonder delen."
  },
  "pl": {
    "activityIntroTitle": "Czym jest aktywność?",
    "activityIntroDefinition": "Aktywności to bieżące informacje wyświetlane przez zgodne aplikacje i tarcze XOCE, takie jak odliczanie, muzyka lub nowe powiadomienie.",
    "activityIntroExample": "Uruchom odliczanie w Timer i wróć do Dynamic, aby zobaczyć pozostały czas. Timer nadal obsługuje odliczanie i alarm.",
    "activityIntroSetup": "Włącz wtyczki aktywności i Timer na poniższej liście, a następnie zapisz. Twórz odliczania i steruj nimi w Timer na zegarku.",
    "activityIntroConnection": "Udostępnianie aktywności między aplikacjami wymaga obsługi wtyczek i połączonego telefonu. Timer działa też samodzielnie bez udostępniania."
  },
  "da": {
    "activityIntroTitle": "Hvad er en aktivitet?",
    "activityIntroDefinition": "Aktiviteter er aktuelle oplysninger i kompatible XOCE-apps og urskiver, f.eks. en nedtælling, musik eller en ny notifikation.",
    "activityIntroExample": "Start en nedtælling i Timer, og vend tilbage til Dynamic for at se den resterende tid. Timer styrer stadig nedtællingen og alarmen.",
    "activityIntroSetup": "Slå aktivitetsplugins og Timer til i listen nedenfor, og gem. Opret og styr nedtællinger i Timer på uret.",
    "activityIntroConnection": "Deling af aktiviteter mellem apps kræver pluginunderstøttelse og en tilsluttet telefon. Timer virker også alene uden deling."
  },
  "sv": {
    "activityIntroTitle": "Vad är en aktivitet?",
    "activityIntroDefinition": "Aktiviteter är aktuella uppdateringar i kompatibla XOCE-appar och urtavlor, till exempel en nedräkning, musik eller en ny avisering.",
    "activityIntroExample": "Starta en nedräkning i Timer och gå tillbaka till Dynamic för att se återstående tid. Timer sköter fortfarande nedräkningen och larmet.",
    "activityIntroSetup": "Aktivera aktivitetspluginer och Timer i listan nedan och spara. Skapa och styr nedräkningar i Timer på klockan.",
    "activityIntroConnection": "Delning av aktiviteter mellan appar kräver pluginstöd och en ansluten telefon. Timer fungerar även självständigt utan delning."
  },
  "no": {
    "activityIntroTitle": "Hva er en aktivitet?",
    "activityIntroDefinition": "Aktiviteter er aktuelle oppdateringer i kompatible XOCE-apper og urskiver, som en nedtelling, musikk eller et nytt varsel.",
    "activityIntroExample": "Start en nedtelling i Timer og gå tilbake til Dynamic for å se tiden som gjenstår. Timer styrer fortsatt nedtellingen og alarmen.",
    "activityIntroSetup": "Slå på aktivitetsplugins og Timer i listen nedenfor, og lagre. Opprett og styr nedtellinger i Timer på klokken.",
    "activityIntroConnection": "Deling av aktiviteter mellom apper krever pluginstøtte og en tilkoblet telefon. Timer fungerer også alene uten deling."
  },
  "fi": {
    "activityIntroTitle": "Mikä on toiminto?",
    "activityIntroDefinition": "Toiminnot ovat yhteensopivien XOCE-sovellusten ja kellotaulujen näyttämiä ajankohtaisia tietoja, kuten ajastus, musiikki tai uusi ilmoitus.",
    "activityIntroExample": "Käynnistä ajastus Timerissa ja palaa Dynamic-kellotauluun nähdäksesi jäljellä olevan ajan. Timer huolehtii edelleen ajastuksesta ja hälytyksestä.",
    "activityIntroSetup": "Ota toimintolisäosat ja Timer käyttöön alla olevassa luettelossa ja tallenna. Luo ja hallitse ajastuksia kellon Timer-sovelluksessa.",
    "activityIntroConnection": "Toimintojen jakaminen sovellusten välillä vaatii lisäosatuen ja yhteyden puhelimeen. Timer toimii myös itsenäisesti ilman jakamista."
  },
  "hu": {
    "activityIntroTitle": "Mi az a tevékenység?",
    "activityIntroDefinition": "A tevékenységek a kompatibilis XOCE-alkalmazásokban és számlapokon megjelenő aktuális információk, például visszaszámlálás, zene vagy új értesítés.",
    "activityIntroExample": "Indíts visszaszámlálást a Timerben, majd térj vissza a Dynamic számlapra a hátralévő idő megtekintéséhez. A visszaszámlálást és a riasztást továbbra is a Timer kezeli.",
    "activityIntroSetup": "Kapcsold be a tevékenységbővítményeket és a Timert az alábbi listában, majd ments. A visszaszámlálásokat az óra Timer alkalmazásában hozhatod létre és kezelheted.",
    "activityIntroConnection": "A tevékenységek alkalmazások közötti megosztásához bővítménytámogatás és csatlakoztatott telefon kell. A Timer megosztás nélkül is önállóan működik."
  },
  "ro": {
    "activityIntroTitle": "Ce este o activitate?",
    "activityIntroDefinition": "Activitățile sunt informații curente afișate de aplicațiile și cadranele XOCE compatibile, precum o numărătoare inversă, muzică sau o notificare nouă.",
    "activityIntroExample": "Pornește o numărătoare inversă în Timer, apoi revino la Dynamic pentru a vedea timpul rămas. Timer gestionează în continuare numărătoarea și alarma.",
    "activityIntroSetup": "Activează pluginurile de activitate și Timer în lista de mai jos, apoi salvează. Creează și controlează numărătorile în Timer pe ceas.",
    "activityIntroConnection": "Partajarea activităților între aplicații necesită suport pentru pluginuri și un telefon conectat. Timer funcționează și independent, fără partajare."
  },
  "tr": {
    "activityIntroTitle": "Etkinlik nedir?",
    "activityIntroDefinition": "Etkinlikler, uyumlu XOCE uygulama ve saat yüzlerinde gösterilen geri sayım, müzik veya yeni bildirim gibi güncel bilgilerdir.",
    "activityIntroExample": "Timer’da geri sayım başlatın, ardından kalan süreyi görmek için Dynamic’e dönün. Geri sayımı ve alarmı yine Timer yönetir.",
    "activityIntroSetup": "Etkinlik eklentilerini ve aşağıdaki listede Timer’ı açıp kaydedin. Geri sayımları saatteki Timer uygulamasında oluşturun ve yönetin.",
    "activityIntroConnection": "Uygulamalar arasında etkinlik paylaşımı için eklenti desteği ve bağlı bir telefon gerekir. Timer paylaşım olmadan da bağımsız çalışır."
  }
};
Object.keys(ACTIVITY_INTRO).forEach(function(language) {
  Object.keys(ACTIVITY_INTRO.en).forEach(function(key) {
    MESSAGES[language][key] = ACTIVITY_INTRO[language][key];
    LITERALS[ACTIVITY_INTRO.en[key]] = key;
  });
});

var LAYOUT_KEYS=["readingPage", "layoutApproximation", "Split clock and details", "Reading layout", "Columns", "Stacked rows", "Hide reading titles", "Shake to switch readings", "Details background", "Details text", "Night details background", "Night details text"];
var LAYOUT_WORDS={
  "en": [
    "Preview reading page",
    "Approximate layout preview with example data.",
    "Split clock and details",
    "Reading layout",
    "Columns",
    "Stacked rows",
    "Hide reading titles",
    "Shake to switch readings",
    "Details background",
    "Details text",
    "Night details background",
    "Night details text"
  ],
  "cs": [
    "Stránka údajů v náhledu",
    "Přibližný náhled rozložení s ukázkovými údaji.",
    "Oddělit hodiny a podrobnosti",
    "Rozložení údajů",
    "Sloupce",
    "Řádky pod sebou",
    "Skrýt názvy údajů",
    "Zatřesením přepnout údaje",
    "Pozadí podrobností",
    "Text podrobností",
    "Noční pozadí podrobností",
    "Noční text podrobností"
  ],
  "sk": [
    "Stránka údajov v náhľade",
    "Približný náhľad rozloženia s ukážkovými údajmi.",
    "Oddeliť hodiny a podrobnosti",
    "Rozloženie údajov",
    "Stĺpce",
    "Riadky pod sebou",
    "Skryť názvy údajov",
    "Zatrasením prepnúť údaje",
    "Pozadie podrobností",
    "Text podrobností",
    "Nočné pozadie podrobností",
    "Nočný text podrobností"
  ],
  "de": [
    "Datenseite in der Vorschau",
    "Ungefähre Layoutvorschau mit Beispieldaten.",
    "Uhr und Details trennen",
    "Datenanordnung",
    "Spalten",
    "Zeilen untereinander",
    "Datentitel ausblenden",
    "Daten durch Schütteln wechseln",
    "Detailhintergrund",
    "Detailtext",
    "Detailhintergrund nachts",
    "Detailtext nachts"
  ],
  "fr": [
    "Page de données de l’aperçu",
    "Aperçu approximatif avec des données d’exemple.",
    "Séparer l’horloge et les détails",
    "Disposition des données",
    "Colonnes",
    "Lignes empilées",
    "Masquer les titres des données",
    "Secouer pour changer les données",
    "Fond des détails",
    "Texte des détails",
    "Fond nocturne des détails",
    "Texte nocturne des détails"
  ],
  "es": [
    "Página de datos de la vista previa",
    "Vista aproximada con datos de ejemplo.",
    "Separar reloj y detalles",
    "Distribución de datos",
    "Columnas",
    "Filas apiladas",
    "Ocultar títulos de datos",
    "Agitar para cambiar los datos",
    "Fondo de detalles",
    "Texto de detalles",
    "Fondo nocturno de detalles",
    "Texto nocturno de detalles"
  ],
  "it": [
    "Pagina dati nell’anteprima",
    "Anteprima indicativa con dati di esempio.",
    "Separare orologio e dettagli",
    "Disposizione dei dati",
    "Colonne",
    "Righe sovrapposte",
    "Nascondi titoli dei dati",
    "Scuoti per cambiare dati",
    "Sfondo dei dettagli",
    "Testo dei dettagli",
    "Sfondo notturno dei dettagli",
    "Testo notturno dei dettagli"
  ],
  "pt": [
    "Página de dados na pré-visualização",
    "Pré-visualização aproximada com dados de exemplo.",
    "Separar relógio e detalhes",
    "Disposição dos dados",
    "Colunas",
    "Linhas empilhadas",
    "Ocultar títulos dos dados",
    "Agitar para mudar os dados",
    "Fundo dos detalhes",
    "Texto dos detalhes",
    "Fundo noturno dos detalhes",
    "Texto noturno dos detalhes"
  ],
  "nl": [
    "Gegevenspagina in voorbeeld",
    "Benaderend voorbeeld met voorbeeldgegevens.",
    "Klok en details splitsen",
    "Gegevensindeling",
    "Kolommen",
    "Rijen onder elkaar",
    "Gegevenstitels verbergen",
    "Schudden om gegevens te wisselen",
    "Achtergrond details",
    "Tekst details",
    "Nachtachtergrond details",
    "Nachttekst details"
  ],
  "pl": [
    "Strona danych w podglądzie",
    "Przybliżony podgląd z przykładowymi danymi.",
    "Oddziel zegar od szczegółów",
    "Układ danych",
    "Kolumny",
    "Wiersze jeden pod drugim",
    "Ukryj tytuły danych",
    "Potrząśnij, aby zmienić dane",
    "Tło szczegółów",
    "Tekst szczegółów",
    "Nocne tło szczegółów",
    "Nocny tekst szczegółów"
  ],
  "hu": [
    "Adatoldal az előnézetben",
    "Hozzávetőleges elrendezés mintaadatokkal.",
    "Óra és részletek szétválasztása",
    "Adatok elrendezése",
    "Oszlopok",
    "Egymás alatti sorok",
    "Adatcímek elrejtése",
    "Rázásra adatváltás",
    "Részletek háttere",
    "Részletek szövege",
    "Részletek éjszakai háttere",
    "Részletek éjszakai szövege"
  ],
  "fi": [
    "Esikatselun tietosivu",
    "Suuntaa antava esikatselu esimerkkitiedoilla.",
    "Erota kello ja tiedot",
    "Tietojen asettelu",
    "Sarakkeet",
    "Päällekkäiset rivit",
    "Piilota tietojen otsikot",
    "Vaihda tietoja ravistamalla",
    "Tietojen tausta",
    "Tietojen teksti",
    "Tietojen yötausta",
    "Tietojen yöteksti"
  ],
  "sv": [
    "Datasida i förhandsvisning",
    "Ungefärlig layout med exempeldata.",
    "Dela upp klocka och detaljer",
    "Datalayout",
    "Kolumner",
    "Staplade rader",
    "Dölj datarubriker",
    "Skaka för att byta data",
    "Detaljernas bakgrund",
    "Detaljernas text",
    "Detaljernas nattbakgrund",
    "Detaljernas nattext"
  ],
  "no": [
    "Dataside i forhåndsvisning",
    "Omtrentlig oppsett med eksempeldata.",
    "Del klokke og detaljer",
    "Dataoppsett",
    "Kolonner",
    "Stablede rader",
    "Skjul datatitler",
    "Rist for å bytte data",
    "Detaljbakgrunn",
    "Detaljtekst",
    "Detaljbakgrunn om natten",
    "Detaljtekst om natten"
  ],
  "da": [
    "Dataside i forhåndsvisning",
    "Omtrentligt layout med eksempeldata.",
    "Opdel ur og detaljer",
    "Datalayout",
    "Kolonner",
    "Stablede rækker",
    "Skjul datatitler",
    "Ryst for at skifte data",
    "Detaljebaggrund",
    "Detaljetekst",
    "Detaljebaggrund om natten",
    "Detaljetekst om natten"
  ],
  "ro": [
    "Pagina de date din previzualizare",
    "Previzualizare aproximativă cu date de exemplu.",
    "Separă ceasul și detaliile",
    "Aspectul datelor",
    "Coloane",
    "Rânduri suprapuse",
    "Ascunde titlurile datelor",
    "Scutură pentru a schimba datele",
    "Fundalul detaliilor",
    "Textul detaliilor",
    "Fundal nocturn al detaliilor",
    "Text nocturn al detaliilor"
  ],
  "tr": [
    "Önizleme veri sayfası",
    "Örnek verilerle yaklaşık düzen önizlemesi.",
    "Saati ve ayrıntıları ayır",
    "Veri düzeni",
    "Sütunlar",
    "Alt alta satırlar",
    "Veri başlıklarını gizle",
    "Verileri değiştirmek için salla",
    "Ayrıntı arka planı",
    "Ayrıntı metni",
    "Gece ayrıntı arka planı",
    "Gece ayrıntı metni"
  ]
};
Object.keys(LAYOUT_WORDS).forEach(function(language){LAYOUT_KEYS.forEach(function(key,index){MESSAGES[language][key]=LAYOUT_WORDS[language][index];LITERALS[LAYOUT_WORDS.en[index]]=key;});});
var LAYOUT_HELP_KEYS=["Units, required qualifiers and unavailable states stay visible.", "Cycle Pebble slots 1–2, 3–4 and 5. The page stays selected until the next shake.", "Source code: https://github.com/xefensor/pebble-watchface-dynamic", "Feedback: https://github.com/xefensor/pebble-watchface-dynamic/issues"];
var LAYOUT_HELP={
  "en": [
    "Units, required qualifiers and unavailable states stay visible.",
    "Cycle Pebble slots 1–2, 3–4 and 5. The page stays selected until the next shake.",
    "Source code: https://github.com/xefensor/pebble-watchface-dynamic",
    "Feedback: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "cs": [
    "Jednotky, povinná upřesnění a nedostupné stavy zůstanou viditelné.",
    "Přepíná pozice Pebble 1–2, 3–4 a 5. Stránka zůstane vybraná do dalšího zatřesení.",
    "Zdrojový kód: https://github.com/xefensor/pebble-watchface-dynamic",
    "Zpětná vazba: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "sk": [
    "Jednotky, povinné upresnenia a nedostupné stavy zostanú viditeľné.",
    "Prepína pozície Pebble 1–2, 3–4 a 5. Stránka zostane vybraná do ďalšieho zatrasenia.",
    "Zdrojový kód: https://github.com/xefensor/pebble-watchface-dynamic",
    "Spätná väzba: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "de": [
    "Einheiten, notwendige Zusätze und nicht verfügbare Zustände bleiben sichtbar.",
    "Wechselt die Pebble-Plätze 1–2, 3–4 und 5. Die Seite bleibt bis zum nächsten Schütteln ausgewählt.",
    "Quellcode: https://github.com/xefensor/pebble-watchface-dynamic",
    "Rückmeldung: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "fr": [
    "Les unités, précisions obligatoires et états indisponibles restent visibles.",
    "Parcourt les emplacements Pebble 1–2, 3–4 et 5. La page reste choisie jusqu’à la prochaine secousse.",
    "Code source : https://github.com/xefensor/pebble-watchface-dynamic",
    "Commentaires : https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "es": [
    "Las unidades, precisiones necesarias y estados no disponibles siguen visibles.",
    "Alterna las posiciones Pebble 1–2, 3–4 y 5. La página permanece hasta la siguiente sacudida.",
    "Código fuente: https://github.com/xefensor/pebble-watchface-dynamic",
    "Comentarios: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "it": [
    "Unità, precisazioni necessarie e stati non disponibili restano visibili.",
    "Scorre le posizioni Pebble 1–2, 3–4 e 5. La pagina resta selezionata fino alla prossima scossa.",
    "Codice sorgente: https://github.com/xefensor/pebble-watchface-dynamic",
    "Commenti: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "pt": [
    "As unidades, qualificações necessárias e estados indisponíveis permanecem visíveis.",
    "Percorre as posições Pebble 1–2, 3–4 e 5. A página mantém-se até à próxima agitação.",
    "Código-fonte: https://github.com/xefensor/pebble-watchface-dynamic",
    "Comentários: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "nl": [
    "Eenheden, vereiste toelichtingen en niet-beschikbare statussen blijven zichtbaar.",
    "Wisselt Pebble-posities 1–2, 3–4 en 5. De pagina blijft tot de volgende schudbeweging.",
    "Broncode: https://github.com/xefensor/pebble-watchface-dynamic",
    "Reacties: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "pl": [
    "Jednostki, wymagane dopiski i stany niedostępności pozostają widoczne.",
    "Przełącza pozycje Pebble 1–2, 3–4 i 5. Strona pozostaje wybrana do następnego potrząśnięcia.",
    "Kod źródłowy: https://github.com/xefensor/pebble-watchface-dynamic",
    "Uwagi: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "hu": [
    "A mértékegységek, szükséges jelölések és nem elérhető állapotok láthatók maradnak.",
    "A Pebble 1–2, 3–4 és 5 helyei között vált. Az oldal a következő rázásig megmarad.",
    "Forráskód: https://github.com/xefensor/pebble-watchface-dynamic",
    "Visszajelzés: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "fi": [
    "Yksiköt, pakolliset tarkenteet ja ei saatavilla -tilat jäävät näkyviin.",
    "Vaihtaa Pebblen paikkoja 1–2, 3–4 ja 5. Sivu säilyy seuraavaan ravistukseen asti.",
    "Lähdekoodi: https://github.com/xefensor/pebble-watchface-dynamic",
    "Palaute: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "sv": [
    "Enheter, nödvändiga tillägg och otillgängliga tillstånd förblir synliga.",
    "Växlar Pebble-platserna 1–2, 3–4 och 5. Sidan behålls till nästa skakning.",
    "Källkod: https://github.com/xefensor/pebble-watchface-dynamic",
    "Återkoppling: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "no": [
    "Enheter, nødvendige tillegg og utilgjengelige tilstander forblir synlige.",
    "Veksler Pebble-plassene 1–2, 3–4 og 5. Siden beholdes til neste risting.",
    "Kildekode: https://github.com/xefensor/pebble-watchface-dynamic",
    "Tilbakemelding: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "da": [
    "Enheder, nødvendige tilføjelser og utilgængelige tilstande forbliver synlige.",
    "Skifter Pebble-pladserne 1–2, 3–4 og 5. Siden beholdes til næste ryst.",
    "Kildekode: https://github.com/xefensor/pebble-watchface-dynamic",
    "Tilbagemelding: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "ro": [
    "Unitățile, precizările necesare și stările indisponibile rămân vizibile.",
    "Schimbă pozițiile Pebble 1–2, 3–4 și 5. Pagina rămâne până la următoarea scuturare.",
    "Cod sursă: https://github.com/xefensor/pebble-watchface-dynamic",
    "Opinii: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ],
  "tr": [
    "Birimler, gerekli açıklamalar ve kullanılamayan durumlar görünür kalır.",
    "Pebble yuvaları 1–2, 3–4 ve 5 arasında geçer. Sayfa sonraki sallamaya kadar kalır.",
    "Kaynak kodu: https://github.com/xefensor/pebble-watchface-dynamic",
    "Geri bildirim: https://github.com/xefensor/pebble-watchface-dynamic/issues"
  ]
};
Object.keys(LAYOUT_HELP).forEach(function(language){LAYOUT_HELP_KEYS.forEach(function(key,index){MESSAGES[language][key]=LAYOUT_HELP[language][index];LITERALS[key]=key;});});
var READING_SLOT_WORDS={"en": "Slot {slot}", "cs": "Pozice {slot}", "sk": "Pozícia {slot}", "de": "Platz {slot}", "fr": "Emplacement {slot}", "es": "Posición {slot}", "it": "Posizione {slot}", "pt": "Posição {slot}", "nl": "Positie {slot}", "pl": "Pozycja {slot}", "da": "Plads {slot}", "sv": "Plats {slot}", "no": "Plass {slot}", "fi": "Paikka {slot}", "hu": "Hely {slot}", "ro": "Poziția {slot}", "tr": "Yuva {slot}"};
Object.keys(READING_SLOT_WORDS).forEach(function(language){MESSAGES[language].readingSlot=READING_SLOT_WORDS[language];});
var GRID_WORDS={"en":["Four when idle","Four readings in a compact grid when idle; the selected pair stays visible with an activity or Timeline Peek."],"cs":["Čtyři v klidu","V klidu čtyři údaje v kompaktní mřížce; při aktivitě nebo náhledu časové osy zůstane vybraná dvojice."],"sk":["Štyri v pokoji","V pokoji štyri údaje v kompaktnej mriežke; pri aktivite alebo náhľade časovej osi zostane vybraná dvojica."],"de":["Vier im Ruhezustand","Im Ruhezustand vier Werte in einem kompakten Raster; bei einer Aktivität oder Timeline-Vorschau bleibt das gewählte Paar sichtbar."],"fr":["Quatre au repos","Quatre données dans une grille compacte au repos ; la paire choisie reste visible avec une activité ou un aperçu Timeline."],"es":["Cuatro en reposo","Cuatro datos en una cuadrícula compacta en reposo; la pareja elegida sigue visible con una actividad o una vista de Timeline."],"it":["Quattro a riposo","Quattro dati in una griglia compatta a riposo; la coppia scelta resta visibile con un’attività o un’anteprima Timeline."],"pt":["Quatro em repouso","Quatro dados numa grelha compacta em repouso; o par escolhido mantém-se visível com uma atividade ou pré-visualização Timeline."],"nl":["Vier in rust","Vier gegevens in een compact raster in rust; het gekozen paar blijft zichtbaar bij een activiteit of Timeline-voorbeeld."],"pl":["Cztery w spoczynku","Cztery dane w zwartej siatce w spoczynku; wybrana para pozostaje widoczna przy aktywności lub podglądzie Timeline."],"da":["Fire i hvile","Fire data i et kompakt gitter i hvile; det valgte par forbliver synligt med en aktivitet eller Timeline-visning."],"sv":["Fyra i vila","Fyra värden i ett kompakt rutnät i vila; det valda paret förblir synligt vid en aktivitet eller Timeline-förhandsvisning."],"no":["Fire i hvile","Fire data i et kompakt rutenett i hvile; det valgte paret forblir synlig med en aktivitet eller Timeline-visning."],"fi":["Neljä lepotilassa","Neljä tietoa tiiviissä ruudukossa lepotilassa; valittu pari näkyy toiminnon tai Timeline-esikatselun aikana."],"hu":["Négy nyugalomban","Nyugalomban négy adat tömör rácsban; tevékenység vagy Timeline-előnézet közben a kiválasztott pár látható."],"ro":["Patru în repaus","Patru date într-o grilă compactă în repaus; perechea aleasă rămâne vizibilă cu o activitate sau o previzualizare Timeline."],"tr":["Boştayken dört","Boştayken kompakt ızgarada dört veri; etkinlik veya Timeline önizlemesinde seçilen çift görünür kalır."]};
Object.keys(GRID_WORDS).forEach(function(language){GRID_WORDS.en.forEach(function(key,index){MESSAGES[language][key]=GRID_WORDS[language][index];LITERALS[key]=key;});});
var SETTINGS_UX_WORDS={"en":["Settings","Layout & complications","Colours","Activities","More & help","All settings","Watch appearance","Editing palette","Day palette","Night palette","Colour presets","Expand preview","Collapse preview","Share day colours","Choose complications","Activity setup","Reorder","Done","Split background","Solid background","Watch updated","Waiting for watch","Watch update failed","{count} shown"],"cs":["Nastavení","Rozložení a komplikace","Barvy","Aktivity","Další a nápověda","Všechna nastavení","Vzhled hodinek","Upravovaná paleta","Denní paleta","Noční paleta","Barevné předvolby","Rozbalit náhled","Sbalit náhled","Sdílet denní barvy","Vybrat komplikace","Nastavení aktivit","Změnit pořadí","Hotovo","Dělené pozadí","Jednotné pozadí","Hodinky aktualizovány","Čekání na hodinky","Aktualizace hodinek selhala","Zobrazeno: {count}"],"sk":["Nastavenia","Rozloženie a komplikácie","Farby","Aktivity","Ďalšie a pomoc","Všetky nastavenia","Vzhľad hodiniek","Upravovaná paleta","Denná paleta","Nočná paleta","Farebné predvoľby","Rozbaliť náhľad","Zbaliť náhľad","Zdieľať denné farby","Vybrať komplikácie","Nastavenie aktivít","Zmeniť poradie","Hotovo","Delené pozadie","Jednotné pozadie","Hodinky aktualizované","Čakanie na hodinky","Aktualizácia hodiniek zlyhala","Zobrazené: {count}"],"de":["Einstellungen","Layout und Komplikationen","Farben","Aktivitäten","Mehr und Hilfe","Alle Einstellungen","Aussehen der Uhr","Palette bearbeiten","Tagpalette","Nachtpalette","Farbvorlagen","Vorschau erweitern","Vorschau einklappen","Tagfarben teilen","Komplikationen wählen","Aktivitäten einrichten","Reihenfolge ändern","Fertig","Geteilter Hintergrund","Einheitlicher Hintergrund","Uhr aktualisiert","Warten auf die Uhr","Uhraktualisierung fehlgeschlagen","{count} angezeigt"],"fr":["Réglages","Disposition et complications","Couleurs","Activités","Autres et aide","Tous les réglages","Apparence de la montre","Palette à modifier","Palette de jour","Palette de nuit","Préréglages de couleurs","Agrandir l’aperçu","Réduire l’aperçu","Partager les couleurs de jour","Choisir les complications","Configurer les activités","Réorganiser","Terminé","Fond divisé","Fond uni","Montre mise à jour","En attente de la montre","Échec de mise à jour","{count} affichées"],"es":["Ajustes","Diseño y complicaciones","Colores","Actividades","Más y ayuda","Todos los ajustes","Aspecto del reloj","Paleta en edición","Paleta diurna","Paleta nocturna","Colores predefinidos","Ampliar vista previa","Reducir vista previa","Compartir colores diurnos","Elegir complicaciones","Configurar actividades","Reordenar","Hecho","Fondo dividido","Fondo uniforme","Reloj actualizado","Esperando al reloj","Error al actualizar el reloj","{count} visibles"],"it":["Impostazioni","Layout e complicazioni","Colori","Attività","Altro e aiuto","Tutte le impostazioni","Aspetto dell’orologio","Palette da modificare","Palette diurna","Palette notturna","Colori predefiniti","Espandi anteprima","Riduci anteprima","Condividi colori diurni","Scegli complicazioni","Configura attività","Riordina","Fine","Sfondo diviso","Sfondo uniforme","Orologio aggiornato","In attesa dell’orologio","Aggiornamento non riuscito","{count} visibili"],"pt":["Definições","Disposição e complicações","Cores","Atividades","Mais e ajuda","Todas as definições","Aspeto do relógio","Paleta a editar","Paleta diurna","Paleta noturna","Cores predefinidas","Expandir pré-visualização","Recolher pré-visualização","Partilhar cores diurnas","Escolher complicações","Configurar atividades","Reordenar","Concluído","Fundo dividido","Fundo uniforme","Relógio atualizado","À espera do relógio","Falha ao atualizar o relógio","{count} visíveis"],"nl":["Instellingen","Indeling en complicaties","Kleuren","Activiteiten","Meer en hulp","Alle instellingen","Uiterlijk van het horloge","Palet bewerken","Dagpalet","Nachtpalet","Kleurvoorinstellingen","Voorbeeld vergroten","Voorbeeld verkleinen","Dagkleuren delen","Complicaties kiezen","Activiteiten instellen","Volgorde wijzigen","Gereed","Gesplitste achtergrond","Effen achtergrond","Horloge bijgewerkt","Wachten op horloge","Horloge bijwerken mislukt","{count} zichtbaar"],"pl":["Ustawienia","Układ i komplikacje","Kolory","Aktywności","Więcej i pomoc","Wszystkie ustawienia","Wygląd zegarka","Edytowana paleta","Paleta dzienna","Paleta nocna","Gotowe kolory","Rozwiń podgląd","Zwiń podgląd","Udostępnij kolory dzienne","Wybierz komplikacje","Konfiguracja aktywności","Zmień kolejność","Gotowe","Dzielone tło","Jednolite tło","Zegarek zaktualizowany","Oczekiwanie na zegarek","Aktualizacja nie powiodła się","Widoczne: {count}"],"da":["Indstillinger","Layout og komplikationer","Farver","Aktiviteter","Mere og hjælp","Alle indstillinger","Urets udseende","Palet til redigering","Dagpalet","Natpalet","Forudindstillede farver","Udvid forhåndsvisning","Fold forhåndsvisning sammen","Del dagfarver","Vælg komplikationer","Opsæt aktiviteter","Skift rækkefølge","Færdig","Opdelt baggrund","Ensfarvet baggrund","Uret er opdateret","Venter på uret","Opdatering mislykkedes","{count} vises"],"sv":["Inställningar","Layout och komplikationer","Färger","Aktiviteter","Mer och hjälp","Alla inställningar","Klockans utseende","Palett att redigera","Dagpalett","Nattpalett","Förinställda färger","Utöka förhandsvisning","Fäll ihop förhandsvisning","Dela dagfärger","Välj komplikationer","Ställ in aktiviteter","Ändra ordning","Klart","Delad bakgrund","Enfärgad bakgrund","Klockan uppdaterad","Väntar på klockan","Uppdatering misslyckades","{count} visas"],"no":["Innstillinger","Oppsett og komplikasjoner","Farger","Aktiviteter","Mer og hjelp","Alle innstillinger","Klokkens utseende","Palett som redigeres","Dagpalett","Nattpalett","Forhåndsvalgte farger","Utvid forhåndsvisning","Fold sammen forhåndsvisning","Del dagfarger","Velg komplikasjoner","Sett opp aktiviteter","Endre rekkefølge","Ferdig","Delt bakgrunn","Ensfarget bakgrunn","Klokken er oppdatert","Venter på klokken","Oppdatering mislyktes","{count} vises"],"fi":["Asetukset","Asettelu ja komplikaatiot","Värit","Toiminnot","Lisää ja ohje","Kaikki asetukset","Kellon ulkoasu","Muokattava paletti","Päiväpaletti","Yöpaletti","Valmiit värit","Laajenna esikatselu","Pienennä esikatselu","Jaa päivävärit","Valitse komplikaatiot","Toimintojen asetukset","Järjestä","Valmis","Jaettu tausta","Yhtenäinen tausta","Kello päivitetty","Odotetaan kelloa","Kellon päivitys epäonnistui","{count} näkyvissä"],"hu":["Beállítások","Elrendezés és komplikációk","Színek","Tevékenységek","Továbbiak és súgó","Minden beállítás","Óra megjelenése","Szerkesztett paletta","Nappali paletta","Éjszakai paletta","Előre beállított színek","Előnézet kibontása","Előnézet összecsukása","Nappali színek megosztása","Komplikációk kiválasztása","Tevékenységek beállítása","Átrendezés","Kész","Osztott háttér","Egységes háttér","Óra frissítve","Várakozás az órára","Az óra frissítése sikertelen","{count} látható"],"ro":["Setări","Aspect și complicații","Culori","Activități","Altele și ajutor","Toate setările","Aspectul ceasului","Paleta de editat","Paletă de zi","Paletă de noapte","Culori predefinite","Extinde previzualizarea","Restrânge previzualizarea","Partajează culorile de zi","Alege complicații","Configurare activități","Reordonează","Gata","Fundal împărțit","Fundal uniform","Ceas actualizat","Se așteaptă ceasul","Actualizarea ceasului a eșuat","{count} vizibile"],"tr":["Ayarlar","Düzen ve komplikasyonlar","Renkler","Etkinlikler","Diğer ve yardım","Tüm ayarlar","Saat görünümü","Düzenlenen palet","Gündüz paleti","Gece paleti","Hazır renkler","Önizlemeyi genişlet","Önizlemeyi daralt","Gündüz renklerini paylaş","Komplikasyonları seç","Etkinlik ayarları","Yeniden sırala","Bitti","Bölünmüş arka plan","Düz arka plan","Saat güncellendi","Saat bekleniyor","Saat güncellenemedi","{count} gösteriliyor"]};
Object.keys(SETTINGS_UX_WORDS).forEach(function(language){SETTINGS_UX_WORDS.en.forEach(function(key,index){MESSAGES[language][key]=SETTINGS_UX_WORDS[language][index];LITERALS[key]=key;});});
var PREVIEW_ONLY_WORDS={"en":"Preview only; this does not change the active palette.","cs":"Pouze náhled; aktivní paleta se tím nemění.","sk":"Iba náhľad; aktívna paleta sa tým nemení.","de":"Nur Vorschau; die aktive Palette bleibt unverändert.","fr":"Aperçu uniquement ; la palette active ne change pas.","es":"Solo vista previa; no cambia la paleta activa.","it":"Solo anteprima; la palette attiva non cambia.","pt":"Apenas pré-visualização; não altera a paleta ativa.","nl":"Alleen een voorbeeld; het actieve palet verandert niet.","pl":"Tylko podgląd; aktywna paleta się nie zmienia.","da":"Kun forhåndsvisning; den aktive palet ændres ikke.","sv":"Endast förhandsvisning; den aktiva paletten ändras inte.","no":"Bare forhåndsvisning; den aktive paletten endres ikke.","fi":"Vain esikatselu; käytössä oleva paletti ei muutu.","hu":"Csak előnézet; az aktív paletta nem változik.","ro":"Doar previzualizare; paleta activă nu se schimbă.","tr":"Yalnızca önizleme; etkin paleti değiştirmez."};
Object.keys(PREVIEW_ONLY_WORDS).forEach(function(language){MESSAGES[language][PREVIEW_ONLY_WORDS.en]=PREVIEW_ONLY_WORDS[language];LITERALS[PREVIEW_ONLY_WORDS.en]=PREVIEW_ONLY_WORDS.en;});
var ACTIVITY_SETUP_WORDS={"en":"In Activities, enable activity plugins and show Timer, then save.","cs":"V Aktivitách zapněte pluginy aktivit a zobrazování Timeru a potom uložte.","sk":"V Aktivitách zapnite pluginy aktivít a zobrazovanie Timeru a potom uložte.","de":"Aktiviere unter Aktivitäten die Aktivitäts-Plugins und Timer und speichere dann.","fr":"Dans Activités, activez les plugins d’activité et Timer, puis enregistrez.","es":"En Actividades, activa los plugins de actividad y Timer, y guarda.","it":"In Attività, attiva i plugin attività e Timer, poi salva.","pt":"Em Atividades, ative os plugins de atividade e Timer e guarde.","nl":"Schakel bij Activiteiten de activiteitsplugins en Timer in en sla op.","pl":"W Aktywnościach włącz wtyczki aktywności i Timer, a następnie zapisz.","da":"Aktivér aktivitetsplugins og Timer under Aktiviteter, og gem.","sv":"Aktivera aktivitetspluginer och Timer under Aktiviteter och spara.","no":"Aktiver aktivitetsutvidelser og Timer under Aktiviteter, og lagre.","fi":"Ota Toiminnoissa toimintolisäosat ja Timer käyttöön ja tallenna.","hu":"A Tevékenységek alatt engedélyezd a bővítményeket és a Timert, majd ments.","ro":"În Activități, activează pluginurile de activitate și Timer, apoi salvează.","tr":"Etkinlikler bölümünde etkinlik eklentilerini ve Timer’ı açıp kaydedin."};
Object.keys(ACTIVITY_SETUP_WORDS).forEach(function(language){MESSAGES[language][ACTIVITY_SETUP_WORDS.en]=ACTIVITY_SETUP_WORDS[language];LITERALS[ACTIVITY_SETUP_WORDS.en]=ACTIVITY_SETUP_WORDS.en;});
module.exports = {resolveLanguage:resolveLanguage, translateConfig:translateConfig,
  t:t, settingsStrings:settingsStrings, languages:LANGUAGES.slice()};

},
function(module,exports,require){
'use strict';
// Project-owned display wording; keep every supported locale complete.
module.exports={
  "en": {
    "followQuietTime": "Follow Quiet Time",
    "manualAppearance": "Manual",
    "manualPalette": "Manual palette",
    "nightBackground": "Night background",
    "nightText": "Night text",
    "nightAccent": "Night accent",
    "displayTextSize": "Text size",
    "displaySmall": "Small",
    "displayMedium": "Medium",
    "displayLarge": "Large",
    "appearanceUnavailable": "Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.",
    "displayApplied": "Applied on watch",
    "displayPending": "Saved on phone · Pending on watch",
    "displayFailed": "Saved on phone · Watch could not confirm saving",
    "displayRetry": "Retry watch delivery"
  },
  "cs": {
    "followQuietTime": "Podle režimu klidu",
    "manualAppearance": "Ručně",
    "manualPalette": "Ruční paleta",
    "nightBackground": "Noční pozadí",
    "nightText": "Noční text",
    "nightAccent": "Noční zvýraznění",
    "displayTextSize": "Velikost textu",
    "displaySmall": "Malá",
    "displayMedium": "Střední",
    "displayLarge": "Velká",
    "appearanceUnavailable": "Vzhled podle Pebble není v této verzi dostupný. Použije se poslední světlá nebo tmavá volba.",
    "displayApplied": "Použito v hodinkách",
    "displayPending": "Uloženo v telefonu · Čeká na hodinky",
    "displayFailed": "Uloženo v telefonu · Hodinky nepotvrdily uložení",
    "displayRetry": "Znovu odeslat do hodinek"
  },
  "sk": {
    "followQuietTime": "Podľa tichého režimu",
    "manualAppearance": "Ručne",
    "manualPalette": "Ručná paleta",
    "nightBackground": "Nočné pozadie",
    "nightText": "Nočný text",
    "nightAccent": "Nočné zvýraznenie",
    "displayTextSize": "Veľkosť textu",
    "displaySmall": "Malá",
    "displayMedium": "Stredná",
    "displayLarge": "Veľká",
    "appearanceUnavailable": "Vzhľad podľa Pebble nie je v tejto verzii dostupný. Použije sa posledná svetlá alebo tmavá voľba.",
    "displayApplied": "Použité v hodinkách",
    "displayPending": "Uložené v telefóne · Čaká na hodinky",
    "displayFailed": "Uložené v telefóne · Hodinky nepotvrdili uloženie",
    "displayRetry": "Znova odoslať do hodiniek"
  },
  "de": {
    "followQuietTime": "Ruhezeit folgen",
    "manualAppearance": "Manuell",
    "manualPalette": "Manuelle Palette",
    "nightBackground": "Nachthintergrund",
    "nightText": "Nachttext",
    "nightAccent": "Nachtakzent",
    "displayTextSize": "Textgröße",
    "displaySmall": "Klein",
    "displayMedium": "Mittel",
    "displayLarge": "Groß",
    "appearanceUnavailable": "Das Pebble-Erscheinungsbild ist in dieser Version nicht verfügbar. Die letzte Auswahl Hell oder Dunkel wird verwendet.",
    "displayApplied": "Auf der Uhr angewendet",
    "displayPending": "Auf dem Telefon gespeichert · Auf der Uhr ausstehend",
    "displayFailed": "Auf dem Telefon gespeichert · Uhr konnte das Speichern nicht bestätigen",
    "displayRetry": "Erneut an die Uhr senden"
  },
  "fr": {
    "followQuietTime": "Suivre le mode silencieux",
    "manualAppearance": "Manuel",
    "manualPalette": "Palette manuelle",
    "nightBackground": "Fond de nuit",
    "nightText": "Texte de nuit",
    "nightAccent": "Accent de nuit",
    "displayTextSize": "Taille du texte",
    "displaySmall": "Petite",
    "displayMedium": "Moyenne",
    "displayLarge": "Grande",
    "appearanceUnavailable": "Le thème Pebble est indisponible dans cette version. Le dernier choix Clair ou Sombre est utilisé.",
    "displayApplied": "Appliqué sur la montre",
    "displayPending": "Enregistré sur le téléphone · En attente sur la montre",
    "displayFailed": "Enregistré sur le téléphone · La montre n’a pas confirmé l’enregistrement",
    "displayRetry": "Renvoyer à la montre"
  },
  "es": {
    "followQuietTime": "Seguir modo silencioso",
    "manualAppearance": "Manual",
    "manualPalette": "Paleta manual",
    "nightBackground": "Fondo nocturno",
    "nightText": "Texto nocturno",
    "nightAccent": "Acento nocturno",
    "displayTextSize": "Tamaño del texto",
    "displaySmall": "Pequeño",
    "displayMedium": "Mediano",
    "displayLarge": "Grande",
    "appearanceUnavailable": "El aspecto de Pebble no está disponible en esta versión. Se usa la última opción Claro u Oscuro.",
    "displayApplied": "Aplicado en el reloj",
    "displayPending": "Guardado en el teléfono · Pendiente en el reloj",
    "displayFailed": "Guardado en el teléfono · El reloj no confirmó el guardado",
    "displayRetry": "Reenviar al reloj"
  },
  "it": {
    "followQuietTime": "Segui modalità silenziosa",
    "manualAppearance": "Manuale",
    "manualPalette": "Tavolozza manuale",
    "nightBackground": "Sfondo notturno",
    "nightText": "Testo notturno",
    "nightAccent": "Accento notturno",
    "displayTextSize": "Dimensione del testo",
    "displaySmall": "Piccolo",
    "displayMedium": "Medio",
    "displayLarge": "Grande",
    "appearanceUnavailable": "L’aspetto Pebble non è disponibile in questa versione. Viene usata l’ultima scelta Chiaro o Scuro.",
    "displayApplied": "Applicato sull’orologio",
    "displayPending": "Salvato sul telefono · In attesa sull’orologio",
    "displayFailed": "Salvato sul telefono · L’orologio non ha confermato il salvataggio",
    "displayRetry": "Invia di nuovo all’orologio"
  },
  "pt": {
    "followQuietTime": "Seguir modo silencioso",
    "manualAppearance": "Manual",
    "manualPalette": "Paleta manual",
    "nightBackground": "Fundo noturno",
    "nightText": "Texto noturno",
    "nightAccent": "Destaque noturno",
    "displayTextSize": "Tamanho do texto",
    "displaySmall": "Pequeno",
    "displayMedium": "Médio",
    "displayLarge": "Grande",
    "appearanceUnavailable": "O aspeto do Pebble não está disponível nesta versão. É usada a última escolha Claro ou Escuro.",
    "displayApplied": "Aplicado no relógio",
    "displayPending": "Guardado no telefone · Pendente no relógio",
    "displayFailed": "Guardado no telefone · O relógio não confirmou a gravação",
    "displayRetry": "Reenviar para o relógio"
  },
  "nl": {
    "followQuietTime": "Stille tijd volgen",
    "manualAppearance": "Handmatig",
    "manualPalette": "Handmatig palet",
    "nightBackground": "Nachtachtergrond",
    "nightText": "Nachttekst",
    "nightAccent": "Nachtaccent",
    "displayTextSize": "Tekstgrootte",
    "displaySmall": "Klein",
    "displayMedium": "Gemiddeld",
    "displayLarge": "Groot",
    "appearanceUnavailable": "De Pebble-weergave is niet beschikbaar in deze versie. De laatste keuze Licht of Donker wordt gebruikt.",
    "displayApplied": "Toegepast op horloge",
    "displayPending": "Opgeslagen op telefoon · Wacht op horloge",
    "displayFailed": "Opgeslagen op telefoon · Horloge kon opslaan niet bevestigen",
    "displayRetry": "Opnieuw naar horloge sturen"
  },
  "pl": {
    "followQuietTime": "Według trybu ciszy",
    "manualAppearance": "Ręcznie",
    "manualPalette": "Paleta ręczna",
    "nightBackground": "Tło nocne",
    "nightText": "Tekst nocny",
    "nightAccent": "Akcent nocny",
    "displayTextSize": "Rozmiar tekstu",
    "displaySmall": "Mały",
    "displayMedium": "Średni",
    "displayLarge": "Duży",
    "appearanceUnavailable": "Wygląd według Pebble jest niedostępny w tej wersji. Używany jest ostatni wybór Jasny lub Ciemny.",
    "displayApplied": "Zastosowano na zegarku",
    "displayPending": "Zapisano w telefonie · Oczekuje na zegarek",
    "displayFailed": "Zapisano w telefonie · Zegarek nie potwierdził zapisu",
    "displayRetry": "Wyślij ponownie na zegarek"
  },
  "da": {
    "followQuietTime": "Følg stilletid",
    "manualAppearance": "Manuel",
    "manualPalette": "Manuel palet",
    "nightBackground": "Natbaggrund",
    "nightText": "Nattekst",
    "nightAccent": "Natfremhævning",
    "displayTextSize": "Tekststørrelse",
    "displaySmall": "Lille",
    "displayMedium": "Mellem",
    "displayLarge": "Stor",
    "appearanceUnavailable": "Pebbles udseende er ikke tilgængeligt i denne version. Dit seneste valg Lys eller Mørk bruges.",
    "displayApplied": "Anvendt på uret",
    "displayPending": "Gemt på telefonen · Afventer uret",
    "displayFailed": "Gemt på telefonen · Uret kunne ikke bekræfte lagringen",
    "displayRetry": "Send til uret igen"
  },
  "sv": {
    "followQuietTime": "Följ tyst läge",
    "manualAppearance": "Manuellt",
    "manualPalette": "Manuell palett",
    "nightBackground": "Nattbakgrund",
    "nightText": "Nattext",
    "nightAccent": "Nattaccent",
    "displayTextSize": "Textstorlek",
    "displaySmall": "Liten",
    "displayMedium": "Mellan",
    "displayLarge": "Stor",
    "appearanceUnavailable": "Pebbles utseende är inte tillgängligt i denna version. Ditt senaste val Ljust eller Mörkt används.",
    "displayApplied": "Tillämpat på klockan",
    "displayPending": "Sparat på telefonen · Väntar på klockan",
    "displayFailed": "Sparat på telefonen · Klockan kunde inte bekräfta sparandet",
    "displayRetry": "Skicka till klockan igen"
  },
  "no": {
    "followQuietTime": "Følg stilletid",
    "manualAppearance": "Manuelt",
    "manualPalette": "Manuell palett",
    "nightBackground": "Nattbakgrunn",
    "nightText": "Natttekst",
    "nightAccent": "Nattfremheving",
    "displayTextSize": "Tekststørrelse",
    "displaySmall": "Liten",
    "displayMedium": "Middels",
    "displayLarge": "Stor",
    "appearanceUnavailable": "Pebbles utseende er ikke tilgjengelig i denne versjonen. Ditt siste valg Lyst eller Mørkt brukes.",
    "displayApplied": "Brukt på klokken",
    "displayPending": "Lagret på telefonen · Venter på klokken",
    "displayFailed": "Lagret på telefonen · Klokken kunne ikke bekrefte lagringen",
    "displayRetry": "Send til klokken igjen"
  },
  "fi": {
    "followQuietTime": "Seuraa hiljaista tilaa",
    "manualAppearance": "Manuaalinen",
    "manualPalette": "Manuaalinen paletti",
    "nightBackground": "Yötausta",
    "nightText": "Yöteksti",
    "nightAccent": "Yökorostus",
    "displayTextSize": "Tekstin koko",
    "displaySmall": "Pieni",
    "displayMedium": "Keskikokoinen",
    "displayLarge": "Suuri",
    "appearanceUnavailable": "Pebblen ulkoasu ei ole käytettävissä tässä versiossa. Käytetään viimeisintä Vaalea- tai Tumma-valintaa.",
    "displayApplied": "Käytössä kellossa",
    "displayPending": "Tallennettu puhelimeen · Odottaa kelloa",
    "displayFailed": "Tallennettu puhelimeen · Kello ei vahvistanut tallennusta",
    "displayRetry": "Lähetä kelloon uudelleen"
  },
  "hu": {
    "followQuietTime": "Csendes mód követése",
    "manualAppearance": "Kézi",
    "manualPalette": "Kézi paletta",
    "nightBackground": "Éjszakai háttér",
    "nightText": "Éjszakai szöveg",
    "nightAccent": "Éjszakai kiemelés",
    "displayTextSize": "Szövegméret",
    "displaySmall": "Kicsi",
    "displayMedium": "Közepes",
    "displayLarge": "Nagy",
    "appearanceUnavailable": "A Pebble megjelenése ebben a verzióban nem érhető el. Az utolsó Világos vagy Sötét választás érvényes.",
    "displayApplied": "Alkalmazva az órán",
    "displayPending": "Mentve a telefonon · Várakozás az órára",
    "displayFailed": "Mentve a telefonon · Az óra nem igazolta vissza a mentést",
    "displayRetry": "Újraküldés az órára"
  },
  "ro": {
    "followQuietTime": "Urmează modul silențios",
    "manualAppearance": "Manual",
    "manualPalette": "Paletă manuală",
    "nightBackground": "Fundal de noapte",
    "nightText": "Text de noapte",
    "nightAccent": "Accent de noapte",
    "displayTextSize": "Mărimea textului",
    "displaySmall": "Mic",
    "displayMedium": "Mediu",
    "displayLarge": "Mare",
    "appearanceUnavailable": "Aspectul Pebble nu este disponibil în această versiune. Se folosește ultima alegere Luminos sau Întunecat.",
    "displayApplied": "Aplicat pe ceas",
    "displayPending": "Salvat pe telefon · În așteptare pe ceas",
    "displayFailed": "Salvat pe telefon · Ceasul nu a confirmat salvarea",
    "displayRetry": "Retrimite la ceas"
  },
  "tr": {
    "followQuietTime": "Sessiz modu izle",
    "manualAppearance": "Manuel",
    "manualPalette": "Manuel palet",
    "nightBackground": "Gece arka planı",
    "nightText": "Gece metni",
    "nightAccent": "Gece vurgusu",
    "displayTextSize": "Metin boyutu",
    "displaySmall": "Küçük",
    "displayMedium": "Orta",
    "displayLarge": "Büyük",
    "appearanceUnavailable": "Pebble görünümü bu sürümde kullanılamıyor. Son Açık veya Koyu seçiminiz kullanılır.",
    "displayApplied": "Saatte uygulandı",
    "displayPending": "Telefona kaydedildi · Saat bekleniyor",
    "displayFailed": "Telefona kaydedildi · Saat kaydetmeyi onaylamadı",
    "displayRetry": "Saate yeniden gönder"
  }
};

},
function(module,exports,require){
'use strict';

// One Clay form owns the draft; the page hook presents four category screens.
module.exports = [
  {"type":"heading","defaultValue":"Dynamic"},
  {"type":"text","id":"dynamic-overview","defaultValue":"Settings"},
  {"type":"text","id":"dynamic-preview","defaultValue":"Layout & colour preview"},
  {type:'section',items:[
    {"type":"heading","defaultValue":"Layout & complications"},
    {"type":"select","messageKey":"READING_LAYOUT","defaultValue":0,"label":"Reading layout","serializeValueAs":"integer","options":[{"label":"Columns","value":0},{"label":"Stacked rows","value":1},{"label":"Four when idle","value":2}],"description":"Four readings in a compact grid when idle; the selected pair stays visible with an activity or Timeline Peek."},
    {"type":"toggle","messageKey":"HIDE_READING_TITLES","defaultValue":false,"label":"Hide reading titles","description":"Units, required qualifiers and unavailable states stay visible."},
    {"type":"toggle","messageKey":"SHAKE_READINGS","defaultValue":false,"label":"Shake to switch readings","description":"Cycle Pebble slots 1–2, 3–4 and 5. The page stays selected until the next shake."},
    {"type":"text","id":"dynamic-readings","defaultValue":"Your two readings"},
    {"type":"text","id":"dynamic-reading-help","defaultValue":"Choose slots 1 and 2 in Pebble → Settings → Complications."},
  ]},
  {type:'section',items:[
    {"type":"heading","defaultValue":"Colours"},
    {"type":"text","id":"dynamic-appearance-choice","defaultValue":"Watch appearance"},
    {"type":"text","id":"dynamic-appearance-unavailable","defaultValue":"Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice."},
    {"type":"text","id":"dynamic-edit-palette","defaultValue":"Editing palette"},
    {"type":"toggle","messageKey":"SCREEN_SPLIT","defaultValue":false,"label":"Split clock and details"},
    {"type":"text","id":"dynamic-theme","defaultValue":"Colour presets"},
    {"type":"color","messageKey":"BACKGROUND_COLOR","defaultValue":"0xFFFFFF","label":"Background color","layout":"COLOR","sunlight":false},
    {"type":"color","messageKey":"TEXT_COLOR","defaultValue":"0x000000","label":"Text color","layout":"COLOR","sunlight":false},
    {"type":"color","messageKey":"ACCENT_COLOR","defaultValue":"0x55AAFF","label":"Accent color","description":"Color for reading symbols and rain gauges.","layout":"COLOR","sunlight":false},
    {"type":"color","messageKey":"LOWER_BACKGROUND_COLOR","defaultValue":"0x000000","label":"Details background","layout":"COLOR","sunlight":false},
    {"type":"color","messageKey":"LOWER_TEXT_COLOR","defaultValue":"0xFFFFFF","label":"Details text","layout":"COLOR","sunlight":false},
    {"type":"color","messageKey":"NIGHT_BACKGROUND_COLOR","defaultValue":"0x000000","label":"Night background","layout":"COLOR","sunlight":false},
    {"type":"color","messageKey":"NIGHT_TEXT_COLOR","defaultValue":"0xFFFFFF","label":"Night text","layout":"COLOR","sunlight":false},
    {"type":"color","messageKey":"NIGHT_ACCENT_COLOR","defaultValue":"0x55AAFF","label":"Night accent","layout":"COLOR","sunlight":false},
    {"type":"color","messageKey":"NIGHT_LOWER_BACKGROUND_COLOR","defaultValue":"0xFFFFFF","label":"Night details background","layout":"COLOR","sunlight":false},
    {"type":"color","messageKey":"NIGHT_LOWER_TEXT_COLOR","defaultValue":"0x000000","label":"Night details text","layout":"COLOR","sunlight":false},
    {"type":"text","id":"dynamic-contrast","defaultValue":""},
    {"type":"text","id":"dynamic-palette-code","defaultValue":"Share colours"},
    {"type":"select","messageKey":"APPEARANCE_MODE","defaultValue":2,"label":"Appearance","serializeValueAs":"integer","options":[{"label":"Follow Pebble","value":0},{"label":"Follow Quiet Time","value":1},{"label":"Manual","value":2}]},
    {"type":"select","messageKey":"MANUAL_APPEARANCE","defaultValue":0,"label":"Manual palette","serializeValueAs":"integer","options":[{"label":"Light","value":0},{"label":"Dark","value":1}]},
    {"type":"toggle","messageKey":"NIGHT_PALETTE","defaultValue":false,"label":"Quiet Time colours","description":"Use these watch colours while Pebble Quiet Time is active."},
  ]},
  {type:'section',items:[
    {"type":"heading","defaultValue":"Activities"},
    {"type":"toggle","messageKey":"SHOW_ACTIVITIES","defaultValue":true,"label":"Show activity plugins","description":"Show activities from installed plugins. Music and Notifications have their own switches in the list below."},
    {"type":"text","id":"dynamic-activity-order","defaultValue":"Activity priority"},
    {"type":"toggle","messageKey":"SHOW_MUSIC","defaultValue":true,"label":"Show music while playing"},
    {"type":"toggle","messageKey":"SHOW_NOTIFICATIONS","defaultValue":false,"label":"New notifications"},
    {"type":"text","id":"dynamic-notification-mode","defaultValue":"Notification details"},
    {"type":"text","id":"dynamic-notification-disabled","defaultValue":"Enable Notifications in the activity list to change its details."},
    {"type":"toggle","messageKey":"NOTIFICATION_PREVIEW","defaultValue":false,"label":"Include message text"},
    {"type":"toggle","messageKey":"NOTIFICATION_APP_ONLY","defaultValue":false,"label":"App name only"},
    {"type":"select","messageKey":"NOTIFICATION_VIBRATION","defaultValue":0,"label":"Additional vibration","description":"One additional vibration per new notification burst, using your app filter. Respects Quiet Time. Turn this off if Pebble already vibrates for those notifications.","serializeValueAs":"integer","options":[{"label":"Off","value":0},{"label":"Short pulse","value":1},{"label":"Double pulse","value":2}]},
    {"type":"text","id":"dynamic-app-mode","defaultValue":"Notification apps"},
    {"type":"input","messageKey":"NOTIFICATION_APPS","defaultValue":"","label":"Selected apps","description":"Use exact app names or Android package names, separated by commas. For example: Signal, org.thoughtcrime.securesms","attributes":{"type":"text","maxlength":160,"autocapitalize":"none","autocomplete":"off","spellcheck":"false"}},
    {"type":"text","id":"dynamic-notification-help","defaultValue":"New notifications use the same activity priority and primary/secondary layouts. Allow notification access in Pebble. Pebble’s system notifications remain separate."},
  ]},
  {type:'section',items:[
    {"type":"heading","defaultValue":"More & help"},
    {"type":"select","messageKey":"CLOCK_FORMAT","defaultValue":0,"label":"Time format","serializeValueAs":"integer","options":[{"label":"Follow Pebble","value":0},{"label":"12-hour time","value":12},{"label":"24-hour time","value":24}]},
    {"type":"select","messageKey":"TEXT_SIZE","defaultValue":0,"label":"Text size","serializeValueAs":"integer","options":[{"label":"Follow Pebble","value":0},{"label":"Small","value":1},{"label":"Medium","value":2},{"label":"Large","value":3}]},
    {"type":"toggle","messageKey":"ANIMATIONS","defaultValue":true,"label":"Animations","description":"Short transitions when activities change."},
    {"type":"toggle","messageKey":"SHOW_STATUS","defaultValue":true,"label":"Status indicators","description":"Low watch or phone battery and lost connection."},
    {"type":"text","defaultValue":"Language follows your watch."},
    {"type":"text","id":"dynamic-activity-help","defaultValue":"Activity setup"},
    {"type":"heading","defaultValue":"What is an activity?","id":"dynamic-activity-help-0"},
    {"type":"text","defaultValue":"Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.","id":"dynamic-activity-help-1"},
    {"type":"text","defaultValue":"Start a countdown in Timer, then return to Dynamic to see the time remaining. Timer still runs the countdown and alarm.","id":"dynamic-activity-help-2"},
    {"type":"text","defaultValue":"In Activities, enable activity plugins and show Timer, then save.","id":"dynamic-activity-help-3"},
    {"type":"text","defaultValue":"Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.","id":"dynamic-activity-help-4"},
    {"type":"text","defaultValue":"Status when settings opened. Reopen settings to refresh."},
    {"type":"text","id":"dynamic-source-status","defaultValue":"Dynamic content: waiting for Pebble"},
    {"type":"text","id":"complications-status","defaultValue":"Complications: waiting for Pebble"},
    {"type":"text","id":"context-status","defaultValue":"Dynamic content: waiting for Pebble"},
    {"type":"text","id":"dynamic-repository","defaultValue":"Source code: https://github.com/xefensor/pebble-watchface-dynamic"},
    {"type":"text","id":"dynamic-issues","defaultValue":"Feedback: https://github.com/xefensor/pebble-watchface-dynamic/issues"},
    {"type":"text","defaultValue":"Timeline Peek keeps the clock and complications. Its event panel takes priority over music and notifications."},
  ]},
  {"type":"text","id":"dynamic-save-status","defaultValue":"Changes apply after you save."},
  {"type":"text","id":"dynamic-display-status","defaultValue":"Saved on phone · Pending on watch"},
  {"type":"submit","defaultValue":"Save"},
  {"type":"text","id":"dynamic-settings-data","defaultValue":"{}"},
  {"type":"text","id":"dynamic-settings-strings","defaultValue":"{}"},
  {"type":"text","id":"dynamic-preview-assets","defaultValue":"{}"},
  {"type":"input","messageKey":"__dynamicActivityPreferences","defaultValue":"","attributes":{"type":"hidden"}},
];

}
]);
