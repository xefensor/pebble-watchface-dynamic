Local review kit for Dynamic 0.19.0.
Not submitted or published.

Remaining publication gates:
- Physical Time 2 and current Android Pebble app checks (Round 2 is emulator-only)
- Verify Developer Dashboard listing ownership, UUID and unused version
- Publish and verify proposed privacy/support URLs
- Explicit final publication approval

https://developer.repebble.com/guides/appstore-publishing/preparing-a-submission/
https://developer.repebble.com/guides/plugins/publishing-plugins/
