Local review kit for Dynamic 1.0.0.
Not submitted or published.

Remaining publication gates:
- Verify Developer Dashboard ownership, existing listing and unused numeric version
- Verify live app-owned support/privacy URLs
- Publish exact checked GitHub and Store artifacts, then activate website links

https://developer.repebble.com/guides/appstore-publishing/preparing-a-submission/
https://developer.repebble.com/guides/plugins/publishing-plugins/
