# Changelog

## 1.0.2

- New XOCE launcher icon.
- Clearer settings help and more stable status messages.
- Improved keyboard navigation for colour palettes and labelled layout previews.
- The current app version is now kept separate from historical preview-image versions.

## 1.0.1

- Package the current reviewed implementation and updated Store assets under a new numeric version, preserving the public UUID and saved settings.
- Earlier released binaries and archives remain unchanged.
- Includes split colours, adaptive two/four-reading layouts, title visibility, shake paging, percent fitting and reorganized phone settings.

## 1.0.0

- Number the first stable public release 1.0.0.
- Retain the reviewed Round 2 and Time 2 implementation, identity, settings and protocols.

## 0.19.1

- Prepare the reviewed full-circle Round 2 layouts for stable publication.
- Preserve complete readings, music artwork and simultaneous track transitions.
- Keep Time 2, saved settings, provider identities and expiry unchanged.

## 0.19.0

Time 2 and Round 2 SDK 4.44 candidate; shared numeric fitting, saved text-size application, paired music transitions and stable loading-art geometry. Duo is deferred. Physical Time 2 and Android checks remain pending.

## 0.18.3

- Adopt shared XOCE type roles, icons and phone settings styling while retaining the Fredoka clock and values.
- Combine each complication symbol, value and unit; retain meaningful public qualifiers and source labels while removing redundant weather captions.
- Restore animated layout changes, Peek response and genuine item transitions. Keep accent complication icons, readable values and the expanded activity area.
- Bundle Core 0.5.2 and UI 0.1.1. Preserve v1–v4 readings, ACT3 activity identity, preferences and private-content handling.
- GitHub development prerelease with fresh package/native emulator validation; physical-device and fresh browser checks remain unverified.

## 0.18.2

- Redesign all native type roles and vertical bands together after Xef rejected
  the header-only correction: readable Roboto utility text, Fredoka values,
  larger reading labels, static secondary and proportionate 24–28px icons.
- Keep the numeric date in compact views; retain weekday/date on Idle and Peek.
  Use a 28px media cover and one larger artist line alongside readable titles.
- Fold paused state and structured detail into the contextual footer before
  optional identity; keep ordinary paused, workout, navigation and message
  layouts alongside the static secondary. Protect complete essential values.
- Keep the secondary receipt/navigation gate tied to actual layout visibility
  when an exceptional value needs the extra space. Preserve local clock ticks.
- Refresh actual native phone previews and their artwork-preservation geometry.
  Local review only; preserve all earlier artifacts and published releases.

## 0.18.1

- Apply Xef’s readability correction: larger date, compact time and reading labels.
- Center footer/secondary caption ink and direction symbols with adjacent text
  using actual glyph metrics, retaining fixed activity/footer bounds.
- Center phone control labels/chevrons and enlarge section/preview button text.
- Preserve identity, source/privacy/lifecycle and all 17-language form contracts.
- Local design review only; main and earlier versioned artifacts stay unchanged.

## 0.18.0

- Unpublished design-branch alternative for visual review. Keep Fredoka time,
  the fixed reading/activity homes, contextual footer and one static secondary.
- Use native Gothic Bold for date and compact reading labels; preserve exact
  Roboto metrics for multi-line activity fitting. Give semantic icons consistent
  2px strokes and filled timer/music silhouettes.
- Keep the 520ms layout morph and bounded 280ms incoming-only replacement;
  add a small 3px settle without replaying on ticks or metadata corrections.
- Align the 17-language phone pages around an app-name title, brief intro,
  neutral headings, 16/24px spacing, accent-filled buttons and left-aligned save
  status. Respect reduced motion for short control/disclosure transitions.
- Preserve confirmed-load/save receipts, persistent Saved, local Discard,
  arbitrary RGB palettes, legacy close fallback and all source/privacy contracts.
- Fresh native captures, actual motion frames, portable tests and exact packaged
  audit pass. Fresh browser QA is blocked by Chromium sandbox restrictions;
  prior browser evidence remains historical. No store/public release is prepared.

## 0.17.0

- Adopt the shared neutral/blue phone settings presentation, including readable
  section shortcuts at enlarged text sizes and consistent Save/status controls.
- Bundle a configuration page that starts Clay only after a confirmed settings
  read. Save stays open with persistent confirmation; failed or uncertain saves
  keep the draft and offer explicit recovery. All 17 page languages remain.
- Confirm the exact phone snapshot through the current PKJS writer or config
  plugin, including Android runtime handoffs. Store stable activity preferences
  atomically with appearance/privacy choices in the existing Clay settings key;
  read older separate preference records without rewriting them on open.
- Restore the latest confirmed draft locally on Discard, without a write or
  forced input focus. Retain native browser scroll anchoring when controls change
  height, and preserve arbitrary stored RGB colours on unrelated saves.
- Keep the legacy return-URL Save-and-close route as a compatibility fallback.
  Preserve native layouts, source identities, expiry, app destinations and the
  pinned Activities/Core versions. Refresh 24 exact native settings previews.
- Local candidate only; no published release or existing artifact is replaced.

## 0.16.2

- Show localized Paused in primary media's existing artwork/artist footer,
  matching the secondary row. Keep the track title, cover and active layout.
- Keep Paused visible when artist metadata is missing or expires; never show
  an expired artist or replay a track transition for playback-only updates.
- Pin Activities 0.4.4: preserve schema-4 paused playback in native frames and
  recover failed provider subscriptions without replacing healthy ones.
- Verify all five media playback states in both roles, original identity/leases,
  standard activities with media icons, native presentation and packaged routes.

## 0.16.1

- Stop Dynamic's motion, activity ticks and presentation heartbeat while covered;
  retain expiry checks and restore the latest clock, palette and activity without
  replaying a transition when the face returns.
- Keep static activity pixels out of minute-only wall-clock invalidations while
  preserving running clocks, locale changes, expiry and promotion. Settle an
  incoming layout immediately if its decorative timer cannot be allocated.
- Cancel obsolete phone bootstrap retries and discard their queued requests
  after a native baseline arrives, preserving other messages' FIFO order.
- Pin Activities 0.4.3 for subscription reuse, source/expiry invalidation and
  reconnect delivery barriers. Preserve Core 0.5.1, layouts and privacy defaults.

## 0.16.0

- Reuse one activity plan across scheduling, drawing and bounded motion. Recheck
  all clock/expiry/locale/session changes and confirm only actually painted roles.
- Batch bitmap pixels into equal-colour runs and skip unrelated redraws and
  unchanged native settings writes. Preserve artwork, typography and transitions.
- Pin Core 0.5.1: validate the complete context packet while retaining only a
  12-byte phone-status record. Pin Activities 0.4.2 and its narrower host entry.
- Defer phone settings initialization, cache saved preferences until a settings
  event, coalesce preview/layout work and reuse preview colour mappings.
- Minify release JavaScript without expression compression or property mangling;
  retain original SDK inputs and exact maps in a separate developer debug ZIP.
- Recheck native compositions, local clocks, routing, settings and final packaged
  cross-app behavior. Published 0.15.0 files and tags remain unchanged.

## 0.15.0

- Separate the single secondary activity row with a restrained divider while
  retaining bottom-aligned primary content, artwork/artist context and static text.
- Localize Paused in all 17 watch languages and show it in either activity role.
  Give it priority over optional labels/context; a compact value and paused state
  that cannot fit together yield the optional row rather than looking active.
- Add a real native Timer+Music settings preview, with 24 state/format/theme
  captures. Keep sample selection independent of saved appearance and privacy.
- Collapse colour-code sharing, complete preview keyboard navigation with
  Home/End/wrapping arrows, and keep focused inputs/selects visible above Save.
- Measure the action area's height and put it into page flow in short viewports,
  including visual-viewport changes, while preserving phone Back/history.
- Review 64 native compositions, 24 settings captures, actual EN/CS Clay,
  enlarged text and the final packaged cross-app privacy/shortcut handoff.

## 0.14.0

- Clean up settings into Appearance, Content & priority, and Connection & help,
  with three keyboard-accessible section shortcuts and a fixed Save area.
- Use the activity list as the single visibility control for Music and
  Notifications. Keep notification detail choices separate and preserve saved
  app-only/body preferences while hidden and after reopening settings.
- Explain that the activity-plugin switch leaves Music and Notifications
  independent. Show why generic rows are disabled without changing saved order
  or per-app visibility. Remove the obsolete activity clock-mark claim and
  redundant reading/status copy; label the title-only preview accurately.
- Retain all preference keys, defaults, 17 locales, activity protocols and the
  0.13.0 native renderer. Refresh the actual Clay checks, 20 native preview assets,
  package provenance and local sideload materials. Earlier archives stay intact.

## 0.13.0

- Render Notifications through the same ACT3 activity selection, primary and
  one-row secondary layouts as Timer, Music and other providers. Source app
  icons and identity stay visible, with or without optional message text.
- Add Notifications to Dynamic's priority/show-hide list. Preserve its Off
  default and app-only/summary/message privacy controls. Start it first when no
  Notifications position has been saved, and respect explicit user ordering.
- Keep one eight-second notification window across privacy modes, capped by
  original source expiry. Baselines do not replay history; privacy, expiry and
  disconnection clear the activity. Source/app-only fallbacks avoid duplicate
  app headings. Optional vibration retains its own bounded event confirmation.
- Route both notification roles through ordinary native presentation status
  and Open Activity metadata, including summaries without message text. Remove
  the separate native notification panel and its special navigation flag.
- Pin Activities 0.4.1, retain Core 0.5.0 and refresh native/browser previews,
  package identity and local sideload materials. Prior artifacts remain intact.

## 0.12.1

- Bottom-align the whole primary activity group with its context footer.
  Media titles sit directly above artwork/artist; standard labels, values,
  supporting text and range indicators move together above their footer.
- Keep the existing 8px footer gap, typography, wrapping limits and optional
  secondary row position. Short content leaves spare space above the group.
- Refresh the affected native previews and local package evidence. Source APIs,
  activity priority, clock ownership and app navigation retain their 0.12.0 behavior.

## 0.12.0

- Adopt Activities 0.4.0 summary schema 4 and explicit ACT3 presentation metadata;
  preserve older provider conventions through phone-side adaptation.
- Put one static compact row above the primary. Anchor context at the bottom,
  with title/artwork/artist for media. Expand primary when secondary is absent.
- Remove automatic title continuation, fixed app headers and Last reported UI.
  Preserve complete values, independent clocks and native Timer lease ownership.
- Use one activity renderer for media and standard content. Add bounded incoming
  transitions for real activity/media replacements without per-tick motion.
- Publish a bounded recent destination record after native presentation status
  for the separate Open Activity helper. Preserve existing keys and append only
  the two status-channel keys. No Dashboard or fork is required.

## 0.11.0

- Adopt the simpler activity/live schema 3 contract: content, optional detail
  and optional image. Plugin developers do not arrange labels, add meters or
  choose watchface layouts. Existing activity/card and session providers remain
  compatible through Activities 0.3.0.
- Redesign normal activities with a small app/icon header and full-width main
  content below it. Song titles keep 24px type and readable wrapping instead of
  sitting in a narrow column beside the image. Clocks use the full value area.
- Render useful detail without boilerplate Track/Artist prefixes; omit missing
  optional artist metadata. Preserve meaningful Rest/ETA labels from existing
  providers, complete values/units and original last-reported age.
- Keep compact activities in a distinct named band. Any activity can take
  either role, following Dynamic's existing saved priority and visibility.
- Validate the actual production Music adapter in native fixture generation,
  including the reported long-title/missing-artist case. Preserve clock, expiry,
  privacy, source revision and native Timer ownership across the simpler API.
- Pin Activities 0.3.0; keep Core 0.5.0. GitHub development prerelease for
  sideload testing. Earlier published assets/tags remain unchanged.

## 0.10.0

- Give every activity a visible app identity and icon. The primary card has
  prominent content; the optional secondary card has its own divided band,
  icon, app name and current content. Any activity can occupy either role.
- Show a recognizable hourglass for Timer without repeating its configured
  duration. Preserve meaningful metric labels, complete units, independent
  supporting items and explicit last-reported provenance.
- Add a reorderable, show/hide activity list in Dynamic's settings. Music
  participates in the same order as compatible plugins. Preferences belong to
  Dynamic; other apps retain their own order. Newly installed providers append
  to saved choices, including compatible apps that currently have no activity.
- Bridge the existing music source into the same transient activity selection,
  preserving privacy, expiry and notification interruption behavior. Source
  revisions and observation times remain separate from host presentation.
- Pin Activities 0.2.2 and retain Core 0.5.0, the UUID and every existing native
  message key. Existing Timer 0.5.0 works without a new Timer installation.
- GitHub development prerelease for sideload testing. Earlier published assets
  and tags remain unchanged; Pebble appstore submission remains held.

## 0.9.1

- Simplify the updated Timer provider's explicit compact projection to one
  remaining clock and its identity. Keep generic main/support views, meaningful
  clock labels, artwork and independent secondary activities available.
- Coalesce matching observation-age and uncertainty indicators once per card.
  Preserve distinct observation/estimate provenance and independent pause state;
  keep cached native snapshots visibly last reported.
- Treat completed clocks as final values instead of paused clocks. Optional
  terminal results yield to ongoing activities and music from either the
  generic activity source or the existing music adapter.
- Pin Activities 0.2.1 and retain Core 0.5.0, UUID, existing message keys,
  privacy settings, typography and native alarm ownership. Timer acknowledgment
  remains the source's responsibility; zero never proves completion.
- Refresh native settings previews and capture compact one-minute timers,
  matching/differing item provenance, acknowledged hidden results and terminal
  results alongside music. Earlier published assets and tags stay unchanged.
- GitHub development prerelease for sideload testing; physical watch and live
  phone/provider checks remain separate. Pebble appstore submission stays held.

## 0.9.0

- Adopt Activities 0.2.0 ACT2 views: each activity has one main item and an
  optional supporting text, value or clock, with optional 40×40 artwork and a
  meter derived from a valid source value and explicit range. Existing schema 1
  providers remain usable through the phone-side adapter.
- Keep each item's observation, expiry, running/pause state and retention
  separate. Source revisions describe activity truth; independent view
  sequences allow presentation updates without claiming a newer observation.
- Show related values together, including Timer 0.3.0's remaining and elapsed
  clocks. Any activity can be primary or secondary; optional content yields
  when space is insufficient. Preserve fixed 24px text and 20px text footers.
- Reserve room for pause, uncertainty and original-observation age marks.
  Estimated or due clocks and unconfirmed native snapshots remain explicit;
  reaching zero does not imply completion or prove that a native alarm rang.
- Schedule second updates only for visible running clocks, keeping independent
  clocks independent of the activity's overall paused state. Clear unavailable
  private content and expire supporting items and meters independently.
- Pin Core 0.5.0 and Activities 0.2.0. Preserve UUID, message-key numbers,
  readings, music composition, settings and notification privacy. Include no
  activity commands, Dashboard app, firmware fork or built-in Workout access.
- All 85 JavaScript tests, 12 portable native suites, 40 Python regressions,
  the fixed-timestamp Emery SDK build and final package/native-style audit pass.
  Native evidence covers 20 settings presets, 28 activity compositions and
  four clock follow-up frames without a source resend, including independent
  clocks, a running secondary clock and supporting-item/meter expiry.
  The native virtual image is 65,120 bytes, leaving 415 bytes below the SDK
  limit. Physical 0.9.0 and live phone/provider behavior remain unverified.
  The earlier release's successful user test does not verify the new binary.
- Published as a GitHub development prerelease for sideload testing. Earlier
  0.8.0 artifacts remain unchanged, and Pebble appstore submission remains held.

## 0.8.0

- Development prerelease for phone/watch testing. Portable, package and emulator
  checks pass; real-device alarm vibration, Bluetooth behavior and live plugin
  delivery remain to be verified.
- Give generic countdown and elapsed activities large centered Fredoka numerals,
  a directly grouped caption and optional secondary music or activity summary.
- Keep pause and last-reported marks with the caption, without reserving empty
  artwork space for imageless clocks. Long values use bounded readable sizes.
- Select the soonest running deadline within a provider, then its paused timers,
  while preserving other provider positions and the two-card native limit.
- Pin separately released Pebble Activities 0.1.2 for compatible multi-slot Timer
  providers. Preserve UUID, AppMessage key numbers, music and privacy controls.
- Refresh native settings previews and capture notification/Timeline edge cases.

## 0.7.0

- Discovers compatible activity providers through independent Pebble Activities
  0.1.0, with a shared main/footer layout and bounded two-card projection.
- Shows native timer snapshots with local countdowns and an explicit last-reported
  mark. Pause/cancel authority and alarms remain in the originating watchapp.
- Adds a translated Plugin activities switch and separate provider health.
- Pins lean Core 0.5.0 for readings and keeps music/notification privacy behavior
  through the optional Activities compatibility adapter.
- Deduplicates identical font measurement rows without changing any glyph metric,
  font resource, text size or footer position.
- Preserves the UUID and all 41 existing AppMessage key numbers; appends 3 activity
  keys. No firmware fork or native Workout integration is included.

## 0.6.1

- Clears fully redacted, malformed or newly filtered notifications immediately,
  including queued replacements, through pinned Core 0.4.1.
- Keeps closed colour-picker swatches out of keyboard navigation and restores
  saved appearance settings after startup or a new watch session.
- Clarifies that watchface banners and vibration are additional to PebbleOS
  alerts; keeps both defaulted to Off and preserves existing choices.
- Adds an independent day/Quiet Time palette preview in settings.
- Protects warning visibility on every native palette background, preserves app
  identity when notification icons are invisible, and pauses title continuation
  underneath system windows. Hardens incoming boolean setting validation.
- Includes third-party licenses and attribution in the standalone PBW; prepares
  store copy, native screenshots, privacy/support documents and release checks.
- Keeps the plugin-preview appstore restriction explicit. Store submission is
  not enabled by preparing these materials.

## 0.6.0

- Fixes settings colours and control contrast in phone light and dark appearances,
  independently of the watch palette. Updates all 17 supported locales.
- Adds App-only notification privacy and optional Off / Short / Double vibration.
  Vibration defaults to Off, uses the existing app filter, respects watch Quiet
  Time and fires once per new burst rather than on history, retries or artwork.
- Gives summary banners a three-second deadline and actual message previews up
  to eight seconds. Replacements never extend the first notice's deadline.
- Continues long received song titles through fixed-size pages once without
  looping or shrinking type. Keeps a 40px fallback cover tile and stable artist
  position when artwork is missing, transparent or late; marks paused music
  during its existing five-second grace.
- Adds an optional palette following watch Quiet Time and restores daytime
  colours afterward. Shares/imports only the three main palette colours with
  a validated DYN1 colour code.
- Pins Core 0.4.0. Keeps v4 reading packets, UUID, existing key numbers and the
  unified layout; appends settings and transient context-state keys.

## 0.5.0

- Preserves precise Temperature / Feels like / High / Low / Forecast / Phone
  labels and public reading identity through loading, failure and expiry.
- Marks a known observation at least an hour old, rather than marking cache
  origin as age. Receipt and observation times stay distinct.
- Uses source/accent colour for ordinary content, amber for warnings, guarded
  secondary ink and visible accent fallbacks. Artist text is quieter; idle
  values and labels sit closer to their symbols.
- Separates notification sender/title from app identity. Late artwork/artist
  updates repaint quietly; a notification burst enters once and coalesces
  replacements for a 900ms stable interval within its existing eight-second
  maximum. Privacy clearing remains immediate.
- Groups settings into Appearance, Content and Connection & help. Five example
  states are independent of enabled features and privacy choices.
- Uses the watch's last reported OS clock style for Follow Pebble examples;
  labels an unknown-format example and adds a read-only CLOCK_FORMAT=255 query.
- Shows unsaved edits and last delivery beside Save, with automatic-retry
  wording. Restores the session's Custom palette when switching themes.
- Replaces the raw app filter with removable entries, explains shared Pebble
  readings and shows source recovery help nearby. Updates all 17 languages.
- Pins Core 0.3.0 and strict v4 packets with precise detail/forecast/observation
  metadata, explicit Expired status and identity-only public missing states.
  Legacy v1–v3 decode remains supported. Keeps the UUID, 34 message keys,
  unified typography, two reading homes and fixed music footer.

## 0.4.1

- Uses one unified typography/layout for new and existing installations,
  retiring Larger text and the settings preview size selector.
- Tunes the idle hierarchy with an 80px clock, 20px date, 36px readings and 14px
  labels. Compact context uses a 42px clock, 14px symbols and 22px values;
  Timeline Peek keeps 16px symbols and 26px values.
- Keeps song titles at 24px and artists at 20px, wrapping before ellipsis
  without changing font size between tracks. Three title lines and two artist
  lines share the fixed 40px artwork/footer anchor at y216.
- Lets heading-only notification banners retain up to two song-title lines
  and a gap above the fixed music footer at the same typography sizes.
- Reduces native settings samples to 20 presets: five states, two clock
  formats and two themes, with no separate size choice.
- Retains provider labels, Core 0.2.0, the app UUID and message-key numbers.
  LARGE_TEXT remains reserved for wire compatibility and no longer changes
  the rendering or stores an active size preference.

## 0.4.0

- Makes short notifications proportional to their content, retaining the fixed
  music footer while giving message previews a bounded reading area.
- Preserves provider labels for neutral numbers, ranges and times, with safe
  UTF-8 ellipses for long labels.
- Preserves two horizontal readings with semantic labels, clearer missing-data
  states and a consistent reading accent, including rain gauges.
- Rebuilds settings around native sample previews, themes, left/right source
  summaries, individual feature health and conditional privacy/app controls.
- Adds Follow Pebble / 12-hour / 24-hour time, preserving existing explicit
  choices, and acknowledged settings delivery with reconnect recovery.
- Translates the complete settings experience into 17 languages.
- Adopts Core 0.2.0: 128-byte UTF-8 text, requested 40px artwork, typed reading
  metadata and replacement of obsolete waiting source snapshots.
- Caps notification bursts at eight seconds without replaying historical
  notifications. Private context stays transient and clears on disconnect.
- Keeps the UUID and existing message-key numbers; appends CLOCK_FORMAT.

## 0.3.2

- Stacks the weekday and date in the compact music/notification header,
  retaining both horizontal complications.
- Anchors artwork and up to two artist lines to a fixed bottom edge. Song
  titles grow upward through up to three lines with a fixed gap above them.
- Fits the music text using measured native ink bounds, keeping the preferred
  Big font when it fits.
- Retains the single-line idle/Peek date, notification content layout and
  native Timeline priority.

## 0.3.1

- Expands body-font coverage for Greek, Cyrillic and Latin Extended Additional
  characters in source-provided text.
- Makes the missing-character glyph visible when text falls outside bundled
  font coverage.
- Uses Fredoka outlines for temperature and percent units, with muted
  11px reading labels.
- Smooths the clock, numeric readings and units with fractional pixel
  coverage while preserving their contour weight.
- Keeps the 0.3.0 layout geometry, bounded motion, data sources and settings.

## 0.3.0

- Adds a chunky Fredoka clock whose shapes scale and move together as the
  layout changes, with Roboto Condensed body text.
- Uses one canvas with two horizontal readings and rounded symbols, with a
  0–100% gauge for source-identified rain probability.
- Makes room for full-width song titles, artist/artwork and notification
  content with bounded layout transitions and context-only content slides.
- Follows native Timeline Peek's available area throughout its movement,
  retaining the clock and both readings.
- Adds a translated Animations toggle for Dynamic's own transitions. The
  native Timeline layout continues to adapt when local animations are off.
- Keeps the shared core, source choices, cache/expiry rules, notification
  privacy defaults, permissions and app UUID unchanged.
- Appends `ANIMATIONS` after the existing 32 message keys and retains the
  earlier release artifacts.

## 0.2.0

- Rebuilds Dynamic with PebbleOS LECO numbers and Gothic text, inspired by the
  built-in Weather and Workout apps.
- Introduces a light default page, thin rules, equal reading columns and
  full-width accent panels for readings and contextual content.
- Adds an accent color setting with automatic panel ink contrast; new notices
  use yellow. Existing saved page and text colors remain usable.
- Keeps music titles wide, artist/artwork together, and both selected readings
  visible above native Timeline Peek.
- Retires the visible shadow setting, custom Fira resources and their generated
  ink table. Legacy message-key numbers are retained; `ACCENT_COLOR` is appended.
- Keeps the pinned shared core, source choices, caches, expiry, permissions,
  notification privacy defaults and app UUID unchanged.

## 0.1.0

- Introduced the borderless content-first watchface using Pebble Watchface Core
  0.1.0, shared with Halftone.
- Added two horizontal complications, adaptive music/notification panels,
  native Timeline Peek handling and translated phone settings.
- Used bundled Fira Sans Condensed fonts. The historical PBW/source archive
  remain in `dist/`; the source archive preserves its font license and validation
  record.
