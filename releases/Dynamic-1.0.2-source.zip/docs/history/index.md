# Dynamic history

Historical decisions, release narratives and original evidence keep their dates and scope.
Current setup is in [CONTRIBUTING](../../CONTRIBUTING.md).

- [github-releases-before-rework](github-releases-before-rework.md)
- [maintainer-notes-before-rework](maintainer-notes-before-rework.md)
- [native-style-before-rework](native-style-before-rework.md)
- [readme-before-maintenance](readme-before-maintenance.md)
- [redesign-before-rework](redesign-before-rework.md)
- [release-policy-before-maintenance](release-policy-before-maintenance.md)
- [ux-alignment-before-rework](ux-alignment-before-rework.md)
- [ux-review-before-rework](ux-review-before-rework.md)
