# Dynamic maintenance contracts

These are current implementation constraints. They apply when changing the
relevant subsystem, not as a requirement to reread every document for every edit.

## Ownership and compatibility

Preserve UUID, appended message-key numbering, ACT3 source/run identity, observation and original validity. Private media/notification content is transient. Keep one native render plan, one static secondary row and one shared queue. Text starts at its beginning and truncates; no marquee, activity/text paging or silent rotation. Optional explicit shake paging changes only the selected reading pair. Only genuinely painted original record indices may be confirmed/exported for navigation. Clock ticks never persist state or send messages. Covered views reconcile expiry without decorative work or fresh presentation claims.

## Current interaction and product boundaries

Readable Roboto Condensed utility roles and dominant Fredoka values are the accepted main UI. Compact numeric date and Idle/Peek weekday/date remain. The selected reading pair keeps its positions; an optional compact idle grid adds the next pair and collapses for activity/Peek; the primary block is bottom-aligned above its footer, with the secondary above it. Structured values/units and Paused/pace/street precede optional identity. Supporting text follows its per-face override or the launch-time OS size through Dynamic’s own font roles; the main clock keeps its design. Required state/value/unit text can wrap and must yield optional secondary content first. A hidden secondary must not escape through the navigation source. Incoming motion is bounded and only starts on a genuine run/item replacement. Dynamic has no physical action rail.

## Source ownership

src/c/dynamic.c integrates the SDK; activity_presentation/watch_layout/music_layout define bounded rendering. src/pkjs owns host integration; src/common/settings-state.js owns atomic phone settings. vendor/ records independently pinned Core and Activities packages.

## Phone persistence and evidence

For apps with phone settings, keep active-writer selection, separate Android
DOM/native storage views, exact application acknowledgements and bounded handoffs.
Saving stays open where supported; uncertain writes retain the draft and explicit
readback/retry. Discard cannot undo a write already sent. Load errors must not
silently replace saved choices with editable defaults. Category navigation keeps one mounted draft and restores screen context. Save
reveals an invalid field before focusing it; asynchronous status must not change
the screen, focus or scroll. Historical browser/emulator results do not validate a
new build. Keep portable, packaged, simulated transport and real-device claims distinct.

Native display key **79** owns a versioned 92-byte snapshot: revision, both raw
RGB palettes, clock/status/animation/vibration choices, text size, appearance mode,
last manual palette and the optional reading layout settings. Key **78** retains
a complete compatible 60-byte v1 mirror. Validate the complete snapshot, verify persistence
readback, then apply and reply. Legacy integer/boolean keys remain compatible
mirrors. Keep raw RGB values before Pebble's GColor quantization. A profile change
invalidates measured activity layout and painted-role cache before repaint.
Display replies own their outbox callbacks and never acknowledge a Core session.

The existing `clay-settings` record remains the phone settings authority.
`dynamic-settings-delivery-v1` now stores version-2 delivery metadata; earlier
transport-only success cannot prove application. Valid older pending native
choices migrate through a verified settings save. Unknown saved keys survive;
source privacy/order choices never enter the native display frame. Numeric wire
keys use the preserved 10000-based SDK mapping; earlier index-style saved keys
remain readable. A fresh phone with no explicit native choices adopts the watch's
raw palette snapshot before attempting delivery.

New desired choices and fresh runtime/native mismatch retries use a new verified
wire revision. Old receipts and late callbacks cannot establish Applied after
invalidation. Failed revision storage leaves pending state without sending a
reusable revision. Source traffic cannot reset an exhausted bounded retry budget.
Plugin-only configuration reads/saves never start a watch queue or source lookup;
the active PKJS writer owns delivery and the existing Android handoff.

## Dependencies, identities and licences

Preserve public identifiers, message-key numbers, compatible storage formats,
licences and attribution. Pinned vendor archives/checksums remain independent of
sibling checkouts. Do not repin consumers or change published bytes as cleanup.

## History

[Earlier maintainer notes](history/maintainer-notes-before-rework.md) retain the
full rationale/history. Read them only when investigating an old decision.


## Round 2 development layout

Gabbro uses the complete 260×260 physical display. Text and artwork are fitted
inside the chord for their vertical band; the shared UI library owns only
geometry and drawing. Time 2 retains its established rectangular composition.
The SDK 4.44 reference and disposable candidate evidence are in the workspace's
`Round2-Development/` directory. This is development work; frozen release files
and historical QA are unchanged. No physical Round 2 or Android result is implied.

Clock raster buffers and activity transition distances use the display dimensions.
Readings fit one shared numeric size before measuring their supporting lines.
Activity plans retain their fitted endpoint geometry throughout item motion.
Peek reads the root window's unobstructed area and keeps the physical circle's
center fixed. Phone preview frames select the connected watch's display shape;
an unknown watch exposes the temporary preview-watch selector.

When the face is running, phone previews select the connected Time 2 / Round 2 automatically. Plugin-only settings cannot read WatchInfo; their temporary preview-watch selector affects only the current page and is never saved or sent to the watch.


## Feedback development preferences

Display v2 appends eight fields without reusing retired LAYOUT_STYLE. The 92-byte
frame stores 21 values at key 79 and verifies readback before applying/replying.
A complete v1 60-byte mirror remains at key 78; v1 messages update their original
13 values and preserve the new choices. Legacy migration turns the features off
and derives lower palettes from the inverse of the saved upper text/background.
New receivers accept both versions; a v1 receipt cannot confirm a v2 preference.
A phone paired with an older native build remains pending until the watchface is
updated. Day/night lower colours remain raw RGB, separate from accent colour.

The Core 0.6.1-dev.1 archive is a local development pin from the source commit in
vendor/CORE.json. Dynamic opts into four slots for the idle grid and five when shake paging is enabled. The default
library contract and every other app pin remain two readings. No released
library, watchface version, UUID or frozen archive has been changed.
