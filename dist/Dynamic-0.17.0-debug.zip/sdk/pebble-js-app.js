/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	__webpack_require__(1);
	module.exports = __webpack_require__(2);


/***/ }),
/* 1 */
/***/ (function(module, exports) {

	/**
	 * Copyright 2024 Google LLC
	 *
	 * Licensed under the Apache License, Version 2.0 (the "License");
	 * you may not use this file except in compliance with the License.
	 * You may obtain a copy of the License at
	 *
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *
	 * Unless required by applicable law or agreed to in writing, software
	 * distributed under the License is distributed on an "AS IS" BASIS,
	 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	 * See the License for the specific language governing permissions and
	 * limitations under the License.
	 */
	
	(function(p) {
	  if (!p === undefined) {
	    console.error('Pebble object not found!?');
	    return;
	  }
	
	  // Aliases:
	  p.on = p.addEventListener;
	  p.off = p.removeEventListener;
	
	  // For Android (WebView-based) pkjs, print stacktrace for uncaught errors:
	  if (typeof window !== 'undefined' && window.addEventListener) {
	    window.addEventListener('error', function(event) {
	      if (event.error && event.error.stack) {
	        console.error('' + event.error + '\n' + event.error.stack);
	      }
	    });
	  }
	
	})(Pebble);


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

	var MessageKeys = __webpack_require__(3);
	var core = __webpack_require__(4);
	var activityLibrary = __webpack_require__(8);
	var activityPresentation = __webpack_require__(18);
	var navigation = __webpack_require__(19).create({storage:localStorage,now:function(){return Date.now();}});
	var createComplications = core.createComplications;
	var createContext = activityLibrary.createContext;
	var createMessageQueue = core.createMessageQueue;
	var localization = __webpack_require__(20);
	var settingsState = __webpack_require__(21);
	var clay,clayConfig;
	function settingsPage() {
	  if(!clay) {
	    var Clay=__webpack_require__(22);
	    clayConfig=__webpack_require__(24);
	    clay=new Clay(clayConfig,__webpack_require__(25),{autoHandleEvents:false});
	  }
	  return clay;
	}
	
	function settingsLanguage() {
	  var watchLanguage;
	  try {
	    var watch = typeof Pebble.getActiveWatchInfo === 'function' && Pebble.getActiveWatchInfo();
	    watchLanguage = watch && watch.language;
	  } catch (ignored) {}
	  var phoneLanguage = typeof navigator !== 'undefined' &&
	    (navigator.language || navigator.userLanguage || (navigator.languages && navigator.languages[0]));
	  return localization.resolveLanguage(watchLanguage, phoneLanguage);
	}
	function messageValue(payload, name) {
	  return payload[name] !== undefined ? payload[name] : payload[MessageKeys[name]];
	}
	var cachedSettings,cachedPreferences;
	function invalidateSettings() {cachedSettings=undefined;cachedPreferences=undefined;}
	function savedSettings() {
	  if(cachedSettings===undefined) {
	    try { cachedSettings=JSON.parse(localStorage.getItem('clay-settings')) || {}; }
	    catch (error) { cachedSettings={}; }
	  }
	  return cachedSettings;
	}
	function clockFormat(settings) {
	  var value = messageValue(settings, 'CLOCK_FORMAT');
	  if (value === 0 || value === 12 || value === 24) { return value; }
	  var previous = messageValue(settings, 'USE_12_HOUR');
	  if (previous === true || previous === 1) { return 12; }
	  if (previous === false || previous === 0) { return 24; }
	  return 0;
	}
	var contextBootstrapGeneration=0,contextBootstrapPending=false,contextBootstrapTimer=null;
	var contextBootstrapTickets=[];
	function removeBootstrapTicket(ticket) {
	  var at=contextBootstrapTickets.indexOf(ticket);
	  if(at>=0)contextBootstrapTickets.splice(at,1);
	}
	function cancelContextBootstrap() {
	  ++contextBootstrapGeneration;contextBootstrapPending=false;
	  if(contextBootstrapTimer!==null)clearTimeout(contextBootstrapTimer);
	  contextBootstrapTimer=null;
	}
	var send = createMessageQueue({
	  keys: MessageKeys,
	  snapshotChannels:[{name:'activities',dataKey:'ACTIVITY_DATA',sidecarKeys:['REQUEST_ACTIVITIES']}],
	  send: function(payload, success, failure) {
	    // The shared queue copies payloads. Keep an ordered, content-free ticket
	    // for each bootstrap so a request queued before the native baseline can
	    // be discarded at dispatch without changing settings/snapshot FIFO order.
	    if(Object.keys(payload).length===1&&messageValue(payload,'REQUEST_CONTEXT')===1) {
	      var ticket=contextBootstrapTickets.shift();
	      if(!ticket||ticket.generation!==contextBootstrapGeneration||!contextBootstrapPending) {
	        failure({code:'SUPERSEDED'});return;
	      }
	    }
	    Pebble.sendAppMessage(payload, success, failure);
	  },
	  later: function(callback, delay) { return setTimeout(callback, delay); },
	  cancelLater: function(timer) { clearTimeout(timer); }
	});
	function log(message) { console.log(message); }
	function escapeHtml(value) {
	  return String(value).replace(/[&<>"']/g, function(character) {
	    return {'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[character];
	  });
	}
	function privateReading(slot) { return slot && (slot.category === 'music' || slot.category === 'notifications'); }
	
	// The default readings follow global complication choices. Context uses the
	// same source API for music, optional new notifications and phone battery.
	// There is no direct weather client, provider override or local unit rewrite.
	var complications = createComplications({
	  pebble: Pebble, keys: MessageKeys, storage: localStorage,
	  cacheKey: 'dynamic-complications-v1',
	  send: send, now: function() { return Date.now(); },
	  later: function(callback, delay) { return setTimeout(callback, delay); },
	  cancelLater: function(timer) { clearTimeout(timer); }, log: log,
	  getSettings: function() {
	    var format = clockFormat(savedSettings());
	    return {use12Hour: format === 12, clockFormat: format, language: settingsLanguage()};
	  },
	  localizeBoolean: function(value) {
	    return localization.t(value ? 'stateOn' : 'stateOff', settingsLanguage());
	  }
	});
	
	function enabledSetting(name, fallback) {
	  var value = messageValue(savedSettings(), name);
	  return value === undefined ? fallback : value === true || value === 1 || value === 'true' || value === '1';
	}
	var ACTIVITY_PREFERENCES_KEY = 'dynamic-activity-preferences-v1';
	var ACTIVITY_PREFERENCES_RESPONSE = '__dynamicActivityPreferences';
	function activityPreferences() {
	  if(cachedPreferences)return cachedPreferences;
	  var value;
	  try {
	    value = savedSettings()[ACTIVITY_PREFERENCES_RESPONSE];
	    if (value === undefined) value = JSON.parse(localStorage.getItem(ACTIVITY_PREFERENCES_KEY));
	  } catch (ignored) {}
	  var result = activityLibrary.selection.normalizePreferences(value);
	  // Existing source/privacy switches remain authoritative for both built-ins.
	  result.hidden = result.hidden.filter(function(id) { return id !== 'builtin:music' && id !== 'builtin:notifications'; });
	  if (!enabledSetting('SHOW_MUSIC', true)) { result.hidden.push('builtin:music'); }
	  if (!enabledSetting('SHOW_NOTIFICATIONS', false)) { result.hidden.push('builtin:notifications'); }
	  // Existing preferences predate this row. New arrivals lead by default until
	  // the user saves an explicit Notifications position in Dynamic's own order.
	  if (result.order.indexOf('builtin:notifications') < 0) {
	    result.order = ['builtin:notifications'].concat(result.order).slice(0,64);
	  }
	  cachedPreferences=result;return result;
	}
	var contextProjectionSignature = '[null,null]';
	function contextChanged() {
	  if (!context) { return; }
	  // Reproject only a changed canonical receipt. Battery/status traffic does
	  // not resend a complete activity view; these RAM signatures contain no text.
	  var signature = JSON.stringify([context.musicActivity(),
	    typeof context.notificationActivity === 'function' ? context.notificationActivity() : null].map(function(card) {
	      return card ? [card.provider,card.id,card.revision,card.observedAt,card.validUntil] : null;
	    }));
	  if (signature === contextProjectionSignature) { return; }
	  contextProjectionSignature = signature;
	  if (activities) { activities.reproject(); }
	}
	var context = createContext({
	  pebble: Pebble, keys: MessageKeys, send: send, musicAsActivity:true,notificationAsActivity:true,
	  now: function() { return Date.now(); },
	  later: function(callback, delay) { return setTimeout(callback, delay); },
	  cancelLater: function(timer) { clearTimeout(timer); },
	  onChanged:contextChanged,
	  getSettings: function() {
	    var apps = messageValue(savedSettings(), 'NOTIFICATION_APPS');
	    return {showMusic:enabledSetting('SHOW_MUSIC', true),
	      showNotifications:enabledSetting('SHOW_NOTIFICATIONS', false),
	      notificationPreview:enabledSetting('NOTIFICATION_PREVIEW', false),
	      notificationAppOnly:enabledSetting('NOTIFICATION_APP_ONLY', false),
	      notificationApps:typeof apps === 'string' ? apps : '',
	      showStatus:enabledSetting('SHOW_STATUS', true)};
	  }
	});
	
	// Dynamic displays summaries and opens apps. Action/entity descriptors belong
	// to interactive hosts; avoid even requesting their separate source fields.
	var activitySourceApi = {};
	if (typeof Pebble.enumeratePlugins === 'function') {
	  activitySourceApi.enumeratePlugins = function() { return Pebble.enumeratePlugins(); };
	}
	if (typeof Pebble.subscribeToSource === 'function') {
	  activitySourceApi.subscribeToSource = function(request) {
	    var display = {};
	    Object.keys(request).forEach(function(key) { display[key] = request[key]; });
	    if (Array.isArray(request.properties)) {
	      display.properties = request.properties.filter(function(property) {
	        return property !== 'actions' && property !== 'entity_ref';
	      });
	    }
	    return Pebble.subscribeToSource(display);
	  };
	}
	var activities = activityLibrary.createActivities({
	  pebble:activitySourceApi,keys:MessageKeys,send:send,nativeFormat:3,
	  onView:function(snapshot){navigation.view(snapshot);},
	  // All generic providers share the same roles. Built-in privacy/source
	  // controls are handled by their adapters and selection preferences.
	  acceptActivity:function(activity){
	    var kind=String(activity.kind).toLowerCase();
	    var media=activity.type==='media'||activity.presentation===2||kind==='music';
	    return enabledSetting('SHOW_ACTIVITIES',true)&&
	      (!media||enabledSetting('SHOW_MUSIC',true));
	  },
	  select:function(cards){
	    return activityPresentation.select(cards,activityPreferences(),context.musicActivity(),
	      typeof context.notificationActivity === 'function' ? context.notificationActivity() : null);
	  },
	  now:function(){return Date.now();},
	  later:function(callback,delay){return setTimeout(callback,delay);},
	  cancelLater:function(timer){clearTimeout(timer);},
	  // The coordinator also transports built-in music. Generic plugin visibility
	  // is a host filter so music and idle-provider discovery remain available.
	  getSettings:function(){return {enabled:true,
	    providers:enabledSetting('SHOW_ACTIVITIES',true)?undefined:[],
	    disabledProviders:activityPreferences().hidden.filter(function(id){return id!=='builtin:music'&&id!=='builtin:notifications';})};}
	});
	
	function requestContextSession(attempt,generation) {
	  if(generation!==contextBootstrapGeneration||!contextBootstrapPending)return;
	  var query = {}; query[MessageKeys.REQUEST_CONTEXT] = 1;
	  var ticket={generation:generation};contextBootstrapTickets.push(ticket);
	  send(query, function(){removeBootstrapTicket(ticket);}, function() {
	    removeBootstrapTicket(ticket);
	    if(generation!==contextBootstrapGeneration||!contextBootstrapPending)return;
	    if(attempt<3)contextBootstrapTimer=setTimeout(function() {
	      contextBootstrapTimer=null;requestContextSession(attempt+1,generation);
	    },attempt*1000);
	    else contextBootstrapPending=false;
	  });
	}
	Pebble.addEventListener('ready', function() {
	  invalidateSettings();
	  resyncPresentation();
	  complications.refresh(); context.refresh(true); activities.refresh();
	  cancelContextBootstrap();contextBootstrapPending=true;
	  requestContextSession(1,contextBootstrapGeneration);
	});
	var SYSTEM_CLOCK_KEY = 'dynamic-system-clock-v1';
	function systemClockFormat() {
	  try {
	    var value = JSON.parse(localStorage.getItem(SYSTEM_CLOCK_KEY));
	    return value === 12 || value === 24 ? value : null;
	  } catch (ignored) { return null; }
	}
	Pebble.addEventListener('appmessage', function(event) {
	  var presented=messageValue(event.payload||{},'ACTIVITY_PRESENTED');
	  if(presented!==undefined)navigation.receive(presented);
	  var format = messageValue(event.payload || {}, 'CLOCK_FORMAT');
	  if (format === 12 || format === 24) {
	    // This is the OS format, not the watchface's saved override.
	    try { localStorage.setItem(SYSTEM_CLOCK_KEY, JSON.stringify(format)); } catch (ignored) {}
	  }
	  retrySavedSettings();
	  if (messageValue(event.payload || {}, 'REQUEST_COMPLICATIONS')) { complications.refresh(); }
	  var requested = messageValue(event.payload || {}, 'REQUEST_CONTEXT');
	  var token = Number(requested);
	  if (Number.isInteger(token) && token >= 2 && token <= 2147483647) {
	    cancelContextBootstrap();
	    context.connectionChanged(true, token);
	    // A reset or another watch can reuse the same counter. Every marked
	    // baseline request may need recovery; ordinary refreshes use token 1.
	    resyncPresentation();
	  }
	  else if (token === 1) { context.refresh(); }
	  var activityToken=Number(messageValue(event.payload || {},'REQUEST_ACTIVITIES'));
	  if(Number.isInteger(activityToken)&&activityToken>=2&&activityToken<=2147483647)
	    activities.connectionChanged(true,activityToken);
	  else if(activityToken===1)activities.refresh();
	});
	Pebble.addEventListener('showConfiguration', function() {
	  invalidateSettings();settingsPage();
	  var previewAssets=__webpack_require__(26);
	  var clockQuery = {}; clockQuery[MessageKeys.CLOCK_FORMAT] = 255;
	  send(clockQuery); // Native replies separately; this offline page remains a snapshot.
	  var language = settingsLanguage();
	  clay.config = localization.translateConfig(clayConfig, language);
	  var saved = savedSettings();
	  var status = complications.status();
	  var dynamic = context.status();
	  var metadata = settingsMetadata(status, dynamic);
	  metadata.language = language;
	  function t(key, params) { return localization.t(key, language, params); }
	  function visit(items) {
	    items.forEach(function(item) {
	      if (item.items) { visit(item.items); }
	      // Clay restores named keys. Also present legacy numeric-key preferences
	      // without rewriting storage merely because the user opened settings.
	      var previous = item.messageKey && messageValue(saved, item.messageKey);
	      if (item.type === 'toggle' && (previous === true || previous === false || previous === 0 || previous === 1)) {
	        item.defaultValue = !!previous;
	      }
	      if (item.type === 'color' && typeof previous === 'number' && isFinite(previous) && previous >= 0 && previous <= 0xFFFFFF) {
	        item.defaultValue = previous;
	      }
	      if (item.messageKey === 'NOTIFICATION_APPS' && typeof previous === 'string') { item.defaultValue = previous; }
	      if (item.messageKey === 'CLOCK_FORMAT') { item.defaultValue = clockFormat(saved); }
	      if (item.messageKey === 'NOTIFICATION_VIBRATION' && [0,1,2].indexOf(previous) >= 0) { item.defaultValue = previous; }
	      if (item.id === 'dynamic-settings-data') { item.defaultValue = escapeHtml(JSON.stringify(metadata)); return; }
	      if (item.id === 'dynamic-preview-assets') {
	        var assets = Object.assign({}, previewAssets, {systemFormat:systemClockFormat()});
	        item.defaultValue = escapeHtml(JSON.stringify(assets)); return;
	      }
	      if (item.id === 'dynamic-settings-strings') {
	        item.defaultValue = escapeHtml(JSON.stringify(localization.settingsStrings(language))); return;
	      }
	      if (item.id === 'context-status') {
	        item.defaultValue = escapeHtml(t(dynamic.error ? 'contextError' : dynamic.ready ? 'contextReady' : 'contextWaiting',
	          {error:dynamic.error || ''}));
	        return;
	      }
	      if (item.id !== 'complications-status') { return; }
	      var summary = status.available === false ? t('complicationsDisabled') :
	        status.configured ? t('complicationsStatus', {ready: status.ready || 0, configured: status.configured}) :
	        t('complicationsWaiting');
	      var issue = status.error;
	      var problem = (status.slots || []).filter(function(slot) { return slot.error === issue; })[0];
	      if (issue && problem) {
	        issue = '#' + problem.slot + ' · ' + problem.category + '/' + problem.item +
	          (problem.property ? '/' + problem.property : '') + ' · ' + issue +
	          (problem.message && !privateReading(problem) ? ' · ' + problem.message : '');
	      } else if (issue && status.message) { issue += ' · ' + status.message; }
	      // Clay text fields support HTML. Source diagnostics remain literal text,
	      // including provider-supplied error messages and category/item names.
	      item.defaultValue = escapeHtml('Dynamic ' + previewAssets.version + '. ' + summary +
	        (issue ? ' · ' + t('complicationsError', {error: issue}) : ''));
	    });
	  }
	  visit(clay.config);
	  Pebble.openURL(clay.generateUrl());
	});
	
	function watchSettings(payload) {
	  var result = {};
	  ['BACKGROUND_COLOR', 'TEXT_COLOR', 'ACCENT_COLOR',
	    'USE_12_HOUR', 'CLOCK_FORMAT', 'SHOW_STATUS', 'ANIMATIONS', 'NOTIFICATION_VIBRATION',
	    'NIGHT_PALETTE', 'NIGHT_BACKGROUND_COLOR', 'NIGHT_TEXT_COLOR', 'NIGHT_ACCENT_COLOR'].forEach(function(name) {
	    var value = messageValue(payload, name);
	    if (value === undefined) { return; }
	    if (/_COLOR$/.test(name)) {
	      if (typeof value !== 'number' || !isFinite(value) || Math.floor(value) !== value ||
	          value < 0 || value > 0xFFFFFF) { return; }
	    } else if (name === 'NOTIFICATION_VIBRATION') {
	      if (value !== 0 && value !== 1 && value !== 2) { return; }
	    } else if (name === 'CLOCK_FORMAT') {
	      if (value !== 0 && value !== 12 && value !== 24) { return; }
	    } else {
	      if (value === true || value === false || value === 0 || value === 1) { value = Number(value); }
	      else { return; }
	    }
	    result[MessageKeys[name]] = value;
	  });
	  return result;
	}
	
	var DELIVERY_KEY = 'dynamic-settings-delivery-v1';
	var settingsDelivery = null;
	var settingsRetry = null;
	var deliverySequence = 0;
	function deliveryRecord() {
	  try {
	    var record = JSON.parse(localStorage.getItem(DELIVERY_KEY));
	    if (!record || typeof record.id !== 'string' ||
	        ['pending', 'failed', 'saved'].indexOf(record.state) < 0) { return null; }
	    // An earlier build may have queued only its now-retired text-size choice.
	    // There is no active setting to deliver or to show as waiting in this UI.
	    if (record.state !== 'saved' && !Object.keys(watchSettings(record.payload || {})).length) { return null; }
	    return record;
	  } catch (ignored) { return null; }
	}
	function storeDelivery(record) {
	  try { localStorage.setItem(DELIVERY_KEY, JSON.stringify(record)); }
	  catch (ignored) { log('Settings delivery status could not be stored'); }
	}
	function settingsMetadata(status, dynamic) {
	  var details = dynamic.sourceStates || {};
	  function source(name, enabled) {
	    if (!enabled) { return {state:'off', message:''}; }
	    if (details[name]) { return {state:details[name].state, message:details[name].message || ''}; }
	    var error = dynamic.sources && dynamic.sources[name] || '';
	    return {state:error === 'PERMISSION_DENIED' ? 'denied' : error || dynamic.available === false ? 'unavailable' :
	      dynamic.connected === false ? 'waiting' : name === 'music' ? dynamic.music ? 'playing' : dynamic.ready ? 'idle' : 'waiting' :
	      dynamic.ready ? 'ready' : 'waiting', message:error};
	  }
	  var slots = status.slots || [];
	  var record = deliveryRecord();
	  return {slots:[0,1].map(function(index) {
	    var slot = slots[index] || {};
	    var privateValue = privateReading(slot);
	    return {side:index ? 'right' : 'left', label:privateValue ? slot.property || '' : slot.label || slot.property || '',
	      value:privateValue ? '' : slot.text || '',
	      status:slot.status || (status.available === false ? 'disabled' : 'empty'), help:privateValue ? '' : slot.message || '',
	      receivedAgeSec:typeof slot.receivedAgeSec === 'number' && isFinite(slot.receivedAgeSec) && slot.receivedAgeSec >= 0 ? slot.receivedAgeSec : null,
	      observationAgeSec:typeof slot.observationAgeSec === 'number' && isFinite(slot.observationAgeSec) && slot.observationAgeSec >= 0 ? slot.observationAgeSec : null,
	      category:slot.category || '', item:slot.item || '', property:slot.property || ''};
	  }), sources:{music:source('music', enabledSetting('SHOW_MUSIC', true)),
	    notifications:source('notifications', enabledSetting('SHOW_NOTIFICATIONS', false)),
	    phone:source('phone', enabledSetting('SHOW_STATUS', true)),
	    activities:(function(){
	      var status=activities.status();
	      return {state:!enabledSetting('SHOW_ACTIVITIES',true)?'off':
	        status.error==='PERMISSION_DENIED'?'denied':status.error?'unavailable':
	        status.available===false?'disabled':status.ready?(status.count?'ready':'idle'):'waiting',
	        message:status.error || ''};
	    })()},
	    activityPreferences:activityPreferences(),
	    activityProviders:typeof activities.providers==='function'?activities.providers():[],
	    save:{state:record ? record.state : 'none', message:''}};
	}
	function deliverSettings(record, attempt) {
	  settingsDelivery = record.id;
	  function current() { var latest = deliveryRecord(); return latest && latest.id === record.id; }
	  send(record.payload, function() {
	    if (settingsDelivery === record.id) { settingsDelivery = null; }
	    if (current()) { storeDelivery({id:record.id, state:'saved'}); }
	    complications.configure();
	  }, function() {
	    if (settingsDelivery === record.id) { settingsDelivery = null; }
	    if (!current()) { return; }
	    if (attempt < 3) {
	      settingsRetry = setTimeout(function() {
	        settingsRetry = null;
	        if (current()) { deliverSettings(record, attempt + 1); }
	      }, attempt * 1000);
	    } else {
	      record.state = 'failed'; storeDelivery(record);
	      log('Settings are saved on the phone; waiting for watch delivery'); complications.configure();
	    }
	  });
	}
	function retrySavedSettings() {
	  if (settingsDelivery || settingsRetry !== null) { return; }
	  var record = deliveryRecord();
	  if (!record || record.state === 'saved') { return; }
	  var payload = watchSettings(record.payload || {});
	  if (!Object.keys(payload).length) { return; }
	  record.payload = payload; record.state = 'pending'; storeDelivery(record);
	  deliverSettings(record, 1);
	}
	function resyncPresentation() {
	  // Phone settings survive watch resets and switching watches. Reapply only
	  // validated presentation values; private source controls never leave PKJS.
	  // A current pending save wins over older stored values. A fresh record also
	  // prevents an old watch/session's late ACK from marking this sync delivered.
	  var payload = watchSettings(savedSettings());
	  var previous = deliveryRecord();
	  if (previous && previous.state !== 'saved') {
	    var waiting = watchSettings(previous.payload || {});
	    Object.keys(waiting).forEach(function(key) { payload[key] = waiting[key]; });
	  }
	  if (!Object.keys(payload).length) { return; }
	  if (settingsRetry !== null) { clearTimeout(settingsRetry); settingsRetry = null; }
	  var record = {id:String(Date.now()) + '-' + (++deliverySequence), state:'pending', payload:payload};
	  storeDelivery(record); deliverSettings(record, 1);
	}
	function applyPhoneSettings(candidate) {
	  var confirmed = settingsState.save(localStorage,candidate);
	  invalidateSettings();
	  if (!confirmed.ok) return confirmed;
	  applySavedSettings(watchSettings(confirmed.settings));
	  return confirmed;
	}
	function applySavedSettings(payload) {
	  // Apply phone-only source controls immediately, including privacy switches.
	  // Theme delivery can retry independently without postponing a context clear.
	  context.configure(); activities.reproject(); activities.configure();
	  if (!Object.keys(payload).length) { complications.configure(); return; }
	  if (settingsRetry !== null) { clearTimeout(settingsRetry); settingsRetry = null; }
	  var record = {id:String(Date.now()) + '-' + (++deliverySequence), state:'pending', payload:payload};
	  storeDelivery(record); deliverSettings(record, 1);
	}
	Pebble.addEventListener('webviewclosed', function(event) {
	  if (!event || !event.response) return;
	  var payload;
	  try {
	    var response = JSON.parse(/^\{/.test(event.response) ? event.response : decodeURIComponent(event.response));
	    var preferences = response[ACTIVITY_PREFERENCES_RESPONSE];
	    delete response[ACTIVITY_PREFERENCES_RESPONSE];
	    if (preferences && typeof preferences.value === 'string') preferences = JSON.parse(preferences.value);
	    if (preferences && typeof preferences === 'object' && !Array.isArray(preferences))
	      response[ACTIVITY_PREFERENCES_RESPONSE] = {value:activityLibrary.selection.normalizePreferences(preferences)};
	    payload = watchSettings(settingsPage().getSettings(JSON.stringify(response)));
	  } catch (ignored) { log('Invalid settings response'); return; }
	  finally { invalidateSettings(); }
	  applySavedSettings(payload);
	});
	Pebble.addEventListener('configmessage',function(event){
	  if (!event || typeof event.respond !== 'function') return;
	  try {
	    var message = event.message || event.data || event.payload || {};
	    if (typeof message === 'string') message = JSON.parse(message);
	    if (message.type === 'save_settings') { event.respond(applyPhoneSettings(message.settings)); return; }
	    if (message.type === 'load_settings') {
	      invalidateSettings();
	      var current = settingsState.read(localStorage);
	      if (!current) { event.respond({ok:false}); return; }
	      event.respond(__webpack_require__(27)(current,settingsLanguage(),settingsMetadata(complications.status(),context.status()),systemClockFormat()));
	      return;
	    }
	    event.respond({ok:false,notSaved:true});
	  } catch (ignored) { event.respond({ok:false}); }
	});


/***/ }),
/* 3 */
/***/ (function(module, exports) {

	module.exports = {"ACCENT_COLOR":10031,"ACTIVITY_DATA":10041,"ACTIVITY_PRESENTED":10044,"ANIMATIONS":10032,"BACKGROUND_COLOR":10002,"CLOCK_FORMAT":10033,"COMPLICATION_DATA":10021,"CONTEXT_DATA":10023,"CONTEXT_STATE":10040,"DEPTH_EFFECT":10004,"FOLLOW_PEBBLE_UNITS":10012,"FORECAST_DATA":10011,"LARGE_TEXT":10006,"LAYOUT_STYLE":10018,"NIGHT_ACCENT_COLOR":10038,"NIGHT_BACKGROUND_COLOR":10036,"NIGHT_PALETTE":10035,"NIGHT_TEXT_COLOR":10037,"NOTIFICATION_APPS":10028,"NOTIFICATION_APP_ONLY":10039,"NOTIFICATION_PREVIEW":10027,"NOTIFICATION_VIBRATION":10034,"PANEL_TRANSITIONS":10030,"REQUEST_ACTIVITIES":10042,"REQUEST_COMPLICATIONS":10022,"REQUEST_CONTEXT":10024,"REQUEST_PRESENTATION":10045,"REQUEST_WEATHER":10001,"SHOW_ACTIVITIES":10043,"SHOW_DAILY_RANGE":10015,"SHOW_MUSIC":10025,"SHOW_NOTIFICATIONS":10026,"SHOW_RAIN_CHANCE":10016,"SHOW_STATUS":10029,"SHOW_WEATHER_ICON":10019,"TEMPERATURE":10000,"TEMPERATURE_FAHRENHEIT":10009,"TEXT_COLOR":10003,"TEXT_SHADOW":10005,"USE_12_HOUR":10007,"USE_FAHRENHEIT":10008,"WEATHER_CLEAR":10014,"WEATHER_CONDITION":10020,"WEATHER_DETAILS":10017,"WEATHER_LOCATION":10013,"WEATHER_UPDATED_AT":10010}

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	// Hosts with an independent activity engine need not bundle legacy context.
	// Services, message dispatch and settings remain owned by the host.
	module.exports = {
	  createMessageQueue: __webpack_require__(5),
	  createComplications: __webpack_require__(6),
	  wire: __webpack_require__(7)
	};


/***/ }),
/* 5 */
/***/ (function(module, exports) {

	'use strict';
	
	// Theme settings, complication snapshots and contextual snapshots share one
	// AppMessage channel. Serialize them so one source cannot make another busy.
	module.exports = function createMessageQueue(options) {
	  var pending = [];
	  var active = null;
	  var keys=options.keys || {};
	  function named(name,fallback) { return String(keys[name] === undefined ? fallback : keys[name]); }
	  var complicationKey=named('COMPLICATION_DATA',10021), contextKey=named('CONTEXT_DATA',10023);
	  var contextRequestKey=named('REQUEST_CONTEXT',10024);
	  var contextStateKey=named('CONTEXT_STATE',10025);
	  // A host can register another bounded snapshot channel without giving the
	  // queue ownership of its protocol. Its data and session/event sidecars stay
	  // one dictionary; unlisted fields (including settings) retain FIFO order.
	  function aliases(key) {
	    if ((typeof key !== 'string' && typeof key !== 'number') || String(key) === '' ||
	        (typeof key === 'number' && (!isFinite(key) || key<0 || key>4294967295 || key%1))) {
	      throw new TypeError('A snapshot key must be a message-key name or number');
	    }
	    var values=[String(key)];
	    if (Object.prototype.hasOwnProperty.call(keys,key)) {
	      var mapped=String(keys[key]);
	      if (values.indexOf(mapped)<0) { values.push(mapped); }
	    }
	    return values;
	  }
	  var declarations=options.snapshotChannels === undefined ? [] : options.snapshotChannels;
	  if (!Array.isArray(declarations) || declarations.length>16) {
	    throw new TypeError('snapshotChannels must be an array of at most 16 channels');
	  }
	  var channelNames=['complications','context'], dataNames=[];
	  var extensions=declarations.map(function(spec) {
	    if (!spec || typeof spec.name !== 'string' || !spec.name || channelNames.indexOf(spec.name)>=0 ||
	        !Array.isArray(spec.sidecarKeys === undefined ? [] : spec.sidecarKeys)) {
	      throw new TypeError('A snapshot channel needs a unique name and sidecar key array');
	    }
	    var data=aliases(spec.dataKey), allowed=data.slice();
	    var reserved=[complicationKey,contextKey,'COMPLICATION_DATA','CONTEXT_DATA'];
	    if (data.some(function(key) { return reserved.indexOf(key)>=0 || dataNames.indexOf(key)>=0; })) {
	      throw new TypeError('Snapshot data keys must identify a distinct channel');
	    }
	    (spec.sidecarKeys || []).forEach(function(key) {
	      aliases(key).forEach(function(value) { if (allowed.indexOf(value)<0) { allowed.push(value); } });
	    });
	    channelNames.push(spec.name);dataNames=dataNames.concat(data);
	    return {name:spec.name,data:data,allowed:allowed};
	  });
	  function byteArray(value) {
	    return Array.isArray(value) || Object.prototype.toString.call(value) === '[object Uint8Array]';
	  }
	  function channel(payload) {
	    var names=Object.keys(payload);
	    var comp=names.indexOf(complicationKey)>=0 || names.indexOf('COMPLICATION_DATA')>=0;
	    var context=names.indexOf(contextKey)>=0 || names.indexOf('CONTEXT_DATA')>=0;
	    if (comp && !context && names.every(function(name) { return name === complicationKey || name === 'COMPLICATION_DATA'; }) &&
	        names.every(function(name) { return byteArray(payload[name]); })) { return 'complications'; }
	    if (context && !comp && names.every(function(name) {
	      return name === contextKey || name === 'CONTEXT_DATA' || name === contextRequestKey || name === 'REQUEST_CONTEXT' ||
	        name === contextStateKey || name === 'CONTEXT_STATE';
	    }) && byteArray(payload[contextKey] === undefined ? payload.CONTEXT_DATA : payload[contextKey])) { return 'context'; }
	    for (var i=0;i<extensions.length;i++) {
	      var spec=extensions[i];
	      var present=names.filter(function(name) { return spec.data.indexOf(name)>=0; });
	      if (present.length === 1 && byteArray(payload[present[0]]) && names.every(function(name) {
	        return spec.allowed.indexOf(name)>=0;
	      })) { return spec.name; }
	    }
	    // Mixed payloads may contain user settings; they always retain FIFO order.
	    return '';
	  }
	  function settle(entry,ok,error) {
	    if (entry.settled) { return; }
	    entry.settled=true;
	    var callback=ok ? entry.success : entry.failure;
	    if (typeof callback === 'function') { callback(error); }
	  }
	  function drain() {
	    if (active || !pending.length) { return; }
	    var entry = pending.shift();
	    active = entry;
	    var done = false;
	    var timer = options.later(function() { finish(false, {code:'TIMEOUT'}); }, 15000);
	    function finish(ok, error) {
	      if (done) { return; }
	      done = true;
	      options.cancelLater(timer);
	      if (active === entry) { active = null; }
	      try { settle(entry,ok,error); }
	      finally { drain(); }
	    }
	    try { options.send(entry.payload, function() { finish(true); }, function(error) { finish(false, error); }); }
	    catch (error) { finish(false, error); }
	  }
	  var send=function(payload, success, failure) {
	    var copy = {};
	    Object.keys(payload).forEach(function(key) {
	      copy[key] = byteArray(payload[key]) ? Array.prototype.slice.call(payload[key]) : payload[key];
	    });
	    var entry={payload:copy,success:success,failure:failure,channel:channel(copy),settled:false};
	    var replace=-1;
	    if (entry.channel) {
	      for (var i=0; i<pending.length; i++) { if (pending[i].channel === entry.channel) { replace=i; break; } }
	    }
	    if (replace>=0) {
	      var obsolete=pending.splice(replace,1)[0];
	      // The latest snapshot takes its actual submission position relative to
	      // settings. Superseded entries fail explicitly; they never receive ACKs.
	      pending.push(entry);
	      try { settle(obsolete,false,{code:'SUPERSEDED'}); }
	      finally { drain(); }
	      return;
	    } else {
	      if (pending.length >= 16) { settle(entry,false,{code:'BUSY'}); return; }
	      pending.push(entry);
	    }
	    drain();
	  };
	  // Coordinators can publish a replacement immediately instead of retaining
	  // stale copied bytes behind the shared transport's active settings transfer.
	  send.supersedesSnapshots=true;
	  return send;
	};


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var wire = __webpack_require__(7);
	var STATUS = {EMPTY:0, LOADING:1, READY:2, UNAVAILABLE:3, DENIED:4, UNSUPPORTED:5, DISABLED:6, EXPIRED:7};
	var NAMES = ['empty','loading','ready','unavailable','denied','unsupported','disabled','expired'];
	var DEFAULT_CACHE_KEY = 'watchface-core-complications-v1';
	var REFRESH = 30 * 60000;
	var MAX_AGE = 7200;
	var MAX_EPOCH = 4294967295;
	var VISIBLE_SLOTS = 2;
	
	function object(value) { return value && typeof value === 'object' && !Array.isArray(value); }
	function finite(value) { return typeof value === 'number' && isFinite(value); }
	function identifier(value) { return typeof value === 'string' && value.length > 0 && value.length <= 128 && !/[\x00-\x1f\x7f]/.test(value); }
	function textOf(property) { return object(property) && object(property.shortText) ? property.shortText.text : null; }
	function codeOf(error) {
	  return error && typeof error.code === 'string' && /^[A-Z0-9_]{1,48}$/.test(error.code) ? error.code : 'UNKNOWN';
	}
	function messageOf(error) {
	  if (!error || typeof error.message !== 'string') { return ''; }
	  var text = error.message.replace(/[\x00-\x1f\x7f-\x9f\u00ad\u061c\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff\ufff9-\ufffb]/g, ' ')
	    .replace(/ +/g, ' ').trim();
	  var out = '';
	  for (var i = 0; i < text.length; i++) {
	    var character = text[i];
	    var code = text.charCodeAt(i);
	    if (code >= 0xd800 && code <= 0xdbff && text.charCodeAt(i + 1) >= 0xdc00 && text.charCodeAt(i + 1) <= 0xdfff) {
	      character += text[++i];
	    } else if (code >= 0xd800 && code <= 0xdfff) { character = '\ufffd'; }
	    if (out.length + character.length > 180) { break; }
	    out += character;
	  }
	  return out;
	}
	function bytesOf(value, max) {
	  if (typeof value !== 'string' || value.length > Math.ceil(max / 3) * 4 ||
	      !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) { return null; }
	  var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
	  var out = [];
	  for (var i = 0; i < value.length; i += 4) {
	    var a = alphabet.indexOf(value[i]);
	    var b = alphabet.indexOf(value[i + 1]);
	    var c = value[i + 2] === '=' ? 0 : alphabet.indexOf(value[i + 2]);
	    var d = value[i + 3] === '=' ? 0 : alphabet.indexOf(value[i + 3]);
	    if (value[i + 2] === '=' && (b & 15) || value[i + 3] === '=' && value[i + 2] !== '=' && (c & 3)) { return null; }
	    out.push((a << 2) | (b >> 4));
	    if (value[i + 2] !== '=') { out.push(((b & 15) << 4) | (c >> 2)); }
	    if (value[i + 3] !== '=') { out.push(((c & 3) << 6) | d); }
	  }
	  return out.length <= max ? out : null;
	}
	function bitmapOf(shape, image) {
	  if (!object(shape) || !Number.isInteger(shape.width) || !Number.isInteger(shape.height) ||
	      shape.width < 1 || shape.width > 24 || shape.height < 1 || shape.height > 24) { return null; }
	  var palette = bytesOf(shape.palette, 16);
	  var sourcePixels = bytesOf(shape.pixels, 288);
	  // Source ImageShape uses tightly packed 4bpp rows. The watch transport has
	  // its own four-byte-aligned stride, so copy visible nibbles instead of
	  // assuming a square 24px source (where the two strides happen to match).
	  var sourceStride = Math.ceil(shape.width / 2);
	  var stride = ((shape.width + 7) >> 3) * 4;
	  if (!palette || !palette.length || !sourcePixels || sourcePixels.length !== sourceStride * shape.height) { return null; }
	  var pixels = [];
	  for (var i = 0; i < stride * shape.height; i++) { pixels.push(0); }
	  for (var y = 0; y < shape.height; y++) {
	    for (var x = 0; x < shape.width; x++) {
	      var sourceByte = sourcePixels[y * sourceStride + (x >> 1)];
	      var value = x & 1 ? sourceByte & 15 : sourceByte >> 4;
	      if (value >= palette.length) { return null; }
	      pixels[y * stride + (x >> 1)] |= x & 1 ? value : value << 4;
	    }
	  }
	  return {width:shape.width, height:shape.height, palette:palette, pixels:pixels, image:image};
	}
	function readingOf(property) {
	  if (!object(property)) { return {error:'PROPERTY_UNAVAILABLE', status:STATUS.UNAVAILABLE}; }
	  var bitmap = bitmapOf(property.icon, false) || bitmapOf(property.image, true);
	  var text = object(property.shortText) ? wire.normalizeText(property.shortText.text) : '';
	  var value = {};
	  if (!text && object(property.numericValue) && finite(property.numericValue.value) &&
	      (property.numericValue.unit === undefined || typeof property.numericValue.unit === 'string' &&
	        property.numericValue.unit.length <= 64 && !/[\x00-\x1f\x7f]/.test(property.numericValue.unit))) {
	    text = wire.normalizeText(String(property.numericValue.value) +
	      (property.numericValue.unit ? ' ' + property.numericValue.unit : ''));
	  }
	  if (!text && object(property.longText)) { text = wire.normalizeText(property.longText.text); }
	  if (text) { value.text = text; }
	  else if (object(property.boolean) && typeof property.boolean.value === 'boolean') { value.booleanValue = property.boolean.value; }
	  else if (object(property.timestamp) && Number.isInteger(property.timestamp.value) &&
	      property.timestamp.value > 0 && property.timestamp.value <= MAX_EPOCH) { value.timestamp = property.timestamp.value; }
	  if (bitmap) { value.bitmap = bitmap; }
	  if (Object.keys(value).length) { return {value:value, status:STATUS.READY}; }
	  return {status:property.series ? STATUS.UNSUPPORTED : STATUS.UNAVAILABLE,
	    error:property.series ? 'SERIES_UNSUPPORTED' : 'INVALID_DATA'};
	}
	
	function labelOf(slot) {
	  return wire.normalizeText(slot.label || slot.property.replace(/_/g,' '),24);
	}
	function utf8Size(text) {
	  var length=0;
	  for (var i=0; i<text.length; i++) {
	    var point=text.charCodeAt(i);
	    if (point>=0xd800 && point<=0xdbff && text.charCodeAt(i+1)>=0xdc00 && text.charCodeAt(i+1)<=0xdfff) { length+=4; i++; }
	    else { length+=point<0x80 ? 1 : point<0x800 ? 2 : 3; }
	  }
	  return length;
	}
	function semanticOf(slot,property,value) {
	  var kind=wire.SEMANTIC_KIND, source=wire.SOURCE_KIND, detail=wire.DETAIL_KIND;
	  var result={kind:kind.GENERIC,source:source.OTHER,label:labelOf(slot),detail:detail.NONE,qualifiers:0};
	  var weather=slot.category === 'weather' && slot.item === 'location';
	  if (weather) { result.source=source.WEATHER; }
	  else if (slot.category === 'phone') { result.source=source.PHONE; }
	  else if (slot.category === 'music') { result.source=source.MUSIC; }
	  else if (slot.category === 'notifications') { result.source=source.NOTIFICATION; }
	  var numeric=object(property) && property.numericValue;
	  if (object(numeric) && finite(numeric.value) &&
	      (numeric.unit === undefined || typeof numeric.unit === 'string' && numeric.unit.length<=64 && !/[\x00-\x1f\x7f]/.test(numeric.unit))) {
	    result.value=numeric.value;
	    if (numeric.unit) {
	      var unit=wire.normalizeText(numeric.unit);
	      if (utf8Size(unit)<=16) { result.unit=unit; }
	    }
	    if (finite(numeric.min) && finite(numeric.max) && numeric.min<=numeric.max) {
	      result.min=numeric.min; result.max=numeric.max;
	    } else if (numeric.min === undefined && finite(numeric.max)) { result.max=numeric.max; }
	    else if (numeric.max === undefined && finite(numeric.min)) { result.min=numeric.min; }
	    result.kind=kind.NUMBER;
	  } else if (typeof value.booleanValue === 'boolean') {
	    result.kind=kind.BOOLEAN; result.value=value.booleanValue ? 1 : 0;
	  } else if (Number.isInteger(value.timestamp)) { result.kind=kind.TIMESTAMP; }
	  if (weather) {
	    var details={temperature:detail.TEMPERATURE,feels_like:detail.FEELS_LIKE,high:detail.HIGH,low:detail.LOW,
	      humidity:detail.HUMIDITY,wind_speed:detail.WIND_SPEED,
	      wind_direction:detail.WIND_DIRECTION,uv_index:detail.UV,condition:detail.CONDITION,condition_code:detail.CONDITION};
	    result.detail=details[slot.property] || detail.NONE;
	    if (['temperature','feels_like','high','low'].indexOf(slot.property)>=0) { result.kind=kind.TEMPERATURE; }
	    else if (slot.property === 'precipitation' && precipitationStyle(slot,property,value)) {
	      result.kind=kind.PRECIPITATION; result.detail=detail.PRECIPITATION;
	    }
	    else if (slot.property === 'humidity') { result.kind=kind.HUMIDITY; }
	    else if (['wind_speed','wind_direction'].indexOf(slot.property)>=0) { result.kind=kind.WIND; }
	    else if (slot.property === 'uv_index') { result.kind=kind.UV; }
	    else if (slot.property === 'condition' || slot.property === 'condition_code') { result.kind=kind.CONDITION; }
	  } else if (slot.category === 'phone' && slot.item === 'phone_state' && slot.property === 'battery_level') {
	    result.kind=kind.BATTERY; result.detail=detail.PHONE_BATTERY;
	  }
	  return result;
	}
	// Missing values retain only a configured public identity. Do not keep a
	// private label, value, image or measurement time merely to explain a failure.
	function publicIdentity(slot,semantic) {
	  if (!slot || slot.invalid || privateDescriptor(slot) || privateRecord({semantic:semantic})) { return null; }
	  var value=semantic || semanticOf(slot,null,{});
	  var result={kind:value.kind,source:value.source,detail:value.detail || 0,
	    qualifiers:value.qualifiers || 0,label:labelOf(slot)};
	  if (typeof value.unit === 'string') { result.unit=value.unit; }
	  return result;
	}
	function observationProperties(slot) {
	  if (slot.category !== 'weather' || slot.item !== 'location') { return []; }
	  if (slot.property === 'temperature') { return ['observed_at','is_forecast']; }
	  if (['feels_like','high','low'].indexOf(slot.property)>=0) { return ['is_forecast']; }
	  if (slot.property === 'humidity') { return ['humidity_observed_at']; }
	  if (slot.property === 'wind_speed' || slot.property === 'wind_direction') { return ['wind_observed_at']; }
	  return [];
	}
	function observedAt(slot,instance,receivedAt) {
	  var properties=object(instance) && instance.properties;
	  if (!object(properties)) { return null; }
	  var names=observationProperties(slot);
	  if (!names.length) { return null; }
	  var forecast=properties.is_forecast;
	  if (slot.property === 'temperature' && object(forecast) && object(forecast.boolean) && forecast.boolean.value === true) { return null; }
	  var observation=properties[names[0]];
	  var stamp=object(observation) && object(observation.timestamp) && observation.timestamp.value;
	  return Number.isInteger(stamp) && stamp>0 && stamp<=receivedAt ? stamp : null;
	}
	function privateDescriptor(slot) {
	  return slot && (slot.category === 'music' || slot.category === 'notifications');
	}
	function privateRecord(record) {
	  return record && record.semantic && (record.semantic.source === wire.SOURCE_KIND.MUSIC ||
	    record.semantic.source === wire.SOURCE_KIND.NOTIFICATION);
	}
	function persistentSignature(slots,prefix) {
	  return (prefix === undefined ? 'two:' : prefix)+JSON.stringify(slots.map(function(slot) {
	    if (!privateDescriptor(slot) || !slot.label) { return slot; }
	    var copy=Object.assign({},slot); delete copy.label; return copy;
	  }));
	}
	
	// A percentage alone is not evidence of rain. Only Pebble's standard weather
	// precipitation reading may request the droplet presentation, and its text
	// must still be a usable probability in the provider's own format.
	function precipitationStyle(slot, property, value) {
	  if (slot.category !== 'weather' || slot.item !== 'location' || slot.property !== 'precipitation' ||
	      !object(property) || !value || typeof value.text !== 'string') { return 0; }
	  var match = /^(\d+(?:[.,]\d+)?)\s*%$/.exec(value.text);
	  if (!match) { return 0; }
	  var shown = Number(match[1].replace(',', '.'));
	  if (!finite(shown) || shown < 0 || shown > 100) { return 0; }
	  if (property.numericValue !== undefined) {
	    var numeric = property.numericValue;
	    if (!object(numeric) || !finite(numeric.value) || numeric.value < 0 || numeric.value > 100 || numeric.unit !== '%') { return 0; }
	    // Compact text may round a more precise value. Accept only that rounding
	    // interval; a contradictory numeric reading must not acquire a rain icon.
	    var decimals = (match[1].split(/[.,]/)[1] || '').length;
	    if (Math.abs(shown - numeric.value) > 0.5 * Math.pow(10, -decimals) + 1e-10) { return 0; }
	  }
	  return 1;
	}
	
	module.exports = function(options) {
	  var cacheKey = typeof options.cacheKey === 'string' && options.cacheKey.length
	      ? options.cacheKey : DEFAULT_CACHE_KEY;
	  var pebble = options.pebble || {};
	  var descriptors = [null,null];
	  var records = [null,null];
	  var identities = [null,null];
	  var states = [0,0];
	  var errors = ['',''];
	  var messages = ['',''];
	  var fromCache = [false,false];
	  var hasPreferences = false;
	  var signature = '';
	  var preferenceGeneration = 0;
	  var sourceGeneration = 0;
	  var preferenceSubscription = null;
	  var subscriptions = [];
	  var refreshTimer = null;
	  var expiryTimer = null;
	  var available = typeof pebble.subscribeToSource === 'function';
	  var preferenceError = '';
	  var preferenceMessage = '';
	  var recoveryTimer = null;
	  var recoveryAttempt = 0;
	  var pending = null;
	  var sending = false;
	  var deliveryTimer = null;
	  var deliveryGeneration = 0;
	
	  function now() { return Math.floor(options.now() / 1000); }
	  function valid(record) {
	    return record && Number.isInteger(record.confirmedAt) && record.confirmedAt > 0 && record.confirmedAt <= now() &&
	      Number.isInteger(record.validUntil) && now() < record.validUntil && record.validUntil <= MAX_EPOCH &&
	      record.validUntil <= record.confirmedAt + MAX_AGE;
	  }
	  function save() {
	    var cacheable=records.map(function(record,i) {
	      return privateDescriptor(descriptors[i]) || privateRecord(record) ? null : record;
	    });
	    try { options.storage.setItem(cacheKey, JSON.stringify({signature:persistentSignature(descriptors), records:cacheable})); } catch (ignored) {}
	  }
	  function sanitizeStoredCache() {
	    try {
	      var cached=JSON.parse(options.storage.getItem(cacheKey));
	      if (!cached || !Array.isArray(cached.records)) { return; }
	      var encoded=typeof cached.signature === 'string' ? cached.signature : '';
	      var choices;
	      try { choices=JSON.parse(encoded.indexOf('two:') === 0 ? encoded.slice(4) : encoded); } catch (ignored) {}
	      var changed=false;
	      var safe=cached.records.map(function(record,i) {
	        // Legacy cache descriptors still identify music and notification data.
	        // Unclassifiable records are discarded rather than retained privately
	        // while the preview API or preference permission is unavailable.
	        if (record && (!Array.isArray(choices) || !choices[i] || privateDescriptor(choices[i]) || privateRecord(record))) {
	          changed=true; return null;
	        }
	        return record;
	      });
	      var safeSignature=Array.isArray(choices) ? persistentSignature(choices,encoded.indexOf('two:') === 0 ? 'two:' : '') : cached.signature;
	      if (safeSignature !== cached.signature) { changed=true; }
	      if (changed) { options.storage.setItem(cacheKey,JSON.stringify({signature:safeSignature,records:safe})); }
	    } catch (ignored) {}
	  }
	  function load() {
	    try {
	      var cached = JSON.parse(options.storage.getItem(cacheKey));
	      if (!cached || cached.signature !== persistentSignature(descriptors) || !Array.isArray(cached.records) || cached.records.length !== VISIBLE_SLOTS) { return; }
	      cached.records.forEach(function(record, i) {
	        if (descriptors[i] && !descriptors[i].invalid && !privateDescriptor(descriptors[i]) && !privateRecord(record) && valid(record) &&
	            wire.packComplications([rendered(record)], now())[7] === STATUS.READY) {
	          // Old public caches retain their original values/times, while the
	          // current descriptor can supply newly introduced meaning metadata.
	          var identified=semanticOf(descriptors[i],null,{});
	          record.semantic=Object.assign({},identified,record.semantic || {});
	          record.semantic.source=identified.source;
	          record.semantic.detail=identified.detail;
	          if (identified.kind !== wire.SEMANTIC_KIND.GENERIC) { record.semantic.kind=identified.kind; }
	          if (descriptors[i].category === 'weather' && descriptors[i].item === 'location' &&
	              descriptors[i].property === 'precipitation' && record.semantic.kind === wire.SEMANTIC_KIND.PRECIPITATION) {
	            record.semantic.detail=wire.DETAIL_KIND.PRECIPITATION;
	          }
	          if (!(record.semantic.qualifiers & wire.QUALIFIERS.FORECAST) && Number.isInteger(record.observedAt) &&
	              record.observedAt>0 && record.observedAt<=record.confirmedAt) {
	            record.semantic.observedAt=record.observedAt;
	          }
	          records[i] = record; states[i] = STATUS.READY;
	          identities[i]=publicIdentity(descriptors[i],record.semantic);
	          fromCache[i]=true;
	        }
	      });
	    } catch (ignored) {}
	  }
	  function cancelDelivery() {
	    deliveryGeneration++;
	    if (deliveryTimer !== null) { options.cancelLater(deliveryTimer); }
	    deliveryTimer = null; pending = null; sending = false;
	  }
	  function cancelRecovery() {
	    if (recoveryTimer !== null) { options.cancelLater(recoveryTimer); }
	    recoveryTimer = null;
	    recoveryAttempt = 0;
	  }
	  function needsRecovery() {
	    return available && hasPreferences && descriptors.some(function(slot, i) {
	      return slot && !slot.invalid && errors[i] === 'PLUGIN_UNAVAILABLE';
	    });
	  }
	  function scheduleRecovery() {
	    if (!needsRecovery()) { cancelRecovery(); return; }
	    if (recoveryTimer !== null) { return; }
	    var expected = signature;
	    var delay = [5000,15000,60000,120000][recoveryAttempt];
	    recoveryTimer = options.later(function() {
	      recoveryTimer = null;
	      if (signature !== expected || !needsRecovery()) { return; }
	      recoveryAttempt = Math.min(recoveryAttempt + 1, 3);
	      // Re-resolve the same generic sources. Keep the normal thirty-minute
	      // preferences refresh independent from this bounded registration retry.
	      sources(); publish(); scheduleRecovery();
	    }, delay);
	  }
	  function pump() {
	    if (sending || !pending) { return; }
	    var payload = pending;
	    pending = null; sending = true;
	    var generation = deliveryGeneration;
	    function attempt(number) {
	      if (generation !== deliveryGeneration) { return; }
	      var done = false;
	      function finish(ok,error) {
	        if (done || generation !== deliveryGeneration) { return; }
	        done = true;
	        options.cancelLater(deliveryTimer); deliveryTimer = null;
	        if (!ok && (!error || error.code !== 'SUPERSEDED') && !pending && number < 3) {
	          deliveryTimer = options.later(function() { attempt(number + 1); }, number * 1000);
	          return;
	        }
	        sending = false;
	        if (!ok && (!error || error.code !== 'SUPERSEDED') && options.log) { options.log('Complication delivery failed'); }
	        pump();
	      }
	      deliveryTimer = options.later(function() { finish(false); }, 10000);
	      try { options.send(payload, function() { finish(true); }, function(error) { finish(false,error); }); }
	      catch (ignored) { finish(false); }
	    }
	    attempt(1);
	  }
	  function rendered(record) {
	    var value = Object.assign({}, record, {status:STATUS.READY});
	    if (typeof record.booleanValue === 'boolean') {
	      var text;
	      try { text = options.localizeBoolean && options.localizeBoolean(record.booleanValue, options.getSettings().language); } catch (ignored) {}
	      value.text = wire.normalizeText(text) || (record.booleanValue ? 'On' : 'Off');
	    }
	    return value;
	  }
	  function publish() {
	    if (!hasPreferences && available) { return; }
	    var slots = records.map(function(record, i) {
	      if (valid(record)) { return rendered(record); }
	      if (record) { records[i] = null; states[i] = STATUS.EXPIRED; errors[i] = 'SOURCE_EXPIRED'; messages[i] = ''; }
	      var missing={status:states[i]};
	      if (states[i] !== STATUS.EMPTY && identities[i]) { missing.semantic=identities[i]; }
	      return missing;
	    });
	    var payload = {};
	    payload[options.keys.COMPLICATION_DATA] = wire.packComplications(slots, now());
	    if (options.send.supersedesSnapshots && sending) { cancelDelivery(); }
	    pending = payload; pump();
	  }
	  function scheduleExpiry() {
	    if (expiryTimer !== null) { options.cancelLater(expiryTimer); }
	    expiryTimer = null;
	    var end = Infinity;
	    records.forEach(function(record) { if (valid(record)) { end = Math.min(end, record.validUntil); } });
	    if (end !== Infinity) {
	      expiryTimer = options.later(function() { expiryTimer = null; publish(); save(); scheduleExpiry(); },
	        Math.max(1, end * 1000 - options.now()));
	    }
	  }
	  function closeSources() {
	    sourceGeneration++;
	    subscriptions.forEach(function(subscription) { try { if (subscription && subscription.unsubscribe) { subscription.unsubscribe(); } } catch (ignored) {} });
	    subscriptions = [];
	  }
	  function sourceError(group, error) {
	    var code = codeOf(error);
	    var status = code === 'PERMISSION_DENIED' ? STATUS.DENIED : code === 'PLUGIN_DISABLED' ? STATUS.DISABLED :
	      code === 'UNSUPPORTED' || code === 'INVALID_REQUEST' ? STATUS.UNSUPPORTED : STATUS.UNAVAILABLE;
	    var terminal = ['PERMISSION_DENIED','PLUGIN_DISABLED','PLUGIN_UNAVAILABLE','SOURCE_UNAVAILABLE','SOURCE_NOT_FOUND','NOT_FOUND','UNSUPPORTED','INVALID_REQUEST'].indexOf(code) >= 0;
	    group.slots.forEach(function(i) {
	      errors[i] = code;
	      messages[i] = messageOf(error);
	      if (terminal || !valid(records[i])) { records[i] = null; states[i] = status; fromCache[i]=false; }
	    });
	    publish(); save(); scheduleExpiry(); scheduleRecovery();
	  }
	  function sources() {
	    closeSources();
	    var generation = sourceGeneration;
	    var groups = {};
	    descriptors.forEach(function(slot, i) {
	      if (!slot || slot.invalid) { return; }
	      var key = JSON.stringify([slot.category,slot.item]);
	      if (!groups[key]) { groups[key] = {category:slot.category,item:slot.item,properties:[],slots:[]}; }
	      var group = groups[key];
	      group.slots.push(i);
	      if (group.properties.indexOf(slot.property) < 0) { group.properties.push(slot.property); }
	      observationProperties(slot).forEach(function(name) {
	        if (group.properties.indexOf(name)<0) { group.properties.push(name); }
	      });
	    });
	    Object.keys(groups).forEach(function(key) {
	      if (generation !== sourceGeneration) { return; }
	      var group = groups[key];
	      try {
	        var handle = pebble.subscribeToSource({category:group.category,item:group.item,properties:group.properties,
	          iconPixelSize:{w:24,h:24},onData:function(envelope) {
	            if (generation !== sourceGeneration) { return; }
	            group.slots.forEach(function(i) { messages[i] = ''; });
	            var confirmedAt = now();
	            var until = Math.min(confirmedAt + MAX_AGE, MAX_EPOCH);
	            var expiry = envelope && envelope.validUntilMs;
	            if (expiry !== undefined && expiry !== null) {
	              if (!finite(expiry)) {
	                group.slots.forEach(function(i) { records[i] = null; states[i] = STATUS.UNAVAILABLE; errors[i] = 'INVALID_EXPIRY'; });
	                publish(); save(); scheduleExpiry(); scheduleRecovery(); return;
	              }
	              until = Math.min(until, Math.floor(expiry / 1000));
	            }
	            if (!envelope || !Array.isArray(envelope.instances) || until <= confirmedAt) {
	              group.slots.forEach(function(i) { records[i] = null; states[i] = STATUS.UNAVAILABLE; errors[i] = 'INVALID_DATA'; });
	            } else {
	              group.slots.forEach(function(i) {
	                var slot = descriptors[i];
	                var instance = envelope.instances[slot.index];
	                var property = instance && object(instance.properties) && instance.properties[slot.property];
	                var parsed = readingOf(property);
	                if (parsed.value) {
	                  parsed.value.displayKind = precipitationStyle(slot, property, parsed.value);
	                  parsed.value.semantic=semanticOf(slot,property,parsed.value);
	                  parsed.value.observedAt=observedAt(slot,instance,confirmedAt);
	                  if (parsed.value.semantic.kind === wire.SEMANTIC_KIND.TEMPERATURE &&
	                      object(instance.properties.is_forecast) && object(instance.properties.is_forecast.boolean) &&
	                      instance.properties.is_forecast.boolean.value === true) {
	                    parsed.value.semantic.qualifiers=wire.QUALIFIERS.FORECAST;
	                    parsed.value.observedAt=null;
	                  }
	                  if (parsed.value.observedAt !== null) { parsed.value.semantic.observedAt=parsed.value.observedAt; }
	                  identities[i]=publicIdentity(slot,parsed.value.semantic);
	                }
	                states[i] = parsed.status; errors[i] = parsed.error || '';
	                fromCache[i]=false;
	                records[i] = parsed.value ? Object.assign({}, parsed.value, {confirmedAt:confirmedAt,validUntil:until}) : null;
	              });
	            }
	            publish(); save(); scheduleExpiry(); scheduleRecovery();
	          },onError:function(error) { if (generation === sourceGeneration) { sourceError(group,error); } }});
	        if (generation === sourceGeneration) { subscriptions.push(handle); }
	        else if (handle && handle.unsubscribe) { handle.unsubscribe(); }
	      } catch (error) { if (generation === sourceGeneration) { sourceError(group,error); } }
	    });
	  }
	  function preferred(envelope) {
	    if (!envelope || !Array.isArray(envelope.instances)) { preferenceError = 'INVALID_DATA'; preferenceMessage = ''; return; }
	    var next = [null,null];
	    var seen = {};
	    envelope.instances.forEach(function(instance) {
	      if (!instance || !/^[01]$/.test(instance.instanceId) || typeof instance.instanceId !== 'string') { return; }
	      var i = Number(instance.instanceId);
	      var p = instance.properties || {};
	      var slot = {category:textOf(p.category),item:textOf(p.item),property:textOf(p.property),
	        index:object(p.index) && object(p.index.numericValue) ? p.index.numericValue.value : null};
	      var label=textOf(p.label);
	      if (typeof label === 'string' && label.trim()) { slot.label=wire.normalizeText(label,24); }
	      if (seen[i] || !identifier(slot.category) || !identifier(slot.item) || !identifier(slot.property) ||
	          !Number.isSafeInteger(slot.index) || slot.index < 0) { slot = {invalid:true}; }
	      seen[i] = true; next[i] = slot;
	    });
	    // The namespace also rejects old five-slot cache records, even if their
	    // first two descriptors happen to match the new face's two choices.
	    var nextSignature = 'two:' + JSON.stringify(next);
	    preferenceError = '';
	    preferenceMessage = '';
	    if (hasPreferences && nextSignature === signature) { return; }
	    var first = !hasPreferences;
	    cancelRecovery(); closeSources(); cancelDelivery();
	    descriptors = next; signature = nextSignature; hasPreferences = true;
	    records = [null,null];
	    identities=descriptors.map(function(slot) { return publicIdentity(slot); });
	    fromCache = [false,false];
	    states = descriptors.map(function(slot) { return !slot ? STATUS.EMPTY : slot.invalid ? STATUS.UNSUPPORTED : STATUS.LOADING; });
	    errors = descriptors.map(function(slot) { return slot && slot.invalid ? 'INVALID_PREFERENCE' : ''; });
	    messages = ['',''];
	    if (first) { load(); }
	    publish(); save(); scheduleExpiry(); sources();
	  }
	  function refresh() {
	    available = typeof pebble.subscribeToSource === 'function';
	    if (refreshTimer !== null) { options.cancelLater(refreshTimer); }
	    if (!available) {
	      cancelRecovery();
	      preferenceGeneration++;
	      try { if (preferenceSubscription && preferenceSubscription.unsubscribe) { preferenceSubscription.unsubscribe(); } } catch (ignored) {}
	      preferenceSubscription = null;
	      closeSources(); cancelDelivery(); states = [3,3]; records = [null,null]; fromCache = [false,false];
	      errors = ['API_UNAVAILABLE','API_UNAVAILABLE'];
	      messages = ['',''];
	      preferenceError = 'API_UNAVAILABLE'; preferenceMessage = ''; publish(); return;
	    }
	    var privateCleared=false;
	    records.forEach(function(record,i) {
	      if (record && (privateDescriptor(descriptors[i]) || privateRecord(record))) {
	        records[i]=null; states[i]=STATUS.LOADING; errors[i]=''; messages[i]=''; fromCache[i]=false;
	        privateCleared=true;
	      }
	    });
	    if (privateCleared) {
	      // Reconnect/refresh requires a new source delivery for private readings.
	      // Retain ordinary cached weather with its original receipt timestamp.
	      closeSources(); publish(); save(); scheduleExpiry();
	    }
	    var alreadyConfigured = hasPreferences;
	    var previousSourceGeneration = sourceGeneration;
	    var generation = ++preferenceGeneration;
	    try { if (preferenceSubscription && preferenceSubscription.unsubscribe) { preferenceSubscription.unsubscribe(); } } catch (ignored) {}
	    preferenceSubscription = null;
	    try {
	      var handle = pebble.subscribeToSource({category:'preferences',item:'complications',
	        onData:function(envelope) { if (generation === preferenceGeneration) { preferred(envelope); } },
	        onError:function(error) {
	          if (generation === preferenceGeneration) { preferenceError = codeOf(error); preferenceMessage = messageOf(error); }
	        }});
	      if (generation === preferenceGeneration) { preferenceSubscription = handle; }
	      else if (handle && handle.unsubscribe) { handle.unsubscribe(); }
	    } catch (error) { preferenceError = codeOf(error); preferenceMessage = messageOf(error); }
	    if (alreadyConfigured && sourceGeneration === previousSourceGeneration) { sources(); publish(); }
	    scheduleRecovery();
	    refreshTimer = options.later(function() { refreshTimer = null; refresh(); }, REFRESH);
	  }
	  sanitizeStoredCache();
	  return {refresh:refresh,configure:function() { publish(); scheduleExpiry(); },status:function() {
	    var firstError = -1;
	    for (var i = 0; i < errors.length; i++) { if (errors[i]) { firstError = i; break; } }
	    return {available:available,configured:descriptors.filter(function(slot) { return slot; }).length,
	      ready:records.filter(valid).length,error:preferenceError || errors.filter(function(error) { return error; })[0] || '',
	      message:preferenceError ? preferenceMessage : firstError >= 0 ? messages[firstError] : '',
	      slots:descriptors.map(function(slot, i) {
	        var record=records[i], received=record && record.confirmedAt || null;
	        var observed=record && Number.isInteger(record.observedAt) && record.observedAt>0 && record.observedAt<=now() ? record.observedAt : null;
	        var safe=slot && (slot.category === 'weather' && slot.item === 'location' || slot.category === 'phone' && slot.item === 'phone_state');
	        return {slot:i+1,category:slot && slot.category || '',item:slot && slot.item || '',
	        index:slot && slot.index !== undefined ? slot.index : null,property:slot && slot.property || '',
	        label:slot && !slot.invalid ? labelOf(slot) : '',
	        text:safe && valid(record) && typeof record.text === 'string' ? record.text : null,
	        receivedAt:received,receivedAgeSec:received === null ? null : Math.max(0,now()-received),
	        observedAt:observed,observationAgeSec:observed === null ? null : now()-observed,cached:!!fromCache[i],
	        status:NAMES[record && !valid(record) ? STATUS.EXPIRED : states[i]],error:errors[i],message:messages[i]}; })};
	  }};
	};


/***/ }),
/* 7 */
/***/ (function(module, exports) {

	'use strict';
	
	var VERSION = 4;
	var HEADER_BYTES = 56;
	var SEMANTIC_KIND = {GENERIC:0,TEMPERATURE:1,PRECIPITATION:2,BATTERY:3,HUMIDITY:4,WIND:5,UV:6,CONDITION:7,RANGE:8,NUMBER:9,BOOLEAN:10,TIMESTAMP:11};
	var SOURCE_KIND = {GENERIC:0,WEATHER:1,PHONE:2,MUSIC:3,NOTIFICATION:4,OTHER:5};
	var DETAIL_KIND = {NONE:0,TEMPERATURE:1,FEELS_LIKE:2,HIGH:3,LOW:4,PRECIPITATION:5,HUMIDITY:6,WIND_SPEED:7,WIND_DIRECTION:8,UV:9,CONDITION:10,PHONE_BATTERY:11};
	var QUALIFIERS = {FORECAST:1};
	var DETAIL_SEMANTIC = [0,1,1,1,1,2,4,5,5,6,7,3];
	var SLOT_COUNT = 5;
	var TEXT = 1;
	var BITMAP = 2;
	var IMAGE = 4;
	var TIMESTAMP = 8;
	var EMPTY = 0;
	var READY = 2;
	var UNAVAILABLE = 3;
	var UNSUPPORTED = 5;
	var EXPIRED = 7;
	var MAX_EPOCH = 4294967295;
	var MAX_AGE = 7200;
	var MAX_TEXT_BYTES = 128;
	
	function object(value) { return value && typeof value === 'object' && !Array.isArray(value); }
	function integer(value, minimum, maximum) {
	  return typeof value === 'number' && isFinite(value) && value >= minimum &&
	    value <= maximum && Math.floor(value) === value;
	}
	function bytes(value) {
	  return Array.isArray(value) || Object.prototype.toString.call(value) === '[object Uint8Array]';
	}
	function byteArray(value, length) {
	  if (!bytes(value) || value.length !== length) { return false; }
	  for (var i = 0; i < length; i++) { if (!integer(value[i], 0, 255)) { return false; } }
	  return true;
	}
	function scalar(text, at) {
	  var first = text.charCodeAt(at);
	  if (first >= 0xD800 && first <= 0xDBFF) {
	    var second = text.charCodeAt(at + 1);
	    if (second >= 0xDC00 && second <= 0xDFFF) {
	      return {value:0x10000 + (first - 0xD800) * 1024 + second - 0xDC00, length:2};
	    }
	    return {value:0xFFFD, length:1};
	  }
	  return {value:first >= 0xDC00 && first <= 0xDFFF ? 0xFFFD : first, length:1};
	}
	function scalarText(value) {
	  if (value <= 0xFFFF) { return String.fromCharCode(value); }
	  value -= 0x10000;
	  return String.fromCharCode(0xD800 + Math.floor(value / 1024), 0xDC00 + value % 1024);
	}
	function utf8Length(value) { return value < 0x80 ? 1 : value < 0x800 ? 2 : value < 0x10000 ? 3 : 4; }
	
	// The native decoder rejects control characters. Keep ordinary word boundaries
	// when sanitizing them, repair orphan surrogates and truncate only whole UTF-8
	// scalars, reserving an ellipsis when content exceeds the byte limit. The
	// bounded returned string is also suitable for coordinator storage and replay.
	function normalizeText(value, maxBytes) {
	  maxBytes = integer(maxBytes, 3, MAX_TEXT_BYTES) ? maxBytes : MAX_TEXT_BYTES;
	  if (typeof value !== 'string') { return ''; }
	  var result = '';
	  var ellipsisPrefix = '';
	  var count = 0;
	  var pendingSpace = false;
	  for (var i = 0; i < value.length;) {
	    var next = scalar(value, i);
	    i += next.length;
	    var code = next.value;
	    if (code < 0x20 || (code >= 0x7F && code <= 0x9F) || code === 0x2028 || code === 0x2029) { code = 0x20; }
	    // Defer spaces until another scalar arrives: trailing controls or spaces
	    // alone do not make an otherwise fitting string require an ellipsis.
	    if (code === 0x20) { pendingSpace = result.length > 0; continue; }
	    var length = utf8Length(code) + (pendingSpace ? 1 : 0);
	    if (count + length > maxBytes) { return ellipsisPrefix + '\u2026'; }
	    result += (pendingSpace ? ' ' : '') + scalarText(code);
	    count += length;
	    pendingSpace = false;
	    if (count <= maxBytes - 3) { ellipsisPrefix = result; }
	  }
	  return result;
	}
	function utf8(text) {
	  var out = [];
	  for (var i = 0; i < text.length;) {
	    var next = scalar(text, i);
	    var code = next.value;
	    i += next.length;
	    if (code < 0x80) { out.push(code); }
	    else if (code < 0x800) { out.push(0xC0 | (code >> 6), 0x80 | (code & 63)); }
	    else if (code < 0x10000) { out.push(0xE0 | (code >> 12), 0x80 | ((code >> 6) & 63), 0x80 | (code & 63)); }
	    else { out.push(0xF0 | (code >> 18), 0x80 | ((code >> 12) & 63), 0x80 | ((code >> 6) & 63), 0x80 | (code & 63)); }
	  }
	  return out;
	}
	function u16(out, at, value) { out[at] = value & 255; out[at + 1] = Math.floor(value / 256) & 255; }
	function u32(out, at, value) {
	  for (var i = 0; i < 4; i++) { out[at + i] = Math.floor(value / Math.pow(256, i)) % 256; }
	}
	function crc16Xmodem(value) {
	  var crc = 0;
	  for (var i = 0; i < value.length; i++) {
	    crc ^= value[i] << 8;
	    for (var bit = 0; bit < 8; bit++) { crc = ((crc << 1) ^ (crc & 0x8000 ? 0x1021 : 0)) & 0xFFFF; }
	  }
	  return crc;
	}
	function statusRecord(status, headerBytes) {
	  headerBytes = headerBytes || HEADER_BYTES;
	  var result = [];
	  for (var i = 0; i < headerBytes; i++) { result.push(0); }
	  result[1] = status;
	  return result;
	}
	function bitmapOf(value, maxSize) {
	  maxSize = maxSize || 40;
	  if (!object(value) || !integer(value.width, 1, maxSize) || !integer(value.height, 1, maxSize) ||
	      !bytes(value.palette) || !integer(value.palette.length, 1, 16)) { return null; }
	  var stride = ((value.width + 7) >> 3) * 4;
	  var count = stride * value.height;
	  if (!byteArray(value.palette, value.palette.length) || !byteArray(value.pixels, count)) { return null; }
	  // The original palette length matters before padding to the 16-byte wire
	  // palette. Ignore row padding and the unused low nibble of odd-width rows.
	  for (var y = 0; y < value.height; y++) {
	    for (var x = 0; x < value.width; x++) {
	      var pair = value.pixels[y * stride + (x >> 1)];
	      var index = x & 1 ? pair & 15 : pair >> 4;
	      if (index >= value.palette.length) { return null; }
	    }
	  }
	  var palette = [];
	  for (var i = 0; i < 16; i++) { palette.push(i < value.palette.length ? value.palette[i] : 0); }
	  return {width:value.width, height:value.height, palette:palette,
	    pixels:Array.prototype.slice.call(value.pixels), image:value.image === true};
	}
	function f64(out, at, value) {
	  var buffer = new ArrayBuffer(8), view = new DataView(buffer);
	  view.setFloat64(0, value, true);
	  for (var i = 0; i < 8; ++i) { out[at + i] = view.getUint8(i); }
	}
	function semanticOf(slot, version, identityOnly) {
	  var value = slot.semantic;
	  if (!object(value)) { return null; }
	  var kind = value.kind === undefined ? 0 : value.kind;
	  var source = value.source === undefined ? 0 : value.source;
	  if (!integer(kind, 0, 11) || !integer(source, 0, 5)) { return null; }
	  var result = {kind:kind,source:source,flags:0,unit:[],label:[],detail:0,qualifiers:0,observedAt:0};
	  if (version === 4) {
	    var detail = value.detail === undefined ? 0 : value.detail;
	    var qualifiers = value.qualifiers === undefined ? 0 : value.qualifiers;
	    var observedAt = identityOnly || value.observedAt === undefined ? 0 : value.observedAt;
	    if (!integer(detail,0,11) || detail && DETAIL_SEMANTIC[detail] !== kind &&
	        !(detail === DETAIL_KIND.PRECIPITATION && (kind === SEMANTIC_KIND.GENERIC || kind === SEMANTIC_KIND.NUMBER)) ||
	        !integer(qualifiers,0,1) || qualifiers && source !== SOURCE_KIND.WEATHER ||
	        !integer(observedAt,0,MAX_EPOCH) || observedAt &&
	          (observedAt > slot.confirmedAt || qualifiers & QUALIFIERS.FORECAST)) { return null; }
	    result.detail=detail; result.qualifiers=qualifiers; result.observedAt=observedAt;
	  }
	  var fields = ['value','min','max'];
	  for (var i = 0; i < fields.length; ++i) {
	    if (!identityOnly && value[fields[i]] !== undefined) {
	      var numeric = value[fields[i]];
	      if (typeof numeric !== 'number' || !isFinite(numeric)) { return null; }
	      result[fields[i]] = numeric; result.flags |= 1 << i;
	    }
	  }
	  if ((result.flags & 6) === 6 && result.min > result.max) { return null; }
	  if (value.unit !== undefined) {
	    if (typeof value.unit !== 'string') { return null; }
	    result.unit = utf8(normalizeText(value.unit));
	    // A shortened unit could change its meaning. Omit invalid optional metadata.
	    if (result.unit.length > 16) { return null; }
	  }
	  if (value.label !== undefined) {
	    if (typeof value.label !== 'string') { return null; }
	    result.label = utf8(normalizeText(value.label,24));
	  }
	  return result;
	}
	
	function unavailableRecord(slot,status,version,header) {
	  if (version !== 4 || status === EMPTY) { return statusRecord(status === EXPIRED ? UNAVAILABLE : status,header); }
	  var metadata=semanticOf(slot,version,true), out=statusRecord(status,header);
	  // Identity may survive a public source failure, but private source names,
	  // old content, numbers and observation times never survive this path.
	  if (!metadata || metadata.source === SOURCE_KIND.MUSIC || metadata.source === SOURCE_KIND.NOTIFICATION) { return out; }
	  out[20]=metadata.kind; out[22]=metadata.unit.length; out[23]=metadata.label.length;
	  out[24]=metadata.source; out[25]=metadata.detail; out[26]=metadata.qualifiers;
	  return out.concat(metadata.unit,metadata.label);
	}
	function record(slot, nowSec, version) {
	  var header = version === 4 ? HEADER_BYTES : version === 3 ? 52 : 20;
	  if (slot === undefined || slot === null) { return statusRecord(EMPTY,header); }
	  if (!object(slot) || !integer(slot.status, 0, 7)) { return statusRecord(UNSUPPORTED,header); }
	  if (slot.status !== READY) { return unavailableRecord(slot,slot.status,version,header); }
	  if (!integer(nowSec, 1, MAX_EPOCH) || !integer(slot.confirmedAt, 1, MAX_EPOCH) ||
	      !integer(slot.validUntil, 1, MAX_EPOCH) || slot.confirmedAt > nowSec) { return statusRecord(UNAVAILABLE,header); }
	  var until = Math.min(slot.validUntil, slot.confirmedAt + MAX_AGE, MAX_EPOCH);
	  if (nowSec >= until) { return unavailableRecord(slot,version === 4 ? EXPIRED : UNAVAILABLE,version,header); }
	  var text = utf8(normalizeText(slot.text,version >= 3 ? 128 : 48));
	  var event = !text.length && integer(slot.timestamp, 1, MAX_EPOCH) ? slot.timestamp : null;
	  var bitmap = bitmapOf(slot.bitmap,version >= 3 ? 40 : 24);
	  var flags = (text.length ? TEXT : event !== null ? TIMESTAMP : 0) |
	    (bitmap ? BITMAP | (bitmap.image ? IMAGE : 0) : 0);
	  if (!flags) { return statusRecord(slot.timestamp === 0 ? UNAVAILABLE : UNSUPPORTED,header); }
	  var out = statusRecord(READY,header);
	  out[0] = flags;
	  out[2] = text.length;
	  out[3] = bitmap ? bitmap.width : 0;
	  out[4] = bitmap ? bitmap.height : 0;
	  // V2 uses the former reserved byte for a provider-aware presentation hint.
	  // Generic percentages (battery, humidity) never acquire precipitation art.
	  out[5] = version !== 1 && slot.displayKind === 1 && text.length ? 1 : 0;
	  u32(out, 6, slot.confirmedAt);
	  u32(out, 10, until);
	  u16(out, 14, bitmap ? bitmap.pixels.length : 0);
	  if (event !== null) { u32(out, 16, event); }
	  var semantic = version >= 3 ? semanticOf(slot,version,false) : null;
	  if (semantic) {
	    out[20] = semantic.kind; out[21] = semantic.flags;
	    out[22] = semantic.unit.length; out[23] = semantic.label.length; out[24] = semantic.source;
	    if (version === 4) {
	      out[25]=semantic.detail; out[26]=semantic.qualifiers; u32(out,52,semantic.observedAt);
	    }
	    if (semantic.flags & 1) { f64(out,28,semantic.value); }
	    if (semantic.flags & 2) { f64(out,36,semantic.min); }
	    if (semantic.flags & 4) { f64(out,44,semantic.max); }
	  }
	  out = out.concat(text,semantic ? semantic.unit : [],semantic ? semantic.label : []);
	  if (bitmap) { out = out.concat(bitmap.palette, bitmap.pixels); }
	  return out;
	}
	
	/** Five fixed slots, including holes. No fetching, cache mutation or inference. */
	function packComplications(slots, nowSec, version) {
	  version = version === 1 || version === 2 || version === 3 ? version : VERSION;
	  var out = [version, 0, 0, 0, 0, 0];
	  var values = Array.isArray(slots) ? slots : [];
	  for (var i = 0; i < SLOT_COUNT; i++) { out = out.concat(record(values[i], nowSec,version)); }
	  u16(out, 2, out.length);
	  // CRC bytes stay zero while calculating the checksum over the whole packet.
	  u16(out, 4, crc16Xmodem(out));
	  return out;
	}
	
	module.exports = {packComplications:packComplications, normalizeText:normalizeText, crc16Xmodem:crc16Xmodem, SEMANTIC_KIND:SEMANTIC_KIND, SOURCE_KIND:SOURCE_KIND, DETAIL_KIND:DETAIL_KIND, QUALIFIERS:QUALIFIERS};


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	// Read-only hosts do not need the native-owner publisher/storage bridge.
	// Keep the complete historical API in index.js for existing consumers.
	module.exports={
	  activity:__webpack_require__(9),
	  summary:__webpack_require__(12),
	  summaryView:__webpack_require__(13),
	  wire:__webpack_require__(10),
	  view:__webpack_require__(11),
	  selection:__webpack_require__(14),
	  createActivities:__webpack_require__(15),
	  createContext:__webpack_require__(16)
	};


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	// Public notification-style activities. The ACT2 card is an internal transport
	// adapter; plugins never arrange slots, mandatory labels, meters or layouts.
	var wire=__webpack_require__(10),view=__webpack_require__(11),MAX=wire.MAX_EPOCH;
	var LIMITS={text:192,label:64,appName:32,descriptor:512};
	var SOURCE_PROPERTIES={schema_version:['numericValue'],kind:['shortText'],state:['shortText'],revision:['numericValue'],
	  app_name:['longText'],observed_at:['timestamp'],valid_until:['timestamp'],private:['boolean'],
	  unconfirmed:['boolean'],show_terminal:['boolean'],content:['longText'],detail:['longText'],artwork:['image','icon']};
	var FIELDS=['provider','id','kind','state','revision','appName','observedAt','validUntil','private','unconfirmed','showTerminal','content','detail','image'];
	var DATUM_FIELDS=['label','observedAt','validUntil','estimated'];
	function own(value,key){return Object.prototype.hasOwnProperty.call(value,key);}
	function known(value,keys){return wire.object(value)&&Object.keys(value).every(function(key){return keys.indexOf(key)>=0;});}
	function bool(value){return value===undefined||typeof value==='boolean';}
	function finite(value){return typeof value==='number'&&isFinite(value);}
	function string(value,limit){return typeof value==='string'&&value.length<=limit&&wire.utf8(value).length<=limit?wire.text(value,limit):null;}
	function datum(input,card){
	  if(typeof input==='string'){input={text:input};}
	  if(!wire.object(input)){return null;}
	  var keys=DATUM_FIELDS.concat(own(input,'text')?['text']:own(input,'value')?['value','unit']:['clock','deadline','seconds','since']);
	  if(!known(input,keys)||!bool(input.estimated)){return null;}
	  var out={},label=input.label===undefined?'':string(input.label,LIMITS.label);
	  if(label===null){return null;}if(label){out.label=label;}
	  if(input.observedAt!==undefined){out.observedAt=input.observedAt;}
	  if(input.validUntil!==undefined){out.validUntil=input.validUntil;}
	  if(input.estimated!==undefined){out.estimated=input.estimated;}
	  var observed=input.observedAt===undefined?card.observedAt:input.observedAt;
	  var expiry=input.validUntil===undefined?card.validUntil:input.validUntil;
	  if(!wire.integer(observed,1,card.observedAt)||!wire.integer(expiry,observed,card.validUntil)){return null;}
	  if(own(input,'text')){
	    out.text=string(input.text,LIMITS.text);if(!out.text){return null;}
	  }else if(own(input,'value')){
	    if(finite(input.value)){out.value=input.value;}
	    else if(typeof input.value==='string'&&input.unit===undefined){out.value=string(input.value,LIMITS.text);if(!out.value){return null;}}
	    else{return null;}
	    if(input.unit!==undefined){out.unit=string(input.unit,16);if(out.unit===null){return null;}}
	    if(wire.utf8(typeof out.value==='string'?out.value:view.numericText(out.value,out.unit)).length>LIMITS.text){return null;}
	  }else{
	    out.clock=input.clock;
	    if(out.clock==='countdown'){
	      if(input.since!==undefined||own(input,'deadline')===own(input,'seconds')){return null;}
	      if(own(input,'deadline')){if(!wire.integer(input.deadline,1,MAX)){return null;}out.deadline=input.deadline;}
	      else{if(!wire.integer(input.seconds,0,MAX)){return null;}out.seconds=input.seconds;}
	    }else if(out.clock==='elapsed'){
	      if(input.deadline!==undefined||input.since===undefined&&input.seconds===undefined){return null;}
	      if(input.since!==undefined){if(!wire.integer(input.since,1,observed)){return null;}out.since=input.since;}
	      if(input.seconds!==undefined){if(!wire.integer(input.seconds,0,MAX)){return null;}out.seconds=input.seconds;}
	    }else{return null;}
	  }
	  return wire.utf8(JSON.stringify(out)).length<=LIMITS.descriptor?out:null;
	}
	function normalize(input,provider){
	  if(!known(input,FIELDS)||!wire.uuid(provider||input.provider)||!wire.identity(input.id,64)||
	      !wire.integer(input.revision,1,MAX)||!wire.integer(input.observedAt,1,MAX)||
	      !wire.integer(input.validUntil,input.observedAt,MAX)||!bool(input.private)||!bool(input.unconfirmed)||!bool(input.showTerminal)){return null;}
	  var kind=input.kind===undefined?'activity':wire.identity(input.kind,24),state=input.state===undefined?'active':input.state;
	  if(!kind||!own(wire.STATES,state)){return null;}kind=kind.toLowerCase();
	  var app=input.appName===undefined?'':string(input.appName,LIMITS.appName);if(app===null){return null;}
	  var result={provider:provider||input.provider,id:input.id,kind:kind,state:state,revision:input.revision,
	    observedAt:input.observedAt,validUntil:input.validUntil,private:input.private!==false||kind==='music'||kind==='notification'||kind==='notifications',
	    unconfirmed:input.unconfirmed===true,showTerminal:input.showTerminal===true,appName:app};
	  if(result.private&&result.unconfirmed){return null;}
	  result.content=datum(input.content,result);if(!result.content){return null;}
	  result.detail=input.detail===undefined||input.detail===null?null:datum(input.detail,result);
	  if(input.detail!==undefined&&input.detail!==null&&!result.detail){return null;}
	  if(input.image!==undefined&&input.image!==null){result.image=wire.image(input.image);if(!result.image){return null;}}
	  return result;
	}
	function compiledDatum(input,card){
	  var label=input.label||card.appName||'Activity';
	  var observed=input.observedAt===undefined?card.observedAt:input.observedAt;
	  var out={label:label,observedAt:observed,validUntil:input.validUntil===undefined?card.validUntil:input.validUntil,
	    estimated:input.estimated===true,retain:!card.private};
	  if(input.text!==undefined){out.type='text';out.text=input.text;}
	  else if(input.value!==undefined){out.type='value';if(typeof input.value==='string'){out.text=input.value;}else{out.value=input.value;out.unit=input.unit||'';}}
	  else{
	    out.type='clock';out.mode=input.clock==='countdown'?'deadline':'elapsed';
	    out.running=input.deadline!==undefined||input.since!==undefined;
	    out.anchorAt=out.running?(input.since===undefined?observed:input.since):0;
	    out.baseSeconds=input.deadline===undefined?input.seconds||0:Math.max(0,input.deadline-observed);
	  }
	  return out;
	}
	function toView(input,provider){
	  var record=normalize(input,provider);if(!record){return null;}
	  var projection={provider:record.provider,id:record.id,kind:record.kind,state:record.state,revision:record.revision,
	    observedAt:record.observedAt,validUntil:record.validUntil,private:record.private,unconfirmed:record.unconfirmed,
	    showTerminal:record.showTerminal,caption:record.appName||'Activity',main:compiledDatum(record.content,record),
	    support:record.detail?compiledDatum(record.detail,record):null,image:record.image};
	  var card=view.normalize(projection);
	  // A bounded native host can omit optional detail, never an essential value,
	  // unit or clock. This does not modify the authoritative source/fingerprint.
	  if(!card&&projection.support){projection.support=null;card=view.normalize(projection);}
	  if(card){card.sourceFormat=3;if(record.appName){card.providerName=record.appName;}}
	  return card;
	}
	function scalar(p,name,shape,field){return p&&p[name]&&p[name][shape]?p[name][shape][field||'value']:undefined;}
	function parseDescriptor(p,name,optional){
	  if(!p||p[name]===undefined){return optional?null:undefined;}
	  var raw=scalar(p,name,'longText','text');
	  if(typeof raw!=='string'||raw.length>LIMITS.descriptor||wire.utf8(raw).length>LIMITS.descriptor){return undefined;}
	  try{var value=JSON.parse(raw);return wire.object(value)||typeof value==='string'?value:undefined;}catch(ignored){return undefined;}
	}
	function sourceCard(instance,provider){
	  var p=instance&&instance.properties;if(!wire.object(p)||scalar(p,'schema_version','numericValue')!==3){return null;}
	  var malformed=Object.keys(SOURCE_PROPERTIES).some(function(name){
	    if(p[name]===undefined||name==='artwork'){return false;}
	    var shape=SOURCE_PROPERTIES[name][0],field=shape==='shortText'||shape==='longText'?'text':'value';
	    return !wire.object(p[name])||!wire.object(p[name][shape])||scalar(p,name,shape,field)===undefined;
	  });
	  if(malformed||p.artwork!==undefined&&(!wire.object(p.artwork)||!p.artwork.image&&!p.artwork.icon)){return null;}
	  var content=parseDescriptor(p,'content',false),detail=parseDescriptor(p,'detail',true);
	  if(content===undefined||detail===undefined){return null;}
	  return normalize({provider:provider,id:instance.instanceId,kind:scalar(p,'kind','shortText','text'),state:scalar(p,'state','shortText','text'),
	    revision:scalar(p,'revision','numericValue'),appName:scalar(p,'app_name','longText','text'),observedAt:scalar(p,'observed_at','timestamp'),
	    validUntil:scalar(p,'valid_until','timestamp'),private:scalar(p,'private','boolean'),unconfirmed:scalar(p,'unconfirmed','boolean'),
	    showTerminal:scalar(p,'show_terminal','boolean'),content:content,detail:detail,image:p.artwork&&(p.artwork.image||p.artwork.icon)},provider);
	}
	function toSourceInstance(input,request){
	  var record=normalize(input);if(!record){return null;}
	  var p={schema_version:{numericValue:{value:3}},kind:{shortText:{text:record.kind}},state:{shortText:{text:record.state}},
	    revision:{numericValue:{value:record.revision}},app_name:{longText:{text:record.appName}},observed_at:{timestamp:{value:record.observedAt}},
	    valid_until:{timestamp:{value:record.validUntil}},private:{boolean:{value:record.private}},unconfirmed:{boolean:{value:record.unconfirmed}},
	    show_terminal:{boolean:{value:record.showTerminal}},content:{longText:{text:JSON.stringify(record.content)}}};
	  if(record.detail){p.detail={longText:{text:JSON.stringify(record.detail)}};}
	  if(record.image&&request&&request.iconPixelSize){
	    var internal=view.toSourceInstance(toView(record),request);if(!internal){return null;}p.artwork=internal.properties.artwork;
	  }
	  return {instanceId:record.id,properties:p};
	}
	function fromLegacy(input,options){
	  options=options||{};var record=wire.normalize(input);if(!record){return null;}
	  var content;
	  if(record.clock==='deadline'){content={clock:'countdown'};content[record.state==='active'?'deadline':'seconds']=record.state==='active'?record.deadline:record.duration;}
	  else if(record.clock==='elapsed'){content={clock:'elapsed',seconds:record.duration};if(record.state==='active'){content.since=record.clockAt;}}
	  else if(record.kind==='timer'&&(record.state==='completed'||record.state==='cancelled')){content=record.state==='completed'?'Finished':'Cancelled';}
	  else{content=record.value===undefined?record.main:{value:record.value,unit:record.unit};}
	  return normalize({provider:record.provider,id:record.id,kind:record.kind,state:record.state,revision:record.revision,
	    appName:options.appName||'',observedAt:record.observedAt,validUntil:record.validUntil,private:record.private,
	    unconfirmed:record.unconfirmed,showTerminal:input.showTerminal===true,content:content,image:record.image});
	}
	function helper(value,options){var result={};Object.keys(options||{}).forEach(function(k){result[k]=options[k];});Object.keys(value).forEach(function(k){result[k]=value[k];});return result;}
	function value(number,unit,options){var out={value:number};if(unit!==undefined){out.unit=unit;}return helper(out,options);}
	function countdown(options){return helper({clock:'countdown'},options);}
	function elapsed(options){return helper({clock:'elapsed'},options);}
	function createProvider(options){
	  options=options||{};if(!wire.uuid(options.pluginUuid)||typeof options.getActivities!=='function'){throw new Error('INVALID_PROVIDER');}
	  var now=options.now||Date.now;
	  function source(request){
	    var input=options.getActivities(),instances=[];if(!Array.isArray(input)||input.length>wire.LIMITS.instances){throw new Error('INVALID_ACTIVITIES');}
	    var time=now(),ids=Object.create(null);
	    input.forEach(function(raw){
	      var copy={};if(!wire.object(raw)){throw new Error('INVALID_ACTIVITY');}Object.keys(raw).forEach(function(k){copy[k]=raw[k];});
	      if(copy.appName===undefined){copy.appName=options.appName;}
	      var record=normalize(copy,options.pluginUuid);if(!record||ids[record.id]){throw new Error('INVALID_ACTIVITY');}ids[record.id]=true;
	      if(record.validUntil*1000>time){var instance=toSourceInstance(record,request);if(!instance){throw new Error('INVALID_ACTIVITY');}instances.push(instance);}
	    });
	    return {validUntilMs:Math.min(MAX*1000,Math.floor(time+30000)),instances:instances};
	  }
	  function handleSource(request,respond){
	    if(!request||request.category!=='activity'||request.item!=='live'){if(respond&&typeof respond.error==='function'){respond.error('INVALID_REQUEST','Unsupported source');}return;}
	    try{respond.data(source(request));}catch(ignored){if(respond&&typeof respond.error==='function'){respond.error('INVALID_DATA','Invalid activity snapshot');}}
	  }
	  return {source:source,handleSource:handleSource};
	}
	module.exports={VERSION:3,CATEGORY:'activity',ITEM:'live',LIMITS:LIMITS,SOURCE_PROPERTIES:SOURCE_PROPERTIES,PROPERTIES:Object.keys(SOURCE_PROPERTIES),
	  normalize:normalize,toView:toView,sourceCard:sourceCard,toSourceInstance:toSourceInstance,fromLegacy:fromLegacy,
	  value:value,countdown:countdown,elapsed:elapsed,createProvider:createProvider};


/***/ }),
/* 10 */
/***/ (function(module, exports) {

	'use strict';
	
	var MAX = 4294967295;
	var STATES = {active:1, paused:2, completed:3, cancelled:4};
	var CLOCKS = {none:0, deadline:1, elapsed:2};
	var LIMITS = {providers:32, instances:16, cards:2, main:192, footer:128, id:64, kind:24, unit:16, image:40, packet:2672};
	function object(v) { return !!v && typeof v === 'object' && !Array.isArray(v); }
	function integer(v, min, max) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v && v >= min && v <= max; }
	function uuid(v) { return typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(v); }
	function utf8(value) {
	  var out=[];
	  for (var i=0; i<value.length; i++) {
	    var c=value.charCodeAt(i);
	    if (c>=0xd800 && c<=0xdbff && i+1<value.length) {
	      var next=value.charCodeAt(i+1);
	      if (next>=0xdc00 && next<=0xdfff) { c=0x10000+((c-0xd800)<<10)+(next-0xdc00); i++; }
	      else { c=0xfffd; }
	    } else if (c>=0xd800 && c<=0xdfff) { c=0xfffd; }
	    if (c<128) { out.push(c); }
	    else if (c<2048) { out.push(192|(c>>6),128|(c&63)); }
	    else if (c<65536) { out.push(224|(c>>12),128|((c>>6)&63),128|(c&63)); }
	    else { out.push(240|(c>>18),128|((c>>12)&63),128|((c>>6)&63),128|(c&63)); }
	  }
	  return out;
	}
	function text(value, limit) {
	  if (typeof value !== 'string') { return ''; }
	  value=value.slice(0,4096).replace(/[\x00-\x1f\x7f-\x9f\u00ad\u061c\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/g,' ').replace(/\s+/g,' ').trim();
	  if (utf8(value).length<=limit) { return value; }
	  var out='';
	  for (var i=0; i<value.length; i++) {
	    var c=value.charAt(i), code=value.charCodeAt(i);
	    if (code>=0xd800 && code<=0xdbff && i+1<value.length) { c+=value.charAt(++i); }
	    if (utf8(out+c).length>limit-3) { break; }
	    out+=c;
	  }
	  return out+'\u2026';
	}
	function identity(v, limit) { return typeof v === 'string' && v.length>0 && !/[\x00-\x1f\x7f-\x9f]/.test(v) && utf8(v).length<=limit ? v : null; }
	function bytes(v, max) {
	  if (Array.isArray(v)) { return v.length<=max && v.every(function(n){return integer(n,0,255);}) ? v.slice() : null; }
	  if (typeof v !== 'string' || v.length>Math.ceil(max/3)*4 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(v)) { return null; }
	  var alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/', out=[];
	  for (var i=0;i<v.length;i+=4) {
	    var a=alphabet.indexOf(v[i]), b=alphabet.indexOf(v[i+1]), c=v[i+2]==='='?0:alphabet.indexOf(v[i+2]), d=v[i+3]==='='?0:alphabet.indexOf(v[i+3]);
	    if (v[i+2]==='=' && (b&15) || v[i+3]==='=' && v[i+2]!=='=' && (c&3)) { return null; }
	    out.push((a<<2)|(b>>4));
	    if(v[i+2]!=='=') {out.push(((b&15)<<4)|(c>>2));}
	    if(v[i+3]!=='=') {out.push(((c&3)<<6)|d);}
	  }
	  return out.length<=max ? out : null;
	}
	function image(v) {
	  if (!object(v) || !integer(v.width,1,40) || !integer(v.height,1,40)) { return null; }
	  var palette=bytes(v.palette,16), pixels=bytes(v.pixels,800), stride=Math.ceil(v.width/2);
	  if (!palette || !palette.length || !pixels || pixels.length!==stride*v.height) { return null; }
	  for (var y=0;y<v.height;y++) {
	    for (var x=0;x<v.width;x++) { var pair=pixels[y*stride+(x>>1)], n=x&1 ? pair&15 : pair>>4; if(n>=palette.length) {return null;} }
	    if(v.width&1) { pixels[y*stride+stride-1]&=240; }
	  }
	  while(palette.length<16) {palette.push(0);}
	  return {width:v.width,height:v.height,palette:palette,pixels:pixels};
	}
	function normalize(v, provider) {
	  if (!object(v) || !uuid(provider || v.provider)) { return null; }
	  var id=identity(v.id,LIMITS.id), kind=identity(typeof v.kind==='string'?v.kind.toLowerCase():v.kind,LIMITS.kind);
	  var state=v.state==='running'?'active':v.state==='finished'?'completed':v.state;
	  if(!id || !kind || !STATES[state] || !Object.prototype.hasOwnProperty.call(CLOCKS,v.clock) ||
	      !integer(v.revision,1,MAX) || !integer(v.observedAt,1,MAX) || !integer(v.validUntil,v.observedAt,MAX)) { return null; }
	  var result={provider:provider || v.provider,id:id,kind:kind,state:state,clock:v.clock,revision:v.revision,
	    observedAt:v.observedAt,validUntil:v.validUntil,deadline:v.deadline===undefined?0:v.deadline,
	    duration:v.duration===undefined?0:v.duration,clockAt:v.clockAt===undefined?0:v.clockAt,
	    main:text(v.main,LIMITS.main),footer:text(v.footer===undefined?v.name:v.footer,LIMITS.footer),unit:text(v.unit,LIMITS.unit),private:v.private!==false||kind==='music'||kind==='notification'||kind==='notifications',unconfirmed:v.unconfirmed===true};
	  if(result.private && result.unconfirmed) {return null;}
	  if(!integer(result.deadline,0,MAX) || !integer(result.duration,0,MAX) || !integer(result.clockAt,0,MAX)) { return null; }
	  if(state==='completed' || state==='cancelled') { result.clock='none';result.deadline=result.duration=result.clockAt=0; }
	  if(result.clock==='none' && (result.deadline || result.duration || result.clockAt)) {return null;}
	  if(result.clock==='deadline') {
	    if(state==='active' && (!result.deadline || result.duration || result.clockAt)) {return null;}
	    if(state==='paused' && (result.deadline || result.clockAt)) {return null;}
	  }
	  if(result.clock==='elapsed' && (result.deadline || state==='active' && !result.clockAt || state==='paused' && result.clockAt)) {return null;}
	  if(result.clock==='none' && (state==='active'||state==='paused') && !result.main && (v.value===undefined||v.value===null)) {return null;}
	  if(v.value!==undefined && v.value!==null) { if(typeof v.value!=='number'||!isFinite(v.value)) {return null;} result.value=v.value; }
	  if(v.image!==undefined && v.image!==null) {result.image=image(v.image);if(!result.image) {return null;}}
	  return result;
	}
	function put16(out, at, v) {out[at]=v&255;out[at+1]=(v>>>8)&255;}
	function put32(out, at, v) {for(var i=0;i<4;i++){out[at+i]=Math.floor(v/Math.pow(256,i))&255;}}
	function crc16(out) {var crc=65535;for(var i=0;i<out.length;i++){if(i===8||i===9){continue;}crc^=out[i]<<8;for(var n=0;n<8;n++){crc=((crc<<1)^(crc&32768?0x1021:0))&65535;}}return crc;}
	function encode(cards, options) {
	  options=options||{};
	  if(!Array.isArray(cards)||cards.length>2||!integer(options.session,2,MAX)||!integer(options.revision,1,MAX)||!integer(options.sentAt,1,MAX)) {throw new Error('INVALID_SNAPSHOT');}
	  var out=[65,67,84,49,1,cards.length,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
	  put32(out,12,options.session);put32(out,16,options.revision);put32(out,20,options.sentAt);
	  cards.forEach(function(raw){
	    var card=normalize(raw);
	    if(!card){throw new Error('INVALID_ACTIVITY');}
	    var strings=[card.provider,card.id,card.kind,card.main,card.footer,card.unit].map(utf8), record=[];
	    for(var i=0;i<48;i++){record.push(0);}
	    record[0]=STATES[card.state];record[1]=CLOCKS[card.clock];record[2]=(card.private?1:0)|(card.image?2:0)|(card.value===undefined?0:4)|(card.unconfirmed?8:0);
	    put32(record,4,card.revision);put32(record,8,card.observedAt);put32(record,12,card.validUntil);put32(record,16,card.deadline);put32(record,20,card.duration);put32(record,24,card.clockAt);
	    if(card.value!==undefined){var b=new ArrayBuffer(8),view=new DataView(b);view.setFloat64(0,card.value,true);for(i=0;i<8;i++){record[28+i]=view.getUint8(i);}}
	    strings.forEach(function(value,i){record[36+i]=value.length;});
	    if(card.image){record[42]=card.image.width;record[43]=card.image.height;put16(record,44,card.image.pixels.length);}
	    out=out.concat(record);strings.forEach(function(value){out=out.concat(value);});
	    if(card.image){out=out.concat(card.image.palette,card.image.pixels);}
	  });
	  if(out.length>LIMITS.packet){throw new Error('SNAPSHOT_TOO_LARGE');}
	  put16(out,6,out.length);put16(out,8,crc16(out));return out;
	}
	function clockValue(card, now) {
	  if(card.clock==='deadline'){return card.state==='paused'?card.duration:Math.max(0,card.deadline-Math.max(now,card.observedAt));}
	  if(card.clock==='elapsed'){return Math.min(MAX,card.duration+(card.state==='active'?Math.max(0,now-card.clockAt):0));}
	  return null;
	}
	function formatClock(seconds) {seconds=Math.max(0,Math.floor(seconds));var hours=Math.floor(seconds/3600),minutes=Math.floor(seconds/60)%60,s=seconds%60;return hours?hours+':'+('0'+minutes).slice(-2)+':'+('0'+s).slice(-2):('0'+minutes).slice(-2)+':'+('0'+s).slice(-2);}
	module.exports={VERSION:1,CATEGORY:'activity',ITEM:'session',LIMITS:LIMITS,STATES:STATES,CLOCKS:CLOCKS,MAX_EPOCH:MAX,object:object,integer:integer,uuid:uuid,utf8:utf8,text:text,identity:identity,image:image,normalize:normalize,encode:encode,crc16:crc16,clockValue:clockValue,formatClock:formatClock};


/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	// ACT2 is a bounded native view. Authoritative source revisions are checked by
	// the consumer before projection; the frame sequence orders view changes.
	var wire=__webpack_require__(10);
	var MAX=wire.MAX_EPOCH;
	var TYPES={text:1,value:2,clock:3};
	var METERS={progress:1,level:2};
	var LIMITS={cards:2,packet:2672,pool:320,label:64,text:192,caption:128};
	var COMMON=['schema_version','kind','state','revision','name','caption','observed_at','valid_until','private','unconfirmed','show_terminal','artwork'];
	var SOURCE_PROPERTIES={schema_version:['numericValue'],kind:['shortText'],state:['shortText'],revision:['numericValue'],
	  name:['longText'],caption:['longText'],observed_at:['timestamp'],valid_until:['timestamp'],private:['boolean'],unconfirmed:['boolean'],show_terminal:['boolean'],artwork:['image','icon'],
	  meter_kind:['shortText'],meter_source:['shortText'],meter_min:['numericValue'],meter_max:['numericValue']};
	['main','support'].forEach(function(prefix){
	  Object.keys({type:1,label:1,text:1,value:1,observed_at:1,valid_until:1,retain:1,estimated:1,clock:1,base:1,anchor:1,running:1}).forEach(function(suffix){
	    SOURCE_PROPERTIES[prefix+'_'+suffix]=[suffix==='value'||suffix==='base'?'numericValue':suffix==='observed_at'||suffix==='valid_until'||suffix==='anchor'?'timestamp':suffix==='retain'||suffix==='estimated'||suffix==='running'?'boolean':suffix==='type'||suffix==='clock'?'shortText':'longText'];
	  });
	});
	var PROPERTIES=Object.keys(SOURCE_PROPERTIES);
	function bool(value){return value===undefined||typeof value==='boolean';}
	function finite(value){return typeof value==='number'&&isFinite(value);}
	function clean(value,limit){return wire.text(value,limit);}
	function numericText(value,unit){return String(value)+(unit?(/^(%|°|°C|°F)$/.test(unit)?'':' ')+unit:'');}
	function scalar(properties,name,shape,field){return properties&&properties[name]&&properties[name][shape]?properties[name][shape][field||'value']:undefined;}
	function string(properties,name){var value=scalar(properties,name,'longText','text');return value===undefined?scalar(properties,name,'shortText','text'):value;}
	function datum(input,card,summaryProfile){
	  if(!wire.object(input)||!Object.prototype.hasOwnProperty.call(TYPES,input.type)||!bool(input.retain)||!bool(input.estimated)||!bool(input.running)){return null;}
	  var result={type:input.type,label:clean(input.label,LIMITS.label),text:'',
	    observedAt:input.observedAt===undefined?card.observedAt:input.observedAt,
	    validUntil:input.validUntil===undefined?card.validUntil:input.validUntil,
	    retain:input.retain===true,estimated:input.estimated===true};
	  if((!summaryProfile&&!result.label)||!wire.integer(result.observedAt,1,card.observedAt)||!wire.integer(result.validUntil,result.observedAt,card.validUntil)){return null;}
	  if(input.type==='clock'){
	    result.mode=input.mode;result.running=input.running===true;
	    result.baseSeconds=input.baseSeconds===undefined?0:input.baseSeconds;
	    result.anchorAt=input.anchorAt===undefined?0:input.anchorAt;
	    if((result.mode!=='deadline'&&result.mode!=='elapsed')||!wire.integer(result.baseSeconds,0,MAX)||
	        !wire.integer(result.anchorAt,0,result.observedAt)||(result.running?!result.anchorAt:result.anchorAt!==0)){return null;}
	    if(input.text){return null;}
	  } else {
	    if(input.running===true||input.mode!==undefined||input.baseSeconds!==undefined&&input.baseSeconds!==0||input.anchorAt!==undefined&&input.anchorAt!==0){return null;}
	    if(input.type==='value'&&input.value!==undefined){
	      if(!finite(input.value)||input.unit!==undefined&&(typeof input.unit!=='string'||wire.utf8(input.unit).length>16)){return null;}
	      result.value=input.value;result.unit=clean(input.unit,16);
	      result.text=numericText(result.value,result.unit);
	      if(input.text!==undefined&&input.text!==''&&clean(input.text,LIMITS.text)!==result.text){return null;}
	    } else {result.text=clean(input.text,LIMITS.text);}
	    if(!result.text||wire.utf8(result.text).length>LIMITS.text){return null;}
	  }
	  return result;
	}
	function poolFor(card){
	  var bytes=[],known=Object.create(null);
	  function add(value){
	    value=value||'';
	    if(Object.prototype.hasOwnProperty.call(known,value)){return known[value];}
	    var encoded=wire.utf8(value),reference={offset:bytes.length,length:encoded.length};
	    known[value]=reference;bytes=bytes.concat(encoded,[0]);return reference;
	  }
	  var refs={caption:add(card.caption),main:{label:add(card.main.label),text:add(card.main.text)}};
	  if(card.support){refs.support={label:add(card.support.label),text:add(card.support.text)};}
	  return {bytes:bytes,refs:refs};
	}
	function normalize(input,provider,summaryProfile){
	  if(!wire.object(input)||!wire.uuid(provider||input.provider)||!wire.identity(input.id,64)||!wire.identity(input.kind,24)||
	      !wire.integer(input.revision,1,MAX)||!wire.integer(input.observedAt,1,MAX)||!wire.integer(input.validUntil,input.observedAt,MAX)||
	      !Object.prototype.hasOwnProperty.call(wire.STATES,input.state)||!bool(input.private)||!bool(input.unconfirmed)||!bool(input.showTerminal)){return null;}
	  var kind=input.kind.toLowerCase(),card={provider:provider||input.provider,id:input.id,kind:kind,revision:input.revision,state:input.state,
	    observedAt:input.observedAt,validUntil:input.validUntil,private:input.private!==false||kind==='music'||kind==='notification'||kind==='notifications',
	    unconfirmed:input.unconfirmed===true,showTerminal:input.showTerminal===true,caption:clean(input.caption===undefined?input.name:input.caption,LIMITS.caption)};
	  if(card.private&&card.unconfirmed){return null;}
	  card.main=datum(input.main,card,summaryProfile);if(!card.main){return null;}
	  card.support=input.support===undefined||input.support===null?null:datum(input.support,card,summaryProfile);
	  if(input.support!==undefined&&input.support!==null&&!card.support){return null;}
	  card.meter=null;
	  if(input.meter!==undefined&&input.meter!==null){
	    var m=input.meter,target=card[m.source];
	    if(!wire.object(m)||!Object.prototype.hasOwnProperty.call(METERS,m.kind)||(m.source!=='main'&&m.source!=='support')||!target||target.type!=='value'){return null;}
	    var fraction;
	    if(m.min!==undefined||m.max!==undefined){
	      if(!finite(m.min)||!finite(m.max)||m.max<=m.min||!finite(target.value)||target.value<m.min||target.value>m.max){return null;}
	      fraction=(target.value-m.min)/(m.max-m.min);
	    } else {fraction=m.fraction;}
	    if(!finite(fraction)||fraction<0||fraction>1){return null;}
	    card.meter={kind:m.kind,source:m.source,fraction:fraction};
	    if(m.min!==undefined){card.meter.min=m.min;card.meter.max=m.max;}
	  }
	  if(input.image!==undefined&&input.image!==null){card.image=wire.image(input.image);if(!card.image){return null;}}
	  if(!summaryProfile&&poolFor(card).bytes.length>LIMITS.pool){return null;}
	  return card;
	}
	function fromLegacy(input,options){
	  options=options||{};
	  var legacy=wire.normalize(input);if(!legacy||!bool(input.showTerminal)||
	      options.timerPresentation!==undefined&&options.timerPresentation!=='detailed'&&options.timerPresentation!=='compact'){return null;}
	  var compactTimer=legacy.kind==='timer'&&options.timerPresentation==='compact';
	  var main,terminal=legacy.state==='completed'||legacy.state==='cancelled';
	  if(legacy.clock!=='none'){
	    main={type:'clock',label:legacy.clock==='deadline'?'Left':'Elapsed',mode:legacy.clock,running:legacy.state==='active',
	      baseSeconds:legacy.clock==='deadline'&&legacy.state==='active'?Math.max(0,legacy.deadline-legacy.observedAt):legacy.duration,
	      anchorAt:legacy.state==='active'?(legacy.clock==='deadline'?legacy.observedAt:legacy.clockAt):0,retain:!legacy.private};
	  } else {
	    main={type:legacy.value===undefined?'text':'value',label:terminal?'State':legacy.value===undefined?'Text':'Value',
	      text:legacy.main|| (legacy.value===undefined?(terminal?legacy.state:''):numericText(legacy.value,legacy.unit))};
	  }
	  var card={provider:legacy.provider,id:legacy.id,kind:legacy.kind,revision:legacy.revision,state:legacy.state,
	    observedAt:legacy.observedAt,validUntil:legacy.validUntil,private:legacy.private,unconfirmed:legacy.unconfirmed,
	    caption:legacy.footer,main:main,image:legacy.image};
	  if(!compactTimer&&legacy.kind==='timer'&&legacy.clock==='deadline'&&wire.integer(input.totalDuration,0,MAX)){
	    card.support={type:'clock',label:'Elapsed',mode:'elapsed',running:legacy.state==='active',
	      baseSeconds:Math.max(0,input.totalDuration-main.baseSeconds),anchorAt:legacy.state==='active'?legacy.observedAt:0,retain:!legacy.private};
	  }
	  if(options.terminalResults&&input.showTerminal!==false&&legacy.kind==='timer'&&legacy.state==='completed'){
	    card.showTerminal=true;card.main={type:'text',label:'State',text:'Finished',retain:!legacy.private};
	    if(!compactTimer&&wire.integer(input.totalDuration,0,MAX)){card.support={type:'clock',label:'Elapsed',mode:'elapsed',running:false,baseSeconds:input.totalDuration,anchorAt:0,retain:!legacy.private};}
	  }
	  if(compactTimer&&legacy.clock==='deadline'&&card.caption){
	    // One explicit identity caption fits both fields, so a host can deduplicate
	    // by exact equality without guessing which clock labels are expendable.
	    card.caption=clean(card.caption,LIMITS.label);card.main.label=card.caption;
	  }
	  // Legacy sources had separate maximum main/caption buffers. Fit the optional
	  // caption into the shared pool; never trim a structured clock or value unit.
	  var result=normalize(card);
	  for(var limit=LIMITS.caption-1;!result&&limit>=0;limit--){card.caption=clean(legacy.footer,limit);result=normalize(card);}
	  return result;
	}
	function put16(bytes,offset,value){bytes[offset]=value&255;bytes[offset+1]=(value>>>8)&255;}
	function put32(bytes,offset,value){for(var i=0;i<4;i++){bytes[offset+i]=Math.floor(value/Math.pow(256,i))&255;}}
	function writeDatum(header,offset,item,refs){
	  if(!item){return;}
	  header[offset]=TYPES[item.type];header[offset+1]=(item.type==='clock'&&item.mode==='elapsed'?1:0)|(item.running?2:0)|(item.retain?4:0)|(item.estimated?8:0);
	  put32(header,offset+4,item.observedAt);put32(header,offset+8,item.validUntil);
	  put32(header,offset+12,item.baseSeconds||0);put32(header,offset+16,item.anchorAt||0);
	  put16(header,offset+20,refs.text.offset);put16(header,offset+22,refs.text.length);
	  put16(header,offset+24,refs.label.offset);put16(header,offset+26,refs.label.length);
	}
	function encode(cards,options){
	  options=options||{};var seq=options.sequence===undefined?options.revision:options.sequence;
	  if(!Array.isArray(cards)||cards.length>2||!wire.integer(options.session,2,MAX)||!wire.integer(seq,1,MAX)||!wire.integer(options.sentAt,1,MAX)){throw new Error('INVALID_SNAPSHOT');}
	  var out=[65,67,84,50,2,cards.length,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],seen=Object.create(null);
	  put32(out,12,options.session);put32(out,16,seq);put32(out,20,options.sentAt);
	  cards.forEach(function(raw){
	    var card=normalize(raw);if(!card||seen[card.provider+'|'+card.id]){throw new Error('INVALID_ACTIVITY');}seen[card.provider+'|'+card.id]=true;
	    var pool=poolFor(card),id=wire.utf8(card.id),header=[];
	    for(var i=0;i<88;i++){header.push(0);}
	    header[2]=wire.STATES[card.state];header[3]=(card.private?1:0)|(card.unconfirmed?2:0)|(card.showTerminal?4:0)|(card.image?8:0);
	    put32(header,4,card.revision);put32(header,8,card.observedAt);put32(header,12,card.validUntil);
	    header[16]=id.length;header[17]=card.image?card.image.width:0;header[18]=card.image?card.image.height:0;
	    header[19]=card.meter?METERS[card.meter.kind]:0;put16(header,20,card.image?card.image.pixels.length:0);put16(header,22,pool.bytes.length);
	    put16(header,24,pool.refs.caption.offset);put16(header,26,pool.refs.caption.length);
	    put16(header,28,card.meter?Math.round(card.meter.fraction*65535):0);header[30]=card.meter&&card.meter.source==='support'?1:0;
	    writeDatum(header,32,card.main,pool.refs.main);writeDatum(header,60,card.support,pool.refs.support);
	    var record=header.concat(wire.utf8(card.provider),id,pool.bytes);
	    if(card.image){record=record.concat(card.image.palette,card.image.pixels);}
	    put16(record,0,record.length);out=out.concat(record);
	  });
	  if(out.length>LIMITS.packet){throw new Error('SNAPSHOT_TOO_LARGE');}
	  put16(out,6,out.length);put16(out,8,wire.crc16(out));return out;
	}
	function readDatum(properties,prefix){
	  var type=string(properties,prefix+'_type');if(type===undefined){return null;}
	  var number=properties[prefix+'_value']&&properties[prefix+'_value'].numericValue;
	  var body=string(properties,prefix+'_text');
	  if(number&&(type!=='value'||body!==undefined&&body!=='')){return false;}
	  return {type:type,label:string(properties,prefix+'_label'),text:body,
	    value:number&&number.value,unit:number&&number.unit,observedAt:scalar(properties,prefix+'_observed_at','timestamp'),
	    validUntil:scalar(properties,prefix+'_valid_until','timestamp'),retain:scalar(properties,prefix+'_retain','boolean'),estimated:scalar(properties,prefix+'_estimated','boolean'),
	    mode:string(properties,prefix+'_clock'),running:scalar(properties,prefix+'_running','boolean'),
	    baseSeconds:scalar(properties,prefix+'_base','numericValue'),anchorAt:scalar(properties,prefix+'_anchor','timestamp')};
	}
	function sourceCard(instance,provider){
	  var p=instance&&instance.properties;if(!wire.object(p)||scalar(p,'schema_version','numericValue')!==2){return null;}
	  var main=readDatum(p,'main'),support=readDatum(p,'support');if(!main||support===false){return null;}
	  var meterKind=string(p,'meter_kind'),meter=meterKind&&meterKind!=='none'?{kind:meterKind,source:string(p,'meter_source'),min:scalar(p,'meter_min','numericValue'),max:scalar(p,'meter_max','numericValue')}:null;
	  return normalize({provider:provider,id:instance.instanceId,kind:string(p,'kind'),revision:scalar(p,'revision','numericValue'),state:string(p,'state'),
	    observedAt:scalar(p,'observed_at','timestamp'),validUntil:scalar(p,'valid_until','timestamp'),private:scalar(p,'private','boolean'),
	    unconfirmed:scalar(p,'unconfirmed','boolean'),showTerminal:scalar(p,'show_terminal','boolean'),caption:string(p,'caption')===undefined?string(p,'name'):string(p,'caption'),
	    main:main,support:support,meter:meter,image:p.artwork&&(p.artwork.image||p.artwork.icon)});
	}
	function base64(bytes){var alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',out='';for(var i=0;i<bytes.length;i+=3){var a=bytes[i],b=i+1<bytes.length?bytes[i+1]:0,c=i+2<bytes.length?bytes[i+2]:0;out+=alphabet[a>>2]+alphabet[((a&3)<<4)|(b>>4)]+(i+1<bytes.length?alphabet[((b&15)<<2)|(c>>6)]:'=')+(i+2<bytes.length?alphabet[c&63]:'=');}return out;}
	function toSourceInstance(input,request){
	  var card=normalize(input);if(!card){return null;}
	  var p={schema_version:{numericValue:{value:2}},revision:{numericValue:{value:card.revision}},kind:{shortText:{text:card.kind}},state:{shortText:{text:card.state}},
	    name:{longText:{text:card.caption}},caption:{longText:{text:card.caption}},observed_at:{timestamp:{value:card.observedAt}},valid_until:{timestamp:{value:card.validUntil}},
	    private:{boolean:{value:card.private}},unconfirmed:{boolean:{value:card.unconfirmed}},show_terminal:{boolean:{value:card.showTerminal}}};
	  ['main','support'].forEach(function(prefix){var d=card[prefix];if(!d){return;}
	    p[prefix+'_type']={shortText:{text:d.type}};p[prefix+'_label']={longText:{text:d.label}};
	    p[prefix+'_observed_at']={timestamp:{value:d.observedAt}};p[prefix+'_valid_until']={timestamp:{value:d.validUntil}};
	    p[prefix+'_retain']={boolean:{value:d.retain}};p[prefix+'_estimated']={boolean:{value:d.estimated}};
	    if(d.type==='clock'){p[prefix+'_clock']={shortText:{text:d.mode}};p[prefix+'_base']={numericValue:{value:d.baseSeconds,unit:'s'}};p[prefix+'_anchor']={timestamp:{value:d.anchorAt}};p[prefix+'_running']={boolean:{value:d.running}};}
	    else if(d.type==='value'&&finite(d.value)){p[prefix+'_value']={numericValue:{value:d.value,unit:d.unit}};}
	    else{p[prefix+'_text']={longText:{text:d.text}};}
	  });
	  if(card.meter){if(!finite(card.meter.min)||!finite(card.meter.max)){return null;}p.meter_kind={shortText:{text:card.meter.kind}};p.meter_source={shortText:{text:card.meter.source}};p.meter_min={numericValue:{value:card.meter.min}};p.meter_max={numericValue:{value:card.meter.max}};}
	  if(card.image&&request&&request.iconPixelSize){p.artwork={image:{width:card.image.width,height:card.image.height,palette:base64(card.image.palette),pixels:base64(card.image.pixels)}};}
	  return {instanceId:card.id,properties:p};
	}
	module.exports={VERSION:2,CATEGORY:'activity',ITEM:'card',TYPES:TYPES,METERS:METERS,LIMITS:LIMITS,PROPERTIES:PROPERTIES,SOURCE_PROPERTIES:SOURCE_PROPERTIES,
	  normalize:normalize,createCard:normalize,encode:encode,fromLegacy:fromLegacy,sourceCard:sourceCard,toSourceInstance:toSourceInstance,poolFor:poolFor,numericText:numericText};


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	// Schema 4 is semantic source content. Layout and source observation are never
	// supplied by fresh-read authors; imported owners use the separate snapshot path.
	var wire=__webpack_require__(10),MAX=wire.MAX_EPOCH;
	var ICONS=['activity','timer','stopwatch','media','message','call','navigation','workout','recording','download','delivery'];
	var DIRECTIONS=['turn-left','turn-right','straight','u-turn'];
	var STATES=['active','paused','completed','cancelled'];
	var PLAYBACK=['playing','paused','buffering','stopped','unknown'];
	var META_KEY='pebble.activities.summary.metadata.v1';
	var LIMITS={records:16,descriptor:1024,text:192,label:32,name:64,value:64,unit:16,actions:1536,entity:256,openApp:96};
	var SOURCE_PROPERTIES={schema_version:['numericValue'],publisher_incarnation:['longText'],publisher_mode:['shortText'],snapshot_sequence:['numericValue'],activity_count:['numericValue'],
	  revision:['numericValue'],observed_at:['timestamp'],valid_until:['timestamp'],private:['boolean'],unconfirmed:['boolean'],content:['longText'],
	  app_name:['longText'],icon:['image','icon'],artwork:['image','icon'],entity_ref:['longText'],actions:['longText'],open_app:['longText']};
	var SHARED=['id','type','name','icon','visibleUntil','entityRef','actions','openApp'];
	function own(v,k){return Object.prototype.hasOwnProperty.call(v,k);}
	function known(v,keys){return wire.object(v)&&Object.keys(v).every(function(k){return keys.indexOf(k)>=0;});}
	function finite(v){return typeof v==='number'&&isFinite(v);}
	function text(v,max){
	  if(typeof v!=='string'||/[\x00-\x1f\x7f-\x9f\u00ad\u061c\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/.test(v)){return null;}
	  var t=v.trim();
	  if(!t||wire.utf8(t).length>max||/[\ud800-\udfff]/.test(t.replace(/[\ud800-\udbff][\udc00-\udfff]/g,''))){return null;}
	  return t;
	}
	function bounded(v,max){try{return wire.utf8(JSON.stringify(v)).length<=max;}catch(ignored){return false;}}
	function jsonValue(v,depth){
	  if(v===null||typeof v==='string'||typeof v==='boolean'){return true;}
	  if(typeof v==='number'){return finite(v);}
	  if(depth<=0||typeof v!=='object'){return false;}
	  if(Array.isArray(v)){return v.every(function(x){return jsonValue(x,depth-1);});}
	  if(!wire.object(v)||Object.getPrototypeOf(v)!==Object.prototype&&Object.getPrototypeOf(v)!==null){return false;}
	  return Object.keys(v).every(function(k){return jsonValue(v[k],depth-1);});
	}
	function extension(input,name){
	  if(name==='openApp'){
	    return known(input,['watchAppUuid'])&&wire.uuid(input.watchAppUuid)&&!/^0{8}-0{4}-0{4}-0{4}-0{12}$/.test(input.watchAppUuid)?{watchAppUuid:input.watchAppUuid}:null;
	  }
	  if(name==='entityRef'){
	    if(!known(input,['category','item','instanceId'])){return null;}
	    var out={};
	    if(!['category','item','instanceId'].every(function(k){out[k]=text(input[k],64);return !!out[k];})){return null;}
	    return bounded(out,LIMITS.entity)?out:null;
	  }
	  if(!Array.isArray(input)||input.length>3){return null;}
	  var ids=Object.create(null),result=[];
	  for(var i=0;i<input.length;i++){
	    var a=input[i];if(!known(a,['id','label','action','args','semantic'])){return null;}
	    var action={id:text(a.id,32),label:text(a.label,32),action:text(a.action,64),args:a.args===undefined?{}:a.args};
	    if(!action.id||!action.label||!action.action||ids[action.id]||!wire.object(action.args)||!jsonValue(action.args,4)||!bounded(action.args,256)){return null;}
	    ids[action.id]=true;
	    if(a.semantic!==undefined){if(['play','pause','resume','stop','next','previous','cancel','acknowledge'].indexOf(a.semantic)<0){return null;}action.semantic=a.semantic;}
	    result.push(action);
	  }
	  return bounded(result,LIMITS.actions)?result:null;
	}
	function datum(input,observedAt){
	  if(!wire.object(input)){return null;}
	  var d={type:input.type},keys=['type','label'];
	  if(input.type==='text'){
	    keys.push('text');d.text=text(input.text,LIMITS.text);if(!d.text){return null;}
	  }else if(input.type==='value'){
	    keys=keys.concat(['value','unit','range','symbol']);
	    d.value=finite(input.value)?input.value:text(input.value,LIMITS.value);if(d.value===null){return null;}
	    if(input.unit!==undefined){d.unit=text(input.unit,LIMITS.unit);if(!d.unit){return null;}}
	    if(input.range!==undefined){
	      var r=input.range,min=r&&r.min===undefined?0:r&&r.min;
	      if(!known(r,['min','max'])||!finite(d.value)||!finite(min)||!finite(r.max)||r.max<=min||d.value<min||d.value>r.max){return null;}
	      d.range={min:min,max:r.max};
	    }
	    if(input.symbol!==undefined){if(DIRECTIONS.indexOf(input.symbol)<0){return null;}d.symbol=input.symbol;}
	  }else if(input.type==='clock'){
	    keys=keys.concat(['mode','deadline','since','seconds']);d.mode=input.mode;
	    if(d.mode==='countdown'){
	      if(input.since!==undefined||own(input,'deadline')===own(input,'seconds')){return null;}
	      if(own(input,'deadline')){if(!wire.integer(input.deadline,1,MAX)){return null;}d.deadline=input.deadline;}
	      else{if(!wire.integer(input.seconds,0,MAX)){return null;}d.seconds=input.seconds;}
	    }else if(d.mode==='elapsed'){
	      if(input.deadline!==undefined||input.since===undefined&&input.seconds===undefined){return null;}
	      if(input.since!==undefined){if(!wire.integer(input.since,1,observedAt||MAX)){return null;}d.since=input.since;}
	      if(input.seconds!==undefined){if(!wire.integer(input.seconds,0,MAX)){return null;}d.seconds=input.seconds;}
	    }else{return null;}
	  }else{return null;}
	  if(!known(input,keys)){return null;}
	  if(input.label!==undefined){d.label=text(input.label,LIMITS.label);if(!d.label){return null;}}
	  return d;
	}
	function descriptor(record){
	  var out={};Object.keys(record).forEach(function(k){
	    if(k==='artwork'||k==='entityRef'||k==='actions'||k==='openApp'||k==='icon'&&typeof record.icon!=='string'){return;}out[k]=record[k];
	  });return out;
	}
	function normalize(input,observedAt){
	  var keys=SHARED.concat(input&&input.type==='media'?['title','artist','artwork','itemId','playback']:['headline','detail','summary','state','result']);
	  if(!known(input,keys)||!text(input.id,64)||input.id[0]==='@'||input.id!==input.id.trim()){return null;}
	  var out={id:input.id,type:input.type};
	  if(input.name!==undefined){out.name=text(input.name,LIMITS.name);if(!out.name){return null;}}
	  if(input.icon!==undefined){
	    out.icon=typeof input.icon==='string'?(ICONS.indexOf(input.icon)>=0?input.icon:null):wire.image(input.icon);if(!out.icon){return null;}
	  }
	  if(input.visibleUntil!==undefined){if(!wire.integer(input.visibleUntil,1,MAX)){return null;}out.visibleUntil=input.visibleUntil;}
	  ['entityRef','actions','openApp'].forEach(function(k){if(input[k]!==undefined){out[k]=extension(input[k],k);}});
	  if(['entityRef','actions','openApp'].some(function(k){return own(out,k)&&out[k]===null;})){return null;}
	  if(input.type==='standard'){
	    out.headline=datum(input.headline,observedAt);if(!out.headline){return null;}
	    if(input.detail!==undefined){out.detail=datum(input.detail,observedAt);if(!out.detail){return null;}}
	    out.summary=input.summary===undefined?'headline':input.summary;
	    out.state=input.state===undefined?'active':input.state;out.result=input.result===undefined?false:input.result;
	    if(['headline','detail'].indexOf(out.summary)<0||out.summary==='detail'&&!out.detail||STATES.indexOf(out.state)<0||typeof out.result!=='boolean'||out.result&&out.state!=='completed'&&out.state!=='cancelled'){return null;}
	  }else if(input.type==='media'){
	    out.title=text(input.title,LIMITS.text);if(!out.title){return null;}
	    if(input.artist!==undefined){out.artist=text(input.artist,LIMITS.text);if(!out.artist){return null;}}
	    if(input.itemId!==undefined){out.itemId=text(input.itemId,64);if(!out.itemId){return null;}}
	    out.playback=input.playback===undefined?'unknown':input.playback;if(PLAYBACK.indexOf(out.playback)<0){return null;}
	    if(input.artwork!==undefined){out.artwork=wire.image(input.artwork);if(!out.artwork){return null;}}
	  }else{return null;}
	  return bounded(descriptor(out),LIMITS.descriptor)?out:null;
	}
	function sourceRecord(input,provider){
	  if(!wire.object(input)||!wire.uuid(provider||input.provider)||!wire.integer(input.revision,1,MAX)||
	    !wire.integer(input.observedAt,1,MAX)||!wire.integer(input.validUntil,input.observedAt,MAX)||
	    input.private!==undefined&&typeof input.private!=='boolean'||input.unconfirmed!==undefined&&typeof input.unconfirmed!=='boolean'){return null;}
	  var record=normalize(input.record,input.observedAt);if(!record){return null;}
	  var out={provider:provider||input.provider,record:record,id:record.id,type:record.type,revision:input.revision,observedAt:input.observedAt,
	    validUntil:Math.min(input.validUntil,record.visibleUntil===undefined?MAX:record.visibleUntil),private:record.type==='media'||input.private!==false,
	    unconfirmed:input.unconfirmed===true,displayName:text(input.displayName,64)||''};
	  if(out.validUntil<out.observedAt||out.private&&out.unconfirmed){return null;}
	  return out;
	}
	function scalar(p,k,shape,field){return p&&p[k]&&p[k][shape]?p[k][shape][field||'value']:undefined;}
	function parseJson(p,key,limit){var raw=scalar(p,key,'longText','text');if(typeof raw!=='string'||wire.utf8(raw).length>limit){return null;}try{return JSON.parse(raw);}catch(ignored){return null;}}
	function sourceCard(instance,provider){
	  var p=instance&&instance.properties;if(!wire.object(p)||scalar(p,'schema_version','numericValue')!==4){return null;}
	  if(!wire.integer(scalar(p,'revision','numericValue'),1,MAX)||!wire.integer(scalar(p,'observed_at','timestamp'),1,MAX)||
	      !wire.integer(scalar(p,'valid_until','timestamp'),1,MAX)||typeof scalar(p,'private','boolean')!=='boolean'||typeof scalar(p,'unconfirmed','boolean')!=='boolean'){return null;}
	  if(p.icon!==undefined&&(!wire.object(p.icon)||!p.icon.image&&!p.icon.icon)||p.artwork!==undefined&&(!wire.object(p.artwork)||!p.artwork.image&&!p.artwork.icon)){return null;}
	  var record=parseJson(p,'content',LIMITS.descriptor);if(!wire.object(record)||instance.instanceId!==record.id){return null;}
	  delete record.entityRef;delete record.actions;delete record.openApp;delete record.artwork;
	  if(record.icon&&typeof record.icon!=='string'){delete record.icon;}
	  if(p.icon!==undefined){record.icon=p.icon.image||p.icon.icon;}
	  if(p.artwork!==undefined){record.artwork=p.artwork.image||p.artwork.icon;}
	  // Malformed optional capabilities are discarded independently of content.
	  [['entity_ref','entityRef',LIMITS.entity],['actions','actions',LIMITS.actions],['open_app','openApp',LIMITS.openApp]].forEach(function(pair){
	    if(p[pair[0]]!==undefined){var value=extension(parseJson(p,pair[0],pair[2]),pair[1]);if(value!==null){record[pair[1]]=value;}}
	  });
	  return sourceRecord({record:record,revision:scalar(p,'revision','numericValue'),observedAt:scalar(p,'observed_at','timestamp'),
	    validUntil:scalar(p,'valid_until','timestamp'),private:scalar(p,'private','boolean'),unconfirmed:scalar(p,'unconfirmed','boolean'),
	    displayName:scalar(p,'app_name','longText','text')},provider);
	}
	function header(envelope){
	  if(!envelope||!Array.isArray(envelope.instances)||envelope.instances.length>17){return null;}
	  var found=envelope.instances.filter(function(i){return i&&i.instanceId==='@snapshot';});
	  if(found.length!==1){return null;}var p=found[0].properties;
	  var h={mode:scalar(p,'publisher_mode','shortText','text'),incarnation:scalar(p,'publisher_incarnation','longText','text'),sequence:scalar(p,'snapshot_sequence','numericValue'),count:scalar(p,'activity_count','numericValue')};
	  return scalar(p,'schema_version','numericValue')===4&&['fresh','snapshot'].indexOf(h.mode)>=0&&typeof h.incarnation==='string'&&text(h.incarnation,64)===h.incarnation&&wire.integer(h.sequence,1,MAX)&&wire.integer(h.count,0,16)&&h.count===envelope.instances.length-1?h:null;
	}
	function base64(bytes){var alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',out='';for(var i=0;i<bytes.length;i+=3){var a=bytes[i],b=i+1<bytes.length?bytes[i+1]:0,c=i+2<bytes.length?bytes[i+2]:0;out+=alphabet[a>>2]+alphabet[((a&3)<<4)|(b>>4)]+(i+1<bytes.length?alphabet[((b&15)<<2)|(c>>6)]:'=')+(i+2<bytes.length?alphabet[c&63]:'=');}return out;}
	function imageProperty(image){return {image:{width:image.width,height:image.height,palette:base64(image.palette),pixels:base64(image.pixels)}};}
	function toSourceInstance(input,request){
	  var value=sourceRecord(input);if(!value){return null;}var r=value.record;
	  var p={schema_version:{numericValue:{value:4}},revision:{numericValue:{value:value.revision}},observed_at:{timestamp:{value:value.observedAt}},valid_until:{timestamp:{value:value.validUntil}},
	    private:{boolean:{value:value.private}},unconfirmed:{boolean:{value:value.unconfirmed}},content:{longText:{text:JSON.stringify(descriptor(r))}}};
	  if(value.displayName){p.app_name={longText:{text:value.displayName}};}
	  if(request&&request.iconPixelSize){if(r.icon&&typeof r.icon!=='string'){p.icon=imageProperty(r.icon);}if(r.artwork){p.artwork=imageProperty(r.artwork);}}
	  [['entityRef','entity_ref'],['actions','actions'],['openApp','open_app']].forEach(function(pair){if(r[pair[0]]!==undefined){p[pair[1]]={longText:{text:JSON.stringify(r[pair[0]])}};}});
	  return {instanceId:r.id,properties:p};
	}
	function provider(options,snapshot){
	  options=options||{};
	  if(!wire.uuid(options.pluginUuid)||!options.storage||typeof options.storage.getItem!=='function'||typeof options.storage.setItem!=='function'||typeof options[snapshot?'readSnapshot':'readCurrent']!=='function'){throw new Error('INVALID_PROVIDER');}
	  var refresh=options.refreshSeconds===undefined?30:options.refreshSeconds,validity=options.validitySeconds===undefined?90:options.validitySeconds;
	  if(!wire.integer(refresh,1,MAX)||!wire.integer(validity,refresh+1,MAX)){throw new Error('INVALID_VALIDITY');}
	  var now=options.now||Date.now,key=options.metadataKey||META_KEY;
	  function reserve(){
	    var meta;
	    try{meta=JSON.parse(options.storage.getItem(key));}catch(ignored){}
	    if(!known(meta,['version','incarnation','sequence'])||meta.version!==1||typeof meta.incarnation!=='string'||text(meta.incarnation,64)!==meta.incarnation||!wire.integer(meta.sequence,0,MAX)){
	      meta={version:1,incarnation:String(now())+'-'+String(Math.random()).slice(2),sequence:0};
	    }
	    if(meta.sequence===MAX){throw new Error('SEQUENCE_EXHAUSTED');}meta.sequence++;
	    var encoded=JSON.stringify(meta);options.storage.setItem(key,encoded);if(options.storage.getItem(key)!==encoded){throw new Error('STORAGE_UNAVAILABLE');}
	    return meta;
	  }
	  function source(request){
	    return Promise.resolve().then(function(){
	    var meta=reserve();
	    return Promise.resolve(options[snapshot?'readSnapshot':'readCurrent'](request||{})).then(function(raw){
	      var records=Array.isArray(raw)?raw:raw&&raw.records,time=now(),observed=Math.max(1,Math.floor(time/1000)),seen=Object.create(null),instances=[];
	      if(!Array.isArray(records)||records.length>16){throw new Error('INVALID_SNAPSHOT');}
	      records.forEach(function(input){
	        var entry;
	        if(snapshot){entry=typeof options.adapt==='function'?options.adapt(input):input;}
	        else{entry={record:input,revision:meta.sequence,observedAt:observed,validUntil:Math.min(MAX,observed+validity),private:true,unconfirmed:false};}
	        if(!entry){throw new Error('INVALID_SNAPSHOT');}
	        var copy={};Object.keys(entry).forEach(function(k){copy[k]=entry[k];});copy.displayName=options.displayName||copy.displayName;
	        if(copy.record&&copy.record.icon===undefined&&options.icon!==undefined){copy.record=helper({icon:options.icon},copy.record);}
	        var validated=normalize(copy.record,copy.observedAt);
	        if(!validated||seen[validated.id]){throw new Error('INVALID_SNAPSHOT');}seen[validated.id]=true;
	        copy.record=validated;
	        if(validated.visibleUntil!==undefined&&validated.visibleUntil<=observed){return;}
	        var result=sourceRecord(copy,options.pluginUuid);if(!result){throw new Error('INVALID_SNAPSHOT');}
	        if(result.record.type==='standard'&&(result.record.state==='completed'||result.record.state==='cancelled')&&!result.record.result){return;}
	        if(result.validUntil>observed){var instance=toSourceInstance(result,request);if(!instance){throw new Error('INVALID_SNAPSHOT');}instances.push(instance);}
	      });
	      var count=instances.length;
	      instances.unshift({instanceId:'@snapshot',properties:{schema_version:{numericValue:{value:4}},publisher_incarnation:{longText:{text:meta.incarnation}},publisher_mode:{shortText:{text:snapshot?'snapshot':'fresh'}},snapshot_sequence:{numericValue:{value:meta.sequence}},activity_count:{numericValue:{value:count}}}});
	      var expiry=Math.min(MAX*1000,time+(snapshot?refresh:validity)*1000);
	      if(raw&&!Array.isArray(raw)&&raw.validUntilMs!==undefined){if(!wire.integer(raw.validUntilMs,1,MAX*1000)){throw new Error('INVALID_SNAPSHOT');}expiry=Math.min(expiry,raw.validUntilMs);}
	      return {validUntilMs:expiry,instances:instances};
	    });
	    });
	  }
	  function handleSource(request,respond){
	    if(!request||request.category!=='activity'||request.item!=='summary'){if(respond&&respond.error){respond.error('INVALID_REQUEST','Unsupported source');}return Promise.resolve();}
	    return Promise.resolve().then(function(){return source(request);}).then(function(result){respond.data(result);},function(error){respond.error(error&&/^(STORAGE_UNAVAILABLE|SEQUENCE_EXHAUSTED)$/.test(error.message)?error.message:'INVALID_DATA','Activity source unavailable');});
	  }
	  return {source:source,handleSource:handleSource,sourceDeclaration:{category:'activity',items:['summary'],properties:SOURCE_PROPERTIES,supportsMultiple:true,suggestedRefreshIntervalSec:refresh}};
	}
	function helper(base,options){var result={};Object.keys(options||{}).forEach(function(k){result[k]=options[k];});Object.keys(base).forEach(function(k){result[k]=base[k];});return result;}
	function timerSnapshot(raw){
	  var original=wire.normalize(raw);if(!original||original.kind!=='timer'){return null;}
	  var headline;
	  if(original.state==='active'&&original.clock==='deadline'){headline={type:'clock',mode:'countdown',deadline:original.deadline};}
	  else if(original.state==='paused'&&original.clock==='deadline'){headline={type:'clock',mode:'countdown',seconds:original.duration};}
	  else{headline={type:'text',text:original.state==='completed'?'Finished':'Cancelled'};}
	  var record={id:original.id,type:'standard',icon:'timer',headline:headline,state:original.state,result:raw.showTerminal===true,
	    openApp:{watchAppUuid:'50e9ef12-a5ab-4369-a3b5-3447bfba5151'}};
	  var name=text(original.footer,64);if(name){record.name=name;}
	  var validUntil=original.validUntil;
	  if(original.state==='paused'){validUntil=Math.min(validUntil,original.observedAt+300);}
	  if(original.state==='active'&&original.deadline){validUntil=Math.min(validUntil,original.deadline+60);}
	  return {record:record,revision:original.revision,observedAt:original.observedAt,validUntil:validUntil,private:original.private,unconfirmed:true};
	}
	function toView(input,provider){return __webpack_require__(13).fromSummary(input,provider);}
	module.exports={VERSION:4,CATEGORY:'activity',ITEM:'summary',LIMITS:LIMITS,ICONS:ICONS,DIRECTIONS:DIRECTIONS,METADATA_KEY:META_KEY,
	  SOURCE_PROPERTIES:SOURCE_PROPERTIES,PROPERTIES:Object.keys(SOURCE_PROPERTIES),normalize:normalize,datum:datum,sourceRecord:sourceRecord,sourceCard:sourceCard,header:header,
	  descriptor:descriptor,toSourceInstance:toSourceInstance,toView:toView,extension:extension,
	  standard:function(id,options){return helper({id:id,type:'standard'},options);},media:function(id,options){return helper({id:id,type:'media'},options);},
	  text:function(value,options){return helper({type:'text',text:value},options);},
	  value:function(value,unit,options){var out={type:'value',value:value};if(unit!==undefined&&unit!==''){out.unit=unit;}return helper(out,options);},
	  countdown:function(options){return helper({type:'clock',mode:'countdown'},options);},elapsed:function(options){return helper({type:'clock',mode:'elapsed'},options);},
	  defineProvider:function(options){return provider(options,false);},defineSnapshotProvider:function(options){return provider(options,true);},adapters:{timerSnapshot:timerSnapshot}};


/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	// ACT3 is the bounded two-role projection. It preserves ACT2's datum layout
	// while adding explicit media, summary and semantic-symbol metadata.
	var wire=__webpack_require__(10),view=__webpack_require__(11),summary=__webpack_require__(12),MAX=wire.MAX_EPOCH;
	var PRESENTATIONS={text:1,media:2,clock:3,value:4,ranged:5};
	var LIMITS={cards:2,packet:2672,pool:304,header:104};
	function own(v,k){return Object.prototype.hasOwnProperty.call(v,k);}
	function clone(v){return JSON.parse(JSON.stringify(v));}
	function put16(b,o,v){b[o]=v&255;b[o+1]=(v>>>8)&255;}
	function put32(b,o,v){for(var i=0;i<4;i++){b[o+i]=Math.floor(v/Math.pow(256,i))&255;}}
	function numericText(value,unit){return String(value)+(unit?(/^(%|°|°C|°F)$/.test(unit)?'':' ')+unit:'');}
	function token(value){
	  var bytes=wire.utf8(value||''),a=2166136261,b=2246822519;
	  bytes.forEach(function(x){a=(a^x)>>>0;a=(a*16777619)>>>0;b=(b^x)>>>0;b=(b*65599)>>>0;});
	  var out=[];put32(out,0,a);put32(out,4,b);return out;
	}
	function poolFor(card){
	  var bytes=[],known=Object.create(null);
	  function add(value){value=value||'';if(own(known,value)){return known[value];}var data=wire.utf8(value),ref={offset:bytes.length,length:data.length};known[value]=ref;bytes=bytes.concat(data,[0]);return ref;}
	  var refs={caption:add(card.caption),main:{label:add(card.main.label),text:add(card.main.text)},qualifier:add(card.qualifier)};
	  if(card.support){refs.support={label:add(card.support.label),text:add(card.support.text)};}
	  return {bytes:bytes,refs:refs};
	}
	function normalize(input){
	  var card=view.normalize(input,undefined,true);if(!card){return null;}
	  card.main.label=wire.text(card.main.label,32);if(card.support){card.support.label=wire.text(card.support.label,32);}
	  card.presentation=input.presentation===undefined?(card.main.type==='clock'?PRESENTATIONS.clock:card.main.type==='value'?(card.meter?PRESENTATIONS.ranged:PRESENTATIONS.value):PRESENTATIONS.text):input.presentation;
	  card.identitySymbol=input.identitySymbol===undefined?0:input.identitySymbol;
	  card.compactItem=input.compactItem===undefined?0:input.compactItem;
	  card.directions=input.directions===undefined?[0,0]:input.directions;
	  card.qualifier=typeof input.qualifier==='string'?wire.text(input.qualifier,304):'';
	  card.visualToken=input.visualToken===undefined?[0,0,0,0,0,0,0,0]:input.visualToken;
	  if(!wire.integer(card.presentation,1,5)||!wire.integer(card.identitySymbol,0,10)||!wire.integer(card.compactItem,0,1)||card.compactItem&&!card.support||
	    !Array.isArray(card.directions)||card.directions.length!==2||!card.directions.every(function(x){return wire.integer(x,0,4);})||
	    !Array.isArray(card.visualToken)||card.visualToken.length!==8||!card.visualToken.every(function(x){return wire.integer(x,0,255);})){return null;}
	  if(card.presentation===PRESENTATIONS.media&&(card.main.type!=='text'||card.support&&card.support.type!=='text'||card.compactItem||card.meter)){return null;}
	  if(card.presentation===PRESENTATIONS.text&&card.main.type!=='text'||card.presentation===PRESENTATIONS.clock&&card.main.type!=='clock'||card.presentation===PRESENTATIONS.value&&card.main.type!=='value'||card.presentation===PRESENTATIONS.ranged&&(!card.meter||card.main.type!=='value'||card.meter.source!=='main')){return null;}
	  if(card.directions[0]&&card.main.type!=='value'||card.directions[1]&&(!card.support||card.support.type!=='value')||card.presentation!==PRESENTATIONS.media&&card.visualToken.some(function(x){return x!==0;})){return null;}
	  ['providerName','selectionKey','name','openApp','playback','sourceFormat','entityRef','actions','mediaItemId'].forEach(function(k){if(input[k]!==undefined){card[k]=clone(input[k]);}});
	  // Keep shrinking monotonic even when strings share a pool reference.
	  // Splitting a deduplicated string can increase storage, so optional aliases
	  // are omitted rather than leaving ellipsis-only context behind.
	  var fields=[['qualifier'],['caption'],['main','label'],['support','label']];
	  if(card.support&&card.support.type==='text'){fields.push(['support','text']);}
	  if(card.main.type==='text'){fields.push(['main','text']);}
	  for(var f=0;poolFor(card).bytes.length>304&&f<fields.length;f++){
	    var field=fields[f],owner=field.length===1?card:card[field[0]],key=field[field.length-1];if(!owner||!owner[key]){continue;}
	    var requiredText=key==='text'&&(field[0]==='main'||card.compactItem===1||card.presentation===PRESENTATIONS.media);
	    var before=poolFor(card).bytes.length,original=owner[key],size=wire.utf8(original).length;
	    var limit=Math.max(requiredText?8:0,size-(before-304));
	    owner[key]=limit<4?'':wire.text(original,limit);
	    if(poolFor(card).bytes.length>=before){owner[key]=requiredText?wire.text(original,8):'';}
	    if(field[0]==='support'&&key==='text'&&!owner.text){card.support=null;card.directions[1]=0;if(card.meter&&card.meter.source==='support'){card.meter=null;}}
	  }
	  if(poolFor(card).bytes.length>304||!card.main.text&&card.main.type!=='clock'||card.compactItem===1&&(!card.support||!card.support.text&&card.support.type!=='clock')){return null;}
	  return card;
	}
	function compiledDatum(d,source){
	  var out={type:d.type,label:d.label||'',observedAt:source.observedAt,validUntil:source.validUntil,retain:!source.private,estimated:false};
	  if(d.type==='text'){out.text=d.text;}
	  else if(d.type==='value'){out.text=numericText(d.value,d.unit||'');if(typeof d.value==='number'){out.value=d.value;out.unit=d.unit||'';}}
	  else{out.mode=d.mode==='countdown'?'deadline':'elapsed';out.running=d.deadline!==undefined||d.since!==undefined;out.anchorAt=out.running?(d.since===undefined?source.observedAt:d.since):0;out.baseSeconds=d.deadline===undefined?d.seconds||0:Math.max(0,d.deadline-source.observedAt);}
	  return out;
	}
	function textPart(d){return d&&d.type==='text'?(d.label?d.label+': ':'')+d.text:'';}
	function unique(parts){var seen=Object.create(null);return parts.filter(function(x){if(!x||seen[x]){return false;}seen[x]=true;return true;}).join(' · ');}
	function fromSummary(input,provider){
	  var source=summary.sourceRecord(input,provider);if(!source){return null;}
	  var r=source.record,media=r.type==='media',selected=r.summary==='detail'?1:0;
	  var card={provider:source.provider,id:r.id,kind:media?'music':typeof r.icon==='string'?r.icon:'activity',revision:source.revision,state:media?(r.playback==='paused'?'paused':'active'):r.state,
	    observedAt:source.observedAt,validUntil:source.validUntil,private:source.private,unconfirmed:source.unconfirmed,showTerminal:!media&&r.result,
	    caption:media?r.artist||'':r.name||source.displayName||'',main:media?compiledDatum({type:'text',text:r.title},source):compiledDatum(r.headline,source),
	    support:media?(r.artist?compiledDatum({type:'text',text:r.artist},source):null):(r.detail?compiledDatum(r.detail,source):null),
	    image:media?r.artwork||typeof r.icon==='object'&&r.icon:typeof r.icon==='object'?r.icon:undefined,
	    compactItem:media?0:selected,identitySymbol:summary.ICONS.indexOf(typeof r.icon==='string'?r.icon:media?'media':'activity'),
	    directions:media?[0,0]:[summary.DIRECTIONS.indexOf(r.headline.symbol)+1,summary.DIRECTIONS.indexOf(r.detail&&r.detail.symbol)+1],
	    presentation:media?PRESENTATIONS.media:r.headline.type==='clock'?PRESENTATIONS.clock:r.headline.type==='value'?(r.headline.range?PRESENTATIONS.ranged:PRESENTATIONS.value):PRESENTATIONS.text,
	    visualToken:media?token(r.itemId===undefined?r.title:r.itemId):[0,0,0,0,0,0,0,0],
	    qualifier:media?unique([r.name,r.artist].filter(function(part){return part!==r.title;})):unique([textPart(selected?r.headline:r.detail),r.name].filter(function(part){var d=selected?r.detail:r.headline;return part!==d.label&&part!==textPart(d);})),sourceFormat:4,playback:r.playback,mediaItemId:r.itemId};
	  if(!card.image){delete card.image;}
	  if(r.headline&&r.headline.range){card.meter={kind:'progress',source:'main',min:r.headline.range.min,max:r.headline.range.max};}
	  if(r.openApp){card.openApp=r.openApp;}if(r.actions){card.actions=r.actions;}if(r.entityRef){card.entityRef=r.entityRef;}
	  if(source.displayName){card.providerName=source.displayName;}if(r.name){card.name=r.name;}
	  return normalize(card);
	}
	function fromLegacy(input){
	  var card=input&&input.main?clone(input):view.fromLegacy(input);if(!card){return null;}
	  var media=card.kind==='music';
	  card.presentation=media?PRESENTATIONS.media:card.main.type==='clock'?PRESENTATIONS.clock:card.main.type==='value'?(card.meter&&card.meter.source==='main'?PRESENTATIONS.ranged:PRESENTATIONS.value):PRESENTATIONS.text;
	  var kind=card.kind==='music'?'media':card.kind==='notification'||card.kind==='notifications'?'message':card.kind;
	  card.identitySymbol=Math.max(0,summary.ICONS.indexOf(kind));card.compactItem=0;card.directions=[0,0];card.qualifier='';
	  if(media){
	    if(card.caption&&card.caption.indexOf('__dynamic_media__')===0){card.caption=card.caption.slice('__dynamic_media__'.length);}
	    card.visualToken=token(card.main.text);card.qualifier=card.support?card.support.text:'';card.caption=card.support?card.support.text:'';
	  }
	  [card.main,card.support].forEach(function(d){if(d&&['Track','Artist','Text','Value','Left','Activity','Music',card.caption,card.providerName].indexOf(d.label)>=0){d.label='';}});
	  if(!media){card.qualifier=unique([card.support&&card.support.type==='text'?card.support.text:'',card.caption]);}
	  return normalize(card);
	}
	function writeDatum(header,offset,item,refs){
	  if(!item){return;}header[offset]=view.TYPES[item.type];header[offset+1]=(item.type==='clock'&&item.mode==='elapsed'?1:0)|(item.running?2:0)|(item.retain?4:0)|(item.estimated?8:0);
	  put32(header,offset+4,item.observedAt);put32(header,offset+8,item.validUntil);put32(header,offset+12,item.baseSeconds||0);put32(header,offset+16,item.anchorAt||0);
	  put16(header,offset+20,refs.text.offset);put16(header,offset+22,refs.text.length);put16(header,offset+24,refs.label.offset);put16(header,offset+26,refs.label.length);
	}
	function encode(cards,options){
	  options=options||{};var seq=options.sequence===undefined?options.revision:options.sequence;
	  if(!Array.isArray(cards)||cards.length>2||!wire.integer(options.session,2,MAX)||!wire.integer(seq,1,MAX)||!wire.integer(options.sentAt,1,MAX)){throw new Error('INVALID_SNAPSHOT');}
	  var out=[65,67,84,51,3,cards.length,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],seen=Object.create(null);
	  put32(out,12,options.session);put32(out,16,seq);put32(out,20,options.sentAt);
	  cards.forEach(function(raw){
	    var card=normalize(raw);if(!card||seen[card.provider+'|'+card.id]){throw new Error('INVALID_ACTIVITY');}seen[card.provider+'|'+card.id]=true;
	    var pool=poolFor(card),id=wire.utf8(card.id),h=[];for(var i=0;i<104;i++){h.push(0);}
	    h[2]=wire.STATES[card.state];h[3]=(card.private?1:0)|(card.unconfirmed?2:0)|(card.showTerminal?4:0)|(card.image?8:0);
	    put32(h,4,card.revision);put32(h,8,card.observedAt);put32(h,12,card.validUntil);h[16]=id.length;h[17]=card.image?card.image.width:0;h[18]=card.image?card.image.height:0;h[19]=card.meter?view.METERS[card.meter.kind]:0;
	    put16(h,20,card.image?card.image.pixels.length:0);put16(h,22,pool.bytes.length);put16(h,24,pool.refs.caption.offset);put16(h,26,pool.refs.caption.length);
	    put16(h,28,card.meter?Math.round(card.meter.fraction*65535):0);h[30]=card.meter&&card.meter.source==='support'?1:0;
	    writeDatum(h,32,card.main,pool.refs.main);writeDatum(h,60,card.support,pool.refs.support);
	    h[88]=card.presentation;h[89]=card.identitySymbol;h[90]=card.compactItem;h[91]=card.directions[0]|card.directions[1]<<3;
	    put16(h,92,pool.refs.qualifier.offset);put16(h,94,pool.refs.qualifier.length);for(i=0;i<8;i++){h[96+i]=card.visualToken[i];}
	    var record=h.concat(wire.utf8(card.provider),id,pool.bytes);if(card.image){record=record.concat(card.image.palette,card.image.pixels);}put16(record,0,record.length);out=out.concat(record);
	  });
	  if(out.length>2672){throw new Error('SNAPSHOT_TOO_LARGE');}put16(out,6,out.length);put16(out,8,wire.crc16(out));return out;
	}
	function formatDatum(d,now){
	  if(d.type==='text'){return textPart(d);}
	  if(d.type==='value'){return numericText(d.value,d.unit||'');}
	  return wire.formatClock(d.mode==='countdown'?(d.deadline===undefined?d.seconds:Math.max(0,d.deadline-now)):Math.min(MAX,(d.seconds||0)+(d.since===undefined?0:Math.max(0,now-d.since))));
	}
	function compactText(record,now){
	  var r=summary.normalize(record,now);if(!r){return null;}
	  if(r.type==='media'){return unique([r.title,r.name,r.artist]);}
	  var selected=r.summary==='detail'?r.detail:r.headline,other=r.summary==='detail'?r.headline:r.detail;
	  return unique([formatDatum(selected,now),selected.type==='text'?'':selected.label,textPart(other),r.name]);
	}
	module.exports={VERSION:3,PRESENTATIONS:PRESENTATIONS,LIMITS:LIMITS,normalize:normalize,encode:encode,fromSummary:fromSummary,fromLegacy:fromLegacy,poolFor:poolFor,compactText:compactText,visualToken:token,numericText:numericText};


/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var wire=__webpack_require__(10);
	var MUSIC='builtin:music';
	var NOTIFICATIONS='builtin:notifications';
	function key(value){return value===MUSIC||value===NOTIFICATIONS||wire.uuid(value)?value:null;}
	function list(value){return (Array.isArray(value)?value:[]).map(key).filter(function(v,i,a){return v&&a.indexOf(v)===i;}).slice(0,64);}
	function normalizePreferences(value){value=value&&typeof value==='object'?value:{};return {order:list(value.order),hidden:list(value.hidden)};}
	function providerKey(card){return card&&[MUSIC,NOTIFICATIONS].indexOf(card.selectionKey)>=0?card.selectionKey:card&&key(card.provider);}
	function terminal(card){return card.state==='completed'||card.state==='cancelled';}
	function countdown(card){var d=card.main;return d&&d.type==='clock'&&d.mode==='deadline'?d:null;}
	/** Pure host policy. Persist provider keys only; cards and run IDs stay transient. */
	function select(cards,options){
	  options=options||{};var prefs=normalizePreferences(options),limit=wire.integer(options.limit,0,2)?options.limit:2;
	  var entries=(Array.isArray(cards)?cards:[]).map(function(card,index){return {card:card,index:index,key:providerKey(card)};})
	    .filter(function(entry){return entry.key&&prefs.hidden.indexOf(entry.key)<0;}),positions=Object.create(null);
	  entries.forEach(function(entry,index){if(countdown(entry.card)&&!terminal(entry.card)){(positions[entry.key]||(positions[entry.key]=[])).push(index);}});
	  Object.keys(positions).forEach(function(provider){
	    var slots=positions[provider],runs=slots.map(function(index){return {card:entries[index].card,index:index};}).sort(function(a,b){
	      var ac=countdown(a.card),bc=countdown(b.card);if(ac.running!==bc.running){return ac.running?-1:1;}
	      return ac.baseSeconds+(ac.running?ac.anchorAt:0)-bc.baseSeconds-(bc.running?bc.anchorAt:0)||a.index-b.index;
	    });
	    slots.forEach(function(index,run){entries[index].card=runs[run].card;});
	  });
	  return entries
	    .sort(function(a,b){
	      var at=terminal(a.card),bt=terminal(b.card);if(at!==bt){return at?1:-1;}
	      var ar=prefs.order.indexOf(a.key),br=prefs.order.indexOf(b.key);ar=ar<0?prefs.order.length:ar;br=br<0?prefs.order.length:br;
	      if(ar!==br){return ar-br;}
	      return a.index-b.index;
	    }).slice(0,limit).map(function(entry){return entry.card;});
	}
	module.exports={select:select,normalizePreferences:normalizePreferences,providerKey:providerKey,MUSIC_KEY:MUSIC,NOTIFICATIONS_KEY:NOTIFICATIONS};


/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var wire=__webpack_require__(10);
	var view=__webpack_require__(11);
	var activity=__webpack_require__(9);
	var summary=__webpack_require__(12),summaryView=__webpack_require__(13);
	var PROPERTIES=['schema_version','kind','state','clock','revision','name','main','footer','observed_at','valid_until','deadline','duration','clock_at','private','unconfirmed','value','artwork'];
	function scalar(p,name,shape,field) {return p && p[name] && p[name][shape] ? p[name][shape][field||'value'] : undefined;}
	function string(p,name) {var v=scalar(p,name,'longText','text');return v===undefined?scalar(p,name,'shortText','text'):v;}
	function sourceCard(instance,provider) {
	  if(!instance || !wire.object(instance.properties)) {return null;}
	  var p=instance.properties;
	  if(scalar(p,'schema_version','numericValue')!==1) {return null;}
	  var number=p.value && p.value.numericValue;
	  return wire.normalize({id:instance.instanceId,kind:string(p,'kind'),state:string(p,'state'),clock:string(p,'clock'),
	    revision:scalar(p,'revision','numericValue'),observedAt:scalar(p,'observed_at','timestamp'),validUntil:scalar(p,'valid_until','timestamp'),
	    deadline:scalar(p,'deadline','timestamp'),duration:scalar(p,'duration','numericValue'),clockAt:scalar(p,'clock_at','timestamp'),
	    main:string(p,'main')===undefined?string(p,'value'):string(p,'main'),footer:string(p,'footer')===undefined?string(p,'name'):string(p,'footer'),
	    private:scalar(p,'private','boolean')!==false,unconfirmed:scalar(p,'unconfirmed','boolean')===true,value:number && number.value,unit:number && number.unit,
	    image:p.artwork && (p.artwork.image || p.artwork.icon)},provider);
	}
	function sourceItem(plugin,format) {
	  if(!plugin||!wire.uuid(plugin.uuid)||!Array.isArray(plugin.sources)){return null;}
	  var items=[];
	  plugin.sources.forEach(function(source){if(wire.object(source)&&source.category===wire.CATEGORY&&Array.isArray(source.items)&&source.properties&&
	    Array.isArray(source.properties.schema_version)&&source.properties.schema_version.indexOf('numericValue')>=0){items=items.concat(source.items);}});
	  return format>=3&&items.indexOf(summary.ITEM)>=0?summary.ITEM:
	    format>=2&&items.indexOf(activity.ITEM)>=0?activity.ITEM:
	    format>=2&&items.indexOf(view.ITEM)>=0?view.ITEM:items.indexOf(wire.ITEM)>=0?wire.ITEM:null;
	}
	function compatible(plugin,format) {
	  return !!sourceItem(plugin,format);
	}
	function errorCode(error) {return error && typeof error.code==='string' && /^[A-Z0-9_]{1,48}$/.test(error.code)?error.code:'UNKNOWN';}
	function clone(value) {return JSON.parse(JSON.stringify(value));}
	function sourceFingerprint(source) {
	  // Omit mutable capabilities without first copying the complete bitmap and
	  // parsing it back. The source has already passed its format's validation.
	  var copy={};
	  Object.keys(source).forEach(function(name){if(name!=='unconfirmed'&&name!=='displayName'){copy[name]=source[name];}});
	  if(source.record){
	    copy.record={};Object.keys(source.record).forEach(function(name){
	      if(name!=='actions'&&name!=='entityRef'&&name!=='openApp'){copy.record[name]=source.record[name];}
	    });
	  }
	  return JSON.stringify(copy);
	}
	module.exports=function createActivities(options) {
	  options=options||{};
	  var nativeFormat=options.nativeFormat===3?3:options.nativeFormat===2?2:1,codec=nativeFormat===3?summaryView:nativeFormat===2?view:wire;
	  var pebble=options.pebble||{}, now=options.now||Date.now, later=options.later||setTimeout, cancel=options.cancelLater||clearTimeout;
	  var keys=options.keys||{}, send=options.send, groups=Object.create(null), session=0, sequence=0, generation=0;
	  var stopped=false,connected=true,enabled=true,available=typeof pebble.enumeratePlugins==='function' && typeof pebble.subscribeToSource==='function';
	  var expiryTimer=null,expiryAt=Infinity,discoveryTimer=null,retryTimer=null,bootTimer=null,deliveryEpoch=0,lastError='',bootRequested=false,bootAttempts=0,failureCount=0,seenOrder=0,enumerated=false;
	  var revisions=Object.create(null), orders=Object.create(null), lastSignature='',currentSettings={},installed=[],providerMetadata=Object.create(null),lastView=null;
	  function seconds(){return Math.max(1,Math.floor(now()/1000));}
	  function key(name){return keys[name]===undefined?name:keys[name];}
	  function readSettings(){var s=typeof options.getSettings==='function'?options.getSettings():{};return s&&typeof s==='object'?s:{};}
	  function isEnabled(s){return s.enabled!==false && s.showActivities!==false;}
	  function allowed(provider){return (!Array.isArray(currentSettings.providers)||currentSettings.providers.indexOf(provider)>=0) &&
	    (!Array.isArray(currentSettings.disabledProviders)||currentSettings.disabledProviders.indexOf(provider)<0);}
	  function stopGroup(group){group.generation++;var handle=group.handle;group.handle=null;if(handle && typeof handle.unsubscribe==='function'){try{handle.unsubscribe();}catch(ignored){}}}
	  function accepted(card){try{return typeof options.acceptActivity!=='function'||options.acceptActivity(clone(card))!==false;}catch(ignored){return false;}}
	  function visible(card,t){return card.validUntil>t&&
	    (nativeFormat<2||card.main.validUntil>t&&(!card.unconfirmed||!card.private&&card.main.retain))&&
	    ((card.state!=='completed'&&card.state!=='cancelled')||nativeFormat>=2&&card.showTerminal);}
	  function cleanGroup(provider){var group=groups[provider];if(!group){return;}stopGroup(group);group.cards=[];delete groups[provider];}
	  function catalogue(defensive){
	    var t=seconds(), result=[];
	    Object.keys(groups).forEach(function(provider){
	      var metadata=providerMetadata[provider];
	      groups[provider].cards.forEach(function(card){if(visible(card,t)&&accepted(card)){
	        // Internal default selection can borrow immutable cards: normalize()
	        // below owns the resulting copy. User callbacks/public reads get deep
	        // copies, including nested artwork and capabilities.
	        var copy=defensive?clone(card):card;
	        if(metadata&&metadata.name){
	          if(!defensive){copy={};Object.keys(card).forEach(function(k){copy[k]=card[k];});}
	          copy.providerName=metadata.name;
	        }
	        result.push(copy);
	      }});
	    });
	    result.sort(function(a,b){return orders[a.provider+'|'+a.id]-orders[b.provider+'|'+b.id];});
	    return result;
	  }
	  function catalogueCount(){
	    var t=seconds(),count=0;
	    Object.keys(groups).forEach(function(provider){groups[provider].cards.forEach(function(card){if(visible(card,t)&&accepted(card)){count++;}});});
	    return count;
	  }
	  function projection(){
	    var custom=typeof options.select==='function',all=catalogue(custom),result=custom?options.select(all):all.slice(0,2);
	    if(!Array.isArray(result)){result=[];}
	    return result.slice(0,2).map(function(card){return codec.normalize(card);}).filter(Boolean);
	  }
	  function notify(){if(typeof options.onChanged==='function'){options.onChanged();}}
	  function deliveryCurrent(epoch,token){return epoch===deliveryEpoch&&token===session&&!stopped&&connected&&enabled;}
	  function invalidateDelivery(){
	    deliveryEpoch++;lastView=null;bootRequested=false;bootAttempts=0;
	    [retryTimer,bootTimer].forEach(function(timer){if(timer!==null){cancel(timer);}});retryTimer=bootTimer=null;
	  }
	  function requestBootstrap(){
	    if(bootRequested || typeof send!=='function' || !connected || !enabled || stopped){return;}
	    if(bootAttempts>=3){return;}bootRequested=true;bootAttempts++;var attempt=bootAttempts,epoch=deliveryEpoch,payload={};payload[key('REQUEST_ACTIVITIES')]=1;
	    function live(){return deliveryCurrent(epoch,0)&&attempt===bootAttempts;}
	    function retry(){if(!live()){return;}if(bootTimer!==null){cancel(bootTimer);}bootTimer=later(function(){bootTimer=null;if(live()){bootRequested=false;requestBootstrap();}},2000);}
	    function failed(){if(!live()){return;}bootRequested=false;retry();}
	    try{send(payload,retry,failed);}catch(ignored){failed();}
	  }
	  function publish(force,afterAccepted){
	    if(stopped || !connected || !enabled){return;}
	    scheduleExpiry();notify();
	    if(!session){requestBootstrap();return;}
	    var cards=projection(),signature=JSON.stringify(cards);
	    if(!force && signature===lastSignature){return;}
	    if(signature!==lastSignature){failureCount=0;}lastSignature=signature;
	    sequence=sequence===wire.MAX_EPOCH?1:sequence+1;
	    if(typeof send!=='function'){return;}
	    var revision=sequence,epoch=deliveryEpoch,token=session,payload={},barriers=[];
	    Object.keys(groups).forEach(function(provider){var group=groups[provider];
	      if(group.rebinding&&!cards.some(function(card){return card.provider===provider;})){barriers.push({group:group,generation:group.generation});}
	    });
	    var sentAt=seconds();payload[key('ACTIVITY_DATA')]=codec.encode(cards,{session:session,revision:revision,sentAt:sentAt});
	    // projection() owns these normalized records. Only copied snapshots leave
	    // the consumer, so retaining them needs no second JSON round trip.
	    lastView={session:session,viewSequence:revision,sequence:revision,sentAt:sentAt,cards:cards};
	    if(typeof options.onView==='function'){options.onView(clone(lastView));}
	    if(!deliveryCurrent(epoch,token)){return;}
	    if(retryTimer!==null){cancel(retryTimer);retryTimer=null;}
	    try{send(payload,function(){
	      if(!deliveryCurrent(epoch,token)){return;}
	      if(revision===sequence){failureCount=0;}
	      // Any acknowledged view excluding a resetting provider is a valid clear
	      // barrier, including one that superseded the original queued clear.
	      barriers.forEach(function(barrier){
	        var group=barrier.group,provider=group.provider;
	        if(groups[provider]!==group||group.generation!==barrier.generation||!group.rebinding){return;}
	        var pending=group.pendingReset;group.pendingReset=null;group.rebinding=false;
	        var needsRebind=group.pendingRebind;group.pendingRebind=false;
	        if(group.pendingMode!=='snapshot'){Object.keys(revisions).forEach(function(id){if(id.indexOf(provider+'|')===0){delete revisions[id];}});}
	        if(needsRebind){bind(provider,group.item);}
	        else if(pending){receive(group,pending,true);}
	      });
	      if(typeof afterAccepted==='function'){afterAccepted();}
	    },function(error){
	      if(!deliveryCurrent(epoch,token)||revision!==sequence||error && error.code==='SUPERSEDED'){return;}
	      if(++failureCount<3){retryTimer=later(function(){retryTimer=null;publish(true);},2000);}
	    });}catch(ignored){if(deliveryCurrent(epoch,token)&&++failureCount<3){retryTimer=later(function(){retryTimer=null;publish(true);},2000);}}
	  }
	  function uncertain(group){
	    var before=group.cards.length,changed=false,t=seconds();
	    group.cards=group.cards.filter(function(card){return !card.private&&card.validUntil>t&&
	      (nativeFormat>=2?card.main.retain&&card.main.validUntil>t:card.clock!=='none');}).map(function(card){
	        if(card.unconfirmed){return card;}
	        changed=true;var copy={};Object.keys(card).forEach(function(k){copy[k]=card[k];});copy.unconfirmed=true;return copy;
	      });
	    return changed||before!==group.cards.length;
	  }
	  function expire(){
	    var t=seconds(), changed=false;
	    Object.keys(groups).forEach(function(provider){
	      var group=groups[provider],before=group.cards.length;
	      group.cards=group.cards.filter(function(card){return card.validUntil>t&&(nativeFormat<2||card.main.validUntil>t);});
	      if(group.expiresAt!==null && group.expiresAt<=t){group.expiresAt=null;group.error='SOURCE_EXPIRED';if(uncertain(group)){changed=true;}}
	      if(before!==group.cards.length){changed=true;}
	    });
	    if(changed){publish();}else{scheduleExpiry();}
	  }
	  function scheduleExpiry(){
	    if(stopped||!connected||!enabled){if(expiryTimer!==null){cancel(expiryTimer);}expiryTimer=null;expiryAt=Infinity;return;}
	    var t=seconds(),end=Infinity;
	    Object.keys(groups).forEach(function(provider){var group=groups[provider];if(group.expiresAt!==null && group.expiresAt>t){end=Math.min(end,group.expiresAt);}group.cards.forEach(function(card){if(card.validUntil>t){end=Math.min(end,card.validUntil);}if(nativeFormat>=2){[card.main,card.support].forEach(function(d){if(d&&d.validUntil>t){end=Math.min(end,d.validUntil);}});}});});
	    if(expiryTimer!==null&&expiryAt===end){return;}
	    if(expiryTimer!==null){cancel(expiryTimer);expiryTimer=null;}
	    expiryAt=end;
	    if(end!==Infinity){expiryTimer=later(function(){expiryTimer=null;expiryAt=Infinity;expire();},Math.max(1,end*1000-now()));}
	  }
	  function receive(group,envelope,rebound){
	    if(!envelope || envelope.pluginUuid!==group.provider || !Array.isArray(envelope.instances) || envelope.instances.length>(group.item===summary.ITEM?17:wire.LIMITS.instances)){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
	    var t=seconds(),expiry=envelope.validUntilMs===undefined?null:Math.floor(envelope.validUntilMs/1000);
	    if(expiry!==null && !wire.integer(expiry,1,wire.MAX_EPOCH)){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
	    var snapshotHeader=null;
	    if(group.item===summary.ITEM){
	      snapshotHeader=summary.header(envelope);
	      if(!snapshotHeader){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
	      if(!rebound&&group.incarnation&&group.incarnation!==snapshotHeader.incarnation){
	        group.cards=[];group.incarnation=null;group.snapshotSequence=0;
	        // The source-floor clear must reach native before a reset managed
	        // revision. Queue only this cleared view until the send completes.
	        group.rebinding=true;group.pendingReset=null;group.pendingMode=snapshotHeader.mode;group.pendingRebind=true;
	        stopGroup(group);
	        publish(true);return;
	      }
	      if(group.rebinding&&!rebound){
	        var pendingHeader=summary.header(group.pendingReset);
	        if(!pendingHeader||pendingHeader.incarnation!==snapshotHeader.incarnation||snapshotHeader.sequence>pendingHeader.sequence){group.pendingReset=envelope;group.pendingMode=snapshotHeader.mode;}
	        return;
	      }
	      if(group.incarnation===snapshotHeader.incarnation&&group.publisherMode!==snapshotHeader.mode){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
	      if(group.incarnation===snapshotHeader.incarnation&&snapshotHeader.sequence<group.snapshotSequence){return;}
	      var responseSignature=JSON.stringify(envelope.instances);
	      if(group.incarnation===snapshotHeader.incarnation&&snapshotHeader.sequence===group.snapshotSequence){
	        if(group.responseSignature!==responseSignature){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
	        // A source can recover on the same handle or immediately deliver its
	        // cached response on a new binding. Its outer availability can also
	        // change independently. Revalidate those cases without renewing any
	        // owner observation/validity; healthy exact duplicates remain inert.
	        if(group.ready&&!group.error&&expiry===group.expiresAt){return;}
	      }
	      group.incarnation=snapshotHeader.incarnation;group.publisherMode=snapshotHeader.mode;group.snapshotSequence=snapshotHeader.sequence;group.responseSignature=responseSignature;
	    }
	    var next=[],seen=Object.create(null),pendingRevisions=Object.create(null),pendingOrders=[],malformed=false;
	    envelope.instances.forEach(function(instance){
	      if(group.item===summary.ITEM&&instance&&instance.instanceId==='@snapshot'){return;}
	
	      var source=group.item===summary.ITEM?summary.sourceCard(instance,group.provider):group.item===activity.ITEM?activity.sourceCard(instance,group.provider):
	        group.item===view.ITEM?view.sourceCard(instance,group.provider):sourceCard(instance,group.provider);
	      if(!source){malformed=true;return;}
	      if(group.item===summary.ITEM&&!source.displayName){
	        var metadataEntry=providerMetadata[group.provider];
	        if(metadataEntry&&metadataEntry.name){source.displayName=metadataEntry.name;}
	      }
	      var card=group.item===summary.ITEM?summary.toView(source):group.item===activity.ITEM?activity.toView(source):nativeFormat>=2&&group.item!==view.ITEM?view.fromLegacy(source):source;
	      if(nativeFormat===3&&group.item!==summary.ITEM&&card){card=summaryView.fromLegacy(card);}
	      if(!card&&group.item!==summary.ITEM){malformed=true;return;}
	      if(card&&!accepted(card)){return;}
	      var fingerprint=sourceFingerprint(source),identity=source.provider+'|'+source.id;
	      var state=source.record?(source.record.state||'active'):source.state;
	      var metadata=JSON.stringify([source.kind||source.type,state,source.observedAt,source.validUntil,source.private]);
	
	      if(seen[identity]){malformed=true;return;}seen[identity]=true;
	      var previous=revisions[identity];
	      if(previous && source.revision<previous.revision){
	        var retained=group.cards.filter(function(old){return old.id===source.id && old.revision===previous.revision;})[0];
	        if(retained && retained.validUntil>t){next.push(retained);}return;
	      }
	      if(previous && (source.revision===previous.revision && (metadata!==previous.metadata || group.item===previous.item&&fingerprint!==previous.fingerprint) || previous.terminal && state!=='completed' && state!=='cancelled')){malformed=true;return;}
	      pendingRevisions[identity]={revision:source.revision,fingerprint:fingerprint,metadata:metadata,item:group.item,terminal:state==='completed'||state==='cancelled'};
	      if(!card){return;}
	      card.sourceFormat=group.item===summary.ITEM?4:group.item===activity.ITEM?3:group.item===view.ITEM?2:1;
	      if(card.kind==='music'){
	        card.validUntil=Math.min(card.validUntil,card.observedAt+120);
	        if(nativeFormat>=2){card.main.validUntil=Math.min(card.main.validUntil,card.validUntil);if(card.support){card.support.validUntil=Math.min(card.support.validUntil,card.validUntil);}}
	      }
	      if(!Object.prototype.hasOwnProperty.call(orders,identity)){pendingOrders.push(identity);}
	      if(card.validUntil>t&&((card.state!=='completed'&&card.state!=='cancelled')||nativeFormat>=2&&card.showTerminal)){next.push(card);}
	    });
	    // A malformed/redacted entry cannot leave an older private preview alive.
	    if(malformed){next=[];}
	    else{
	      // A rejected complete response cannot advance another record's source
	      // floor or install a terminal tombstone through its valid-looking rows.
	      Object.keys(pendingRevisions).forEach(function(identity){revisions[identity]=pendingRevisions[identity];});
	      pendingOrders.forEach(function(identity){orders[identity]=++seenOrder;});
	    }
	    group.cards=next;group.receivedAt=t;group.expiresAt=expiry;group.error=malformed?'INVALID_SOURCE':'';group.ready=true;
	    if(expiry!==null && expiry<=t){uncertain(group);group.error='SOURCE_EXPIRED';}
	    // Bound revision/ordering tombstones independently of untrusted source churn.
	    var identities=Object.keys(revisions);
	    if(identities.length>1024){var live=Object.create(null);Object.keys(groups).forEach(function(provider){groups[provider].cards.forEach(function(card){live[card.provider+'|'+card.id]=true;});});identities.filter(function(id){return !live[id];}).slice(0,identities.length-1024).forEach(function(id){delete revisions[id];delete orders[id];});}
	    publish();
	  }
	  function bind(provider,item){
	    var group=groups[provider]||{provider:provider,generation:0,handle:null,cards:[],error:'',receivedAt:null,expiresAt:null,ready:false};
	    groups[provider]=group;stopGroup(group);group.item=item;group.ready=false;group.settled=false;group.error='';var run=group.generation;
	    function live(){return !stopped && connected && enabled && groups[provider]===group && run===group.generation;}
	    try{
	      var handle=pebble.subscribeToSource({plugin:provider,category:wire.CATEGORY,item:item,properties:(item===summary.ITEM?summary.PROPERTIES:item===activity.ITEM?activity.PROPERTIES:item===view.ITEM?view.PROPERTIES:PROPERTIES).slice(),iconPixelSize:{w:40,h:40},
	        onData:function(envelope){if(live()){group.settled=true;receive(group,envelope);}},
	        onError:function(error){if(!live()){return;}group.settled=true;group.error=errorCode(error);if(group.error==='TIMEOUT'||group.error==='PLUGIN_UNAVAILABLE'||group.error==='RATE_LIMITED'){uncertain(group);}else{group.cards=[];}publish();}});
	      if(live()){group.handle=handle;}else if(handle && typeof handle.unsubscribe==='function'){handle.unsubscribe();}
	    }catch(error){group.settled=true;group.error=errorCode(error);group.cards=[];publish();}
	  }
	  function discover(rebind){
	    if(stopped||!connected||!enabled){return;}
	    available=typeof pebble.enumeratePlugins==='function' && typeof pebble.subscribeToSource==='function';
	    if(!available){Object.keys(groups).forEach(cleanGroup);lastError='API_UNAVAILABLE';publish();return;}
	    var run=++generation;enumerated=false;
	    function apply(plugins){
	      if(run!==generation||stopped||!connected||!enabled){return;}
	      if(!Array.isArray(plugins)){lastError='INVALID_CATALOGUE';Object.keys(groups).forEach(cleanGroup);publish();return;}
	      var items=Object.create(null),metadata=Object.create(null);
	      plugins.filter(function(p){return compatible(p,nativeFormat);}).forEach(function(p){
	        // The official plugin-test app reads enumeratePlugins().name. Treat it
	        // as untrusted display metadata, never as source/revision identity.
	        if(!metadata[p.uuid]){metadata[p.uuid]={uuid:p.uuid,name:wire.text(p.name,64),item:sourceItem(p,nativeFormat),available:true};}
	      });
	      installed=Object.keys(metadata).sort().slice(0,wire.LIMITS.providers).map(function(uuid){return metadata[uuid];});
	      providerMetadata=Object.create(null);installed.forEach(function(p){providerMetadata[p.uuid]=p;});
	      var providers=installed.filter(function(p){return allowed(p.uuid);}).map(function(p){items[p.uuid]=p.item;return p.uuid;});
	      enumerated=true;
	      Object.keys(groups).forEach(function(provider){if(providers.indexOf(provider)<0){cleanGroup(provider);}});
	      providers.forEach(function(provider){var group=groups[provider];if(rebind||!group||group.item!==items[provider]||
	        !group.rebinding&&(group.error||!group.handle)){bind(provider,items[provider]);}});
	      lastError='';publish();
	    }
	    try{var result=pebble.enumeratePlugins();if(result && typeof result.then==='function'){result.then(apply,function(){if(run===generation){lastError='CATALOGUE_UNAVAILABLE';Object.keys(groups).forEach(cleanGroup);publish();}});}else{apply(result);}}
	    catch(ignored){lastError='CATALOGUE_UNAVAILABLE';Object.keys(groups).forEach(cleanGroup);publish();}
	    if(discoveryTimer!==null){cancel(discoveryTimer);}
	    discoveryTimer=later(function(){discoveryTimer=null;discover(false);},60000);
	  }
	  function configure(){
	    if(stopped){return;}
	    var next=readSettings(),previous=enabled;currentSettings=next;enabled=isEnabled(next);
	    if(!enabled){invalidateDelivery();Object.keys(groups).forEach(cleanGroup);lastSignature='';if(expiryTimer!==null){cancel(expiryTimer);expiryTimer=null;}if(discoveryTimer!==null){cancel(discoveryTimer);discoveryTimer=null;}
	      if(previous && connected && session && typeof send==='function'){sequence=sequence===wire.MAX_EPOCH?1:sequence+1;var payload={};payload[key('ACTIVITY_DATA')]=codec.encode([],{session:session,revision:sequence,sentAt:seconds()});try{send(payload,function(){},function(){});}catch(ignored){}}
	      notify();return;
	    }
	    // Apply known policy immediately: asynchronous discovery may be slow or
	    // never settle, and cannot be the boundary for withdrawing private data.
	    var removed=false;
	    Object.keys(groups).forEach(function(provider){if(!allowed(provider)){cleanGroup(provider);removed=true;}});
	    if(removed){publish();}
	    discover(false);
	  }
	  function refresh(rebaseline,token){
	    if(stopped){return;}
	    if(typeof rebaseline==='number'){token=rebaseline;rebaseline=true;}
	    if(wire.integer(token,2,wire.MAX_EPOCH) && token!==session){invalidateDelivery();session=token;sequence=0;lastSignature='';failureCount=0;}
	    else if(rebaseline && !token){bootRequested=false;bootAttempts=0;}failureCount=0;
	    currentSettings=readSettings();enabled=isEnabled(currentSettings);
	    if(!enabled){configure();return;}
	    discover(true);publish(true);
	  }
	  function connectionChanged(value,token){
	    if(stopped || typeof value!=='boolean'){return;}
	    connected=value;generation++;
	    if(!connected){invalidateDelivery();Object.keys(groups).forEach(cleanGroup);session=0;sequence=0;lastSignature='';
	      [expiryTimer,discoveryTimer,retryTimer,bootTimer].forEach(function(timer){if(timer!==null){cancel(timer);}});expiryTimer=discoveryTimer=retryTimer=bootTimer=null;notify();}
	    else{refresh(true,token);}
	  }
	  return {refresh:refresh,configure:configure,connectionChanged:connectionChanged,reproject:function(){publish(true);},
	    providers:function(){return clone(installed);},
	    catalogue:function(){return catalogue(true);},
	    view:function(){return lastView?clone(lastView):null;},
	    status:function(){var providers=Object.keys(groups).map(function(provider){var group=groups[provider];return {pluginUuid:provider,state:group.error?'unavailable':group.ready?'ready':'waiting',error:group.error,receivedAt:group.receivedAt};});var count=catalogueCount(),complete=enumerated&&Object.keys(groups).every(function(provider){return groups[provider].settled;});var ready=enabled&&available&&connected&&enumerated&&providers.every(function(p){return p.state==='ready';});return {available:available,connected:connected,enabled:enabled,ready:ready,complete:complete,phase:ready?'ready':count?'partial':complete||lastError||!connected||!available?'unavailable':'loading',error:lastError||providers.map(function(p){return p.error;}).filter(Boolean)[0]||'',providers:providers,count:count};},
	    stop:function(){stopped=true;generation++;invalidateDelivery();Object.keys(groups).forEach(cleanGroup);[expiryTimer,discoveryTimer,retryTimer,bootTimer].forEach(function(timer){if(timer!==null){cancel(timer);}});expiryTimer=discoveryTimer=retryTimer=bootTimer=null;revisions=Object.create(null);orders=Object.create(null);}}
	};
	module.exports.sourceCard=sourceCard;
	module.exports.compatible=compatible;
	module.exports.PROPERTIES=PROPERTIES;


/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var wire = __webpack_require__(17);
	var activityWire = __webpack_require__(10);
	var activity = __webpack_require__(9);
	var summary = __webpack_require__(12);
	// Namespace of this host adapter only; never claim an unknown SDK provider UUID.
	var MUSIC_ADAPTER_UUID = '718089b7-d9d4-4d6b-81c0-915dcd4c7e4a';
	var NOTIFICATION_ADAPTER_UUID = 'cdb6d497-547a-4940-8026-f7c97ea73a9d';
	var NOTIFICATIONS_APP_UUID = 'b2cae818-10f8-46df-ad2b-98ad2254a3c1';
	var KIND = wire.SEMANTIC_KIND;
	var SOURCE = wire.SOURCE_KIND;
	var LEASE = 120;
	var NOTICE_SUMMARY_LIFE = 3;
	var NOTICE_MESSAGE_LIFE = 8;
	var NOTICE_QUIET = 3;
	var NOTICE_STABLE_MS = 900;
	var PAUSED_GRACE = 5;
	var HEARTBEAT = 60000;
	var MAX_EPOCH = 4294967295;
	var DEFINITIONS = {
	  music:{category:'music', item:'track', properties:['title','artist','playing','artwork']},
	  notifications:{category:'notifications', item:'notification', properties:['name','body','app','package','app_icon']},
	  phone:{category:'phone', item:'phone_state', properties:['battery_level']}
	};
	
	function object(value) { return value && typeof value === 'object' && !Array.isArray(value); }
	function finite(value) { return typeof value === 'number' && isFinite(value); }
	function tokenOf(value) {
	  return finite(value) && Math.floor(value) === value && value>=2 && value<=2147483647 ? value : null;
	}
	function textOf(value) {
	  if (!object(value)) { return ''; }
	  return object(value.shortText) && typeof value.shortText.text === 'string' ? value.shortText.text :
	    object(value.longText) && typeof value.longText.text === 'string' ? value.longText.text : '';
	}
	function clean(value) {
	  return wire.normalizeText(typeof value === 'string' ? value.slice(0,4096)
	    .replace(/[\u00ad\u061c\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff\ufff9-\ufffb]/g,' ') : '',128);
	}
	function codeOf(error) {
	  return error && typeof error.code === 'string' && /^[A-Z0-9_]{1,48}$/.test(error.code) ? error.code : 'UNKNOWN';
	}
	function bytesOf(value, max) {
	  if (typeof value !== 'string' || value.length > Math.ceil(max / 3) * 4 ||
	      !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) { return null; }
	  var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
	  var out = [];
	  for (var i=0; i<value.length; i+=4) {
	    var a=alphabet.indexOf(value[i]), b=alphabet.indexOf(value[i+1]);
	    var c=value[i+2] === '=' ? 0 : alphabet.indexOf(value[i+2]);
	    var d=value[i+3] === '=' ? 0 : alphabet.indexOf(value[i+3]);
	    if (value[i+2] === '=' && (b & 15) || value[i+3] === '=' && value[i+2] !== '=' && (c & 3)) { return null; }
	    out.push((a << 2) | (b >> 4));
	    if (value[i+2] !== '=') { out.push(((b & 15) << 4) | (c >> 2)); }
	    if (value[i+3] !== '=') { out.push(((c & 3) << 6) | d); }
	  }
	  return out.length <= max ? out : null;
	}
	// The source bitmap has tightly packed rows; the existing watch packet uses
	// four-byte aligned rows. Do not assume that every source returns a 24px square.
	function bitmapOf(shape,image,maxSize) {
	  maxSize=maxSize || 24;
	  if (!object(shape) || !Number.isInteger(shape.width) || !Number.isInteger(shape.height) ||
	      shape.width<1 || shape.width>maxSize || shape.height<1 || shape.height>maxSize) { return null; }
	  var palette=bytesOf(shape.palette,16), source=bytesOf(shape.pixels,Math.ceil(maxSize/2)*maxSize);
	  var sourceStride=Math.ceil(shape.width/2), stride=((shape.width+7)>>3)*4;
	  if (!palette || !palette.length || !source || source.length !== sourceStride*shape.height) { return null; }
	  var pixels=[];
	  for (var i=0; i<stride*shape.height; i++) { pixels.push(0); }
	  for (var y=0; y<shape.height; y++) {
	    for (var x=0; x<shape.width; x++) {
	      var pair=source[y*sourceStride+(x>>1)], value=x&1 ? pair&15 : pair>>4;
	      if (value>=palette.length) { return null; }
	      pixels[y*stride+(x>>1)] |= x&1 ? value : value<<4;
	    }
	  }
	  return {width:shape.width,height:shape.height,palette:palette,pixels:pixels,image:image};
	}
	function pictureOf(property,maxSize) {
	  return object(property) ? bitmapOf(property.image,true,maxSize) || bitmapOf(property.icon,false,maxSize) : null;
	}
	function activityImage(bitmap) {
	  if (!bitmap) { return undefined; }
	  var pixels=[],stride=((bitmap.width+7)>>3)*4,row=Math.ceil(bitmap.width/2);
	  for (var y=0;y<bitmap.height;y++) { pixels=pixels.concat(bitmap.pixels.slice(y*stride,y*stride+row)); }
	  return {width:bitmap.width,height:bitmap.height,palette:bitmap.palette.slice(),pixels:pixels};
	}
	function keyOf(instance) {
	  return object(instance) && typeof instance.instanceId === 'string' && instance.instanceId.length>0 &&
	    instance.instanceId.length<=1024 && !/[\x00-\x1f\x7f]/.test(instance.instanceId) ? instance.instanceId : null;
	}
	function filterNames(value) {
	  return (typeof value === 'string' ? value.slice(0,2048) : '').split(',').map(function(name) {
	    return name.trim().toLowerCase();
	  }).filter(function(name,index,names) { return name && names.indexOf(name) === index; }).slice(0,64);
	}
	function fingerprintOf(instance) {
	  var p=instance.properties;
	  // Android conversation notifications often reuse the same notification key.
	  // Observe their text too, but exclude late artwork or an unchanged redelivery.
	  // Keep only bounded text digests in the baseline, rather than retaining bodies.
	  var hash=2166136261, second=5381;
	  ['app','name','body'].forEach(function(name) {
	    var source=textOf(p[name]);
	    var value=(source.slice(0,1024)+'\u001f'+source.slice(-1024))
	      .replace(/[\x00-\x1f\x7f-\x9f\u00ad\u061c\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/g,' ')
	      .replace(/ +/g,' ').trim();
	    value=value.length+':'+value+'\u001f';
	    for (var i=0; i<value.length; i++) {
	      var point=value.charCodeAt(i);
	      hash=Math.imul(hash ^ point,16777619);
	      second=((second << 5)+second) ^ point;
	    }
	  });
	  return (hash>>>0).toString(16)+':'+(second>>>0).toString(16);
	}
	function digest(value) {
	  var hash=2166136261,second=5381;
	  for (var i=0;i<value.length;i++) {
	    var point=value.charCodeAt(i);hash=Math.imul(hash ^ point,16777619);second=((second << 5)+second) ^ point;
	  }
	  return (hash>>>0).toString(16)+':'+(second>>>0).toString(16);
	}
	
	/** Ephemeral context only: sends to the watch, never persists or logs content. */
	module.exports = function createContext(options) {
	  var pebble=options.pebble || {};
	  var groups={};
	  Object.keys(DEFINITIONS).forEach(function(name) {
	    groups[name]={handle:null,generation:0,error:'',hasData:false,receivedAt:null,recovery:null,attempt:0};
	  });
	  var settings=null;
	  var connected=true;
	  var stopped=false;
	  var available=typeof pebble.subscribeToSource === 'function';
	  var records=[null,null,null,null,null];
	  var playing=false;
	  var pausedUntil=0;
	  var musicCard=null, musicRun=0, musicRevision=0, musicIdentity='';
	  var baseline=false;
	  var notificationIds=Object.create(null);
	  var activeNotice=null;
	  var noticeMetadata=null, notificationCard=null, notificationRun=0, notificationRevision=0;
	  var notificationIdentity='', notificationSignature='';
	  var noticeWindowEnd=0, lastNoticeAt=0;
	  var burstSequence=0, noticeBurst=0;
	  var noticeShownAt=0, pendingNotice=null, noticeUpdateTimer=null;
	  var markerNeeded=false, baselineGeneration=0, baselineToken=null;
	  var heartbeat=null, expiryTimer=null;
	  var pending=false, sending=false, deliveryTimer=null, deliveryGeneration=0;
	  var revision=0;
	
	  function now() { return Math.floor(options.now()/1000); }
	  function readSettings() {
	    var value={};
	    try { value=options.getSettings() || {}; } catch (ignored) {}
	    return {showMusic:value.showMusic !== false,showNotifications:value.showNotifications === true,
	      notificationPreview:value.notificationPreview === true,notificationAppOnly:value.notificationAppOnly === true,
	      notificationApps:filterNames(value.notificationApps),
	      showStatus:value.showStatus !== false};
	  }
	  function enabled(name) {
	    return settings && (name === 'music' ? settings.showMusic : name === 'phone' ? settings.showStatus : settings.showNotifications);
	  }
	  function fresh(record) {
	    return record && Number.isInteger(record.confirmedAt) && record.confirmedAt>0 && record.confirmedAt<=now() &&
	      Number.isInteger(record.validUntil) && now()<record.validUntil && record.validUntil<=MAX_EPOCH;
	  }
	  function until(envelope, seconds) {
	    var end=now()+seconds;
	    if (envelope.validUntilMs !== undefined && envelope.validUntilMs !== null) {
	      if (!finite(envelope.validUntilMs)) { return 0; }
	      end=Math.min(end,Math.floor(envelope.validUntilMs/1000));
	    }
	    return end>now() && end<=MAX_EPOCH ? end : 0;
	  }
	  function record(text, bitmap, end, semantic) {
	    text=clean(text);
	    return (text || bitmap) && end>now() ? {status:2,text:text,bitmap:bitmap || undefined,
	      confirmedAt:now(),validUntil:end,semantic:semantic} : null;
	  }
	  function clearNotice() {
	    records[2]=records[3]=null;
	    activeNotice=null;
	    noticeMetadata=notificationCard=null;
	    pendingNotice=null; noticeShownAt=0;
	    if (noticeUpdateTimer !== null) { options.cancelLater(noticeUpdateTimer); noticeUpdateTimer=null; }
	  }
	  function clearGroup(name) {
	    if (name === 'music') { records[0]=records[1]=null; playing=false; pausedUntil=0; musicCard=null; musicIdentity=''; }
	    else if (name === 'phone') { records[4]=null; }
	    else { clearNotice(); baseline=false; notificationIds=Object.create(null); noticeWindowEnd=lastNoticeAt=noticeBurst=0; }
	  }
	  function markBaseline(token, replaceToken) {
	    if (replaceToken) {
	      var nextToken=tokenOf(token);
	      if (nextToken !== baselineToken) { burstSequence=0; }
	      baselineToken=nextToken;
	    }
	    baselineGeneration++;
	    markerNeeded=true;
	    clearGroup('notifications');
	    groups.notifications.hasData=false;
	  }
	  function currentSlots() {
	    return records.map(function(value,i) {
	      if (fresh(value)) { return value; }
	      if (value) { records[i]=null; }
	      return null;
	    });
	  }
	  function payload() {
	    var result={};
	    var slots=currentSlots();
	    // Opt-in hosts render this same ephemeral record in their activity slots.
	    // Do not let the compatibility footer defeat their hide/order preferences.
	    if (options.musicAsActivity === true && musicActivity()) { slots[0]=slots[1]=null; }
	    if (options.notificationAsActivity === true) { slots[2]=slots[3]=null; }
	    if (markerNeeded) {
	      // A boundary may itself have been queued before a second reconnect.
	      // Boundaries never contain private notification data. A fresh notice is
	      // sent only after this baseline's boundary has actually been acknowledged.
	      slots[2]=slots[3]=null;
	      // Startup may precede the watch's unique launch/reconnect token. An old
	      // token must never open that native notification gate, so wait for it.
	      if (baselineToken !== null && options.keys.REQUEST_CONTEXT !== undefined) {
	        result[options.keys.REQUEST_CONTEXT]=baselineToken;
	      }
	    }
	    result[options.keys.CONTEXT_DATA]=wire.packComplications(slots,now());
	    if (options.keys.CONTEXT_STATE !== undefined) {
	      // This sidecar travels atomically with its snapshot. It contains no
	      // provider identity or content, and is never persisted. The native host
	      // must check the session and notification gate before acting on it.
	      var notice=options.notificationAsActivity === true ? notificationActivity() : null;
	      var session=baselineToken || 0, event=!markerNeeded && (notice || slots[2]) ? noticeBurst : 0;
	      var state=[0,0,0,0,0,0,0,0,slots[0] && !playing ? 1 : 0];
	      for (var i=0; i<4; i++) { state[i]=(session >>> (i*8)) & 255; state[i+4]=(event >>> (i*8)) & 255; }
	      // Opt-in hosts no longer receive notification slots. Preserve the original
	      // deadline beside the event so a delayed queue cannot vibrate after expiry.
	      if (options.notificationAsActivity === true) {
	        var expiry=notice ? notice.validUntil : 0;
	        for (i=0;i<4;i++) { state[9+i]=(expiry >>> (i*8)) & 255; }
	      }
	      result[options.keys.CONTEXT_STATE]=state;
	    }
	    return result;
	  }
	  function cancelDelivery() {
	    deliveryGeneration++;
	    if (deliveryTimer !== null) { options.cancelLater(deliveryTimer); }
	    deliveryTimer=null; sending=false; pending=false;
	  }
	  function pump() {
	    if (stopped || !connected || sending || !pending) { return; }
	    pending=false; sending=true;
	    var generation=deliveryGeneration;
	    function attempt(number) {
	      if (generation !== deliveryGeneration || stopped || !connected) { return; }
	      var sentRevision=revision, sentBaselineGeneration=baselineGeneration, sentToken=baselineToken;
	      var sentMarker=markerNeeded && sentToken !== null && options.keys.REQUEST_CONTEXT !== undefined, done=false;
	      function finish(ok,error) {
	        if (done || generation !== deliveryGeneration) { return; }
	        done=true;
	        // Only this baseline's acknowledged boundary can release its marker.
	        // A packet copied into the shared queue before reconnect cannot do so.
	        if (ok && sentMarker && sentBaselineGeneration === baselineGeneration && sentToken === baselineToken) {
	          markerNeeded=false;
	          if (fresh(records[2])) { pending=true; }
	          if (options.notificationAsActivity === true) { notify(); }
	        }
	        if (deliveryTimer !== null) { options.cancelLater(deliveryTimer); }
	        deliveryTimer=null;
	        if (!ok && (!error || error.code !== 'SUPERSEDED') && !pending && revision === sentRevision && number<3) {
	          deliveryTimer=options.later(function() { deliveryTimer=null; attempt(number+1); },number*1000);
	          return;
	        }
	        sending=false;
	        pump();
	      }
	      // The shared transport can wait behind another bounded transfer. Its
	      // own watchdog owns a stuck native send; leave room for that queue here.
	      deliveryTimer=options.later(function() { finish(false); },45000);
	      try { options.send(payload(),function() { finish(true); },function(error) { finish(false,error); }); }
	      catch (ignored) { finish(false); }
	    }
	    attempt(1);
	  }
	  function publish() {
	    revision++;
	    if (options.send.supersedesSnapshots && sending) { cancelDelivery(); }
	    pending=true;
	    pump();
	    scheduleExpiry();
	    notify();
	  }
	  function notify() { if (typeof options.onChanged === 'function') { options.onChanged(); } }
	  function musicActivity() {
	    if (stopped || !connected || !enabled('music') || !fresh(records[0]) || !musicCard || musicCard.validUntil<=now()) { return null; }
	    // Reading a projection never changes the authoritative receipt or revision.
	    var result=JSON.parse(JSON.stringify(musicCard));
	    result.selectionKey='builtin:music'; result.providerName='Music';
	    return result;
	  }
	  function notificationActivity() {
	    if (stopped || !connected || markerNeeded || !enabled('notifications') || !fresh(records[2]) ||
	        !notificationCard || notificationCard.validUntil<=now()) { return null; }
	    return JSON.parse(JSON.stringify(notificationCard));
	  }
	  function syncNotificationActivity() {
	    if (!noticeMetadata || !noticeMetadata.provider || !fresh(records[2])) { notificationCard=null; return; }
	    var identity=digest(JSON.stringify([noticeMetadata.provider,activeNotice,noticeMetadata.burst]));
	    var source={provider:noticeMetadata.provider,observedAt:records[2].confirmedAt,validUntil:records[2].validUntil,
	      private:true,displayName:'Notifications',record:{id:'notification',type:'standard',icon:activityImage(records[2].bitmap)||'message',
	        name:noticeMetadata.appName,headline:{type:'text',text:records[2].text},
	        openApp:{watchAppUuid:NOTIFICATIONS_APP_UUID}}};
	    if (fresh(records[3])) { source.record.detail={type:'text',text:records[3].text}; }
	    // Retain only digests across a redaction, never an earlier body or source ID.
	    var signature=digest(JSON.stringify(source));
	    if (identity !== notificationIdentity || notificationRevision===MAX_EPOCH) {
	      notificationIdentity=identity; notificationRun++; notificationRevision=0; notificationSignature='';
	    }
	    if (signature !== notificationSignature) { notificationRevision++; notificationSignature=signature; }
	    source.revision=notificationRevision; source.record.id='legacy-notification-'+notificationRun;
	    notificationCard=summary.toView(source);
	    if (notificationCard) { notificationCard.selectionKey='builtin:notifications'; }
	  }
	  function activateNotice(next) {
	    records[2]=next.title; records[3]=next.body; activeNotice=next.id;
	    noticeMetadata={provider:next.provider,appName:next.appName,burst:next.burst};
	    noticeShownAt=options.now(); syncNotificationActivity();
	  }
	  function scheduleExpiry() {
	    if (expiryTimer !== null) { options.cancelLater(expiryTimer); }
	    expiryTimer=null;
	    var end=Infinity;
	    records.forEach(function(value) { if (fresh(value)) { end=Math.min(end,value.validUntil); } });
	    if (pendingNotice && fresh(pendingNotice.title)) { end=Math.min(end,pendingNotice.title.validUntil); }
	    if (end !== Infinity && !stopped) {
	      expiryTimer=options.later(function() {
	        expiryTimer=null;
	        if (!fresh(records[2])) { clearNotice(); }
	        if (pendingNotice && !fresh(pendingNotice.title)) {
	          pendingNotice=null;
	          if (noticeUpdateTimer !== null) { options.cancelLater(noticeUpdateTimer); noticeUpdateTimer=null; }
	        }
	        currentSlots(); publish();
	      },Math.max(1,end*1000-options.now()));
	    }
	  }
	  function cancelRecovery(name, reset) {
	    var group=groups[name];
	    if (group.recovery !== null) { options.cancelLater(group.recovery); }
	    group.recovery=null;
	    if (reset) { group.attempt=0; }
	  }
	  function recover(name) {
	    var group=groups[name];
	    if (stopped || !connected || !enabled(name) || !available ||
	        ['PLUGIN_UNAVAILABLE','TIMEOUT','UNKNOWN'].indexOf(group.error)<0) { cancelRecovery(name,true); return; }
	    if (group.recovery !== null) { return; }
	    var generation=group.generation;
	    group.recovery=options.later(function() {
	      group.recovery=null;
	      if (generation !== group.generation || stopped || !connected || !enabled(name)) { return; }
	      group.attempt=Math.min(group.attempt+1,3);
	      bind(name); recover(name);
	    },[5000,15000,60000,120000][group.attempt]);
	  }
	  function sourceError(name,error) {
	    groups[name].error=codeOf(error);
	    groups[name].hasData=false;
	    clearGroup(name);
	    publish(); recover(name);
	  }
	  function sourceData(name,envelope) {
	    if (!object(envelope) || !Array.isArray(envelope.instances) || envelope.instances.length>512) {
	      sourceError(name,{code:'INVALID_DATA'}); return;
	    }
	    groups[name].error=''; groups[name].hasData=true; cancelRecovery(name,true);
	    var valid;
	    if (name === 'music') { valid=musicData(envelope); }
	    else if (name === 'phone') { valid=phoneData(envelope); }
	    else { valid=notificationData(envelope); }
	    if (valid === false) { sourceError(name,{code:'INVALID_DATA'}); return; }
	    groups[name].receivedAt=now();
	    if (valid !== 'deferred') { publish(); }
	  }
	  function musicData(envelope) {
	    if (!envelope.instances.length) { clearGroup('music'); return; }
	    var instance=envelope.instances[0], p=object(instance) && instance.properties;
	    var isPlaying=object(p) && object(p.playing) && object(p.playing.boolean) ? p.playing.boolean.value : null;
	    var title=object(p) ? clean(textOf(p.title)) : '';
	    var end=until(envelope,LEASE);
	    if (typeof isPlaying !== 'boolean' || !title || !end) { return false; }
	    if (isPlaying) { playing=true; pausedUntil=0; }
	    else {
	      if (playing) { pausedUntil=now()+PAUSED_GRACE; }
	      playing=false;
	      if (!pausedUntil || now()>=pausedUntil) { clearGroup('music'); return; }
	      end=Math.min(end,pausedUntil);
	    }
	    records[0]=record(title,pictureOf(p.artwork,40),end,{kind:KIND.GENERIC,source:SOURCE.MUSIC});
	    records[1]=record(textOf(p.artist),null,end,{kind:KIND.GENERIC,source:SOURCE.MUSIC});
	    var provider=envelope.pluginUuid===undefined?MUSIC_ADAPTER_UUID:activityWire.uuid(envelope.pluginUuid)?envelope.pluginUuid:null;
	    if (!provider) { musicCard=null; return; }
	    var artist=records[1] ? records[1].text : '', identity=JSON.stringify([provider,keyOf(instance),title,artist]);
	    if (identity !== musicIdentity || musicRevision===MAX_EPOCH) { musicIdentity=identity; musicRun++; musicRevision=0; }
	    musicRevision++;
	    var image=activityImage(records[0].bitmap);
	    // Missing optional metadata contributes no label or placeholder row.
	    var detail=/^(?:\?|unknown|unknown artist)$/i.test(artist.trim())?'':artist;
	    musicCard=activity.toView({provider:provider,id:'legacy-music-'+musicRun,kind:'music',revision:musicRevision,
	      state:playing?'active':'paused',observedAt:records[0].confirmedAt,validUntil:end,private:true,appName:'Music',
	      content:title,detail:detail||null,image:image});
	  }
	  function phoneData(envelope) {
	    if (!envelope.instances.length) { records[4]=null; return; }
	    var instance=envelope.instances[0], p=object(instance) && instance.properties;
	    var property=object(p) && p.battery_level;
	    var numeric=object(property) && property.numericValue;
	    var level=object(numeric) && numeric.value;
	    var end=until(envelope,LEASE);
	    if (!object(p) || property !== undefined && (!object(numeric) || !finite(level) || level<0 || level>100 ||
	        numeric.unit !== undefined && numeric.unit !== '%') || !end) { return false; }
	    records[4]=finite(level) && level>=0 && level<=15 &&
	      (numeric.unit === undefined || numeric.unit === '%') && end ? record(Math.round(level)+'%',null,end,
	        {kind:KIND.BATTERY,source:SOURCE.PHONE,detail:wire.DETAIL_KIND.PHONE_BATTERY,value:level,min:0,max:100,unit:'%'}) : null;
	  }
	  function notificationContent(instance) {
	    var p=object(instance) && instance.properties;
	    if (!object(p)) { return null; }
	    var app=textOf(p.app), packageName=textOf(p.package);
	    var allowed=!settings.notificationApps.length || settings.notificationApps.indexOf(app.trim().toLowerCase())>=0 ||
	      settings.notificationApps.indexOf(packageName.trim().toLowerCase())>=0;
	    var title=clean(textOf(p.name)), appTitle=wire.normalizeText(clean(app),24);
	    var heading=settings.notificationAppOnly ? clean(app) || clean(packageName) : title || clean(app);
	    if (!allowed || !heading) { return null; }
	    return {title:title,appTitle:appTitle,
	      appName:settings.notificationAppOnly || heading===clean(app) ? 'Notifications' :
	        wire.normalizeText(clean(app)||clean(packageName)||'Notifications',64),heading:heading,
	      body:settings.notificationPreview && !settings.notificationAppOnly ? clean(textOf(p.body)) : ''};
	  }
	  function notificationData(envelope) {
	    var incoming=Object.create(null), candidates=[], activeInstance=null, pendingInstance=null, deferred=false, changed=false;
	    var provider=envelope.pluginUuid===undefined?NOTIFICATION_ADAPTER_UUID:activityWire.uuid(envelope.pluginUuid)?envelope.pluginUuid:null;
	    envelope.instances.forEach(function(instance) {
	      var id=keyOf(instance);
	      if (id === null || incoming[id]) { return; }
	      incoming[id]=object(instance.properties) ? fingerprintOf(instance) : 'invalid';
	      if (id === activeNotice) { activeInstance=instance; }
	      if (pendingNotice && id === pendingNotice.id) { pendingInstance=instance; }
	      if (baseline && notificationIds[id] !== incoming[id] && object(instance.properties)) { candidates.push(instance); }
	    });
	    if (envelope.instances.length && !Object.keys(incoming).length) { return false; }
	    // A retained source ID does not mean its earlier private content is still
	    // available. Full redaction, malformed properties and a newly excluded app
	    // must clear both visible and queued text before the stable-reading delay.
	    if (activeNotice && !notificationContent(activeInstance)) { clearNotice(); }
	    if (pendingNotice && !notificationContent(pendingInstance)) {
	      pendingNotice=null;
	      if (noticeUpdateTimer !== null) { options.cancelLater(noticeUpdateTimer); noticeUpdateTimer=null; }
	    }
	    // Late artwork is not a new notice and must not renew its original lease.
	    if (activeInstance && fresh(records[2]) && notificationIds[activeNotice] === incoming[activeNotice]) {
	      var refreshedIcon=pictureOf(activeInstance.properties.app_icon,24);
	      if (refreshedIcon) { records[2].bitmap=refreshedIcon; }
	      if (noticeMetadata) { noticeMetadata.provider=provider; }
	    }
	    // First delivery is a snapshot of the existing phone shade, not a new
	    // notification. Reconnects, errors and settings changes establish it again.
	    notificationIds=incoming;
	    if (!baseline) { baseline=true; return; }
	    var availableEnd=until(envelope,NOTICE_MESSAGE_LIFE);
	    if (!availableEnd) { clearNotice(); return; }
	    // An unchanged redelivery may shorten the authoritative source lease. Cap
	    // visible AND queued text without changing its original observation time.
	    function cap(record) {
	      if (record && record.validUntil>availableEnd) { record.validUntil=availableEnd; changed=true; }
	    }
	    cap(records[2]); cap(records[3]);
	    if (pendingNotice) { cap(pendingNotice.title); cap(pendingNotice.body); }
	    if (noticeWindowEnd>availableEnd) { noticeWindowEnd=availableEnd; }
	    for (var i=0; i<candidates.length; i++) {
	      var instance=candidates[i], p=instance.properties;
	      var content=notificationContent(instance);
	      if (!content) { continue; }
	      var title=content.title, appTitle=content.appTitle, heading=content.heading, body=content.body;
	      var lifetime=options.notificationAsActivity === true || body ? NOTICE_MESSAGE_LIFE : NOTICE_SUMMARY_LIFE;
	      var end=Math.min(availableEnd,now()+lifetime);
	      var received=now();
	      if (received>=noticeWindowEnd) {
	        var quiet=lastNoticeAt === 0 || received-lastNoticeAt>=NOTICE_QUIET;
	        lastNoticeAt=received;
	        // A continuous burst gets one bounded interruption, not another
	        // lifetime on every message. New arrivals still advance the baseline,
	        // and a later independent burst can start after a short quiet gap.
	        if (!quiet) { break; }
	        noticeWindowEnd=end;
	        burstSequence=(burstSequence+1)>>>0 || 1;
	        noticeBurst=burstSequence;
	      } else { lastNoticeAt=received; }
	      end=Math.min(end,noticeWindowEnd);
	      var next={id:keyOf(instance),provider:provider,appName:content.appName,burst:noticeBurst,title:record(heading,pictureOf(p.app_icon,24),end,
	        {kind:KIND.GENERIC,source:SOURCE.NOTIFICATION,label:settings.notificationAppOnly ? '' : appTitle}),
	        body:body ? record(body,null,end,{kind:KIND.GENERIC,source:SOURCE.NOTIFICATION}) : null};
	      // A stable reading interval must never postpone a source redaction.
	      var removesPrivateText=fresh(records[3]) && !next.body ||
	        !title && fresh(records[2]) && records[2].text !== heading;
	      if (!removesPrivateText && fresh(records[2]) && options.now()<noticeShownAt+NOTICE_STABLE_MS) {
	        pendingNotice=next; deferred=true;
	        if (noticeUpdateTimer === null) {
	          noticeUpdateTimer=options.later(function() {
	            noticeUpdateTimer=null;
	            var pending=pendingNotice; pendingNotice=null;
	            if (!pending || stopped || !connected || !baseline || !enabled('notifications') || !fresh(pending.title)) { return; }
	            activateNotice(pending); publish();
	          },Math.max(1,noticeShownAt+NOTICE_STABLE_MS-options.now()));
	        }
	      } else {
	        if (noticeUpdateTimer !== null) { options.cancelLater(noticeUpdateTimer); noticeUpdateTimer=null; }
	        pendingNotice=null;
	        activateNotice(next);
	      }
	      break; // The native source orders instances newest first.
	    }
	    syncNotificationActivity();
	    return deferred && !changed ? 'deferred' : undefined;
	  }
	  function close(name) {
	    var group=groups[name];
	    group.generation++;
	    if (group.handle && typeof group.handle.unsubscribe === 'function') {
	      try { group.handle.unsubscribe(); } catch (ignored) {}
	    }
	    group.handle=null;
	    cancelRecovery(name,false);
	  }
	  function updateAvailability() {
	    var current=typeof pebble.subscribeToSource === 'function';
	    if (current === available) { return false; }
	    available=current;
	    markBaseline();
	    // The phone can enable or disable the preview API while PKJS remains
	    // loaded. Neither old handles nor an old notification baseline survive it.
	    Object.keys(groups).forEach(function(name) {
	      close(name); clearGroup(name);
	      groups[name].error=''; groups[name].hasData=false; groups[name].receivedAt=null; groups[name].attempt=0;
	    });
	    return true;
	  }
	  function bind(name) {
	    close(name);
	    if (!connected || stopped || !available || !enabled(name)) { return; }
	    var group=groups[name], generation=group.generation, definition=DEFINITIONS[name];
	    var request={category:definition.category,item:definition.item,properties:definition.properties.slice(),
	      onData:function(envelope) { if (generation === group.generation && !stopped && connected) { sourceData(name,envelope); } },
	      onError:function(error) { if (generation === group.generation && !stopped && connected) { sourceError(name,error); } }};
	    if (name !== 'phone') { request.iconPixelSize=name === 'music' ? {w:40,h:40} : {w:24,h:24}; }
	    try {
	      var handle=pebble.subscribeToSource(request);
	      if (generation === group.generation && !stopped && connected) { group.handle=handle; }
	      else if (handle && typeof handle.unsubscribe === 'function') { handle.unsubscribe(); }
	    } catch (error) { if (generation === group.generation) { sourceError(name,error); } }
	  }
	  function scheduleHeartbeat() {
	    if (heartbeat !== null) { options.cancelLater(heartbeat); }
	    heartbeat=null;
	    if (!stopped && connected && available && (enabled('music') || enabled('phone'))) {
	      heartbeat=options.later(function() {
	        heartbeat=null;
	        // Native sources expose current state immediately on subscription.
	        // Rebinding renews a lease only when that authoritative delivery occurs.
	        var changed=updateAvailability();
	        if (enabled('music')) { bind('music'); }
	        if (enabled('phone')) { bind('phone'); }
	        if (changed && available && enabled('notifications')) { bind('notifications'); }
	        if (changed) { publish(); }
	        scheduleHeartbeat();
	      },HEARTBEAT);
	    }
	  }
	  function configure() {
	    if (stopped) { return; }
	    var availabilityChanged=updateAvailability();
	    var previous=settings;
	    settings=readSettings();
	    Object.keys(groups).forEach(function(name) {
	      var changed=availabilityChanged || !previous || name === 'music' && previous.showMusic !== settings.showMusic ||
	        name === 'phone' && previous.showStatus !== settings.showStatus || name === 'notifications' &&
	        (previous.showNotifications !== settings.showNotifications || previous.notificationPreview !== settings.notificationPreview ||
	          previous.notificationAppOnly !== settings.notificationAppOnly ||
	          JSON.stringify(previous.notificationApps) !== JSON.stringify(settings.notificationApps));
	      if (changed) { clearGroup(name); groups[name].error=''; groups[name].hasData=false; groups[name].receivedAt=null; groups[name].attempt=0; bind(name); }
	    });
	    publish(); scheduleHeartbeat();
	  }
	  function refresh(rebaseline, token) {
	    if (stopped) { return; }
	    // Set the boundary before configure/bind can synchronously publish data.
	    if (rebaseline) { markBaseline(token,true); }
	    if (!settings) { configure(); return; }
	    updateAvailability();
	    if (rebaseline) { bind('notifications'); }
	    else if (enabled('notifications') && !groups.notifications.handle) { bind('notifications'); }
	    if (enabled('music')) { bind('music'); }
	    if (enabled('phone')) { bind('phone'); }
	    publish(); scheduleHeartbeat();
	  }
	  function connectionChanged(value, token) {
	    if (stopped || typeof value !== 'boolean') { return; }
	    if (!value) {
	      connected=false;
	      baselineToken=null;
	      Object.keys(groups).forEach(function(name) { close(name); clearGroup(name); groups[name].error=''; groups[name].hasData=false; groups[name].receivedAt=null; groups[name].attempt=0; });
	      cancelDelivery();
	      if (heartbeat !== null) { options.cancelLater(heartbeat); }
	      if (expiryTimer !== null) { options.cancelLater(expiryTimer); }
	      heartbeat=expiryTimer=null;
	      notify();
	    } else { connected=true; refresh(true,token); }
	  }
	  return {refresh:refresh,configure:configure,connectionChanged:connectionChanged,musicActivity:musicActivity,notificationActivity:notificationActivity,
	    musicProvider:function(){var card=musicActivity();return card?{uuid:card.provider,name:'Music',item:'track',available:true}:null;},
	    notificationProvider:function(){var card=notificationActivity();return card?{uuid:card.provider,name:'Notifications',item:'notification',available:true}:null;},
	    status:function() {
	      var sources={}, sourceStates={}, error='';
	      Object.keys(groups).forEach(function(name) { sources[name]=groups[name].error; });
	      Object.keys(groups).some(function(name) { if (enabled(name) && groups[name].error) { error=groups[name].error; return true; } return false; });
	      if (!available && Object.keys(groups).some(enabled)) { error='API_UNAVAILABLE'; }
	      var ready=!!settings && connected && (available || !Object.keys(groups).some(enabled)) &&
	        Object.keys(groups).every(function(name) { return !enabled(name) || groups[name].hasData; });
	      Object.keys(groups).forEach(function(name) {
	        var group=groups[name], state='ready', message=group.error;
	        if (!enabled(name)) { state='off'; message=''; }
	        else if (!connected || !available) { state='unavailable'; message=!connected ? 'DISCONNECTED' : 'API_UNAVAILABLE'; }
	        else if (group.error) { state=group.error === 'PERMISSION_DENIED' ? 'denied' : 'unavailable'; }
	        else if (!group.hasData) { state='waiting'; }
	        else if (name === 'music') {
	          if (fresh(records[0])) { state=playing ? 'playing' : 'paused'; }
	          else if (playing) { state='unavailable'; message='SOURCE_EXPIRED'; }
	          else { state='idle'; }
	        } else if (name === 'phone' && group.receivedAt !== null && now()-group.receivedAt>=LEASE) {
	          state='unavailable'; message='SOURCE_EXPIRED';
	        } else if (name === 'notifications' && !fresh(records[2])) { state='idle'; }
	        sourceStates[name]={state:state,message:message,receivedAt:group.receivedAt,
	          receivedAgeSec:group.receivedAt === null ? null : Math.max(0,now()-group.receivedAt),
	          observedAt:null,observationAgeSec:null};
	      });
	      return {available:available,connected:connected,ready:ready,error:error,music:!!fresh(records[0]),notification:!!fresh(records[2]),
	        phoneBattery:!!fresh(records[4]),sources:sources,sourceStates:sourceStates};
	    },
	    stop:function() {
	      Object.keys(groups).forEach(function(name) { close(name); clearGroup(name); });
	      stopped=true; cancelDelivery();
	      if (heartbeat !== null) { options.cancelLater(heartbeat); }
	      if (expiryTimer !== null) { options.cancelLater(expiryTimer); }
	      heartbeat=expiryTimer=null;
	      notify();
	    }};
	};


/***/ }),
/* 17 */
/***/ (function(module, exports) {

	'use strict';
	
	var VERSION = 4;
	var HEADER_BYTES = 56;
	var SEMANTIC_KIND = {GENERIC:0,TEMPERATURE:1,PRECIPITATION:2,BATTERY:3,HUMIDITY:4,WIND:5,UV:6,CONDITION:7,RANGE:8,NUMBER:9,BOOLEAN:10,TIMESTAMP:11};
	var SOURCE_KIND = {GENERIC:0,WEATHER:1,PHONE:2,MUSIC:3,NOTIFICATION:4,OTHER:5};
	var DETAIL_KIND = {NONE:0,TEMPERATURE:1,FEELS_LIKE:2,HIGH:3,LOW:4,PRECIPITATION:5,HUMIDITY:6,WIND_SPEED:7,WIND_DIRECTION:8,UV:9,CONDITION:10,PHONE_BATTERY:11};
	var QUALIFIERS = {FORECAST:1};
	var DETAIL_SEMANTIC = [0,1,1,1,1,2,4,5,5,6,7,3];
	var SLOT_COUNT = 5;
	var TEXT = 1;
	var BITMAP = 2;
	var IMAGE = 4;
	var TIMESTAMP = 8;
	var EMPTY = 0;
	var READY = 2;
	var UNAVAILABLE = 3;
	var UNSUPPORTED = 5;
	var EXPIRED = 7;
	var MAX_EPOCH = 4294967295;
	var MAX_AGE = 7200;
	var MAX_TEXT_BYTES = 128;
	
	function object(value) { return value && typeof value === 'object' && !Array.isArray(value); }
	function integer(value, minimum, maximum) {
	  return typeof value === 'number' && isFinite(value) && value >= minimum &&
	    value <= maximum && Math.floor(value) === value;
	}
	function bytes(value) {
	  return Array.isArray(value) || Object.prototype.toString.call(value) === '[object Uint8Array]';
	}
	function byteArray(value, length) {
	  if (!bytes(value) || value.length !== length) { return false; }
	  for (var i = 0; i < length; i++) { if (!integer(value[i], 0, 255)) { return false; } }
	  return true;
	}
	function scalar(text, at) {
	  var first = text.charCodeAt(at);
	  if (first >= 0xD800 && first <= 0xDBFF) {
	    var second = text.charCodeAt(at + 1);
	    if (second >= 0xDC00 && second <= 0xDFFF) {
	      return {value:0x10000 + (first - 0xD800) * 1024 + second - 0xDC00, length:2};
	    }
	    return {value:0xFFFD, length:1};
	  }
	  return {value:first >= 0xDC00 && first <= 0xDFFF ? 0xFFFD : first, length:1};
	}
	function scalarText(value) {
	  if (value <= 0xFFFF) { return String.fromCharCode(value); }
	  value -= 0x10000;
	  return String.fromCharCode(0xD800 + Math.floor(value / 1024), 0xDC00 + value % 1024);
	}
	function utf8Length(value) { return value < 0x80 ? 1 : value < 0x800 ? 2 : value < 0x10000 ? 3 : 4; }
	
	// The native decoder rejects control characters. Keep ordinary word boundaries
	// when sanitizing them, repair orphan surrogates and truncate only whole UTF-8
	// scalars, reserving an ellipsis when content exceeds the byte limit. The
	// bounded returned string is also suitable for coordinator storage and replay.
	function normalizeText(value, maxBytes) {
	  maxBytes = integer(maxBytes, 3, MAX_TEXT_BYTES) ? maxBytes : MAX_TEXT_BYTES;
	  if (typeof value !== 'string') { return ''; }
	  var result = '';
	  var ellipsisPrefix = '';
	  var count = 0;
	  var pendingSpace = false;
	  for (var i = 0; i < value.length;) {
	    var next = scalar(value, i);
	    i += next.length;
	    var code = next.value;
	    if (code < 0x20 || (code >= 0x7F && code <= 0x9F) || code === 0x2028 || code === 0x2029) { code = 0x20; }
	    // Defer spaces until another scalar arrives: trailing controls or spaces
	    // alone do not make an otherwise fitting string require an ellipsis.
	    if (code === 0x20) { pendingSpace = result.length > 0; continue; }
	    var length = utf8Length(code) + (pendingSpace ? 1 : 0);
	    if (count + length > maxBytes) { return ellipsisPrefix + '\u2026'; }
	    result += (pendingSpace ? ' ' : '') + scalarText(code);
	    count += length;
	    pendingSpace = false;
	    if (count <= maxBytes - 3) { ellipsisPrefix = result; }
	  }
	  return result;
	}
	function utf8(text) {
	  var out = [];
	  for (var i = 0; i < text.length;) {
	    var next = scalar(text, i);
	    var code = next.value;
	    i += next.length;
	    if (code < 0x80) { out.push(code); }
	    else if (code < 0x800) { out.push(0xC0 | (code >> 6), 0x80 | (code & 63)); }
	    else if (code < 0x10000) { out.push(0xE0 | (code >> 12), 0x80 | ((code >> 6) & 63), 0x80 | (code & 63)); }
	    else { out.push(0xF0 | (code >> 18), 0x80 | ((code >> 12) & 63), 0x80 | ((code >> 6) & 63), 0x80 | (code & 63)); }
	  }
	  return out;
	}
	function u16(out, at, value) { out[at] = value & 255; out[at + 1] = Math.floor(value / 256) & 255; }
	function u32(out, at, value) {
	  for (var i = 0; i < 4; i++) { out[at + i] = Math.floor(value / Math.pow(256, i)) % 256; }
	}
	function crc16Xmodem(value) {
	  var crc = 0;
	  for (var i = 0; i < value.length; i++) {
	    crc ^= value[i] << 8;
	    for (var bit = 0; bit < 8; bit++) { crc = ((crc << 1) ^ (crc & 0x8000 ? 0x1021 : 0)) & 0xFFFF; }
	  }
	  return crc;
	}
	function statusRecord(status, headerBytes) {
	  headerBytes = headerBytes || HEADER_BYTES;
	  var result = [];
	  for (var i = 0; i < headerBytes; i++) { result.push(0); }
	  result[1] = status;
	  return result;
	}
	function bitmapOf(value, maxSize) {
	  maxSize = maxSize || 40;
	  if (!object(value) || !integer(value.width, 1, maxSize) || !integer(value.height, 1, maxSize) ||
	      !bytes(value.palette) || !integer(value.palette.length, 1, 16)) { return null; }
	  var stride = ((value.width + 7) >> 3) * 4;
	  var count = stride * value.height;
	  if (!byteArray(value.palette, value.palette.length) || !byteArray(value.pixels, count)) { return null; }
	  // The original palette length matters before padding to the 16-byte wire
	  // palette. Ignore row padding and the unused low nibble of odd-width rows.
	  for (var y = 0; y < value.height; y++) {
	    for (var x = 0; x < value.width; x++) {
	      var pair = value.pixels[y * stride + (x >> 1)];
	      var index = x & 1 ? pair & 15 : pair >> 4;
	      if (index >= value.palette.length) { return null; }
	    }
	  }
	  var palette = [];
	  for (var i = 0; i < 16; i++) { palette.push(i < value.palette.length ? value.palette[i] : 0); }
	  return {width:value.width, height:value.height, palette:palette,
	    pixels:Array.prototype.slice.call(value.pixels), image:value.image === true};
	}
	function f64(out, at, value) {
	  var buffer = new ArrayBuffer(8), view = new DataView(buffer);
	  view.setFloat64(0, value, true);
	  for (var i = 0; i < 8; ++i) { out[at + i] = view.getUint8(i); }
	}
	function semanticOf(slot, version, identityOnly) {
	  var value = slot.semantic;
	  if (!object(value)) { return null; }
	  var kind = value.kind === undefined ? 0 : value.kind;
	  var source = value.source === undefined ? 0 : value.source;
	  if (!integer(kind, 0, 11) || !integer(source, 0, 5)) { return null; }
	  var result = {kind:kind,source:source,flags:0,unit:[],label:[],detail:0,qualifiers:0,observedAt:0};
	  if (version === 4) {
	    var detail = value.detail === undefined ? 0 : value.detail;
	    var qualifiers = value.qualifiers === undefined ? 0 : value.qualifiers;
	    var observedAt = identityOnly || value.observedAt === undefined ? 0 : value.observedAt;
	    if (!integer(detail,0,11) || detail && DETAIL_SEMANTIC[detail] !== kind &&
	        !(detail === DETAIL_KIND.PRECIPITATION && (kind === SEMANTIC_KIND.GENERIC || kind === SEMANTIC_KIND.NUMBER)) ||
	        !integer(qualifiers,0,1) || qualifiers && source !== SOURCE_KIND.WEATHER ||
	        !integer(observedAt,0,MAX_EPOCH) || observedAt &&
	          (observedAt > slot.confirmedAt || qualifiers & QUALIFIERS.FORECAST)) { return null; }
	    result.detail=detail; result.qualifiers=qualifiers; result.observedAt=observedAt;
	  }
	  var fields = ['value','min','max'];
	  for (var i = 0; i < fields.length; ++i) {
	    if (!identityOnly && value[fields[i]] !== undefined) {
	      var numeric = value[fields[i]];
	      if (typeof numeric !== 'number' || !isFinite(numeric)) { return null; }
	      result[fields[i]] = numeric; result.flags |= 1 << i;
	    }
	  }
	  if ((result.flags & 6) === 6 && result.min > result.max) { return null; }
	  if (value.unit !== undefined) {
	    if (typeof value.unit !== 'string') { return null; }
	    result.unit = utf8(normalizeText(value.unit));
	    // A shortened unit could change its meaning. Omit invalid optional metadata.
	    if (result.unit.length > 16) { return null; }
	  }
	  if (value.label !== undefined) {
	    if (typeof value.label !== 'string') { return null; }
	    result.label = utf8(normalizeText(value.label,24));
	  }
	  return result;
	}
	
	function unavailableRecord(slot,status,version,header) {
	  if (version !== 4 || status === EMPTY) { return statusRecord(status === EXPIRED ? UNAVAILABLE : status,header); }
	  var metadata=semanticOf(slot,version,true), out=statusRecord(status,header);
	  // Identity may survive a public source failure, but private source names,
	  // old content, numbers and observation times never survive this path.
	  if (!metadata || metadata.source === SOURCE_KIND.MUSIC || metadata.source === SOURCE_KIND.NOTIFICATION) { return out; }
	  out[20]=metadata.kind; out[22]=metadata.unit.length; out[23]=metadata.label.length;
	  out[24]=metadata.source; out[25]=metadata.detail; out[26]=metadata.qualifiers;
	  return out.concat(metadata.unit,metadata.label);
	}
	function record(slot, nowSec, version) {
	  var header = version === 4 ? HEADER_BYTES : version === 3 ? 52 : 20;
	  if (slot === undefined || slot === null) { return statusRecord(EMPTY,header); }
	  if (!object(slot) || !integer(slot.status, 0, 7)) { return statusRecord(UNSUPPORTED,header); }
	  if (slot.status !== READY) { return unavailableRecord(slot,slot.status,version,header); }
	  if (!integer(nowSec, 1, MAX_EPOCH) || !integer(slot.confirmedAt, 1, MAX_EPOCH) ||
	      !integer(slot.validUntil, 1, MAX_EPOCH) || slot.confirmedAt > nowSec) { return statusRecord(UNAVAILABLE,header); }
	  var until = Math.min(slot.validUntil, slot.confirmedAt + MAX_AGE, MAX_EPOCH);
	  if (nowSec >= until) { return unavailableRecord(slot,version === 4 ? EXPIRED : UNAVAILABLE,version,header); }
	  var text = utf8(normalizeText(slot.text,version >= 3 ? 128 : 48));
	  var event = !text.length && integer(slot.timestamp, 1, MAX_EPOCH) ? slot.timestamp : null;
	  var bitmap = bitmapOf(slot.bitmap,version >= 3 ? 40 : 24);
	  var flags = (text.length ? TEXT : event !== null ? TIMESTAMP : 0) |
	    (bitmap ? BITMAP | (bitmap.image ? IMAGE : 0) : 0);
	  if (!flags) { return statusRecord(slot.timestamp === 0 ? UNAVAILABLE : UNSUPPORTED,header); }
	  var out = statusRecord(READY,header);
	  out[0] = flags;
	  out[2] = text.length;
	  out[3] = bitmap ? bitmap.width : 0;
	  out[4] = bitmap ? bitmap.height : 0;
	  // V2 uses the former reserved byte for a provider-aware presentation hint.
	  // Generic percentages (battery, humidity) never acquire precipitation art.
	  out[5] = version !== 1 && slot.displayKind === 1 && text.length ? 1 : 0;
	  u32(out, 6, slot.confirmedAt);
	  u32(out, 10, until);
	  u16(out, 14, bitmap ? bitmap.pixels.length : 0);
	  if (event !== null) { u32(out, 16, event); }
	  var semantic = version >= 3 ? semanticOf(slot,version,false) : null;
	  if (semantic) {
	    out[20] = semantic.kind; out[21] = semantic.flags;
	    out[22] = semantic.unit.length; out[23] = semantic.label.length; out[24] = semantic.source;
	    if (version === 4) {
	      out[25]=semantic.detail; out[26]=semantic.qualifiers; u32(out,52,semantic.observedAt);
	    }
	    if (semantic.flags & 1) { f64(out,28,semantic.value); }
	    if (semantic.flags & 2) { f64(out,36,semantic.min); }
	    if (semantic.flags & 4) { f64(out,44,semantic.max); }
	  }
	  out = out.concat(text,semantic ? semantic.unit : [],semantic ? semantic.label : []);
	  if (bitmap) { out = out.concat(bitmap.palette, bitmap.pixels); }
	  return out;
	}
	
	/** Five fixed slots, including holes. No fetching, cache mutation or inference. */
	function packComplications(slots, nowSec, version) {
	  version = version === 1 || version === 2 || version === 3 ? version : VERSION;
	  var out = [version, 0, 0, 0, 0, 0];
	  var values = Array.isArray(slots) ? slots : [];
	  for (var i = 0; i < SLOT_COUNT; i++) { out = out.concat(record(values[i], nowSec,version)); }
	  u16(out, 2, out.length);
	  // CRC bytes stay zero while calculating the checksum over the whole packet.
	  u16(out, 4, crc16Xmodem(out));
	  return out;
	}
	
	module.exports = {packComplications:packComplications, normalizeText:normalizeText, crc16Xmodem:crc16Xmodem, SEMANTIC_KIND:SEMANTIC_KIND, SOURCE_KIND:SOURCE_KIND, DETAIL_KIND:DETAIL_KIND, QUALIFIERS:QUALIFIERS};


/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var library=__webpack_require__(8);
	var selection=library.selection,wire=library.wire;
	var TIMER='50e9ef12-a5ab-4369-a3b5-3447bfba5151';
	var MUSIC_SOURCE='00000000-0000-0000-0001-000000000003';
	var MUSIC_APP='1f03293d-47af-4f28-b960-f2b02a6dd757';
	function symbolBitmap(kind){
	  var pixels=[],size=40;
	  for(var i=0;i<800;i++)pixels.push(0);
	  function dot(x,y){x=Math.round(x);y=Math.round(y);if(x<0||x>=40||y<0||y>=40)return;var at=y*20+(x>>1);pixels[at]|=x&1?1:16;}
	  function line(x1,y1,x2,y2,w){var n=Math.max(Math.abs(x2-x1),Math.abs(y2-y1),1);for(var p=0;p<=n;p++)for(var yy=-w;yy<=w;yy++)for(var xx=-w;xx<=w;xx++)if(xx*xx+yy*yy<=w*w)dot(x1+(x2-x1)*p/n+xx,y1+(y2-y1)*p/n+yy);}
	  function circle(cx,cy,r,fill){for(var y=cy-r;y<=cy+r;y++)for(var x=cx-r;x<=cx+r;x++){var d=(x-cx)*(x-cx)+(y-cy)*(y-cy);if(d<=r*r&&(fill||d>=(r-2)*(r-2)))dot(x,y);}}
	  function rect(l,t,r,b){line(l,t,r,t,1);line(r,t,r,b,1);line(r,b,l,b,1);line(l,b,l,t,1);}
	  if(kind===2){circle(20,22,12);line(20,5,20,9,1);line(16,4,24,4,1);line(20,22,20,14,1);}
	  else if(kind===4){rect(6,8,33,29);line(15,29,10,35,1);line(10,35,23,29,1);}
	  else if(kind===5){
	    line(9,7,6,13,2);line(6,13,10,23,2);line(10,23,20,33,2);
	    line(20,33,30,35,2);line(30,35,35,28,2);line(35,28,27,23,2);
	    line(27,23,22,28,2);line(22,28,12,18,2);line(12,18,17,13,2);line(17,13,9,7,2);
	  }
	  else if(kind===7){circle(20,7,4);line(20,13,20,25,1);line(8,18,32,18,1);line(20,25,10,35,1);line(20,25,30,35,1);}
	  else if(kind===8){
	    circle(20,9,5,true);circle(20,21,5,true);
	    for(var my=9;my<=21;my++)line(15,my,25,my,1);
	    line(9,15,9,23,1);line(9,23,15,30,1);line(15,30,25,30,1);
	    line(25,30,31,23,1);line(31,23,31,15,1);line(20,30,20,36,1);line(14,36,26,36,1);
	  }
	  else if(kind===9){line(20,5,20,29,1);line(9,20,20,30,1);line(31,20,20,30,1);line(7,35,33,35,1);}
	  else if(kind===10){rect(6,9,34,34);line(20,9,20,21,1);line(6,14,34,14,1);}
	  return {width:size,height:size,palette:[0,192],pixels:pixels};
	}
	function media(card){return card.type==='media'||card.kind==='music'||card.presentation===2;}
	function project(input){
	  if(!input||!library.summaryView)return null;
	  var candidate=input;
	  if(input.content!==undefined&&library.activity)candidate=library.activity.toView(input);
	  var card;
	  if(input.type==='standard'||input.type==='media')card=library.summary.toView(input);
	  else if(input.presentation!==undefined)card=library.summaryView.normalize(candidate);
	  else {
	    if(candidate&&candidate.kind==='music'&&candidate.support&&candidate.support.type==='text'&&candidate.support.text.trim()==='?'){
	      candidate=JSON.parse(JSON.stringify(candidate));candidate.support=null;
	    }
	    card=library.summaryView.fromLegacy(candidate);
	  }
	  if(!card)return null;
	  // Timer's native-owner adapter explicitly permits bounded public countdown
	  // predictions. Other saved/uncertain sources need a provenance-aware host.
	  if(card.unconfirmed&&card.provider!==TIMER)return null;
	  if(!card.image&&[2,4,5,7,8,9,10].indexOf(card.identitySymbol)>=0){
	    card.image=symbolBitmap(card.identitySymbol);card=library.summaryView.normalize(card);
	    if(!card)return null;
	  }
	  if(!card.openApp&&input.openApp)card.openApp=input.openApp;
	  if(!card.openApp&&card.provider===TIMER)card.openApp={watchAppUuid:TIMER};
	  if(!card.openApp&&card.provider===MUSIC_SOURCE&&media(card))card.openApp={watchAppUuid:MUSIC_APP};
	  if(input.selectionKey)card.selectionKey=input.selectionKey;
	  if(input.providerName)card.providerName=input.providerName;
	  return card;
	}
	function select(cards,prefs,extraMusic,extraNotifications){
	  var all=(Array.isArray(cards)?cards:[]).slice();
	  if(extraMusic){
	    var duplicate=all.some(function(card){return card.provider===extraMusic.provider&&media(card);});
	    if(!duplicate&&selection.normalizePreferences(prefs).hidden.indexOf(extraMusic.provider)<0)all.push(extraMusic);
	  }
	  if(extraNotifications){
	    var notificationDuplicate=all.some(function(card){return card.selectionKey==='builtin:notifications';});
	    if(!notificationDuplicate&&selection.normalizePreferences(prefs).hidden.indexOf(extraNotifications.provider)<0)all.push(extraNotifications);
	  }
	  all=all.map(function(card,index){return {card:card,index:index};}).sort(function(a,b){
	    // This is only the stable default. The shared selector applies explicit
	    // Dynamic priorities afterwards, so Notifications can take either role.
	    function rank(card){return card.selectionKey==='builtin:notifications'?0:media(card)?2:1;}
	    return rank(a.card)-rank(b.card)||a.index-b.index;
	  }).map(function(entry){return entry.card;});
	  return selection.select(all.map(project).filter(Boolean),prefs);
	}
	module.exports={project:project,select:select};


/***/ }),
/* 19 */
/***/ (function(module, exports) {

	'use strict';
	
	// Only destination app identities and freshness/session metadata cross an app
	// switch. Source records, occurrence IDs and private display contents do not.
	var KEY='dynamic-navigation-v1';
	var UUID='cc1281f1-3b4d-45b5-b235-6881b1fd8fbd';
	var LEASE=45000,MAX=4294967295;
	function object(value){return value&&typeof value==='object'&&!Array.isArray(value);}
	function integer(value,min,max){return typeof value==='number'&&isFinite(value)&&Math.floor(value)===value&&value>=min&&value<=max;}
	function uuid(value){return typeof value==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(value)&&value!=='00000000-0000-0000-0000-000000000000';}
	function keys(value,allowed){return object(value)&&Object.keys(value).every(function(key){return allowed.indexOf(key)>=0;});}
	function destination(value){return value===null?null:keys(value,['watchAppUuid'])&&uuid(value.watchAppUuid)?{watchAppUuid:value.watchAppUuid}:undefined;}
	function remove(storage){try{if(typeof storage.removeItem==='function')storage.removeItem(KEY);else storage.setItem(KEY,'');}catch(ignored){}}
	function read(storage,now){
	  var hint,text;
	  try{text=storage.getItem(KEY);if(text===null||text===undefined)return null;if(typeof text!=='string'||!text||text.length>512){remove(storage);return null;}hint=JSON.parse(text);}catch(ignored){remove(storage);return null;}
	  var primary=object(hint)?destination(hint.primary):undefined;
	  var secondary=object(hint)?destination(hint.secondary):undefined;
	  if(!keys(hint,['schema','watchfaceUuid','nativeSession','viewSequence','presentationSequence','presentedAtMs','expiresAtMs','primary','secondary'])||
	      hint.schema!==1||hint.watchfaceUuid!==UUID||!integer(hint.nativeSession,2,MAX)||
	      !integer(hint.viewSequence,1,MAX)||!integer(hint.presentationSequence,1,MAX)||
	      !integer(hint.presentedAtMs,1,9007199254740991)||!integer(hint.expiresAtMs,1,9007199254740991)||
	      hint.presentedAtMs>now||hint.expiresAtMs<=now||hint.expiresAtMs<=hint.presentedAtMs||
	      hint.expiresAtMs-hint.presentedAtMs>LEASE||primary===undefined||secondary===undefined||(!primary&&!secondary)){
	    remove(storage);return null;
	  }
	  return {schema:1,watchfaceUuid:UUID,nativeSession:hint.nativeSession,
	    viewSequence:hint.viewSequence,presentationSequence:hint.presentationSequence,
	    presentedAtMs:hint.presentedAtMs,expiresAtMs:hint.expiresAtMs,primary:primary,secondary:secondary};
	}
	function source(storage,now){
	  var hint=read(storage,now);
	  return {validUntilMs:hint?hint.expiresAtMs:now+30000,instances:hint?[{instanceId:'current',properties:{hint:{longText:{text:JSON.stringify(hint)}}}}]:[]};
	}
	function create(options){
	  var storage=options.storage,now=options.now||Date.now;
	  var mapping=null,lastPresentation=0;
	  remove(storage);
	  function view(snapshot){
	    if(!snapshot||!integer(snapshot.session,2,MAX)||!integer(snapshot.sequence,1,MAX)||!Array.isArray(snapshot.cards)||snapshot.cards.length>2){mapping=null;remove(storage);return;}
	    if(mapping&&mapping.session===snapshot.session&&snapshot.sequence<=mapping.sequence)return;
	    if(!mapping||mapping.session!==snapshot.session)lastPresentation=0;
	    mapping={session:snapshot.session,sequence:snapshot.sequence,cards:snapshot.cards.map(function(card){
	      var target=destination(card.openApp===undefined?null:card.openApp);
	      return {destination:target===undefined?null:target,until:integer(card.validUntil,1,MAX)?card.validUntil*1000:0};
	    })};
	    remove(storage);
	  }
	  function u32(bytes,at){return (bytes[at]+bytes[at+1]*256+bytes[at+2]*65536+bytes[at+3]*16777216)>>>0;}
	  function receive(bytes){
	    if(!mapping||!bytes||bytes.length!==24||bytes[0]!==1||bytes[3]!==0)return false;
	    for(var i=0;i<bytes.length;i++)if(!integer(bytes[i],0,255))return false;
	    var session=u32(bytes,4),sequence=u32(bytes,8),presentation=u32(bytes,12),reported=u32(bytes,16)*1000,until=u32(bytes,20)*1000;
	    if(session!==mapping.session||sequence!==mapping.sequence||!presentation||presentation<=lastPresentation)return false;
	    var primary=bytes[1],secondary=bytes[2],current=now();
	    if((primary!==255&&primary>=mapping.cards.length)||(secondary!==255&&secondary>=mapping.cards.length)||
	        (secondary!==255&&(primary===255||primary===secondary)))return false;
	    lastPresentation=presentation;
	    if(primary===255){remove(storage);return true;}
	    if(!reported||reported>current+5000||current-reported>=LEASE){remove(storage);return false;}
	    var first=mapping.cards[primary];
	    var second=secondary===255?null:mapping.cards[secondary];
	    var expires=Math.min(current+LEASE,reported+LEASE,until,first.until,second?second.until:Infinity);
	    if(expires<=current||(!first.destination&&(!second||!second.destination))){remove(storage);return true;}
	    var hint={schema:1,watchfaceUuid:UUID,nativeSession:session,viewSequence:sequence,presentationSequence:presentation,
	      presentedAtMs:current,expiresAtMs:expires,primary:first.destination,secondary:second?second.destination:null};
	    var text=JSON.stringify(hint);if(text.length>512){remove(storage);return false;}
	    try{storage.setItem(KEY,text);return storage.getItem(KEY)===text;}catch(ignored){remove(storage);return false;}
	  }
	  return {view:view,receive:receive,clear:function(){mapping=null;remove(storage);}};
	}
	module.exports={KEY:KEY,UUID:UUID,LEASE:LEASE,create:create,read:read,source:source};


/***/ }),
/* 20 */
/***/ (function(module, exports) {

	'use strict';
	
	// Dynamic settings and source-status framing are translated here.
	// Provider names, values and units remain as received from Pebble.
	var MESSAGES = {
	  "en": {
	    "title": "Dynamic Settings",
	    "appearance": "Appearance",
	    "background": "Background color",
	    "textColor": "Text color",
	    "time12": "12-hour time",
	    "largeText": "Big text",
	    "largeTextHelp": "Larger date, readings and messages. The clock fits the available width.",
	    "showStatus": "Status indicators",
	    "statusIndicatorsHelp": "Low watch or phone battery and lost connection.",
	    "complications": "Complications",
	    "complicationsHelp": "Choose slots 1 and 2 in Pebble → Settings → Complications.",
	    "adaptiveHelp": "Complications 1 and 2 sit side by side. Both shrink above music or notifications.",
	    "complicationsUnits": "Units come from Pebble and the selected plugin.",
	    "dynamicContent": "Dynamic content",
	    "showMusic": "Show music while playing",
	    "showNotifications": "New notifications",
	    "notificationsHelp": "Allow notification access in Pebble. Only new notifications appear.",
	    "notificationPreview": "Include message text",
	    "notificationApps": "Apps to show",
	    "notificationAppsHelp": "Separate app names with commas. Empty means all allowed apps.",
	    "statusHelp": "Status & help",
	    "complicationsWaiting": "Complications: waiting for Pebble",
	    "contextWaiting": "Dynamic content: waiting for Pebble",
	    "adaptivePeek": "Timeline Peek keeps the clock and complications 1 and 2. Its event panel takes priority over music and notifications.",
	    "save": "Save settings",
	    "complicationsStatus": "Complications: {ready}/{configured} ready",
	    "complicationsDisabled": "Enable plugins in Pebble to use complications.",
	    "complicationsError": "Complication error: {error}",
	    "contextReady": "Dynamic content: ready",
	    "contextError": "Dynamic content: {error}",
	    "stateOn": "On",
	    "stateOff": "Off",
	    "accentColor": "Accent color",
	    "accentHelp": "Color for reading symbols and rain gauges.",
	    "animations": "Animations",
	    "animationsHelp": "Short transitions when music or notifications change."
	  },
	  "cs": {
	    "title": "Nastavení Dynamic",
	    "appearance": "Vzhled",
	    "background": "Barva pozadí",
	    "textColor": "Barva textu",
	    "time12": "12hodinový čas",
	    "largeText": "Velký text",
	    "largeTextHelp": "Větší datum, údaje a zprávy. Čas se přizpůsobí dostupné šířce.",
	    "showStatus": "Ukazatele stavu",
	    "statusIndicatorsHelp": "Slabá baterie hodinek nebo telefonu a ztráta připojení.",
	    "complications": "Komplikace",
	    "complicationsHelp": "Vyberte pozice 1 a 2 v Pebble → Nastavení → Komplikace.",
	    "adaptiveHelp": "Komplikace 1 a 2 jsou vedle sebe. Obě se zmenší nad hudbou nebo oznámením.",
	    "complicationsUnits": "Jednotky se přebírají z Pebble a vybraného pluginu.",
	    "dynamicContent": "Dynamický obsah",
	    "showMusic": "Zobrazit hudbu při přehrávání",
	    "showNotifications": "Nová oznámení",
	    "notificationsHelp": "Povolte přístup k oznámením v Pebble. Zobrazí se jen nová oznámení.",
	    "notificationPreview": "Zahrnout text zprávy",
	    "notificationApps": "Zobrazené aplikace",
	    "notificationAppsHelp": "Názvy aplikací oddělte čárkami. Prázdné pole povolí všechny povolené aplikace.",
	    "statusHelp": "Stav a nápověda",
	    "complicationsWaiting": "Komplikace: čeká se na Pebble",
	    "contextWaiting": "Dynamický obsah: čeká se na Pebble",
	    "adaptivePeek": "Timeline Peek zachová čas a komplikace 1 a 2. Panel události má přednost před hudbou a oznámeními.",
	    "save": "Uložit nastavení",
	    "complicationsStatus": "Komplikace: připraveno {ready}/{configured}",
	    "complicationsDisabled": "Pro používání komplikací zapněte pluginy v Pebble.",
	    "complicationsError": "Chyba komplikace: {error}",
	    "contextReady": "Dynamický obsah: připraveno",
	    "contextError": "Dynamický obsah: {error}",
	    "stateOn": "Zapnuto",
	    "stateOff": "Vypnuto",
	    "accentColor": "Barva zvýraznění",
	    "accentHelp": "Barva symbolů u údajů a ukazatelů deště.",
	    "animations": "Animace",
	    "animationsHelp": "Krátké přechody při změně hudby nebo oznámení."
	  },
	  "sk": {
	    "title": "Nastavenia Dynamic",
	    "appearance": "Vzhľad",
	    "background": "Farba pozadia",
	    "textColor": "Farba textu",
	    "time12": "12-hodinový čas",
	    "largeText": "Veľký text",
	    "largeTextHelp": "Väčší dátum, údaje a správy. Čas sa prispôsobí dostupnej šírke.",
	    "showStatus": "Ukazovatele stavu",
	    "statusIndicatorsHelp": "Slabá batéria hodiniek alebo telefónu a strata pripojenia.",
	    "complications": "Komplikácie",
	    "complicationsHelp": "Vyberte pozície 1 a 2 v Pebble → Nastavenia → Komplikácie.",
	    "adaptiveHelp": "Komplikácie 1 a 2 sú vedľa seba. Obe sa zmenšia nad hudbou alebo oznámením.",
	    "complicationsUnits": "Jednotky sa preberajú z Pebble a vybraného pluginu.",
	    "dynamicContent": "Dynamický obsah",
	    "showMusic": "Zobraziť hudbu počas prehrávania",
	    "showNotifications": "Nové oznámenia",
	    "notificationsHelp": "Povoľte prístup k oznámeniam v Pebble. Zobrazia sa iba nové oznámenia.",
	    "notificationPreview": "Zahrnúť text správy",
	    "notificationApps": "Zobrazené aplikácie",
	    "notificationAppsHelp": "Názvy aplikácií oddeľte čiarkami. Prázdne pole povolí všetky povolené aplikácie.",
	    "statusHelp": "Stav a pomocník",
	    "complicationsWaiting": "Komplikácie: čaká sa na Pebble",
	    "contextWaiting": "Dynamický obsah: čaká sa na Pebble",
	    "adaptivePeek": "Timeline Peek zachová čas a komplikácie 1 a 2. Panel udalosti má prednosť pred hudbou a oznámeniami.",
	    "save": "Uložiť nastavenia",
	    "complicationsStatus": "Komplikácie: pripravených {ready}/{configured}",
	    "complicationsDisabled": "Na používanie komplikácií zapnite pluginy v Pebble.",
	    "complicationsError": "Chyba komplikácie: {error}",
	    "contextReady": "Dynamický obsah: pripravený",
	    "contextError": "Dynamický obsah: {error}",
	    "stateOn": "Zapnuté",
	    "stateOff": "Vypnuté",
	    "accentColor": "Farba zvýraznenia",
	    "accentHelp": "Farba symbolov pri údajoch a ukazovateľov dažďa.",
	    "animations": "Animácie",
	    "animationsHelp": "Krátke prechody pri zmene hudby alebo oznámení."
	  },
	  "de": {
	    "title": "Dynamic-Einstellungen",
	    "appearance": "Aussehen",
	    "background": "Hintergrundfarbe",
	    "textColor": "Textfarbe",
	    "time12": "12-Stunden-Zeit",
	    "largeText": "Großer Text",
	    "largeTextHelp": "Größeres Datum, größere Werte und Nachrichten. Die Uhrzeit passt sich der verfügbaren Breite an.",
	    "showStatus": "Statusanzeigen",
	    "statusIndicatorsHelp": "Niedriger Akku von Uhr oder Telefon und unterbrochene Verbindung.",
	    "complications": "Komplikationen",
	    "complicationsHelp": "Wähle die Plätze 1 und 2 unter Pebble → Einstellungen → Komplikationen.",
	    "adaptiveHelp": "Komplikationen 1 und 2 stehen nebeneinander. Über Musik oder Mitteilungen werden beide kleiner.",
	    "complicationsUnits": "Die Einheiten kommen von Pebble und dem gewählten Plugin.",
	    "dynamicContent": "Dynamische Inhalte",
	    "showMusic": "Musik während der Wiedergabe anzeigen",
	    "showNotifications": "Neue Mitteilungen",
	    "notificationsHelp": "Erlaube Mitteilungszugriff in Pebble. Nur neue Mitteilungen werden angezeigt.",
	    "notificationPreview": "Nachrichtentext einbeziehen",
	    "notificationApps": "Anzuzeigende Apps",
	    "notificationAppsHelp": "App-Namen durch Kommas trennen. Leer lassen für alle zugelassenen Apps.",
	    "statusHelp": "Status und Hilfe",
	    "complicationsWaiting": "Komplikationen: Warten auf Pebble",
	    "contextWaiting": "Dynamische Inhalte: Warten auf Pebble",
	    "adaptivePeek": "Timeline Peek behält die Uhr und die Komplikationen 1 und 2 bei. Das Ereignisfeld hat Vorrang vor Musik und Mitteilungen.",
	    "save": "Einstellungen speichern",
	    "complicationsStatus": "Komplikationen: {ready}/{configured} bereit",
	    "complicationsDisabled": "Aktiviere Plugins in Pebble, um Komplikationen zu nutzen.",
	    "complicationsError": "Komplikationsfehler: {error}",
	    "contextReady": "Dynamische Inhalte: bereit",
	    "contextError": "Dynamische Inhalte: {error}",
	    "stateOn": "Ein",
	    "stateOff": "Aus",
	    "accentColor": "Akzentfarbe",
	    "accentHelp": "Farbe der Messwertsymbole und Regenanzeigen.",
	    "animations": "Animationen",
	    "animationsHelp": "Kurze Übergänge bei Änderungen von Musik oder Benachrichtigungen."
	  },
	  "fr": {
	    "title": "Réglages Dynamic",
	    "appearance": "Apparence",
	    "background": "Couleur de fond",
	    "textColor": "Couleur du texte",
	    "time12": "Format 12 heures",
	    "largeText": "Grand texte",
	    "largeTextHelp": "Date, valeurs et messages plus grands. L’heure s’adapte à la largeur disponible.",
	    "showStatus": "Indicateurs d’état",
	    "statusIndicatorsHelp": "Batterie faible de la montre ou du téléphone et perte de connexion.",
	    "complications": "Complications",
	    "complicationsHelp": "Choisissez les emplacements 1 et 2 dans Pebble → Réglages → Complications.",
	    "adaptiveHelp": "Les complications 1 et 2 sont côte à côte. Elles rétrécissent au-dessus de la musique ou des notifications.",
	    "complicationsUnits": "Les unités proviennent de Pebble et du plugin sélectionné.",
	    "dynamicContent": "Contenu dynamique",
	    "showMusic": "Afficher la musique pendant la lecture",
	    "showNotifications": "Nouvelles notifications",
	    "notificationsHelp": "Autorisez l’accès aux notifications dans Pebble. Seules les nouvelles apparaissent.",
	    "notificationPreview": "Inclure le texte du message",
	    "notificationApps": "Applications à afficher",
	    "notificationAppsHelp": "Séparez les noms des apps par des virgules. Vide pour toutes les apps autorisées.",
	    "statusHelp": "État et aide",
	    "complicationsWaiting": "Complications : en attente de Pebble",
	    "contextWaiting": "Contenu dynamique : en attente de Pebble",
	    "adaptivePeek": "Timeline Peek conserve l’heure et les complications 1 et 2. Le panneau d’événement est prioritaire sur la musique et les notifications.",
	    "save": "Enregistrer les réglages",
	    "complicationsStatus": "Complications : {ready}/{configured} prêtes",
	    "complicationsDisabled": "Activez les plugins dans Pebble pour utiliser les complications.",
	    "complicationsError": "Erreur de complication : {error}",
	    "contextReady": "Contenu dynamique : prêt",
	    "contextError": "Contenu dynamique : {error}",
	    "stateOn": "Activé",
	    "stateOff": "Désactivé",
	    "accentColor": "Couleur d’accentuation",
	    "accentHelp": "Couleur des symboles des données et des jauges de pluie.",
	    "animations": "Animations",
	    "animationsHelp": "Transitions brèves lors des changements de musique ou de notifications."
	  },
	  "es": {
	    "title": "Ajustes de Dynamic",
	    "appearance": "Apariencia",
	    "background": "Color de fondo",
	    "textColor": "Color del texto",
	    "time12": "Formato de 12 horas",
	    "largeText": "Texto grande",
	    "largeTextHelp": "Fecha, valores y mensajes más grandes. La hora se ajusta al ancho disponible.",
	    "showStatus": "Indicadores de estado",
	    "statusIndicatorsHelp": "Batería baja del reloj o teléfono y pérdida de conexión.",
	    "complications": "Complicaciones",
	    "complicationsHelp": "Elige las posiciones 1 y 2 en Pebble → Ajustes → Complicaciones.",
	    "adaptiveHelp": "Las complicaciones 1 y 2 están una junto a otra. Ambas se reducen sobre la música o las notificaciones.",
	    "complicationsUnits": "Las unidades proceden de Pebble y del plugin seleccionado.",
	    "dynamicContent": "Contenido dinámico",
	    "showMusic": "Mostrar música durante la reproducción",
	    "showNotifications": "Nuevas notificaciones",
	    "notificationsHelp": "Permite el acceso a notificaciones en Pebble. Solo aparecen las nuevas.",
	    "notificationPreview": "Incluir el texto del mensaje",
	    "notificationApps": "Aplicaciones que mostrar",
	    "notificationAppsHelp": "Separa los nombres de las apps con comas. Vacío permite todas las apps autorizadas.",
	    "statusHelp": "Estado y ayuda",
	    "complicationsWaiting": "Complicaciones: esperando a Pebble",
	    "contextWaiting": "Contenido dinámico: esperando a Pebble",
	    "adaptivePeek": "Timeline Peek conserva el reloj y las complicaciones 1 y 2. El panel de eventos tiene prioridad sobre la música y las notificaciones.",
	    "save": "Guardar ajustes",
	    "complicationsStatus": "Complicaciones: {ready}/{configured} listas",
	    "complicationsDisabled": "Activa los plugins en Pebble para usar complicaciones.",
	    "complicationsError": "Error de complicación: {error}",
	    "contextReady": "Contenido dinámico: listo",
	    "contextError": "Contenido dinámico: {error}",
	    "stateOn": "Activado",
	    "stateOff": "Desactivado",
	    "accentColor": "Color de acento",
	    "accentHelp": "Color de los símbolos de las lecturas y los indicadores de lluvia.",
	    "animations": "Animaciones",
	    "animationsHelp": "Transiciones breves al cambiar la música o las notificaciones."
	  },
	  "it": {
	    "title": "Impostazioni Dynamic",
	    "appearance": "Aspetto",
	    "background": "Colore dello sfondo",
	    "textColor": "Colore del testo",
	    "time12": "Formato a 12 ore",
	    "largeText": "Testo grande",
	    "largeTextHelp": "Data, valori e messaggi più grandi. L’ora si adatta alla larghezza disponibile.",
	    "showStatus": "Indicatori di stato",
	    "statusIndicatorsHelp": "Batteria scarica di orologio o telefono e connessione persa.",
	    "complications": "Complicazioni",
	    "complicationsHelp": "Scegli le posizioni 1 e 2 in Pebble → Impostazioni → Complicazioni.",
	    "adaptiveHelp": "Le complicazioni 1 e 2 sono affiancate. Entrambe si riducono sopra musica o notifiche.",
	    "complicationsUnits": "Le unità provengono da Pebble e dal plugin selezionato.",
	    "dynamicContent": "Contenuti dinamici",
	    "showMusic": "Mostra la musica durante la riproduzione",
	    "showNotifications": "Nuove notifiche",
	    "notificationsHelp": "Consenti l’accesso alle notifiche in Pebble. Appaiono solo quelle nuove.",
	    "notificationPreview": "Includi il testo del messaggio",
	    "notificationApps": "App da mostrare",
	    "notificationAppsHelp": "Separa i nomi delle app con virgole. Lascia vuoto per tutte le app autorizzate.",
	    "statusHelp": "Stato e aiuto",
	    "complicationsWaiting": "Complicazioni: in attesa di Pebble",
	    "contextWaiting": "Contenuti dinamici: in attesa di Pebble",
	    "adaptivePeek": "Timeline Peek mantiene l’orologio e le complicazioni 1 e 2. Il pannello eventi ha la precedenza su musica e notifiche.",
	    "save": "Salva impostazioni",
	    "complicationsStatus": "Complicazioni: {ready}/{configured} pronte",
	    "complicationsDisabled": "Abilita i plugin in Pebble per usare le complicazioni.",
	    "complicationsError": "Errore della complicazione: {error}",
	    "contextReady": "Contenuti dinamici: pronti",
	    "contextError": "Contenuti dinamici: {error}",
	    "stateOn": "Attivato",
	    "stateOff": "Disattivato",
	    "accentColor": "Colore accento",
	    "accentHelp": "Colore dei simboli dei valori e degli indicatori di pioggia.",
	    "animations": "Animazioni",
	    "animationsHelp": "Brevi transizioni quando cambiano musica o notifiche."
	  },
	  "pt": {
	    "title": "Configurações do Dynamic",
	    "appearance": "Aparência",
	    "background": "Cor de fundo",
	    "textColor": "Cor do texto",
	    "time12": "Formato de 12 horas",
	    "largeText": "Texto grande",
	    "largeTextHelp": "Data, valores e mensagens maiores. A hora adapta-se à largura disponível.",
	    "showStatus": "Indicadores de estado",
	    "statusIndicatorsHelp": "Bateria fraca do relógio ou telefone e perda de conexão.",
	    "complications": "Complicações",
	    "complicationsHelp": "Escolha as posições 1 e 2 em Pebble → Configurações → Complicações.",
	    "adaptiveHelp": "As complicações 1 e 2 ficam lado a lado. Ambas diminuem acima da música ou das notificações.",
	    "complicationsUnits": "As unidades vêm do Pebble e do plugin selecionado.",
	    "dynamicContent": "Conteúdo dinâmico",
	    "showMusic": "Mostrar música durante a reprodução",
	    "showNotifications": "Novas notificações",
	    "notificationsHelp": "Permita acesso às notificações no Pebble. Apenas as novas aparecem.",
	    "notificationPreview": "Incluir o texto da mensagem",
	    "notificationApps": "Aplicativos a mostrar",
	    "notificationAppsHelp": "Separe os nomes dos apps por vírgulas. Vazio permite todos os apps autorizados.",
	    "statusHelp": "Estado e ajuda",
	    "complicationsWaiting": "Complicações: à espera do Pebble",
	    "contextWaiting": "Conteúdo dinâmico: à espera do Pebble",
	    "adaptivePeek": "O Timeline Peek mantém o relógio e as complicações 1 e 2. O painel de eventos tem prioridade sobre música e notificações.",
	    "save": "Salvar configurações",
	    "complicationsStatus": "Complicações: {ready}/{configured} prontas",
	    "complicationsDisabled": "Ative os plugins no Pebble para usar complicações.",
	    "complicationsError": "Erro de complicação: {error}",
	    "contextReady": "Conteúdo dinâmico: pronto",
	    "contextError": "Conteúdo dinâmico: {error}",
	    "stateOn": "Ativado",
	    "stateOff": "Desativado",
	    "accentColor": "Cor de destaque",
	    "accentHelp": "Cor dos símbolos dos valores e dos indicadores de chuva.",
	    "animations": "Animações",
	    "animationsHelp": "Transições curtas quando a música ou as notificações mudam."
	  },
	  "nl": {
	    "title": "Dynamic-instellingen",
	    "appearance": "Uiterlijk",
	    "background": "Achtergrondkleur",
	    "textColor": "Tekstkleur",
	    "time12": "12-uursnotatie",
	    "largeText": "Grote tekst",
	    "largeTextHelp": "Grotere datum, waarden en berichten. De tijd past zich aan de beschikbare breedte aan.",
	    "showStatus": "Statusindicatoren",
	    "statusIndicatorsHelp": "Lage batterij van horloge of telefoon en verbroken verbinding.",
	    "complications": "Complicaties",
	    "complicationsHelp": "Kies posities 1 en 2 via Pebble → Instellingen → Complicaties.",
	    "adaptiveHelp": "Complicaties 1 en 2 staan naast elkaar. Beide worden kleiner boven muziek of meldingen.",
	    "complicationsUnits": "De eenheden komen van Pebble en de gekozen plugin.",
	    "dynamicContent": "Dynamische inhoud",
	    "showMusic": "Muziek tonen tijdens het afspelen",
	    "showNotifications": "Nieuwe meldingen",
	    "notificationsHelp": "Sta meldingentoegang toe in Pebble. Alleen nieuwe meldingen verschijnen.",
	    "notificationPreview": "Berichttekst opnemen",
	    "notificationApps": "Te tonen apps",
	    "notificationAppsHelp": "Scheid app-namen met komma’s. Leeg betekent alle toegestane apps.",
	    "statusHelp": "Status en hulp",
	    "complicationsWaiting": "Complicaties: wachten op Pebble",
	    "contextWaiting": "Dynamische inhoud: wachten op Pebble",
	    "adaptivePeek": "Timeline Peek behoudt de klok en complicaties 1 en 2. Het afsprakenpaneel heeft voorrang op muziek en meldingen.",
	    "save": "Instellingen opslaan",
	    "complicationsStatus": "Complicaties: {ready}/{configured} gereed",
	    "complicationsDisabled": "Schakel plugins in Pebble in om complicaties te gebruiken.",
	    "complicationsError": "Complicatiefout: {error}",
	    "contextReady": "Dynamische inhoud: gereed",
	    "contextError": "Dynamische inhoud: {error}",
	    "stateOn": "Aan",
	    "stateOff": "Uit",
	    "accentColor": "Accentkleur",
	    "accentHelp": "Kleur voor meetsymbolen en regenmeters.",
	    "animations": "Animaties",
	    "animationsHelp": "Korte overgangen wanneer muziek of meldingen veranderen."
	  },
	  "pl": {
	    "title": "Ustawienia Dynamic",
	    "appearance": "Wygląd",
	    "background": "Kolor tła",
	    "textColor": "Kolor tekstu",
	    "time12": "Format 12-godzinny",
	    "largeText": "Duży tekst",
	    "largeTextHelp": "Większa data, wartości i wiadomości. Godzina dopasowuje się do dostępnej szerokości.",
	    "showStatus": "Wskaźniki stanu",
	    "statusIndicatorsHelp": "Słaba bateria zegarka lub telefonu i utrata połączenia.",
	    "complications": "Komplikacje",
	    "complicationsHelp": "Wybierz pozycje 1 i 2 w Pebble → Ustawienia → Komplikacje.",
	    "adaptiveHelp": "Komplikacje 1 i 2 są obok siebie. Obie zmniejszają się nad muzyką lub powiadomieniami.",
	    "complicationsUnits": "Jednostki pochodzą z Pebble i wybranej wtyczki.",
	    "dynamicContent": "Treść dynamiczna",
	    "showMusic": "Pokazuj muzykę podczas odtwarzania",
	    "showNotifications": "Nowe powiadomienia",
	    "notificationsHelp": "Zezwól na dostęp do powiadomień w Pebble. Pojawiają się tylko nowe.",
	    "notificationPreview": "Dołącz tekst wiadomości",
	    "notificationApps": "Wyświetlane aplikacje",
	    "notificationAppsHelp": "Oddziel nazwy aplikacji przecinkami. Puste pole oznacza wszystkie dozwolone aplikacje.",
	    "statusHelp": "Stan i pomoc",
	    "complicationsWaiting": "Komplikacje: oczekiwanie na Pebble",
	    "contextWaiting": "Treść dynamiczna: oczekiwanie na Pebble",
	    "adaptivePeek": "Timeline Peek zachowuje zegar i komplikacje 1 i 2. Panel wydarzenia ma pierwszeństwo przed muzyką i powiadomieniami.",
	    "save": "Zapisz ustawienia",
	    "complicationsStatus": "Komplikacje: gotowe {ready}/{configured}",
	    "complicationsDisabled": "Włącz wtyczki w Pebble, aby korzystać z komplikacji.",
	    "complicationsError": "Błąd komplikacji: {error}",
	    "contextReady": "Treść dynamiczna: gotowa",
	    "contextError": "Treść dynamiczna: {error}",
	    "stateOn": "Wł.",
	    "stateOff": "Wył.",
	    "accentColor": "Kolor akcentu",
	    "accentHelp": "Kolor symboli odczytów i wskaźników deszczu.",
	    "animations": "Animacje",
	    "animationsHelp": "Krótkie przejścia przy zmianie muzyki lub powiadomień."
	  },
	  "da": {
	    "title": "Dynamic-indstillinger",
	    "appearance": "Udseende",
	    "background": "Baggrundsfarve",
	    "textColor": "Tekstfarve",
	    "time12": "12-timersformat",
	    "largeText": "Stor tekst",
	    "largeTextHelp": "Større dato, værdier og beskeder. Klokkeslættet tilpasses den tilgængelige bredde.",
	    "showStatus": "Statusindikatorer",
	    "statusIndicatorsHelp": "Lavt batteri på ur eller telefon og mistet forbindelse.",
	    "complications": "Komplikationer",
	    "complicationsHelp": "Vælg plads 1 og 2 i Pebble → Indstillinger → Komplikationer.",
	    "adaptiveHelp": "Komplikation 1 og 2 står ved siden af hinanden. Begge bliver mindre over musik eller notifikationer.",
	    "complicationsUnits": "Enhederne kommer fra Pebble og det valgte plugin.",
	    "dynamicContent": "Dynamisk indhold",
	    "showMusic": "Vis musik under afspilning",
	    "showNotifications": "Nye notifikationer",
	    "notificationsHelp": "Tillad adgang til notifikationer i Pebble. Kun nye vises.",
	    "notificationPreview": "Medtag beskedtekst",
	    "notificationApps": "Apps, der skal vises",
	    "notificationAppsHelp": "Adskil appnavne med kommaer. Tomt felt tillader alle godkendte apps.",
	    "statusHelp": "Status og hjælp",
	    "complicationsWaiting": "Komplikationer: venter på Pebble",
	    "contextWaiting": "Dynamisk indhold: venter på Pebble",
	    "adaptivePeek": "Timeline Peek beholder uret og komplikation 1 og 2. Begivenhedspanelet har forrang over musik og notifikationer.",
	    "save": "Gem indstillinger",
	    "complicationsStatus": "Komplikationer: {ready}/{configured} klar",
	    "complicationsDisabled": "Aktivér plugins i Pebble for at bruge komplikationer.",
	    "complicationsError": "Komplikationsfejl: {error}",
	    "contextReady": "Dynamisk indhold: klar",
	    "contextError": "Dynamisk indhold: {error}",
	    "stateOn": "Til",
	    "stateOff": "Fra",
	    "accentColor": "Accentfarve",
	    "accentHelp": "Farve til symboler for målinger og regnmålere.",
	    "animations": "Animationer",
	    "animationsHelp": "Korte overgange, når musik eller notifikationer ændres."
	  },
	  "sv": {
	    "title": "Dynamic-inställningar",
	    "appearance": "Utseende",
	    "background": "Bakgrundsfärg",
	    "textColor": "Textfärg",
	    "time12": "12-timmarsformat",
	    "largeText": "Stor text",
	    "largeTextHelp": "Större datum, värden och meddelanden. Klockslaget anpassas till den tillgängliga bredden.",
	    "showStatus": "Statusindikatorer",
	    "statusIndicatorsHelp": "Lågt batteri i klocka eller telefon och förlorad anslutning.",
	    "complications": "Komplikationer",
	    "complicationsHelp": "Välj plats 1 och 2 i Pebble → Inställningar → Komplikationer.",
	    "adaptiveHelp": "Komplikation 1 och 2 ligger bredvid varandra. Båda krymper ovanför musik eller aviseringar.",
	    "complicationsUnits": "Enheterna kommer från Pebble och det valda insticksprogrammet.",
	    "dynamicContent": "Dynamiskt innehåll",
	    "showMusic": "Visa musik under uppspelning",
	    "showNotifications": "Nya aviseringar",
	    "notificationsHelp": "Tillåt aviseringsåtkomst i Pebble. Endast nya aviseringar visas.",
	    "notificationPreview": "Ta med meddelandetext",
	    "notificationApps": "Appar att visa",
	    "notificationAppsHelp": "Avgränsa appnamn med kommatecken. Tomt fält tillåter alla godkända appar.",
	    "statusHelp": "Status och hjälp",
	    "complicationsWaiting": "Komplikationer: väntar på Pebble",
	    "contextWaiting": "Dynamiskt innehåll: väntar på Pebble",
	    "adaptivePeek": "Timeline Peek behåller klockan och komplikation 1 och 2. Händelsepanelen har företräde framför musik och aviseringar.",
	    "save": "Spara inställningar",
	    "complicationsStatus": "Komplikationer: {ready}/{configured} klara",
	    "complicationsDisabled": "Aktivera insticksprogram i Pebble för att använda komplikationer.",
	    "complicationsError": "Komplikationsfel: {error}",
	    "contextReady": "Dynamiskt innehåll: klart",
	    "contextError": "Dynamiskt innehåll: {error}",
	    "stateOn": "På",
	    "stateOff": "Av",
	    "accentColor": "Accentfärg",
	    "accentHelp": "Färg för mätvärdessymboler och regnmätare.",
	    "animations": "Animationer",
	    "animationsHelp": "Korta övergångar när musik eller aviseringar ändras."
	  },
	  "no": {
	    "title": "Dynamic-innstillinger",
	    "appearance": "Utseende",
	    "background": "Bakgrunnsfarge",
	    "textColor": "Tekstfarge",
	    "time12": "12-timersformat",
	    "largeText": "Stor tekst",
	    "largeTextHelp": "Større dato, verdier og meldinger. Klokkeslettet tilpasses den tilgjengelige bredden.",
	    "showStatus": "Statusindikatorer",
	    "statusIndicatorsHelp": "Lavt batteri på klokke eller telefon og mistet forbindelse.",
	    "complications": "Komplikasjoner",
	    "complicationsHelp": "Velg plass 1 og 2 i Pebble → Innstillinger → Komplikasjoner.",
	    "adaptiveHelp": "Komplikasjon 1 og 2 står ved siden av hverandre. Begge krymper over musikk eller varsler.",
	    "complicationsUnits": "Enhetene kommer fra Pebble og det valgte programtillegget.",
	    "dynamicContent": "Dynamisk innhold",
	    "showMusic": "Vis musikk under avspilling",
	    "showNotifications": "Nye varsler",
	    "notificationsHelp": "Tillat varseltilgang i Pebble. Bare nye varsler vises.",
	    "notificationPreview": "Ta med meldingstekst",
	    "notificationApps": "Apper som skal vises",
	    "notificationAppsHelp": "Skill appnavn med komma. Tomt felt tillater alle godkjente apper.",
	    "statusHelp": "Status og hjelp",
	    "complicationsWaiting": "Komplikasjoner: venter på Pebble",
	    "contextWaiting": "Dynamisk innhold: venter på Pebble",
	    "adaptivePeek": "Timeline Peek beholder klokken og komplikasjon 1 og 2. Hendelsespanelet prioriteres fremfor musikk og varsler.",
	    "save": "Lagre innstillinger",
	    "complicationsStatus": "Komplikasjoner: {ready}/{configured} klare",
	    "complicationsDisabled": "Aktiver programtillegg i Pebble for å bruke komplikasjoner.",
	    "complicationsError": "Komplikasjonsfeil: {error}",
	    "contextReady": "Dynamisk innhold: klart",
	    "contextError": "Dynamisk innhold: {error}",
	    "stateOn": "På",
	    "stateOff": "Av",
	    "accentColor": "Aksentfarge",
	    "accentHelp": "Farge på målesymboler og regnmålere.",
	    "animations": "Animasjoner",
	    "animationsHelp": "Korte overganger når musikk eller varsler endres."
	  },
	  "fi": {
	    "title": "Dynamic-asetukset",
	    "appearance": "Ulkoasu",
	    "background": "Taustaväri",
	    "textColor": "Tekstin väri",
	    "time12": "12 tunnin kellonaika",
	    "largeText": "Suuri teksti",
	    "largeTextHelp": "Suurempi päivämäärä, arvot ja viestit. Kellonaika mukautuu käytettävissä olevaan leveyteen.",
	    "showStatus": "Tilailmaisimet",
	    "statusIndicatorsHelp": "Kellon tai puhelimen vähäinen akku ja katkennut yhteys.",
	    "complications": "Kellon lisätiedot",
	    "complicationsHelp": "Valitse paikat 1 ja 2 kohdasta Pebble → Asetukset → Lisätiedot.",
	    "adaptiveHelp": "Lisätiedot 1 ja 2 ovat vierekkäin. Molemmat pienenevät musiikin tai ilmoitusten yläpuolelle.",
	    "complicationsUnits": "Yksiköt tulevat Pebblestä ja valitusta lisäosasta.",
	    "dynamicContent": "Muuttuva sisältö",
	    "showMusic": "Näytä musiikki toiston aikana",
	    "showNotifications": "Uudet ilmoitukset",
	    "notificationsHelp": "Salli ilmoitusten käyttö Pebblessä. Vain uudet ilmoitukset näkyvät.",
	    "notificationPreview": "Sisällytä viestin teksti",
	    "notificationApps": "Näytettävät sovellukset",
	    "notificationAppsHelp": "Erota sovellusten nimet pilkuilla. Tyhjä kenttä sallii kaikki hyväksytyt sovellukset.",
	    "statusHelp": "Tila ja ohje",
	    "complicationsWaiting": "Lisätiedot: odotetaan Pebbleä",
	    "contextWaiting": "Muuttuva sisältö: odotetaan Pebbleä",
	    "adaptivePeek": "Timeline Peek säilyttää kellon ja lisätiedot 1 ja 2. Tapahtumapaneeli on etusijalla musiikkiin ja ilmoituksiin nähden.",
	    "save": "Tallenna asetukset",
	    "complicationsStatus": "Lisätiedot: {ready}/{configured} valmiina",
	    "complicationsDisabled": "Ota lisäosat käyttöön Pebblessä, jotta voit näyttää lisätietoja.",
	    "complicationsError": "Lisätietovirhe: {error}",
	    "contextReady": "Muuttuva sisältö: valmis",
	    "contextError": "Muuttuva sisältö: {error}",
	    "stateOn": "Päällä",
	    "stateOff": "Pois",
	    "accentColor": "Korostusväri",
	    "accentHelp": "Arvojen symbolien ja sadeilmaisimien väri.",
	    "animations": "Animaatiot",
	    "animationsHelp": "Lyhyet siirtymät musiikin tai ilmoitusten vaihtuessa."
	  },
	  "hu": {
	    "title": "Dynamic beállításai",
	    "appearance": "Megjelenés",
	    "background": "Háttérszín",
	    "textColor": "Szövegszín",
	    "time12": "12 órás időformátum",
	    "largeText": "Nagy szöveg",
	    "largeTextHelp": "Nagyobb dátum, értékek és üzenetek. Az idő a rendelkezésre álló szélességhez igazodik.",
	    "showStatus": "Állapotjelzők",
	    "statusIndicatorsHelp": "Az óra vagy telefon alacsony töltöttsége és megszakadt kapcsolat.",
	    "complications": "Komplikációk",
	    "complicationsHelp": "Válaszd az 1. és 2. helyet itt: Pebble → Beállítások → Komplikációk.",
	    "adaptiveHelp": "Az 1. és 2. komplikáció egymás mellett látható. Mindkettő kisebb lesz a zene vagy értesítések felett.",
	    "complicationsUnits": "A mértékegységeket a Pebble és a kiválasztott bővítmény adja meg.",
	    "dynamicContent": "Változó tartalom",
	    "showMusic": "Zene megjelenítése lejátszás közben",
	    "showNotifications": "Új értesítések",
	    "notificationsHelp": "Engedélyezd az értesítések elérését a Pebble-ben. Csak az új értesítések jelennek meg.",
	    "notificationPreview": "Üzenetszöveg megjelenítése",
	    "notificationApps": "Megjelenített alkalmazások",
	    "notificationAppsHelp": "Az alkalmazásneveket vesszővel válaszd el. Üresen minden engedélyezett alkalmazás látszik.",
	    "statusHelp": "Állapot és súgó",
	    "complicationsWaiting": "Komplikációk: várakozás a Pebble-re",
	    "contextWaiting": "Változó tartalom: várakozás a Pebble-re",
	    "adaptivePeek": "A Timeline Peek megtartja az órát és az 1. és 2. komplikációt. Az eseménypanel elsőbbséget élvez a zenével és az értesítésekkel szemben.",
	    "save": "Beállítások mentése",
	    "complicationsStatus": "Komplikációk: {ready}/{configured} kész",
	    "complicationsDisabled": "A komplikációk használatához engedélyezd a bővítményeket a Pebble-ben.",
	    "complicationsError": "Komplikációhiba: {error}",
	    "contextReady": "Változó tartalom: kész",
	    "contextError": "Változó tartalom: {error}",
	    "stateOn": "Be",
	    "stateOff": "Ki",
	    "accentColor": "Kiemelőszín",
	    "accentHelp": "Az értékek szimbólumainak és az esőjelzőknek a színe.",
	    "animations": "Animációk",
	    "animationsHelp": "Rövid átmenetek a zene vagy az értesítések változásakor."
	  },
	  "ro": {
	    "title": "Setări Dynamic",
	    "appearance": "Aspect",
	    "background": "Culoare fundal",
	    "textColor": "Culoare text",
	    "time12": "Format de 12 ore",
	    "largeText": "Text mare",
	    "largeTextHelp": "Dată, valori și mesaje mai mari. Ora se adaptează la lățimea disponibilă.",
	    "showStatus": "Indicatori de stare",
	    "statusIndicatorsHelp": "Baterie scăzută la ceas sau telefon și conexiune pierdută.",
	    "complications": "Complicații",
	    "complicationsHelp": "Alege pozițiile 1 și 2 în Pebble → Setări → Complicații.",
	    "adaptiveHelp": "Complicațiile 1 și 2 sunt alăturate. Ambele se micșorează deasupra muzicii sau notificărilor.",
	    "complicationsUnits": "Unitățile provin de la Pebble și de la extensia selectată.",
	    "dynamicContent": "Conținut dinamic",
	    "showMusic": "Arată muzica în timpul redării",
	    "showNotifications": "Notificări noi",
	    "notificationsHelp": "Permite accesul la notificări în Pebble. Apar doar cele noi.",
	    "notificationPreview": "Include textul mesajului",
	    "notificationApps": "Aplicații de afișat",
	    "notificationAppsHelp": "Separă numele aplicațiilor prin virgule. Lasă gol pentru toate aplicațiile permise.",
	    "statusHelp": "Stare și ajutor",
	    "complicationsWaiting": "Complicații: se așteaptă Pebble",
	    "contextWaiting": "Conținut dinamic: se așteaptă Pebble",
	    "adaptivePeek": "Timeline Peek păstrează ceasul și complicațiile 1 și 2. Panoul evenimentului are prioritate față de muzică și notificări.",
	    "save": "Salvează setările",
	    "complicationsStatus": "Complicații: {ready}/{configured} pregătite",
	    "complicationsDisabled": "Activează extensiile în Pebble pentru a folosi complicații.",
	    "complicationsError": "Eroare de complicație: {error}",
	    "contextReady": "Conținut dinamic: pregătit",
	    "contextError": "Conținut dinamic: {error}",
	    "stateOn": "Pornit",
	    "stateOff": "Oprit",
	    "accentColor": "Culoare de accent",
	    "accentHelp": "Culoarea simbolurilor pentru valori și a indicatoarelor de ploaie.",
	    "animations": "Animații",
	    "animationsHelp": "Tranziții scurte când se schimbă muzica sau notificările."
	  },
	  "tr": {
	    "title": "Dynamic Ayarları",
	    "appearance": "Görünüm",
	    "background": "Arka plan rengi",
	    "textColor": "Metin rengi",
	    "time12": "12 saat biçimi",
	    "largeText": "Büyük metin",
	    "largeTextHelp": "Daha büyük tarih, değerler ve mesajlar. Saat, kullanılabilir genişliğe uyum sağlar.",
	    "showStatus": "Durum göstergeleri",
	    "statusIndicatorsHelp": "Saat veya telefonun düşük pili ve kesilen bağlantı.",
	    "complications": "Komplikasyonlar",
	    "complicationsHelp": "Pebble → Ayarlar → Komplikasyonlar bölümünden 1 ve 2 yuvalarını seçin.",
	    "adaptiveHelp": "1 ve 2. komplikasyon yan yana durur. İkisi de müzik veya bildirimlerin üstünde küçülür.",
	    "complicationsUnits": "Birimler Pebble ve seçilen eklentiden alınır.",
	    "dynamicContent": "Dinamik içerik",
	    "showMusic": "Çalma sırasında müziği göster",
	    "showNotifications": "Yeni bildirimler",
	    "notificationsHelp": "Pebble’da bildirim erişimine izin verin. Yalnızca yeni bildirimler görünür.",
	    "notificationPreview": "Mesaj metnini dahil et",
	    "notificationApps": "Gösterilecek uygulamalar",
	    "notificationAppsHelp": "Uygulama adlarını virgülle ayırın. Boş bırakmak izin verilen tüm uygulamaları gösterir.",
	    "statusHelp": "Durum ve yardım",
	    "complicationsWaiting": "Komplikasyonlar: Pebble bekleniyor",
	    "contextWaiting": "Dinamik içerik: Pebble bekleniyor",
	    "adaptivePeek": "Timeline Peek saati ve 1 ve 2. komplikasyonları korur. Etkinlik paneli müzik ve bildirimlerden önce gelir.",
	    "save": "Ayarları kaydet",
	    "complicationsStatus": "Komplikasyonlar: {ready}/{configured} hazır",
	    "complicationsDisabled": "Komplikasyonları kullanmak için Pebble’da eklentileri etkinleştirin.",
	    "complicationsError": "Komplikasyon hatası: {error}",
	    "contextReady": "Dinamik içerik: hazır",
	    "contextError": "Dinamik içerik: {error}",
	    "stateOn": "Açık",
	    "stateOff": "Kapalı",
	    "accentColor": "Vurgu rengi",
	    "accentHelp": "Değer simgelerinin ve yağmur göstergelerinin rengi.",
	    "animations": "Animasyonlar",
	    "animationsHelp": "Müzik veya bildirimler değiştiğinde kısa geçişler."
	  }
	};
	// Keep previous English literals translatable for stored Clay schemas.
	var LEGACY_LITERALS = {
	  'Color for reading symbols. Rain gauges and notification symbols use yellow.': 'accentHelp',
	  'Settings delivered to watch.': 'saveSaved',
	  'Waiting for watch.': 'savePending',
	  'Could not reach watch. Reconnect and save again.': 'saveFailed'
	};
	var SETTINGS_MESSAGES = {
	  en: {
	    samplePreview: 'Sample preview',
	    sampleHelp: 'Example screens, not live data.',
	    previewIdle: 'Idle',
	    previewMusic: 'Music',
	    previewNotification: 'Notification',
	    previewTimeline: 'Timeline',
	    display: 'Display',
	    theme: 'Theme',
	    themeLight: 'Light',
	    themeDark: 'Dark',
	    themeCustom: 'Custom',
	    timeFormat: 'Time format',
	    followPebble: 'Follow Pebble',
	    time24: '24-hour time',
	    largerText: 'Larger text',
	    languageHelp: 'Language follows your watch.',
	    twoReadings: 'Your two readings',
	    leftReading: 'Left',
	    rightReading: 'Right',
	    musicNotifications: 'Music & notifications',
	    notifications: 'Notifications',
	    notificationSummary: 'App and title',
	    notificationAppsMode: 'Notification apps',
	    allApps: 'All apps',
	    selectedApps: 'Selected apps',
	    appFilterHelp: 'Use exact app names or Android package names, separated by commas. For example: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Enter at least one app name or Android package.',
	    helpConnection: 'Help & connection',
	    snapshotHelp: 'Status when settings opened. Reopen settings to refresh.',
	    permissionHelp: 'Allow access in Pebble, then reopen settings.',
	    pluginHelp: 'Check that the matching plugin is enabled in Pebble.',
	    connectionHelp: 'Connect your phone and watch, then reopen settings.',
	    technicalDetails: 'Technical details',
	    receivedAge: 'Received {age} min ago',
	    observedAge: 'Observed {age} min ago',
	    readingTemperature: 'Temperature',
	    readingFeelsLike: 'Feels like',
	    readingHigh: 'High',
	    readingLow: 'Low',
	    readingCondition: 'Condition',
	    readingHumidity: 'Humidity',
	    readingRain: 'Rain',
	    readingUv: 'UV index',
	    readingBattery: 'Battery',
	    readingTitle: 'Title',
	    readingArtist: 'Artist',
	    readingName: 'Name',
	    phoneSource: 'Phone battery',
	    sourceEmpty: 'Not selected',
	    sourceLoading: 'Loading',
	    sourceReady: 'Ready',
	    sourceUnavailable: 'Unavailable',
	    sourceDenied: 'Permission needed',
	    sourceUnsupported: 'Unsupported data',
	    sourceDisabled: 'Plugin disabled',
	    sourcePlaying: 'Playing',
	    sourcePaused: 'Paused',
	    sourceIdle: 'Not playing',
	    sourceWaiting: 'Waiting for Pebble',
	    saveSaved: 'Watch settings delivered.',
	    savePending: 'Saved on phone; waiting for watch.',
	    saveFailed: 'Saved on phone. Reconnect and save again to update the watch.',
	    saveNone: 'Changes apply after you save.',
	    saveSending: 'Saving…',
	    contrastHelp: 'Text may be hard to read. Choose different text and background colors.',
	    previewSettingsNote: 'Preview uses the watch’s 64-color palette.',
	    previewCustomHelp: 'Custom colors are approximate. The layout uses native watch rendering.',
	    previewTimelineHelp: 'The lower panel is reserved for Pebble Timeline.',
	    noExample: 'No example available'
	  },
	  cs: {
	    samplePreview: 'Ukázkový náhled',
	    sampleHelp: 'Ukázkové obrazovky, nikoli živá data.',
	    previewIdle: 'V klidu',
	    previewMusic: 'Hudba',
	    previewNotification: 'Oznámení',
	    previewTimeline: 'Časová osa',
	    display: 'Zobrazení',
	    theme: 'Motiv',
	    themeLight: 'Světlý',
	    themeDark: 'Tmavý',
	    themeCustom: 'Vlastní',
	    timeFormat: 'Formát času',
	    followPebble: 'Podle Pebble',
	    time24: '24hodinový čas',
	    largerText: 'Větší text',
	    languageHelp: 'Jazyk se řídí hodinkami.',
	    twoReadings: 'Vaše dva údaje',
	    leftReading: 'Vlevo',
	    rightReading: 'Vpravo',
	    musicNotifications: 'Hudba a oznámení',
	    notifications: 'Oznámení',
	    notificationSummary: 'Aplikace a titulek',
	    notificationAppsMode: 'Aplikace s oznámeními',
	    allApps: 'Všechny aplikace',
	    selectedApps: 'Vybrané aplikace',
	    appFilterHelp: 'Zadejte přesné názvy aplikací nebo balíčků Android oddělené čárkami. Například: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Zadejte alespoň jeden název aplikace nebo balíčku Android.',
	    helpConnection: 'Nápověda a připojení',
	    snapshotHelp: 'Stav při otevření nastavení. Pro obnovení otevřete nastavení znovu.',
	    permissionHelp: 'Povolte přístup v Pebble a znovu otevřete nastavení.',
	    pluginHelp: 'Zkontrolujte, že je příslušný plugin v Pebble zapnutý.',
	    connectionHelp: 'Připojte telefon a hodinky a znovu otevřete nastavení.',
	    technicalDetails: 'Technické podrobnosti',
	    receivedAge: 'Přijato před {age} min',
	    observedAge: 'Zaznamenáno před {age} min',
	    readingTemperature: 'Teplota',
	    readingFeelsLike: 'Pocitová teplota',
	    readingHigh: 'Maximum',
	    readingLow: 'Minimum',
	    readingCondition: 'Počasí',
	    readingHumidity: 'Vlhkost',
	    readingRain: 'Déšť',
	    readingUv: 'UV index',
	    readingBattery: 'Baterie',
	    readingTitle: 'Titulek',
	    readingArtist: 'Interpret',
	    readingName: 'Název',
	    phoneSource: 'Baterie telefonu',
	    sourceEmpty: 'Nevybráno',
	    sourceLoading: 'Načítání',
	    sourceReady: 'Připraveno',
	    sourceUnavailable: 'Nedostupné',
	    sourceDenied: 'Je potřeba oprávnění',
	    sourceUnsupported: 'Nepodporovaná data',
	    sourceDisabled: 'Plugin je vypnutý',
	    sourcePlaying: 'Přehrává se',
	    sourcePaused: 'Pozastaveno',
	    sourceIdle: 'Nepřehrává se',
	    sourceWaiting: 'Čeká se na Pebble',
	    saveSaved: 'Nastavení hodinek bylo doručeno.',
	    savePending: 'Uloženo v telefonu; čeká se na hodinky.',
	    saveFailed: 'Uloženo v telefonu. Pro aktualizaci hodinek obnovte připojení a uložte znovu.',
	    saveNone: 'Změny se použijí po uložení.',
	    saveSending: 'Ukládání…',
	    contrastHelp: 'Text může být špatně čitelný. Zvolte jiné barvy textu a pozadí.',
	    previewSettingsNote: 'Náhled používá paletu 64 barev hodinek.',
	    previewCustomHelp: 'Vlastní barvy jsou přibližné. Rozložení používá nativní vykreslování hodinek.',
	    previewTimelineHelp: 'Spodní panel je vyhrazen pro Pebble Timeline.',
	    noExample: 'Ukázka není k dispozici'
	  },
	  sk: {
	    samplePreview: 'Ukážkový náhľad',
	    sampleHelp: 'Ukážkové obrazovky, nie živé údaje.',
	    previewIdle: 'V pokoji',
	    previewMusic: 'Hudba',
	    previewNotification: 'Oznámenie',
	    previewTimeline: 'Časová os',
	    display: 'Zobrazenie',
	    theme: 'Motív',
	    themeLight: 'Svetlý',
	    themeDark: 'Tmavý',
	    themeCustom: 'Vlastný',
	    timeFormat: 'Formát času',
	    followPebble: 'Podľa Pebble',
	    time24: '24-hodinový čas',
	    largerText: 'Väčší text',
	    languageHelp: 'Jazyk sa riadi hodinkami.',
	    twoReadings: 'Vaše dva údaje',
	    leftReading: 'Vľavo',
	    rightReading: 'Vpravo',
	    musicNotifications: 'Hudba a oznámenia',
	    notifications: 'Oznámenia',
	    notificationSummary: 'Aplikácia a nadpis',
	    notificationAppsMode: 'Aplikácie s oznámeniami',
	    allApps: 'Všetky aplikácie',
	    selectedApps: 'Vybrané aplikácie',
	    appFilterHelp: 'Zadajte presné názvy aplikácií alebo balíkov Android oddelené čiarkami. Napríklad: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Zadajte aspoň jeden názov aplikácie alebo balíka Android.',
	    helpConnection: 'Pomoc a pripojenie',
	    snapshotHelp: 'Stav pri otvorení nastavení. Na obnovenie otvorte nastavenia znova.',
	    permissionHelp: 'Povoľte prístup v Pebble a znova otvorte nastavenia.',
	    pluginHelp: 'Skontrolujte, či je príslušný plugin v Pebble zapnutý.',
	    connectionHelp: 'Pripojte telefón a hodinky a znova otvorte nastavenia.',
	    technicalDetails: 'Technické podrobnosti',
	    receivedAge: 'Prijaté pred {age} min',
	    observedAge: 'Zaznamenané pred {age} min',
	    readingTemperature: 'Teplota',
	    readingFeelsLike: 'Pocitová teplota',
	    readingHigh: 'Maximum',
	    readingLow: 'Minimum',
	    readingCondition: 'Počasie',
	    readingHumidity: 'Vlhkosť',
	    readingRain: 'Dážď',
	    readingUv: 'UV index',
	    readingBattery: 'Batéria',
	    readingTitle: 'Nadpis',
	    readingArtist: 'Interpret',
	    readingName: 'Názov',
	    phoneSource: 'Batéria telefónu',
	    sourceEmpty: 'Nevybrané',
	    sourceLoading: 'Načítava sa',
	    sourceReady: 'Pripravené',
	    sourceUnavailable: 'Nedostupné',
	    sourceDenied: 'Vyžaduje sa povolenie',
	    sourceUnsupported: 'Nepodporované údaje',
	    sourceDisabled: 'Plugin je vypnutý',
	    sourcePlaying: 'Prehráva sa',
	    sourcePaused: 'Pozastavené',
	    sourceIdle: 'Neprehráva sa',
	    sourceWaiting: 'Čaká sa na Pebble',
	    saveSaved: 'Nastavenia hodiniek boli doručené.',
	    savePending: 'Uložené v telefóne; čaká sa na hodinky.',
	    saveFailed: 'Uložené v telefóne. Na aktualizáciu hodiniek obnovte pripojenie a uložte znova.',
	    saveNone: 'Zmeny sa použijú po uložení.',
	    saveSending: 'Ukladá sa…',
	    contrastHelp: 'Text môže byť zle čitateľný. Zvoľte iné farby textu a pozadia.',
	    previewSettingsNote: 'Náhľad používa paletu 64 farieb hodiniek.',
	    previewCustomHelp: 'Vlastné farby sú približné. Rozloženie používa natívne vykresľovanie hodiniek.',
	    previewTimelineHelp: 'Spodný panel je vyhradený pre Pebble Timeline.',
	    noExample: 'Ukážka nie je k dispozícii'
	  },
	  de: {
	    samplePreview: 'Beispielvorschau',
	    sampleHelp: 'Beispielansichten ohne Live-Daten.',
	    previewIdle: 'Ruhezustand',
	    previewMusic: 'Musik',
	    previewNotification: 'Mitteilung',
	    previewTimeline: 'Zeitleiste',
	    display: 'Anzeige',
	    theme: 'Design',
	    themeLight: 'Hell',
	    themeDark: 'Dunkel',
	    themeCustom: 'Eigene Farben',
	    timeFormat: 'Zeitformat',
	    followPebble: 'Wie in Pebble',
	    time24: '24-Stunden-Zeit',
	    largerText: 'Größerer Text',
	    languageHelp: 'Die Sprache richtet sich nach deiner Uhr.',
	    twoReadings: 'Deine zwei Messwerte',
	    leftReading: 'Links',
	    rightReading: 'Rechts',
	    musicNotifications: 'Musik und Mitteilungen',
	    notifications: 'Mitteilungen',
	    notificationSummary: 'App und Titel',
	    notificationAppsMode: 'Apps für Mitteilungen',
	    allApps: 'Alle Apps',
	    selectedApps: 'Ausgewählte Apps',
	    appFilterHelp: 'Gib genaue App-Namen oder Android-Paketnamen durch Kommas getrennt ein. Zum Beispiel: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Gib mindestens einen App-Namen oder Android-Paketnamen ein.',
	    helpConnection: 'Hilfe und Verbindung',
	    snapshotHelp: 'Status beim Öffnen der Einstellungen. Zum Aktualisieren erneut öffnen.',
	    permissionHelp: 'Erlaube den Zugriff in Pebble und öffne die Einstellungen erneut.',
	    pluginHelp: 'Prüfe, ob das passende Plugin in Pebble aktiviert ist.',
	    connectionHelp: 'Verbinde Telefon und Uhr und öffne die Einstellungen erneut.',
	    technicalDetails: 'Technische Details',
	    receivedAge: 'Vor {age} Min. empfangen',
	    observedAge: 'Vor {age} Min. erfasst',
	    readingTemperature: 'Temperatur',
	    readingFeelsLike: 'Gefühlt',
	    readingHigh: 'Höchstwert',
	    readingLow: 'Tiefstwert',
	    readingCondition: 'Wetterlage',
	    readingHumidity: 'Luftfeuchtigkeit',
	    readingRain: 'Regen',
	    readingUv: 'UV-Index',
	    readingBattery: 'Akku',
	    readingTitle: 'Titel',
	    readingArtist: 'Interpret',
	    readingName: 'Name',
	    phoneSource: 'Telefonakku',
	    sourceEmpty: 'Nicht ausgewählt',
	    sourceLoading: 'Wird geladen',
	    sourceReady: 'Bereit',
	    sourceUnavailable: 'Nicht verfügbar',
	    sourceDenied: 'Berechtigung erforderlich',
	    sourceUnsupported: 'Nicht unterstützte Daten',
	    sourceDisabled: 'Plugin deaktiviert',
	    sourcePlaying: 'Wiedergabe läuft',
	    sourcePaused: 'Pausiert',
	    sourceIdle: 'Keine Wiedergabe',
	    sourceWaiting: 'Warten auf Pebble',
	    saveSaved: 'Uhreinstellungen übermittelt.',
	    savePending: 'Auf dem Telefon gespeichert; Warten auf die Uhr.',
	    saveFailed: 'Auf dem Telefon gespeichert. Stelle die Verbindung wieder her und speichere erneut, um die Uhr zu aktualisieren.',
	    saveNone: 'Änderungen werden nach dem Speichern übernommen.',
	    saveSending: 'Wird gespeichert…',
	    contrastHelp: 'Der Text könnte schwer lesbar sein. Wähle andere Text- und Hintergrundfarben.',
	    previewSettingsNote: 'Die Vorschau verwendet die 64-Farben-Palette der Uhr.',
	    previewCustomHelp: 'Eigene Farben werden näherungsweise dargestellt. Das Layout verwendet die native Darstellung der Uhr.',
	    previewTimelineHelp: 'Der untere Bereich ist für Pebble Timeline reserviert.',
	    noExample: 'Kein Beispiel verfügbar'
	  },
	  fr: {
	    samplePreview: 'Aperçu d’exemple',
	    sampleHelp: 'Exemples d’écrans, sans données en direct.',
	    previewIdle: 'Au repos',
	    previewMusic: 'Musique',
	    previewNotification: 'Notification',
	    previewTimeline: 'Chronologie',
	    display: 'Affichage',
	    theme: 'Thème',
	    themeLight: 'Clair',
	    themeDark: 'Sombre',
	    themeCustom: 'Personnalisé',
	    timeFormat: 'Format de l’heure',
	    followPebble: 'Suivre Pebble',
	    time24: 'Format 24 heures',
	    largerText: 'Texte plus grand',
	    languageHelp: 'La langue suit celle de votre montre.',
	    twoReadings: 'Vos deux données',
	    leftReading: 'Gauche',
	    rightReading: 'Droite',
	    musicNotifications: 'Musique et notifications',
	    notifications: 'Notifications',
	    notificationSummary: 'Application et titre',
	    notificationAppsMode: 'Applications de notification',
	    allApps: 'Toutes les applications',
	    selectedApps: 'Applications sélectionnées',
	    appFilterHelp: 'Saisissez les noms exacts des applications ou des paquets Android, séparés par des virgules. Par exemple : Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Saisissez au moins un nom d’application ou de paquet Android.',
	    helpConnection: 'Aide et connexion',
	    snapshotHelp: 'État à l’ouverture des réglages. Rouvrez les réglages pour l’actualiser.',
	    permissionHelp: 'Autorisez l’accès dans Pebble, puis rouvrez les réglages.',
	    pluginHelp: 'Vérifiez que le plugin correspondant est activé dans Pebble.',
	    connectionHelp: 'Connectez le téléphone et la montre, puis rouvrez les réglages.',
	    technicalDetails: 'Détails techniques',
	    receivedAge: 'Reçu il y a {age} min',
	    observedAge: 'Observé il y a {age} min',
	    readingTemperature: 'Température',
	    readingFeelsLike: 'Ressenti',
	    readingHigh: 'Maximale',
	    readingLow: 'Minimale',
	    readingCondition: 'Conditions',
	    readingHumidity: 'Humidité',
	    readingRain: 'Pluie',
	    readingUv: 'Indice UV',
	    readingBattery: 'Batterie',
	    readingTitle: 'Titre',
	    readingArtist: 'Artiste',
	    readingName: 'Nom',
	    phoneSource: 'Batterie du téléphone',
	    sourceEmpty: 'Non sélectionné',
	    sourceLoading: 'Chargement',
	    sourceReady: 'Prêt',
	    sourceUnavailable: 'Indisponible',
	    sourceDenied: 'Autorisation requise',
	    sourceUnsupported: 'Données non prises en charge',
	    sourceDisabled: 'Plugin désactivé',
	    sourcePlaying: 'Lecture en cours',
	    sourcePaused: 'En pause',
	    sourceIdle: 'Aucune lecture',
	    sourceWaiting: 'En attente de Pebble',
	    saveSaved: 'Réglages de la montre transmis.',
	    savePending: 'Enregistré sur le téléphone ; en attente de la montre.',
	    saveFailed: 'Enregistré sur le téléphone. Rétablissez la connexion et enregistrez à nouveau pour mettre à jour la montre.',
	    saveNone: 'Les modifications s’appliquent après l’enregistrement.',
	    saveSending: 'Enregistrement…',
	    contrastHelp: 'Le texte risque d’être difficile à lire. Choisissez d’autres couleurs de texte et de fond.',
	    previewSettingsNote: 'L’aperçu utilise la palette de 64 couleurs de la montre.',
	    previewCustomHelp: 'Les couleurs personnalisées sont approximatives. La mise en page utilise le rendu natif de la montre.',
	    previewTimelineHelp: 'Le panneau inférieur est réservé à Pebble Timeline.',
	    noExample: 'Aucun exemple disponible'
	  },
	  es: {
	    samplePreview: 'Vista previa de ejemplo',
	    sampleHelp: 'Pantallas de ejemplo, sin datos en directo.',
	    previewIdle: 'En reposo',
	    previewMusic: 'Música',
	    previewNotification: 'Notificación',
	    previewTimeline: 'Cronología',
	    display: 'Pantalla',
	    theme: 'Tema',
	    themeLight: 'Claro',
	    themeDark: 'Oscuro',
	    themeCustom: 'Personalizado',
	    timeFormat: 'Formato de hora',
	    followPebble: 'Seguir Pebble',
	    time24: 'Formato de 24 horas',
	    largerText: 'Texto más grande',
	    languageHelp: 'El idioma sigue el de tu reloj.',
	    twoReadings: 'Tus dos lecturas',
	    leftReading: 'Izquierda',
	    rightReading: 'Derecha',
	    musicNotifications: 'Música y notificaciones',
	    notifications: 'Notificaciones',
	    notificationSummary: 'Aplicación y título',
	    notificationAppsMode: 'Aplicaciones de notificaciones',
	    allApps: 'Todas las aplicaciones',
	    selectedApps: 'Aplicaciones seleccionadas',
	    appFilterHelp: 'Introduce los nombres exactos de las aplicaciones o de los paquetes de Android, separados por comas. Por ejemplo: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Introduce al menos un nombre de aplicación o de paquete de Android.',
	    helpConnection: 'Ayuda y conexión',
	    snapshotHelp: 'Estado al abrir los ajustes. Vuelve a abrirlos para actualizarlo.',
	    permissionHelp: 'Permite el acceso en Pebble y vuelve a abrir los ajustes.',
	    pluginHelp: 'Comprueba que el plugin correspondiente esté activado en Pebble.',
	    connectionHelp: 'Conecta el teléfono y el reloj y vuelve a abrir los ajustes.',
	    technicalDetails: 'Detalles técnicos',
	    receivedAge: 'Recibido hace {age} min',
	    observedAge: 'Observado hace {age} min',
	    readingTemperature: 'Temperatura',
	    readingFeelsLike: 'Sensación térmica',
	    readingHigh: 'Máxima',
	    readingLow: 'Mínima',
	    readingCondition: 'Estado del tiempo',
	    readingHumidity: 'Humedad',
	    readingRain: 'Lluvia',
	    readingUv: 'Índice UV',
	    readingBattery: 'Batería',
	    readingTitle: 'Título',
	    readingArtist: 'Artista',
	    readingName: 'Nombre',
	    phoneSource: 'Batería del teléfono',
	    sourceEmpty: 'Sin seleccionar',
	    sourceLoading: 'Cargando',
	    sourceReady: 'Listo',
	    sourceUnavailable: 'No disponible',
	    sourceDenied: 'Se requiere permiso',
	    sourceUnsupported: 'Datos no compatibles',
	    sourceDisabled: 'Plugin desactivado',
	    sourcePlaying: 'Reproduciendo',
	    sourcePaused: 'En pausa',
	    sourceIdle: 'Sin reproducción',
	    sourceWaiting: 'Esperando a Pebble',
	    saveSaved: 'El reloj ha recibido sus ajustes.',
	    savePending: 'Guardado en el teléfono; esperando al reloj.',
	    saveFailed: 'Guardado en el teléfono. Restablece la conexión y guarda de nuevo para actualizar el reloj.',
	    saveNone: 'Los cambios se aplican después de guardar.',
	    saveSending: 'Guardando…',
	    contrastHelp: 'El texto puede ser difícil de leer. Elige otros colores de texto y fondo.',
	    previewSettingsNote: 'La vista previa usa la paleta de 64 colores del reloj.',
	    previewCustomHelp: 'Los colores personalizados son aproximados. El diseño usa el renderizado nativo del reloj.',
	    previewTimelineHelp: 'El panel inferior está reservado para Pebble Timeline.',
	    noExample: 'No hay ningún ejemplo disponible'
	  },
	  it: {
	    samplePreview: 'Anteprima di esempio',
	    sampleHelp: 'Schermate di esempio, senza dati in tempo reale.',
	    previewIdle: 'A riposo',
	    previewMusic: 'Musica',
	    previewNotification: 'Notifica',
	    previewTimeline: 'Cronologia',
	    display: 'Schermo',
	    theme: 'Tema',
	    themeLight: 'Chiaro',
	    themeDark: 'Scuro',
	    themeCustom: 'Personalizzato',
	    timeFormat: 'Formato dell’ora',
	    followPebble: 'Segui Pebble',
	    time24: 'Formato a 24 ore',
	    largerText: 'Testo più grande',
	    languageHelp: 'La lingua segue quella dell’orologio.',
	    twoReadings: 'I tuoi due valori',
	    leftReading: 'Sinistra',
	    rightReading: 'Destra',
	    musicNotifications: 'Musica e notifiche',
	    notifications: 'Notifiche',
	    notificationSummary: 'App e titolo',
	    notificationAppsMode: 'App per le notifiche',
	    allApps: 'Tutte le app',
	    selectedApps: 'App selezionate',
	    appFilterHelp: 'Inserisci i nomi esatti delle app o dei pacchetti Android, separati da virgole. Ad esempio: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Inserisci almeno un nome di app o di pacchetto Android.',
	    helpConnection: 'Aiuto e connessione',
	    snapshotHelp: 'Stato all’apertura delle impostazioni. Riaprile per aggiornarlo.',
	    permissionHelp: 'Consenti l’accesso in Pebble, poi riapri le impostazioni.',
	    pluginHelp: 'Verifica che il plugin corrispondente sia attivo in Pebble.',
	    connectionHelp: 'Collega il telefono e l’orologio, poi riapri le impostazioni.',
	    technicalDetails: 'Dettagli tecnici',
	    receivedAge: 'Ricevuto {age} min fa',
	    observedAge: 'Osservato {age} min fa',
	    readingTemperature: 'Temperatura',
	    readingFeelsLike: 'Percepita',
	    readingHigh: 'Massima',
	    readingLow: 'Minima',
	    readingCondition: 'Condizioni',
	    readingHumidity: 'Umidità',
	    readingRain: 'Pioggia',
	    readingUv: 'Indice UV',
	    readingBattery: 'Batteria',
	    readingTitle: 'Titolo',
	    readingArtist: 'Artista',
	    readingName: 'Nome',
	    phoneSource: 'Batteria del telefono',
	    sourceEmpty: 'Non selezionato',
	    sourceLoading: 'Caricamento',
	    sourceReady: 'Pronto',
	    sourceUnavailable: 'Non disponibile',
	    sourceDenied: 'Autorizzazione necessaria',
	    sourceUnsupported: 'Dati non supportati',
	    sourceDisabled: 'Plugin disattivato',
	    sourcePlaying: 'In riproduzione',
	    sourcePaused: 'In pausa',
	    sourceIdle: 'Nessuna riproduzione',
	    sourceWaiting: 'In attesa di Pebble',
	    saveSaved: 'L’orologio ha ricevuto le sue impostazioni.',
	    savePending: 'Salvato sul telefono; in attesa dell’orologio.',
	    saveFailed: 'Salvato sul telefono. Ripristina la connessione e salva di nuovo per aggiornare l’orologio.',
	    saveNone: 'Le modifiche si applicano dopo il salvataggio.',
	    saveSending: 'Salvataggio…',
	    contrastHelp: 'Il testo potrebbe essere difficile da leggere. Scegli colori diversi per testo e sfondo.',
	    previewSettingsNote: 'L’anteprima usa la tavolozza di 64 colori dell’orologio.',
	    previewCustomHelp: 'I colori personalizzati sono approssimativi. Il layout usa il rendering nativo dell’orologio.',
	    previewTimelineHelp: 'Il pannello inferiore è riservato a Pebble Timeline.',
	    noExample: 'Nessun esempio disponibile'
	  },
	  pt: {
	    samplePreview: 'Pré-visualização de exemplo',
	    sampleHelp: 'Ecrãs de exemplo, sem dados em tempo real.',
	    previewIdle: 'Em repouso',
	    previewMusic: 'Música',
	    previewNotification: 'Notificação',
	    previewTimeline: 'Cronologia',
	    display: 'Ecrã',
	    theme: 'Tema',
	    themeLight: 'Claro',
	    themeDark: 'Escuro',
	    themeCustom: 'Personalizado',
	    timeFormat: 'Formato da hora',
	    followPebble: 'Seguir Pebble',
	    time24: 'Formato de 24 horas',
	    largerText: 'Texto maior',
	    languageHelp: 'O idioma segue o do relógio.',
	    twoReadings: 'Os seus dois valores',
	    leftReading: 'Esquerda',
	    rightReading: 'Direita',
	    musicNotifications: 'Música e notificações',
	    notifications: 'Notificações',
	    notificationSummary: 'Aplicação e título',
	    notificationAppsMode: 'Aplicações de notificações',
	    allApps: 'Todas as aplicações',
	    selectedApps: 'Aplicações selecionadas',
	    appFilterHelp: 'Introduza os nomes exatos das aplicações ou dos pacotes Android, separados por vírgulas. Por exemplo: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Introduza pelo menos um nome de aplicação ou de pacote Android.',
	    helpConnection: 'Ajuda e ligação',
	    snapshotHelp: 'Estado ao abrir as definições. Volte a abri-las para atualizar.',
	    permissionHelp: 'Permita o acesso no Pebble e volte a abrir as definições.',
	    pluginHelp: 'Verifique se o plugin correspondente está ativado no Pebble.',
	    connectionHelp: 'Ligue o telemóvel e o relógio e volte a abrir as definições.',
	    technicalDetails: 'Detalhes técnicos',
	    receivedAge: 'Recebido há {age} min',
	    observedAge: 'Observado há {age} min',
	    readingTemperature: 'Temperatura',
	    readingFeelsLike: 'Sensação térmica',
	    readingHigh: 'Máxima',
	    readingLow: 'Mínima',
	    readingCondition: 'Condições',
	    readingHumidity: 'Humidade',
	    readingRain: 'Chuva',
	    readingUv: 'Índice UV',
	    readingBattery: 'Bateria',
	    readingTitle: 'Título',
	    readingArtist: 'Artista',
	    readingName: 'Nome',
	    phoneSource: 'Bateria do telemóvel',
	    sourceEmpty: 'Não selecionado',
	    sourceLoading: 'A carregar',
	    sourceReady: 'Pronto',
	    sourceUnavailable: 'Indisponível',
	    sourceDenied: 'Permissão necessária',
	    sourceUnsupported: 'Dados não suportados',
	    sourceDisabled: 'Plugin desativado',
	    sourcePlaying: 'Em reprodução',
	    sourcePaused: 'Em pausa',
	    sourceIdle: 'Sem reprodução',
	    sourceWaiting: 'A aguardar o Pebble',
	    saveSaved: 'O relógio recebeu as suas definições.',
	    savePending: 'Guardado no telemóvel; a aguardar o relógio.',
	    saveFailed: 'Guardado no telemóvel. Volte a ligar e guarde novamente para atualizar o relógio.',
	    saveNone: 'As alterações são aplicadas depois de guardar.',
	    saveSending: 'A guardar…',
	    contrastHelp: 'O texto pode ser difícil de ler. Escolha outras cores para o texto e o fundo.',
	    previewSettingsNote: 'A pré-visualização usa a paleta de 64 cores do relógio.',
	    previewCustomHelp: 'As cores personalizadas são aproximadas. A disposição usa a renderização nativa do relógio.',
	    previewTimelineHelp: 'O painel inferior está reservado para o Pebble Timeline.',
	    noExample: 'Nenhum exemplo disponível'
	  },
	  nl: {
	    samplePreview: 'Voorbeeldweergave',
	    sampleHelp: 'Voorbeeldschermen, zonder actuele gegevens.',
	    previewIdle: 'In rust',
	    previewMusic: 'Muziek',
	    previewNotification: 'Melding',
	    previewTimeline: 'Tijdlijn',
	    display: 'Weergave',
	    theme: 'Thema',
	    themeLight: 'Licht',
	    themeDark: 'Donker',
	    themeCustom: 'Aangepast',
	    timeFormat: 'Tijdnotatie',
	    followPebble: 'Pebble volgen',
	    time24: '24-uursnotatie',
	    largerText: 'Grotere tekst',
	    languageHelp: 'De taal volgt je horloge.',
	    twoReadings: 'Je twee metingen',
	    leftReading: 'Links',
	    rightReading: 'Rechts',
	    musicNotifications: 'Muziek en meldingen',
	    notifications: 'Meldingen',
	    notificationSummary: 'App en titel',
	    notificationAppsMode: 'Apps voor meldingen',
	    allApps: 'Alle apps',
	    selectedApps: 'Geselecteerde apps',
	    appFilterHelp: 'Voer de exacte appnamen of Android-pakketnamen in, gescheiden door komma’s. Bijvoorbeeld: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Voer minstens één appnaam of Android-pakketnaam in.',
	    helpConnection: 'Hulp en verbinding',
	    snapshotHelp: 'Status bij het openen van de instellingen. Open ze opnieuw om te vernieuwen.',
	    permissionHelp: 'Sta toegang toe in Pebble en open de instellingen opnieuw.',
	    pluginHelp: 'Controleer of de bijbehorende plugin is ingeschakeld in Pebble.',
	    connectionHelp: 'Verbind je telefoon en horloge en open de instellingen opnieuw.',
	    technicalDetails: 'Technische details',
	    receivedAge: '{age} min geleden ontvangen',
	    observedAge: '{age} min geleden waargenomen',
	    readingTemperature: 'Temperatuur',
	    readingFeelsLike: 'Gevoelstemperatuur',
	    readingHigh: 'Maximum',
	    readingLow: 'Minimum',
	    readingCondition: 'Weersomstandigheden',
	    readingHumidity: 'Luchtvochtigheid',
	    readingRain: 'Regen',
	    readingUv: 'UV-index',
	    readingBattery: 'Batterij',
	    readingTitle: 'Titel',
	    readingArtist: 'Artiest',
	    readingName: 'Naam',
	    phoneSource: 'Telefoonbatterij',
	    sourceEmpty: 'Niet geselecteerd',
	    sourceLoading: 'Laden',
	    sourceReady: 'Gereed',
	    sourceUnavailable: 'Niet beschikbaar',
	    sourceDenied: 'Toestemming nodig',
	    sourceUnsupported: 'Niet-ondersteunde gegevens',
	    sourceDisabled: 'Plugin uitgeschakeld',
	    sourcePlaying: 'Wordt afgespeeld',
	    sourcePaused: 'Gepauzeerd',
	    sourceIdle: 'Speelt niet',
	    sourceWaiting: 'Wachten op Pebble',
	    saveSaved: 'Het horloge heeft zijn instellingen ontvangen.',
	    savePending: 'Opgeslagen op de telefoon; wachten op het horloge.',
	    saveFailed: 'Opgeslagen op de telefoon. Verbind opnieuw en sla nogmaals op om het horloge bij te werken.',
	    saveNone: 'Wijzigingen worden toegepast na het opslaan.',
	    saveSending: 'Opslaan…',
	    contrastHelp: 'De tekst is mogelijk moeilijk leesbaar. Kies andere tekst- en achtergrondkleuren.',
	    previewSettingsNote: 'De voorbeeldweergave gebruikt het palet met 64 kleuren van het horloge.',
	    previewCustomHelp: 'Aangepaste kleuren zijn bij benadering. De indeling gebruikt de eigen weergave van het horloge.',
	    previewTimelineHelp: 'Het onderste paneel is gereserveerd voor Pebble Timeline.',
	    noExample: 'Geen voorbeeld beschikbaar'
	  },
	  pl: {
	    samplePreview: 'Przykładowy podgląd',
	    sampleHelp: 'Przykładowe ekrany, bez danych na żywo.',
	    previewIdle: 'W spoczynku',
	    previewMusic: 'Muzyka',
	    previewNotification: 'Powiadomienie',
	    previewTimeline: 'Oś czasu',
	    display: 'Wyświetlanie',
	    theme: 'Motyw',
	    themeLight: 'Jasny',
	    themeDark: 'Ciemny',
	    themeCustom: 'Własny',
	    timeFormat: 'Format godziny',
	    followPebble: 'Według Pebble',
	    time24: 'Format 24-godzinny',
	    largerText: 'Większy tekst',
	    languageHelp: 'Język jest zgodny z ustawieniem zegarka.',
	    twoReadings: 'Twoje dwa odczyty',
	    leftReading: 'Lewy',
	    rightReading: 'Prawy',
	    musicNotifications: 'Muzyka i powiadomienia',
	    notifications: 'Powiadomienia',
	    notificationSummary: 'Aplikacja i tytuł',
	    notificationAppsMode: 'Aplikacje z powiadomieniami',
	    allApps: 'Wszystkie aplikacje',
	    selectedApps: 'Wybrane aplikacje',
	    appFilterHelp: 'Wpisz dokładne nazwy aplikacji lub pakietów Android, oddzielone przecinkami. Na przykład: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Wpisz co najmniej jedną nazwę aplikacji lub pakietu Android.',
	    helpConnection: 'Pomoc i połączenie',
	    snapshotHelp: 'Stan w chwili otwarcia ustawień. Otwórz ustawienia ponownie, aby go odświeżyć.',
	    permissionHelp: 'Zezwól na dostęp w Pebble i ponownie otwórz ustawienia.',
	    pluginHelp: 'Sprawdź, czy odpowiednia wtyczka jest włączona w Pebble.',
	    connectionHelp: 'Połącz telefon z zegarkiem i ponownie otwórz ustawienia.',
	    technicalDetails: 'Szczegóły techniczne',
	    receivedAge: 'Odebrano {age} min temu',
	    observedAge: 'Zaobserwowano {age} min temu',
	    readingTemperature: 'Temperatura',
	    readingFeelsLike: 'Odczuwalna',
	    readingHigh: 'Maksimum',
	    readingLow: 'Minimum',
	    readingCondition: 'Warunki pogodowe',
	    readingHumidity: 'Wilgotność',
	    readingRain: 'Deszcz',
	    readingUv: 'Indeks UV',
	    readingBattery: 'Bateria',
	    readingTitle: 'Tytuł',
	    readingArtist: 'Artysta',
	    readingName: 'Nazwa',
	    phoneSource: 'Bateria telefonu',
	    sourceEmpty: 'Nie wybrano',
	    sourceLoading: 'Ładowanie',
	    sourceReady: 'Gotowe',
	    sourceUnavailable: 'Niedostępne',
	    sourceDenied: 'Wymagane uprawnienie',
	    sourceUnsupported: 'Nieobsługiwane dane',
	    sourceDisabled: 'Wtyczka wyłączona',
	    sourcePlaying: 'Odtwarzanie',
	    sourcePaused: 'Wstrzymano',
	    sourceIdle: 'Brak odtwarzania',
	    sourceWaiting: 'Oczekiwanie na Pebble',
	    saveSaved: 'Ustawienia zegarka dostarczone.',
	    savePending: 'Zapisano w telefonie; oczekiwanie na zegarek.',
	    saveFailed: 'Zapisano w telefonie. Połącz ponownie i zapisz jeszcze raz, aby zaktualizować zegarek.',
	    saveNone: 'Zmiany zostaną zastosowane po zapisaniu.',
	    saveSending: 'Zapisywanie…',
	    contrastHelp: 'Tekst może być trudny do odczytania. Wybierz inne kolory tekstu i tła.',
	    previewSettingsNote: 'Podgląd używa palety 64 kolorów zegarka.',
	    previewCustomHelp: 'Własne kolory są przybliżone. Układ korzysta z natywnego sposobu wyświetlania zegarka.',
	    previewTimelineHelp: 'Dolny panel jest zarezerwowany dla Pebble Timeline.',
	    noExample: 'Brak dostępnego przykładu'
	  },
	  da: {
	    samplePreview: 'Eksempelvisning',
	    sampleHelp: 'Eksempelskærme, uden livedata.',
	    previewIdle: 'I ro',
	    previewMusic: 'Musik',
	    previewNotification: 'Notifikation',
	    previewTimeline: 'Tidslinje',
	    display: 'Visning',
	    theme: 'Tema',
	    themeLight: 'Lyst',
	    themeDark: 'Mørkt',
	    themeCustom: 'Tilpasset',
	    timeFormat: 'Tidsformat',
	    followPebble: 'Følg Pebble',
	    time24: '24-timers ur',
	    largerText: 'Større tekst',
	    languageHelp: 'Sproget følger dit ur.',
	    twoReadings: 'Dine to målinger',
	    leftReading: 'Venstre',
	    rightReading: 'Højre',
	    musicNotifications: 'Musik og notifikationer',
	    notifications: 'Notifikationer',
	    notificationSummary: 'App og titel',
	    notificationAppsMode: 'Apps med notifikationer',
	    allApps: 'Alle apps',
	    selectedApps: 'Valgte apps',
	    appFilterHelp: 'Indtast nøjagtige appnavne eller Android-pakkenavne adskilt af kommaer. For eksempel: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Indtast mindst ét appnavn eller Android-pakkenavn.',
	    helpConnection: 'Hjælp og forbindelse',
	    snapshotHelp: 'Status, da indstillingerne blev åbnet. Åbn dem igen for at opdatere.',
	    permissionHelp: 'Tillad adgang i Pebble, og åbn indstillingerne igen.',
	    pluginHelp: 'Kontrollér, at det relevante plugin er aktiveret i Pebble.',
	    connectionHelp: 'Forbind telefonen og uret, og åbn indstillingerne igen.',
	    technicalDetails: 'Tekniske oplysninger',
	    receivedAge: 'Modtaget for {age} min siden',
	    observedAge: 'Observeret for {age} min siden',
	    readingTemperature: 'Temperatur',
	    readingFeelsLike: 'Føles som',
	    readingHigh: 'Højeste',
	    readingLow: 'Laveste',
	    readingCondition: 'Vejrforhold',
	    readingHumidity: 'Luftfugtighed',
	    readingRain: 'Regn',
	    readingUv: 'UV-indeks',
	    readingBattery: 'Batteri',
	    readingTitle: 'Titel',
	    readingArtist: 'Kunstner',
	    readingName: 'Navn',
	    phoneSource: 'Telefonens batteri',
	    sourceEmpty: 'Ikke valgt',
	    sourceLoading: 'Indlæser',
	    sourceReady: 'Klar',
	    sourceUnavailable: 'Ikke tilgængelig',
	    sourceDenied: 'Tilladelse kræves',
	    sourceUnsupported: 'Data understøttes ikke',
	    sourceDisabled: 'Plugin deaktiveret',
	    sourcePlaying: 'Afspiller',
	    sourcePaused: 'Sat på pause',
	    sourceIdle: 'Afspiller ikke',
	    sourceWaiting: 'Venter på Pebble',
	    saveSaved: 'Urindstillingerne er leveret.',
	    savePending: 'Gemt på telefonen; venter på uret.',
	    saveFailed: 'Gemt på telefonen. Opret forbindelsen igen, og gem igen for at opdatere uret.',
	    saveNone: 'Ændringerne anvendes, når du gemmer.',
	    saveSending: 'Gemmer…',
	    contrastHelp: 'Teksten kan være svær at læse. Vælg andre tekst- og baggrundsfarver.',
	    previewSettingsNote: 'Eksempelvisningen bruger urets palet med 64 farver.',
	    previewCustomHelp: 'Tilpassede farver er omtrentlige. Layoutet bruger urets egen gengivelse.',
	    previewTimelineHelp: 'Det nederste panel er reserveret til Pebble Timeline.',
	    noExample: 'Intet eksempel tilgængeligt'
	  },
	  sv: {
	    samplePreview: 'Exempelförhandsvisning',
	    sampleHelp: 'Exempelskärmar, utan livedata.',
	    previewIdle: 'I vila',
	    previewMusic: 'Musik',
	    previewNotification: 'Avisering',
	    previewTimeline: 'Tidslinje',
	    display: 'Visning',
	    theme: 'Tema',
	    themeLight: 'Ljust',
	    themeDark: 'Mörkt',
	    themeCustom: 'Anpassat',
	    timeFormat: 'Tidsformat',
	    followPebble: 'Följ Pebble',
	    time24: '24-timmarsformat',
	    largerText: 'Större text',
	    languageHelp: 'Språket följer din klocka.',
	    twoReadings: 'Dina två mätvärden',
	    leftReading: 'Vänster',
	    rightReading: 'Höger',
	    musicNotifications: 'Musik och aviseringar',
	    notifications: 'Aviseringar',
	    notificationSummary: 'App och rubrik',
	    notificationAppsMode: 'Appar med aviseringar',
	    allApps: 'Alla appar',
	    selectedApps: 'Valda appar',
	    appFilterHelp: 'Ange exakta appnamn eller Android-paketnamn, åtskilda med kommatecken. Till exempel: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Ange minst ett appnamn eller Android-paketnamn.',
	    helpConnection: 'Hjälp och anslutning',
	    snapshotHelp: 'Status när inställningarna öppnades. Öppna dem igen för att uppdatera.',
	    permissionHelp: 'Tillåt åtkomst i Pebble och öppna sedan inställningarna igen.',
	    pluginHelp: 'Kontrollera att rätt insticksprogram är aktiverat i Pebble.',
	    connectionHelp: 'Anslut telefonen och klockan och öppna sedan inställningarna igen.',
	    technicalDetails: 'Tekniska uppgifter',
	    receivedAge: 'Mottaget för {age} min sedan',
	    observedAge: 'Observerat för {age} min sedan',
	    readingTemperature: 'Temperatur',
	    readingFeelsLike: 'Känns som',
	    readingHigh: 'Högsta',
	    readingLow: 'Lägsta',
	    readingCondition: 'Väderförhållanden',
	    readingHumidity: 'Luftfuktighet',
	    readingRain: 'Regn',
	    readingUv: 'UV-index',
	    readingBattery: 'Batteri',
	    readingTitle: 'Titel',
	    readingArtist: 'Artist',
	    readingName: 'Namn',
	    phoneSource: 'Telefonens batteri',
	    sourceEmpty: 'Inte valt',
	    sourceLoading: 'Läser in',
	    sourceReady: 'Klar',
	    sourceUnavailable: 'Inte tillgängligt',
	    sourceDenied: 'Behörighet krävs',
	    sourceUnsupported: 'Data stöds inte',
	    sourceDisabled: 'Insticksprogrammet är avaktiverat',
	    sourcePlaying: 'Spelar',
	    sourcePaused: 'Pausad',
	    sourceIdle: 'Spelar inte',
	    sourceWaiting: 'Väntar på Pebble',
	    saveSaved: 'Klockinställningarna har levererats.',
	    savePending: 'Sparat på telefonen; väntar på klockan.',
	    saveFailed: 'Sparat på telefonen. Anslut igen och spara på nytt för att uppdatera klockan.',
	    saveNone: 'Ändringarna tillämpas när du sparar.',
	    saveSending: 'Sparar…',
	    contrastHelp: 'Texten kan vara svår att läsa. Välj andra färger för text och bakgrund.',
	    previewSettingsNote: 'Förhandsvisningen använder klockans palett med 64 färger.',
	    previewCustomHelp: 'Anpassade färger är ungefärliga. Layouten använder klockans egen rendering.',
	    previewTimelineHelp: 'Den nedre panelen är reserverad för Pebble Timeline.',
	    noExample: 'Inget exempel tillgängligt'
	  },
	  no: {
	    samplePreview: 'Eksempelforhåndsvisning',
	    sampleHelp: 'Eksempelskjermer, uten sanntidsdata.',
	    previewIdle: 'I ro',
	    previewMusic: 'Musikk',
	    previewNotification: 'Varsel',
	    previewTimeline: 'Tidslinje',
	    display: 'Visning',
	    theme: 'Tema',
	    themeLight: 'Lyst',
	    themeDark: 'Mørkt',
	    themeCustom: 'Tilpasset',
	    timeFormat: 'Tidsformat',
	    followPebble: 'Følg Pebble',
	    time24: '24-timersformat',
	    largerText: 'Større tekst',
	    languageHelp: 'Språket følger klokken din.',
	    twoReadings: 'Dine to målinger',
	    leftReading: 'Venstre',
	    rightReading: 'Høyre',
	    musicNotifications: 'Musikk og varsler',
	    notifications: 'Varsler',
	    notificationSummary: 'App og tittel',
	    notificationAppsMode: 'Apper med varsler',
	    allApps: 'Alle apper',
	    selectedApps: 'Valgte apper',
	    appFilterHelp: 'Skriv inn nøyaktige appnavn eller Android-pakkenavn, atskilt med komma. For eksempel: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Skriv inn minst ett appnavn eller Android-pakkenavn.',
	    helpConnection: 'Hjelp og tilkobling',
	    snapshotHelp: 'Status da innstillingene ble åpnet. Åpne dem igjen for å oppdatere.',
	    permissionHelp: 'Tillat tilgang i Pebble, og åpne innstillingene igjen.',
	    pluginHelp: 'Kontroller at riktig programtillegg er aktivert i Pebble.',
	    connectionHelp: 'Koble sammen telefonen og klokken, og åpne innstillingene igjen.',
	    technicalDetails: 'Tekniske detaljer',
	    receivedAge: 'Mottatt for {age} min siden',
	    observedAge: 'Observert for {age} min siden',
	    readingTemperature: 'Temperatur',
	    readingFeelsLike: 'Føles som',
	    readingHigh: 'Høyeste',
	    readingLow: 'Laveste',
	    readingCondition: 'Værforhold',
	    readingHumidity: 'Luftfuktighet',
	    readingRain: 'Regn',
	    readingUv: 'UV-indeks',
	    readingBattery: 'Batteri',
	    readingTitle: 'Tittel',
	    readingArtist: 'Artist',
	    readingName: 'Navn',
	    phoneSource: 'Telefonbatteri',
	    sourceEmpty: 'Ikke valgt',
	    sourceLoading: 'Laster',
	    sourceReady: 'Klar',
	    sourceUnavailable: 'Utilgjengelig',
	    sourceDenied: 'Tillatelse kreves',
	    sourceUnsupported: 'Data støttes ikke',
	    sourceDisabled: 'Programtillegg deaktivert',
	    sourcePlaying: 'Spiller',
	    sourcePaused: 'Satt på pause',
	    sourceIdle: 'Spiller ikke',
	    sourceWaiting: 'Venter på Pebble',
	    saveSaved: 'Klokkeinnstillingene er levert.',
	    savePending: 'Lagret på telefonen; venter på klokken.',
	    saveFailed: 'Lagret på telefonen. Koble til igjen og lagre på nytt for å oppdatere klokken.',
	    saveNone: 'Endringene tas i bruk etter at du lagrer.',
	    saveSending: 'Lagrer…',
	    contrastHelp: 'Teksten kan være vanskelig å lese. Velg andre tekst- og bakgrunnsfarger.',
	    previewSettingsNote: 'Forhåndsvisningen bruker klokkens palett med 64 farger.',
	    previewCustomHelp: 'Tilpassede farger er omtrentlige. Oppsettet bruker klokkens egen gjengivelse.',
	    previewTimelineHelp: 'Det nederste panelet er reservert for Pebble Timeline.',
	    noExample: 'Ingen eksempler tilgjengelig'
	  },
	  fi: {
	    samplePreview: 'Esimerkkiesikatselu',
	    sampleHelp: 'Esimerkkinäkymiä, ei reaaliaikaisia tietoja.',
	    previewIdle: 'Lepotila',
	    previewMusic: 'Musiikki',
	    previewNotification: 'Ilmoitus',
	    previewTimeline: 'Aikajana',
	    display: 'Näyttö',
	    theme: 'Teema',
	    themeLight: 'Vaalea',
	    themeDark: 'Tumma',
	    themeCustom: 'Mukautettu',
	    timeFormat: 'Ajan esitystapa',
	    followPebble: 'Pebblen mukaan',
	    time24: '24 tunnin kello',
	    largerText: 'Suurempi teksti',
	    languageHelp: 'Kieli määräytyy kellon mukaan.',
	    twoReadings: 'Kaksi arvoasi',
	    leftReading: 'Vasen',
	    rightReading: 'Oikea',
	    musicNotifications: 'Musiikki ja ilmoitukset',
	    notifications: 'Ilmoitukset',
	    notificationSummary: 'Sovellus ja otsikko',
	    notificationAppsMode: 'Ilmoitussovellukset',
	    allApps: 'Kaikki sovellukset',
	    selectedApps: 'Valitut sovellukset',
	    appFilterHelp: 'Kirjoita sovellusten tarkat nimet tai Android-pakettinimet pilkuilla erotettuina. Esimerkiksi: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Kirjoita vähintään yksi sovelluksen nimi tai Android-pakettinimi.',
	    helpConnection: 'Ohje ja yhteys',
	    snapshotHelp: 'Tila asetusten avaushetkellä. Avaa asetukset uudelleen päivittääksesi tilan.',
	    permissionHelp: 'Salli käyttöoikeus Pebblessä ja avaa asetukset uudelleen.',
	    pluginHelp: 'Tarkista, että vastaava lisäosa on käytössä Pebblessä.',
	    connectionHelp: 'Yhdistä puhelin ja kello ja avaa asetukset uudelleen.',
	    technicalDetails: 'Tekniset tiedot',
	    receivedAge: 'Vastaanotettu {age} min sitten',
	    observedAge: 'Havaittu {age} min sitten',
	    readingTemperature: 'Lämpötila',
	    readingFeelsLike: 'Tuntuu kuin',
	    readingHigh: 'Ylin',
	    readingLow: 'Alin',
	    readingCondition: 'Sää',
	    readingHumidity: 'Ilmankosteus',
	    readingRain: 'Sade',
	    readingUv: 'UV-indeksi',
	    readingBattery: 'Akku',
	    readingTitle: 'Otsikko',
	    readingArtist: 'Esittäjä',
	    readingName: 'Nimi',
	    phoneSource: 'Puhelimen akku',
	    sourceEmpty: 'Ei valittu',
	    sourceLoading: 'Ladataan',
	    sourceReady: 'Valmis',
	    sourceUnavailable: 'Ei saatavilla',
	    sourceDenied: 'Lupa tarvitaan',
	    sourceUnsupported: 'Tietoja ei tueta',
	    sourceDisabled: 'Lisäosa poistettu käytöstä',
	    sourcePlaying: 'Toistetaan',
	    sourcePaused: 'Keskeytetty',
	    sourceIdle: 'Ei toistoa',
	    sourceWaiting: 'Odotetaan Pebbleä',
	    saveSaved: 'Kellon asetukset toimitettu.',
	    savePending: 'Tallennettu puhelimeen; odotetaan kelloa.',
	    saveFailed: 'Tallennettu puhelimeen. Muodosta yhteys uudelleen ja tallenna vielä kerran päivittääksesi kellon.',
	    saveNone: 'Muutokset tulevat voimaan tallennuksen jälkeen.',
	    saveSending: 'Tallennetaan…',
	    contrastHelp: 'Tekstiä voi olla vaikea lukea. Valitse toiset teksti- ja taustavärit.',
	    previewSettingsNote: 'Esikatselu käyttää kellon 64 värin palettia.',
	    previewCustomHelp: 'Mukautetut värit ovat likimääräisiä. Asettelu käyttää kellon omaa piirtotapaa.',
	    previewTimelineHelp: 'Alapaneeli on varattu Pebble Timeline -toiminnolle.',
	    noExample: 'Esimerkkiä ei ole saatavilla'
	  },
	  hu: {
	    samplePreview: 'Mintaelőnézet',
	    sampleHelp: 'Példaképernyők, nem élő adatok.',
	    previewIdle: 'Nyugalmi állapot',
	    previewMusic: 'Zene',
	    previewNotification: 'Értesítés',
	    previewTimeline: 'Idővonal',
	    display: 'Kijelző',
	    theme: 'Téma',
	    themeLight: 'Világos',
	    themeDark: 'Sötét',
	    themeCustom: 'Egyéni',
	    timeFormat: 'Időformátum',
	    followPebble: 'A Pebble szerint',
	    time24: '24 órás időformátum',
	    largerText: 'Nagyobb szöveg',
	    languageHelp: 'A nyelv az óra beállítását követi.',
	    twoReadings: 'A két értéked',
	    leftReading: 'Bal',
	    rightReading: 'Jobb',
	    musicNotifications: 'Zene és értesítések',
	    notifications: 'Értesítések',
	    notificationSummary: 'Alkalmazás és cím',
	    notificationAppsMode: 'Értesítést küldő alkalmazások',
	    allApps: 'Minden alkalmazás',
	    selectedApps: 'Kiválasztott alkalmazások',
	    appFilterHelp: 'Add meg az alkalmazások pontos nevét vagy Android-csomagnevét, vesszővel elválasztva. Például: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Adj meg legalább egy alkalmazásnevet vagy Android-csomagnevet.',
	    helpConnection: 'Súgó és kapcsolat',
	    snapshotHelp: 'Állapot a beállítások megnyitásakor. A frissítéshez nyisd meg újra a beállításokat.',
	    permissionHelp: 'Engedélyezd a hozzáférést a Pebble-ben, majd nyisd meg újra a beállításokat.',
	    pluginHelp: 'Ellenőrizd, hogy a megfelelő bővítmény engedélyezve van-e a Pebble-ben.',
	    connectionHelp: 'Csatlakoztasd a telefont és az órát, majd nyisd meg újra a beállításokat.',
	    technicalDetails: 'Műszaki részletek',
	    receivedAge: 'Beérkezett {age} perce',
	    observedAge: 'Megfigyelve {age} perce',
	    readingTemperature: 'Hőmérséklet',
	    readingFeelsLike: 'Hőérzet',
	    readingHigh: 'Legmagasabb',
	    readingLow: 'Legalacsonyabb',
	    readingCondition: 'Időjárás',
	    readingHumidity: 'Páratartalom',
	    readingRain: 'Eső',
	    readingUv: 'UV-index',
	    readingBattery: 'Akkumulátor',
	    readingTitle: 'Cím',
	    readingArtist: 'Előadó',
	    readingName: 'Név',
	    phoneSource: 'Telefon akkumulátora',
	    sourceEmpty: 'Nincs kiválasztva',
	    sourceLoading: 'Betöltés',
	    sourceReady: 'Kész',
	    sourceUnavailable: 'Nem érhető el',
	    sourceDenied: 'Engedély szükséges',
	    sourceUnsupported: 'Nem támogatott adatok',
	    sourceDisabled: 'Bővítmény letiltva',
	    sourcePlaying: 'Lejátszás folyamatban',
	    sourcePaused: 'Szüneteltetve',
	    sourceIdle: 'Nincs lejátszás',
	    sourceWaiting: 'Várakozás a Pebble-re',
	    saveSaved: 'Az óra beállításai megérkeztek.',
	    savePending: 'Mentve a telefonon; várakozás az órára.',
	    saveFailed: 'Mentve a telefonon. Csatlakoztasd újra, majd ments ismét az óra frissítéséhez.',
	    saveNone: 'A módosítások mentés után lépnek életbe.',
	    saveSending: 'Mentés…',
	    contrastHelp: 'A szöveg nehezen olvasható lehet. Válassz más szöveg- és háttérszínt.',
	    previewSettingsNote: 'Az előnézet az óra 64 színű palettáját használja.',
	    previewCustomHelp: 'Az egyéni színek közelítőek. Az elrendezés az óra saját megjelenítését használja.',
	    previewTimelineHelp: 'Az alsó panel a Pebble Timeline számára van fenntartva.',
	    noExample: 'Nincs elérhető példa'
	  },
	  ro: {
	    samplePreview: 'Previzualizare exemplificativă',
	    sampleHelp: 'Ecrane de exemplu, fără date în timp real.',
	    previewIdle: 'În repaus',
	    previewMusic: 'Muzică',
	    previewNotification: 'Notificare',
	    previewTimeline: 'Cronologie',
	    display: 'Afișaj',
	    theme: 'Temă',
	    themeLight: 'Luminoasă',
	    themeDark: 'Întunecată',
	    themeCustom: 'Personalizată',
	    timeFormat: 'Formatul orei',
	    followPebble: 'Conform Pebble',
	    time24: 'Format de 24 de ore',
	    largerText: 'Text mai mare',
	    languageHelp: 'Limba urmează setarea ceasului.',
	    twoReadings: 'Cele două valori ale tale',
	    leftReading: 'Stânga',
	    rightReading: 'Dreapta',
	    musicNotifications: 'Muzică și notificări',
	    notifications: 'Notificări',
	    notificationSummary: 'Aplicație și titlu',
	    notificationAppsMode: 'Aplicații pentru notificări',
	    allApps: 'Toate aplicațiile',
	    selectedApps: 'Aplicații selectate',
	    appFilterHelp: 'Introdu numele exacte ale aplicațiilor sau ale pachetelor Android, separate prin virgule. De exemplu: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'Introdu cel puțin un nume de aplicație sau de pachet Android.',
	    helpConnection: 'Ajutor și conexiune',
	    snapshotHelp: 'Starea la deschiderea setărilor. Redeschide setările pentru a o actualiza.',
	    permissionHelp: 'Permite accesul în Pebble, apoi redeschide setările.',
	    pluginHelp: 'Verifică dacă extensia corespunzătoare este activată în Pebble.',
	    connectionHelp: 'Conectează telefonul și ceasul, apoi redeschide setările.',
	    technicalDetails: 'Detalii tehnice',
	    receivedAge: 'Primit acum {age} min',
	    observedAge: 'Observat acum {age} min',
	    readingTemperature: 'Temperatură',
	    readingFeelsLike: 'Resimțită',
	    readingHigh: 'Maximă',
	    readingLow: 'Minimă',
	    readingCondition: 'Condiții',
	    readingHumidity: 'Umiditate',
	    readingRain: 'Ploaie',
	    readingUv: 'Indice UV',
	    readingBattery: 'Baterie',
	    readingTitle: 'Titlu',
	    readingArtist: 'Artist',
	    readingName: 'Nume',
	    phoneSource: 'Bateria telefonului',
	    sourceEmpty: 'Neselectat',
	    sourceLoading: 'Se încarcă',
	    sourceReady: 'Pregătit',
	    sourceUnavailable: 'Indisponibil',
	    sourceDenied: 'Este necesară permisiunea',
	    sourceUnsupported: 'Date neacceptate',
	    sourceDisabled: 'Extensie dezactivată',
	    sourcePlaying: 'Se redă',
	    sourcePaused: 'În pauză',
	    sourceIdle: 'Nu se redă',
	    sourceWaiting: 'Se așteaptă Pebble',
	    saveSaved: 'Setările ceasului au fost primite.',
	    savePending: 'Salvat pe telefon; se așteaptă ceasul.',
	    saveFailed: 'Salvat pe telefon. Reconectează și salvează din nou pentru a actualiza ceasul.',
	    saveNone: 'Modificările se aplică după salvare.',
	    saveSending: 'Se salvează…',
	    contrastHelp: 'Textul poate fi greu de citit. Alege alte culori pentru text și fundal.',
	    previewSettingsNote: 'Previzualizarea folosește paleta de 64 de culori a ceasului.',
	    previewCustomHelp: 'Culorile personalizate sunt aproximative. Aspectul folosește redarea nativă a ceasului.',
	    previewTimelineHelp: 'Panoul inferior este rezervat pentru Pebble Timeline.',
	    noExample: 'Niciun exemplu disponibil'
	  },
	  tr: {
	    samplePreview: 'Örnek önizleme',
	    sampleHelp: 'Örnek ekranlar, canlı veri değildir.',
	    previewIdle: 'Boşta',
	    previewMusic: 'Müzik',
	    previewNotification: 'Bildirim',
	    previewTimeline: 'Zaman çizelgesi',
	    display: 'Ekran',
	    theme: 'Tema',
	    themeLight: 'Açık',
	    themeDark: 'Koyu',
	    themeCustom: 'Özel',
	    timeFormat: 'Saat biçimi',
	    followPebble: 'Pebble’a göre',
	    time24: '24 saat biçimi',
	    largerText: 'Daha büyük metin',
	    languageHelp: 'Dil, saatinizin ayarına göre belirlenir.',
	    twoReadings: 'İki değeriniz',
	    leftReading: 'Sol',
	    rightReading: 'Sağ',
	    musicNotifications: 'Müzik ve bildirimler',
	    notifications: 'Bildirimler',
	    notificationSummary: 'Uygulama ve başlık',
	    notificationAppsMode: 'Bildirim uygulamaları',
	    allApps: 'Tüm uygulamalar',
	    selectedApps: 'Seçili uygulamalar',
	    appFilterHelp: 'Tam uygulama adlarını veya Android paket adlarını virgülle ayırarak girin. Örneğin: Signal, org.thoughtcrime.securesms',
	    appFilterRequired: 'En az bir uygulama adı veya Android paket adı girin.',
	    helpConnection: 'Yardım ve bağlantı',
	    snapshotHelp: 'Ayarlar açıldığındaki durum. Yenilemek için ayarları yeniden açın.',
	    permissionHelp: 'Pebble’da erişime izin verin, ardından ayarları yeniden açın.',
	    pluginHelp: 'İlgili eklentinin Pebble’da etkin olduğundan emin olun.',
	    connectionHelp: 'Telefonunuzu ve saatinizi bağlayın, ardından ayarları yeniden açın.',
	    technicalDetails: 'Teknik ayrıntılar',
	    receivedAge: '{age} dk önce alındı',
	    observedAge: '{age} dk önce gözlemlendi',
	    readingTemperature: 'Sıcaklık',
	    readingFeelsLike: 'Hissedilen',
	    readingHigh: 'En yüksek',
	    readingLow: 'En düşük',
	    readingCondition: 'Hava durumu',
	    readingHumidity: 'Nem',
	    readingRain: 'Yağmur',
	    readingUv: 'UV indeksi',
	    readingBattery: 'Pil',
	    readingTitle: 'Başlık',
	    readingArtist: 'Sanatçı',
	    readingName: 'Ad',
	    phoneSource: 'Telefon pili',
	    sourceEmpty: 'Seçilmedi',
	    sourceLoading: 'Yükleniyor',
	    sourceReady: 'Hazır',
	    sourceUnavailable: 'Kullanılamıyor',
	    sourceDenied: 'İzin gerekli',
	    sourceUnsupported: 'Desteklenmeyen veri',
	    sourceDisabled: 'Eklenti devre dışı',
	    sourcePlaying: 'Çalıyor',
	    sourcePaused: 'Duraklatıldı',
	    sourceIdle: 'Çalmıyor',
	    sourceWaiting: 'Pebble bekleniyor',
	    saveSaved: 'Saat ayarları iletildi.',
	    savePending: 'Telefona kaydedildi; saat bekleniyor.',
	    saveFailed: 'Telefona kaydedildi. Saati güncellemek için yeniden bağlanıp tekrar kaydedin.',
	    saveNone: 'Değişiklikler kaydettikten sonra uygulanır.',
	    saveSending: 'Kaydediliyor…',
	    contrastHelp: 'Metni okumak zor olabilir. Farklı metin ve arka plan renkleri seçin.',
	    previewSettingsNote: 'Önizleme, saatin 64 renkli paletini kullanır.',
	    previewCustomHelp: 'Özel renkler yaklaşık olarak gösterilir. Düzen, saatin yerel çizimini kullanır.',
	    previewTimelineHelp: 'Alt panel Pebble Timeline için ayrılmıştır.',
	    noExample: 'Örnek yok'
	  }
	};
	// Coherent settings copy for Dynamic 0.5.0. Every active string is present
	// in each supported locale; source names and Android package IDs stay literal.
	var UX_MESSAGES = {
	  "en": {
	    "content": "Content",
	    "layoutPreview": "Layout & colour preview",
	    "previewBanner": "Summary",
	    "previewMessage": "Message",
	    "previewDisabled": "This feature is disabled in your settings.",
	    "previewUnknownFormat": "Example uses 24-hour time; the watch format is not known yet.",
	    "previewSafeHelp": "Examples do not change your privacy settings.",
	    "sharedReadingsHelp": "These are shared Pebble slots. Changing them also affects other watchfaces that use them.",
	    "saveUnsaved": "Unsaved changes",
	    "saveLastDelivered": "Last save delivered",
	    "savePhoneWaiting": "Saved on phone—will apply when the watch reconnects.",
	    "appAdd": "Add",
	    "appRemove": "Remove {app}",
	    "appEntryLabel": "App name or Android package",
	    "appEntryHelp": "Add exact names one at a time. Entries are matched ignoring case.",
	    "appDuplicate": "This app is already listed.",
	    "appInvalid": "Use one app name or package at a time.",
	    "sourceExpired": "Expired",
	    "justObserved": "Just measured",
	    "justReceived": "Just received",
	    "readingSetupHelp": "Choose this reading in Pebble → Settings → Complications.",
	    "sourceNoUpdateHelp": "Check the selected plugin in Pebble.",
	    "accentContrastHelp": "The watch will adjust secondary ink when needed for readability.",
	    "notificationSummaryHelp": "App summaries can include the sender or notification title, but not the message body.",
	    "helpConnection": "Connection & help",
	    "notificationSummary": "App and sender/title",
	    "saveSaved": "Last save delivered",
	    "savePending": "Saved on phone—will apply when the watch reconnects.",
	    "saveFailed": "Saved on phone—will apply when the watch reconnects.",
	    "appLimit": "Keep the complete app list within 160 characters."
	  },
	  "cs": {
	    "content": "Obsah",
	    "layoutPreview": "Náhled rozložení a barev",
	    "previewBanner": "Souhrn",
	    "previewMessage": "Zpráva",
	    "previewDisabled": "Tato funkce je v nastavení vypnutá.",
	    "previewUnknownFormat": "Ukázka používá 24hodinový čas; formát hodinek zatím není známý.",
	    "previewSafeHelp": "Prohlížení ukázek nemění nastavení soukromí.",
	    "sharedReadingsHelp": "Jde o sdílené pozice Pebble. Změna ovlivní také ostatní ciferníky, které je používají.",
	    "saveUnsaved": "Neuložené změny",
	    "saveLastDelivered": "Poslední uložení doručeno",
	    "savePhoneWaiting": "Uloženo v telefonu—použije se po opětovném připojení hodinek.",
	    "appAdd": "Přidat",
	    "appRemove": "Odebrat {app}",
	    "appEntryLabel": "Název aplikace nebo balíčku Androidu",
	    "appEntryHelp": "Přidávejte přesné názvy po jednom. Na velikosti písmen nezáleží.",
	    "appDuplicate": "Tato aplikace už je v seznamu.",
	    "appInvalid": "Zadejte vždy jeden název aplikace nebo balíčku.",
	    "sourceExpired": "Vypršelo",
	    "justObserved": "Právě změřeno",
	    "justReceived": "Právě přijato",
	    "readingSetupHelp": "Tento údaj vyberte v Pebble → Nastavení → Komplikace.",
	    "sourceNoUpdateHelp": "Zkontrolujte vybraný plugin v Pebble.",
	    "accentContrastHelp": "Hodinky podle potřeby upraví barvu vedlejšího textu kvůli čitelnosti.",
	    "notificationSummaryHelp": "Souhrn může obsahovat odesílatele nebo titulek oznámení, ale ne text zprávy.",
	    "helpConnection": "Připojení a nápověda",
	    "notificationSummary": "Aplikace a odesílatel/titulek",
	    "saveSaved": "Poslední uložení doručeno",
	    "savePending": "Uloženo v telefonu—použije se po opětovném připojení hodinek.",
	    "saveFailed": "Uloženo v telefonu—použije se po opětovném připojení hodinek.",
	    "appLimit": "Celý seznam aplikací musí mít nejvýše 160 znaků."
	  },
	  "sk": {
	    "content": "Obsah",
	    "layoutPreview": "Náhľad rozloženia a farieb",
	    "previewBanner": "Súhrn",
	    "previewMessage": "Správa",
	    "previewDisabled": "Táto funkcia je v nastaveniach vypnutá.",
	    "previewUnknownFormat": "Ukážka používa 24-hodinový čas; formát hodiniek zatiaľ nie je známy.",
	    "previewSafeHelp": "Prezeranie ukážok nemení nastavenia súkromia.",
	    "sharedReadingsHelp": "Ide o zdieľané pozície Pebble. Zmena ovplyvní aj ostatné ciferníky, ktoré ich používajú.",
	    "saveUnsaved": "Neuložené zmeny",
	    "saveLastDelivered": "Posledné uloženie doručené",
	    "savePhoneWaiting": "Uložené v telefóne—použije sa po opätovnom pripojení hodiniek.",
	    "appAdd": "Pridať",
	    "appRemove": "Odobrať {app}",
	    "appEntryLabel": "Názov aplikácie alebo balíka Androidu",
	    "appEntryHelp": "Pridávajte presné názvy po jednom. Na veľkosti písmen nezáleží.",
	    "appDuplicate": "Táto aplikácia už je v zozname.",
	    "appInvalid": "Zadajte vždy jeden názov aplikácie alebo balíka.",
	    "sourceExpired": "Vypršalo",
	    "justObserved": "Práve zmerané",
	    "justReceived": "Práve prijaté",
	    "readingSetupHelp": "Tento údaj vyberte v Pebble → Nastavenia → Komplikácie.",
	    "sourceNoUpdateHelp": "Skontrolujte vybraný plugin v Pebble.",
	    "accentContrastHelp": "Hodinky podľa potreby upravia farbu vedľajšieho textu pre lepšiu čitateľnosť.",
	    "notificationSummaryHelp": "Súhrn môže obsahovať odosielateľa alebo titulok oznámenia, ale nie text správy.",
	    "helpConnection": "Pripojenie a pomoc",
	    "notificationSummary": "Aplikácia a odosielateľ/titulok",
	    "saveSaved": "Posledné uloženie doručené",
	    "savePending": "Uložené v telefóne—použije sa po opätovnom pripojení hodiniek.",
	    "saveFailed": "Uložené v telefóne—použije sa po opätovnom pripojení hodiniek.",
	    "appLimit": "Celý zoznam aplikácií musí mať najviac 160 znakov."
	  },
	  "de": {
	    "content": "Inhalt",
	    "layoutPreview": "Vorschau von Layout und Farben",
	    "previewBanner": "Zusammenfassung",
	    "previewMessage": "Nachricht",
	    "previewDisabled": "Diese Funktion ist in deinen Einstellungen ausgeschaltet.",
	    "previewUnknownFormat": "Das Beispiel zeigt das 24-Stunden-Format; das Uhrenformat ist noch unbekannt.",
	    "previewSafeHelp": "Beispiele ändern deine Datenschutzeinstellungen nicht.",
	    "sharedReadingsHelp": "Dies sind gemeinsame Pebble-Felder. Änderungen betreffen auch andere Zifferblätter, die sie nutzen.",
	    "saveUnsaved": "Ungespeicherte Änderungen",
	    "saveLastDelivered": "Letzte Speicherung übertragen",
	    "savePhoneWaiting": "Auf dem Telefon gespeichert—wird bei erneuter Verbindung mit der Uhr angewendet.",
	    "appAdd": "Hinzufügen",
	    "appRemove": "{app} entfernen",
	    "appEntryLabel": "App-Name oder Android-Paket",
	    "appEntryHelp": "Genaue Namen einzeln hinzufügen. Groß- und Kleinschreibung wird nicht unterschieden.",
	    "appDuplicate": "Diese App ist bereits aufgeführt.",
	    "appInvalid": "Jeweils einen App-Namen oder ein Paket eingeben.",
	    "sourceExpired": "Abgelaufen",
	    "justObserved": "Gerade gemessen",
	    "justReceived": "Gerade empfangen",
	    "readingSetupHelp": "Diesen Wert in Pebble → Einstellungen → Komplikationen auswählen.",
	    "sourceNoUpdateHelp": "Prüfe das ausgewählte Plugin in Pebble.",
	    "accentContrastHelp": "Die Uhr passt bei Bedarf die Farbe nachrangiger Texte für bessere Lesbarkeit an.",
	    "notificationSummaryHelp": "App-Zusammenfassungen können Absender oder Benachrichtigungstitel enthalten, aber keinen Nachrichtentext.",
	    "helpConnection": "Verbindung und Hilfe",
	    "notificationSummary": "App und Absender/Titel",
	    "saveSaved": "Letzte Speicherung übertragen",
	    "savePending": "Auf dem Telefon gespeichert—wird bei erneuter Verbindung mit der Uhr angewendet.",
	    "saveFailed": "Auf dem Telefon gespeichert—wird bei erneuter Verbindung mit der Uhr angewendet.",
	    "appLimit": "Die gesamte App-Liste darf höchstens 160 Zeichen enthalten."
	  },
	  "fr": {
	    "content": "Contenu",
	    "layoutPreview": "Aperçu de la disposition et des couleurs",
	    "previewBanner": "Résumé",
	    "previewMessage": "Texte du message",
	    "previewDisabled": "Cette fonction est désactivée dans vos réglages.",
	    "previewUnknownFormat": "L’exemple utilise le format 24 heures ; celui de la montre n’est pas encore connu.",
	    "previewSafeHelp": "Les exemples ne modifient pas vos réglages de confidentialité.",
	    "sharedReadingsHelp": "Ces emplacements Pebble sont partagés. Les modifier affecte aussi les autres cadrans qui les utilisent.",
	    "saveUnsaved": "Modifications non enregistrées",
	    "saveLastDelivered": "Dernier enregistrement transmis",
	    "savePhoneWaiting": "Enregistré sur le téléphone—sera appliqué à la reconnexion de la montre.",
	    "appAdd": "Ajouter",
	    "appRemove": "Retirer {app}",
	    "appEntryLabel": "Nom d’application ou paquet Android",
	    "appEntryHelp": "Ajoutez les noms exacts un par un. La casse n’est pas prise en compte.",
	    "appDuplicate": "Cette application figure déjà dans la liste.",
	    "appInvalid": "Saisissez un seul nom d’application ou paquet à la fois.",
	    "sourceExpired": "Expiré",
	    "justObserved": "Mesuré à l’instant",
	    "justReceived": "Reçu à l’instant",
	    "readingSetupHelp": "Choisissez cette donnée dans Pebble → Réglages → Complications.",
	    "sourceNoUpdateHelp": "Vérifiez le plugin sélectionné dans Pebble.",
	    "accentContrastHelp": "La montre ajuste au besoin la couleur du texte secondaire pour préserver sa lisibilité.",
	    "notificationSummaryHelp": "Les résumés peuvent inclure l’expéditeur ou le titre de la notification, mais pas le corps du message.",
	    "helpConnection": "Connexion et aide",
	    "notificationSummary": "Application et expéditeur/titre",
	    "saveSaved": "Dernier enregistrement transmis",
	    "savePending": "Enregistré sur le téléphone—sera appliqué à la reconnexion de la montre.",
	    "saveFailed": "Enregistré sur le téléphone—sera appliqué à la reconnexion de la montre.",
	    "appLimit": "La liste complète des applications doit rester dans la limite de 160 caractères."
	  },
	  "es": {
	    "content": "Contenido",
	    "layoutPreview": "Vista de distribución y colores",
	    "previewBanner": "Resumen",
	    "previewMessage": "Mensaje",
	    "previewDisabled": "Esta función está desactivada en tus ajustes.",
	    "previewUnknownFormat": "El ejemplo usa el formato de 24 horas; aún no se conoce el del reloj.",
	    "previewSafeHelp": "Los ejemplos no cambian tus ajustes de privacidad.",
	    "sharedReadingsHelp": "Estas posiciones de Pebble son compartidas. Cambiarlas también afecta a otras esferas que las utilizan.",
	    "saveUnsaved": "Cambios sin guardar",
	    "saveLastDelivered": "Último guardado entregado",
	    "savePhoneWaiting": "Guardado en el teléfono—se aplicará cuando el reloj vuelva a conectarse.",
	    "appAdd": "Añadir",
	    "appRemove": "Quitar {app}",
	    "appEntryLabel": "Nombre de aplicación o paquete Android",
	    "appEntryHelp": "Añade los nombres exactos uno a uno. No se distinguen mayúsculas de minúsculas.",
	    "appDuplicate": "Esta aplicación ya está en la lista.",
	    "appInvalid": "Introduce un solo nombre de aplicación o paquete cada vez.",
	    "sourceExpired": "Caducado",
	    "justObserved": "Recién medido",
	    "justReceived": "Recién recibido",
	    "readingSetupHelp": "Elige este dato en Pebble → Ajustes → Complicaciones.",
	    "sourceNoUpdateHelp": "Comprueba el plugin seleccionado en Pebble.",
	    "accentContrastHelp": "El reloj ajustará el color del texto secundario cuando sea necesario para mejorar la lectura.",
	    "notificationSummaryHelp": "Los resúmenes pueden incluir el remitente o el título de la notificación, pero no el texto del mensaje.",
	    "helpConnection": "Conexión y ayuda",
	    "notificationSummary": "Aplicación y remitente/título",
	    "saveSaved": "Último guardado entregado",
	    "savePending": "Guardado en el teléfono—se aplicará cuando el reloj vuelva a conectarse.",
	    "saveFailed": "Guardado en el teléfono—se aplicará cuando el reloj vuelva a conectarse.",
	    "appLimit": "La lista completa de aplicaciones debe tener como máximo 160 caracteres."
	  },
	  "it": {
	    "content": "Contenuti",
	    "layoutPreview": "Anteprima di disposizione e colori",
	    "previewBanner": "Riepilogo",
	    "previewMessage": "Messaggio",
	    "previewDisabled": "Questa funzione è disattivata nelle impostazioni.",
	    "previewUnknownFormat": "L’esempio usa il formato a 24 ore; quello dell’orologio non è ancora noto.",
	    "previewSafeHelp": "Gli esempi non modificano le impostazioni di privacy.",
	    "sharedReadingsHelp": "Queste posizioni Pebble sono condivise. Modificarle influisce anche sugli altri quadranti che le usano.",
	    "saveUnsaved": "Modifiche non salvate",
	    "saveLastDelivered": "Ultimo salvataggio consegnato",
	    "savePhoneWaiting": "Salvato sul telefono—verrà applicato quando l’orologio si riconnetterà.",
	    "appAdd": "Aggiungi",
	    "appRemove": "Rimuovi {app}",
	    "appEntryLabel": "Nome dell’app o pacchetto Android",
	    "appEntryHelp": "Aggiungi i nomi esatti uno alla volta. Maiuscole e minuscole non fanno differenza.",
	    "appDuplicate": "Questa app è già nell’elenco.",
	    "appInvalid": "Inserisci un solo nome di app o pacchetto alla volta.",
	    "sourceExpired": "Scaduto",
	    "justObserved": "Appena misurato",
	    "justReceived": "Appena ricevuto",
	    "readingSetupHelp": "Scegli questo dato in Pebble → Impostazioni → Complicazioni.",
	    "sourceNoUpdateHelp": "Controlla il plugin selezionato in Pebble.",
	    "accentContrastHelp": "L’orologio adatterà il colore del testo secondario quando necessario per facilitarne la lettura.",
	    "notificationSummaryHelp": "I riepiloghi possono includere il mittente o il titolo della notifica, ma non il testo del messaggio.",
	    "helpConnection": "Connessione e aiuto",
	    "notificationSummary": "App e mittente/titolo",
	    "saveSaved": "Ultimo salvataggio consegnato",
	    "savePending": "Salvato sul telefono—verrà applicato quando l’orologio si riconnetterà.",
	    "saveFailed": "Salvato sul telefono—verrà applicato quando l’orologio si riconnetterà.",
	    "appLimit": "L’elenco completo delle app deve rimanere entro 160 caratteri."
	  },
	  "pt": {
	    "content": "Conteúdo",
	    "layoutPreview": "Pré-visualização do esquema e das cores",
	    "previewBanner": "Resumo",
	    "previewMessage": "Mensagem",
	    "previewDisabled": "Esta função está desativada nas definições.",
	    "previewUnknownFormat": "O exemplo usa o formato de 24 horas; o formato do relógio ainda não é conhecido.",
	    "previewSafeHelp": "Os exemplos não alteram as definições de privacidade.",
	    "sharedReadingsHelp": "Estas posições Pebble são partilhadas. Alterá-las também afeta outros mostradores que as usam.",
	    "saveUnsaved": "Alterações por guardar",
	    "saveLastDelivered": "Última gravação entregue",
	    "savePhoneWaiting": "Guardado no telefone—será aplicado quando o relógio voltar a ligar-se.",
	    "appAdd": "Adicionar",
	    "appRemove": "Remover {app}",
	    "appEntryLabel": "Nome da aplicação ou pacote Android",
	    "appEntryHelp": "Adicione os nomes exatos um de cada vez. Maiúsculas e minúsculas não fazem diferença.",
	    "appDuplicate": "Esta aplicação já está na lista.",
	    "appInvalid": "Introduza apenas um nome de aplicação ou pacote de cada vez.",
	    "sourceExpired": "Expirado",
	    "justObserved": "Acabado de medir",
	    "justReceived": "Acabado de receber",
	    "readingSetupHelp": "Escolha este dado em Pebble → Definições → Complicações.",
	    "sourceNoUpdateHelp": "Verifique o plugin selecionado no Pebble.",
	    "accentContrastHelp": "O relógio ajustará a cor do texto secundário quando necessário para melhorar a leitura.",
	    "notificationSummaryHelp": "Os resumos podem incluir o remetente ou o título da notificação, mas não o texto da mensagem.",
	    "helpConnection": "Ligação e ajuda",
	    "notificationSummary": "Aplicação e remetente/título",
	    "saveSaved": "Última gravação entregue",
	    "savePending": "Guardado no telefone—será aplicado quando o relógio voltar a ligar-se.",
	    "saveFailed": "Guardado no telefone—será aplicado quando o relógio voltar a ligar-se.",
	    "appLimit": "A lista completa de aplicações deve ter no máximo 160 caracteres."
	  },
	  "nl": {
	    "content": "Inhoud",
	    "layoutPreview": "Voorbeeld van indeling en kleuren",
	    "previewBanner": "Overzicht",
	    "previewMessage": "Bericht",
	    "previewDisabled": "Deze functie staat uit in je instellingen.",
	    "previewUnknownFormat": "Het voorbeeld gebruikt de 24-uursnotatie; de notatie van het horloge is nog onbekend.",
	    "previewSafeHelp": "Voorbeelden veranderen je privacyinstellingen niet.",
	    "sharedReadingsHelp": "Dit zijn gedeelde Pebble-posities. Wijzigingen gelden ook voor andere wijzerplaten die ze gebruiken.",
	    "saveUnsaved": "Niet-opgeslagen wijzigingen",
	    "saveLastDelivered": "Laatste opslag afgeleverd",
	    "savePhoneWaiting": "Op de telefoon opgeslagen—wordt toegepast zodra het horloge opnieuw verbinding maakt.",
	    "appAdd": "Toevoegen",
	    "appRemove": "{app} verwijderen",
	    "appEntryLabel": "App-naam of Android-pakket",
	    "appEntryHelp": "Voeg exacte namen één voor één toe. Hoofdletters en kleine letters worden gelijk behandeld.",
	    "appDuplicate": "Deze app staat al in de lijst.",
	    "appInvalid": "Voer één app-naam of pakket tegelijk in.",
	    "sourceExpired": "Verlopen",
	    "justObserved": "Zojuist gemeten",
	    "justReceived": "Zojuist ontvangen",
	    "readingSetupHelp": "Kies deze waarde in Pebble → Instellingen → Complicaties.",
	    "sourceNoUpdateHelp": "Controleer de geselecteerde plug-in in Pebble.",
	    "accentContrastHelp": "Het horloge past de kleur van secundaire tekst zo nodig aan voor betere leesbaarheid.",
	    "notificationSummaryHelp": "App-overzichten kunnen de afzender of meldingstitel bevatten, maar niet de berichttekst.",
	    "helpConnection": "Verbinding en hulp",
	    "notificationSummary": "App en afzender/titel",
	    "saveSaved": "Laatste opslag afgeleverd",
	    "savePending": "Op de telefoon opgeslagen—wordt toegepast zodra het horloge opnieuw verbinding maakt.",
	    "saveFailed": "Op de telefoon opgeslagen—wordt toegepast zodra het horloge opnieuw verbinding maakt.",
	    "appLimit": "Houd de volledige applijst binnen 160 tekens."
	  },
	  "pl": {
	    "content": "Treść",
	    "layoutPreview": "Podgląd układu i kolorów",
	    "previewBanner": "Podsumowanie",
	    "previewMessage": "Wiadomość",
	    "previewDisabled": "Ta funkcja jest wyłączona w ustawieniach.",
	    "previewUnknownFormat": "Przykład używa formatu 24-godzinnego; format zegarka nie jest jeszcze znany.",
	    "previewSafeHelp": "Podgląd przykładów nie zmienia ustawień prywatności.",
	    "sharedReadingsHelp": "To wspólne pozycje Pebble. Ich zmiana wpływa też na inne tarcze, które z nich korzystają.",
	    "saveUnsaved": "Niezapisane zmiany",
	    "saveLastDelivered": "Ostatni zapis dostarczony",
	    "savePhoneWaiting": "Zapisano w telefonie—zostanie zastosowane po ponownym połączeniu zegarka.",
	    "appAdd": "Dodaj",
	    "appRemove": "Usuń {app}",
	    "appEntryLabel": "Nazwa aplikacji lub pakiet Androida",
	    "appEntryHelp": "Dodawaj dokładne nazwy pojedynczo. Wielkość liter nie ma znaczenia.",
	    "appDuplicate": "Ta aplikacja jest już na liście.",
	    "appInvalid": "Wpisz jedną nazwę aplikacji lub pakietu naraz.",
	    "sourceExpired": "Wygasło",
	    "justObserved": "Właśnie zmierzono",
	    "justReceived": "Właśnie odebrano",
	    "readingSetupHelp": "Wybierz tę wartość w Pebble → Ustawienia → Komplikacje.",
	    "sourceNoUpdateHelp": "Sprawdź wybraną wtyczkę w Pebble.",
	    "accentContrastHelp": "Zegarek w razie potrzeby dostosuje kolor tekstu pomocniczego, aby zachować czytelność.",
	    "notificationSummaryHelp": "Podsumowania mogą zawierać nadawcę lub tytuł powiadomienia, ale nie treść wiadomości.",
	    "helpConnection": "Połączenie i pomoc",
	    "notificationSummary": "Aplikacja i nadawca/tytuł",
	    "saveSaved": "Ostatni zapis dostarczony",
	    "savePending": "Zapisano w telefonie—zostanie zastosowane po ponownym połączeniu zegarka.",
	    "saveFailed": "Zapisano w telefonie—zostanie zastosowane po ponownym połączeniu zegarka.",
	    "appLimit": "Cała lista aplikacji może mieć najwyżej 160 znaków."
	  },
	  "da": {
	    "content": "Indhold",
	    "layoutPreview": "Forhåndsvisning af layout og farver",
	    "previewBanner": "Oversigt",
	    "previewMessage": "Besked",
	    "previewDisabled": "Denne funktion er slået fra i dine indstillinger.",
	    "previewUnknownFormat": "Eksemplet bruger 24-timers format; urets format er endnu ukendt.",
	    "previewSafeHelp": "Eksempler ændrer ikke dine privatlivsindstillinger.",
	    "sharedReadingsHelp": "Dette er delte Pebble-pladser. Ændringer påvirker også andre urskiver, der bruger dem.",
	    "saveUnsaved": "Ikke-gemte ændringer",
	    "saveLastDelivered": "Seneste gemning leveret",
	    "savePhoneWaiting": "Gemt på telefonen—anvendes, når uret opretter forbindelse igen.",
	    "appAdd": "Tilføj",
	    "appRemove": "Fjern {app}",
	    "appEntryLabel": "Appnavn eller Android-pakke",
	    "appEntryHelp": "Tilføj præcise navne ét ad gangen. Der skelnes ikke mellem store og små bogstaver.",
	    "appDuplicate": "Denne app er allerede på listen.",
	    "appInvalid": "Indtast ét appnavn eller én pakke ad gangen.",
	    "sourceExpired": "Udløbet",
	    "justObserved": "Netop målt",
	    "justReceived": "Netop modtaget",
	    "readingSetupHelp": "Vælg denne værdi i Pebble → Indstillinger → Komplikationer.",
	    "sourceNoUpdateHelp": "Kontrollér det valgte plugin i Pebble.",
	    "accentContrastHelp": "Uret tilpasser farven på sekundær tekst efter behov, så den er læselig.",
	    "notificationSummaryHelp": "Appoversigter kan indeholde afsenderen eller meddelelsens titel, men ikke beskedteksten.",
	    "helpConnection": "Forbindelse og hjælp",
	    "notificationSummary": "App og afsender/titel",
	    "saveSaved": "Seneste gemning leveret",
	    "savePending": "Gemt på telefonen—anvendes, når uret opretter forbindelse igen.",
	    "saveFailed": "Gemt på telefonen—anvendes, når uret opretter forbindelse igen.",
	    "appLimit": "Den samlede appliste må højst indeholde 160 tegn."
	  },
	  "sv": {
	    "content": "Innehåll",
	    "layoutPreview": "Förhandsvisning av layout och färger",
	    "previewBanner": "Sammanfattning",
	    "previewMessage": "Meddelande",
	    "previewDisabled": "Den här funktionen är avstängd i dina inställningar.",
	    "previewUnknownFormat": "Exemplet använder 24-timmarsformat; klockans format är ännu okänt.",
	    "previewSafeHelp": "Exemplen ändrar inte dina integritetsinställningar.",
	    "sharedReadingsHelp": "Detta är delade Pebble-platser. Ändringar påverkar också andra urtavlor som använder dem.",
	    "saveUnsaved": "Osparade ändringar",
	    "saveLastDelivered": "Senaste sparningen levererad",
	    "savePhoneWaiting": "Sparat på telefonen—tillämpas när klockan ansluter igen.",
	    "appAdd": "Lägg till",
	    "appRemove": "Ta bort {app}",
	    "appEntryLabel": "Appnamn eller Android-paket",
	    "appEntryHelp": "Lägg till exakta namn ett i taget. Stora och små bokstäver behandlas lika.",
	    "appDuplicate": "Den här appen finns redan i listan.",
	    "appInvalid": "Ange ett appnamn eller paket i taget.",
	    "sourceExpired": "Utgånget",
	    "justObserved": "Nyss uppmätt",
	    "justReceived": "Nyss mottaget",
	    "readingSetupHelp": "Välj detta värde i Pebble → Inställningar → Komplikationer.",
	    "sourceNoUpdateHelp": "Kontrollera valt plugin i Pebble.",
	    "accentContrastHelp": "Klockan anpassar färgen på sekundär text vid behov för bättre läsbarhet.",
	    "notificationSummaryHelp": "Appsammanfattningar kan innehålla avsändaren eller aviseringsrubriken, men inte meddelandetexten.",
	    "helpConnection": "Anslutning och hjälp",
	    "notificationSummary": "App och avsändare/rubrik",
	    "saveSaved": "Senaste sparningen levererad",
	    "savePending": "Sparat på telefonen—tillämpas när klockan ansluter igen.",
	    "saveFailed": "Sparat på telefonen—tillämpas när klockan ansluter igen.",
	    "appLimit": "Hela applistan får innehålla högst 160 tecken."
	  },
	  "no": {
	    "content": "Innhold",
	    "layoutPreview": "Forhåndsvisning av oppsett og farger",
	    "previewBanner": "Sammendrag",
	    "previewMessage": "Melding",
	    "previewDisabled": "Denne funksjonen er slått av i innstillingene.",
	    "previewUnknownFormat": "Eksemplet bruker 24-timersformat; klokkens format er ennå ukjent.",
	    "previewSafeHelp": "Eksemplene endrer ikke personverninnstillingene dine.",
	    "sharedReadingsHelp": "Dette er delte Pebble-plasser. Endringer påvirker også andre urskiver som bruker dem.",
	    "saveUnsaved": "Ulagrede endringer",
	    "saveLastDelivered": "Siste lagring levert",
	    "savePhoneWaiting": "Lagret på telefonen—tas i bruk når klokken kobler til igjen.",
	    "appAdd": "Legg til",
	    "appRemove": "Fjern {app}",
	    "appEntryLabel": "Appnavn eller Android-pakke",
	    "appEntryHelp": "Legg til nøyaktige navn ett om gangen. Store og små bokstaver behandles likt.",
	    "appDuplicate": "Denne appen finnes allerede i listen.",
	    "appInvalid": "Skriv inn ett appnavn eller én pakke om gangen.",
	    "sourceExpired": "Utløpt",
	    "justObserved": "Nettopp målt",
	    "justReceived": "Nettopp mottatt",
	    "readingSetupHelp": "Velg denne verdien i Pebble → Innstillinger → Komplikasjoner.",
	    "sourceNoUpdateHelp": "Kontroller valgt programtillegg i Pebble.",
	    "accentContrastHelp": "Klokken tilpasser fargen på sekundær tekst ved behov for bedre lesbarhet.",
	    "notificationSummaryHelp": "Appsammendrag kan inneholde avsenderen eller varseltittelen, men ikke meldingsteksten.",
	    "helpConnection": "Tilkobling og hjelp",
	    "notificationSummary": "App og avsender/tittel",
	    "saveSaved": "Siste lagring levert",
	    "savePending": "Lagret på telefonen—tas i bruk når klokken kobler til igjen.",
	    "saveFailed": "Lagret på telefonen—tas i bruk når klokken kobler til igjen.",
	    "appLimit": "Hele applisten kan inneholde høyst 160 tegn."
	  },
	  "fi": {
	    "content": "Sisältö",
	    "layoutPreview": "Asettelun ja värien esikatselu",
	    "previewBanner": "Yhteenveto",
	    "previewMessage": "Viesti",
	    "previewDisabled": "Tämä toiminto on poistettu käytöstä asetuksissasi.",
	    "previewUnknownFormat": "Esimerkki käyttää 24 tunnin aikaa; kellon aikamuoto ei ole vielä tiedossa.",
	    "previewSafeHelp": "Esimerkit eivät muuta yksityisyysasetuksiasi.",
	    "sharedReadingsHelp": "Nämä ovat yhteisiä Pebble-paikkoja. Muutokset vaikuttavat myös muihin niitä käyttäviin kellotauluihin.",
	    "saveUnsaved": "Tallentamattomia muutoksia",
	    "saveLastDelivered": "Viimeisin tallennus toimitettu",
	    "savePhoneWaiting": "Tallennettu puhelimeen—otetaan käyttöön, kun kello muodostaa yhteyden uudelleen.",
	    "appAdd": "Lisää",
	    "appRemove": "Poista {app}",
	    "appEntryLabel": "Sovelluksen nimi tai Android-paketti",
	    "appEntryHelp": "Lisää tarkat nimet yksi kerrallaan. Kirjainkoolla ei ole merkitystä.",
	    "appDuplicate": "Tämä sovellus on jo luettelossa.",
	    "appInvalid": "Anna yksi sovelluksen tai paketin nimi kerrallaan.",
	    "sourceExpired": "Vanhentunut",
	    "justObserved": "Juuri mitattu",
	    "justReceived": "Juuri vastaanotettu",
	    "readingSetupHelp": "Valitse tämä arvo kohdassa Pebble → Asetukset → Komplikaatiot.",
	    "sourceNoUpdateHelp": "Tarkista valittu liitännäinen Pebblessä.",
	    "accentContrastHelp": "Kello säätää tarvittaessa toissijaisen tekstin väriä luettavuuden parantamiseksi.",
	    "notificationSummaryHelp": "Sovellusyhteenvedot voivat sisältää lähettäjän tai ilmoituksen otsikon, mutta eivät viestin tekstiä.",
	    "helpConnection": "Yhteys ja ohje",
	    "notificationSummary": "Sovellus ja lähettäjä/otsikko",
	    "saveSaved": "Viimeisin tallennus toimitettu",
	    "savePending": "Tallennettu puhelimeen—otetaan käyttöön, kun kello muodostaa yhteyden uudelleen.",
	    "saveFailed": "Tallennettu puhelimeen—otetaan käyttöön, kun kello muodostaa yhteyden uudelleen.",
	    "appLimit": "Koko sovellusluettelo saa sisältää enintään 160 merkkiä."
	  },
	  "hu": {
	    "content": "Tartalom",
	    "layoutPreview": "Elrendezés és színek előnézete",
	    "previewBanner": "Összegzés",
	    "previewMessage": "Üzenet",
	    "previewDisabled": "Ez a funkció ki van kapcsolva a beállításokban.",
	    "previewUnknownFormat": "A példa 24 órás formátumot használ; az óra formátuma még nem ismert.",
	    "previewSafeHelp": "A példák nem változtatják meg az adatvédelmi beállításokat.",
	    "sharedReadingsHelp": "Ezek közös Pebble-helyek. Módosításuk a többi, ezeket használó számlapra is hat.",
	    "saveUnsaved": "Nem mentett módosítások",
	    "saveLastDelivered": "Legutóbbi mentés kézbesítve",
	    "savePhoneWaiting": "A telefonon mentve—az óra újracsatlakozásakor lép érvénybe.",
	    "appAdd": "Hozzáadás",
	    "appRemove": "{app} eltávolítása",
	    "appEntryLabel": "Alkalmazásnév vagy Android-csomag",
	    "appEntryHelp": "A pontos neveket egyenként add hozzá. A kis- és nagybetűk nem számítanak.",
	    "appDuplicate": "Ez az alkalmazás már szerepel a listában.",
	    "appInvalid": "Egyszerre egy alkalmazás- vagy csomagnevet adj meg.",
	    "sourceExpired": "Lejárt",
	    "justObserved": "Most mérve",
	    "justReceived": "Most érkezett",
	    "readingSetupHelp": "Ezt az értéket itt válaszd ki: Pebble → Beállítások → Komplikációk.",
	    "sourceNoUpdateHelp": "Ellenőrizd a kiválasztott bővítményt a Pebble-ben.",
	    "accentContrastHelp": "Az óra szükség esetén módosítja a másodlagos szöveg színét az olvashatóság érdekében.",
	    "notificationSummaryHelp": "Az alkalmazásösszegzések tartalmazhatják a feladót vagy az értesítés címét, de az üzenet szövegét nem.",
	    "helpConnection": "Kapcsolat és súgó",
	    "notificationSummary": "Alkalmazás és feladó/cím",
	    "saveSaved": "Legutóbbi mentés kézbesítve",
	    "savePending": "A telefonon mentve—az óra újracsatlakozásakor lép érvénybe.",
	    "saveFailed": "A telefonon mentve—az óra újracsatlakozásakor lép érvénybe.",
	    "appLimit": "A teljes alkalmazáslista legfeljebb 160 karakter lehet."
	  },
	  "ro": {
	    "content": "Conținut",
	    "layoutPreview": "Previzualizarea aspectului și culorilor",
	    "previewBanner": "Rezumat",
	    "previewMessage": "Mesaj",
	    "previewDisabled": "Această funcție este dezactivată în setări.",
	    "previewUnknownFormat": "Exemplul folosește formatul de 24 de ore; formatul ceasului nu este încă cunoscut.",
	    "previewSafeHelp": "Exemplele nu modifică setările de confidențialitate.",
	    "sharedReadingsHelp": "Aceste poziții Pebble sunt comune. Modificarea lor afectează și alte cadrane care le folosesc.",
	    "saveUnsaved": "Modificări nesalvate",
	    "saveLastDelivered": "Ultima salvare livrată",
	    "savePhoneWaiting": "Salvat pe telefon—se va aplica atunci când ceasul se reconectează.",
	    "appAdd": "Adaugă",
	    "appRemove": "Elimină {app}",
	    "appEntryLabel": "Numele aplicației sau pachetul Android",
	    "appEntryHelp": "Adaugă numele exacte pe rând. Nu se face diferență între majuscule și minuscule.",
	    "appDuplicate": "Această aplicație este deja în listă.",
	    "appInvalid": "Introdu un singur nume de aplicație sau de pachet odată.",
	    "sourceExpired": "Expirat",
	    "justObserved": "Tocmai măsurat",
	    "justReceived": "Tocmai primit",
	    "readingSetupHelp": "Alege această valoare în Pebble → Setări → Complicații.",
	    "sourceNoUpdateHelp": "Verifică pluginul selectat în Pebble.",
	    "accentContrastHelp": "Ceasul va ajusta culoarea textului secundar când este necesar pentru lizibilitate.",
	    "notificationSummaryHelp": "Rezumatele pot include expeditorul sau titlul notificării, dar nu și textul mesajului.",
	    "helpConnection": "Conexiune și ajutor",
	    "notificationSummary": "Aplicație și expeditor/titlu",
	    "saveSaved": "Ultima salvare livrată",
	    "savePending": "Salvat pe telefon—se va aplica atunci când ceasul se reconectează.",
	    "saveFailed": "Salvat pe telefon—se va aplica atunci când ceasul se reconectează.",
	    "appLimit": "Lista completă de aplicații trebuie să aibă cel mult 160 de caractere."
	  },
	  "tr": {
	    "content": "İçerik",
	    "layoutPreview": "Düzen ve renk önizlemesi",
	    "previewBanner": "Özet",
	    "previewMessage": "İleti",
	    "previewDisabled": "Bu özellik ayarlarınızda kapalı.",
	    "previewUnknownFormat": "Örnek 24 saat biçimini kullanır; saatin biçimi henüz bilinmiyor.",
	    "previewSafeHelp": "Örnekler gizlilik ayarlarınızı değiştirmez.",
	    "sharedReadingsHelp": "Bunlar paylaşılan Pebble alanlarıdır. Değişiklikler, bunları kullanan diğer saat yüzlerini de etkiler.",
	    "saveUnsaved": "Kaydedilmemiş değişiklikler",
	    "saveLastDelivered": "Son kayıt iletildi",
	    "savePhoneWaiting": "Telefona kaydedildi—saat yeniden bağlandığında uygulanacak.",
	    "appAdd": "Ekle",
	    "appRemove": "{app} uygulamasını kaldır",
	    "appEntryLabel": "Uygulama adı veya Android paketi",
	    "appEntryHelp": "Tam adları birer birer ekleyin. Büyük ve küçük harfler aynı kabul edilir.",
	    "appDuplicate": "Bu uygulama zaten listede.",
	    "appInvalid": "Bir seferde tek bir uygulama veya paket adı girin.",
	    "sourceExpired": "Süresi doldu",
	    "justObserved": "Az önce ölçüldü",
	    "justReceived": "Az önce alındı",
	    "readingSetupHelp": "Bu değeri Pebble → Ayarlar → Komplikasyonlar bölümünden seçin.",
	    "sourceNoUpdateHelp": "Pebble’da seçili eklentiyi kontrol edin.",
	    "accentContrastHelp": "Saat, okunabilirlik için gerektiğinde ikincil metin rengini ayarlar.",
	    "notificationSummaryHelp": "Uygulama özetleri göndereni veya bildirim başlığını içerebilir, ancak ileti metnini içermez.",
	    "helpConnection": "Bağlantı ve yardım",
	    "notificationSummary": "Uygulama ve gönderen/başlık",
	    "saveSaved": "Son kayıt iletildi",
	    "savePending": "Telefona kaydedildi—saat yeniden bağlandığında uygulanacak.",
	    "saveFailed": "Telefona kaydedildi—saat yeniden bağlandığında uygulanacak.",
	    "appLimit": "Tam uygulama listesi en fazla 160 karakter içermelidir."
	  }
	};
	
	// Privacy, alerts and colour sharing are kept together so each locale expresses
	// the same boundaries: app-only hides people and text; colour codes carry no
	// alert or privacy preferences; Quiet Time belongs to the watch.
	var ALERT_MESSAGES = {
	  en: {
	    notificationAppOnly: 'App name only',
	    notificationAppOnlyHelp: 'Shows the app without sender or message text.',
	    notificationVibration: "Additional vibration",
	    vibrationShort: 'Short pulse',
	    vibrationDouble: 'Double pulse',
	    vibrationHelp: "One additional vibration per new notification burst, using your app filter. Respects Quiet Time. Turn this off if Pebble already vibrates for those notifications.",
	    nightPalette: 'Quiet Time colours',
	    nightPaletteHelp: 'Use these watch colours while Pebble Quiet Time is active.',
	    nightBackground: 'Quiet Time background',
	    nightText: 'Quiet Time text',
	    nightAccent: 'Quiet Time accent',
	    paletteCode: 'Share colours',
	    paletteCodeHelp: 'This code contains only background, text and accent colours.',
	    paletteCopy: 'Copy code',
	    paletteApply: 'Apply code',
	    paletteCopied: 'Colour code copied.',
	    paletteSelectCopy: 'Select and copy the colour code.',
	    paletteInvalid: 'Use a code like DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Colours applied. Save to send them to your watch.',
	    paletteInput: 'Colour code',
	    watchfaceBanners: "Notification activity",
	    notificationsHelp: "New notifications use the same activity priority and primary/secondary layouts. Allow notification access in Pebble. Pebble’s system notifications remain separate.",
	    previewPalette: "Preview colours",
	    previewDay: "Daytime",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Preview only. Your watch switches palettes with Pebble Quiet Time."
	  },
	  cs: {
	    notificationAppOnly: 'Jen název aplikace',
	    notificationAppOnlyHelp: 'Zobrazí aplikaci bez odesílatele a textu zprávy.',
	    notificationVibration: "Vibrace navíc",
	    vibrationShort: 'Krátké zavibrování',
	    vibrationDouble: 'Dvojité zavibrování',
	    vibrationHelp: "Jedna vibrace navíc pro každou novou sérii oznámení podle filtru aplikací. Respektuje Quiet Time. Vypněte ji, pokud už pro tato oznámení vibruje Pebble.",
	    nightPalette: 'Barvy pro Quiet Time',
	    nightPaletteHelp: 'Tyto barvy hodinek se použijí, když je v Pebble aktivní Quiet Time.',
	    nightBackground: 'Pozadí při Quiet Time',
	    nightText: 'Text při Quiet Time',
	    nightAccent: 'Zvýraznění při Quiet Time',
	    paletteCode: 'Sdílet barvy',
	    paletteCodeHelp: 'Kód obsahuje pouze barvy pozadí, textu a zvýraznění.',
	    paletteCopy: 'Zkopírovat kód',
	    paletteApply: 'Použít kód',
	    paletteCopied: 'Kód barev zkopírován.',
	    paletteSelectCopy: 'Označte a zkopírujte kód barev.',
	    paletteInvalid: 'Použijte kód ve tvaru DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Barvy použity. Uložením je odešlete do hodinek.',
	    paletteInput: 'Kód barev',
	    watchfaceBanners: "Aktivita oznámení",
	    notificationsHelp: "Nová oznámení používají stejné pořadí aktivit a hlavní i vedlejší zobrazení. Povolte přístup k oznámením v Pebble. Systémová oznámení Pebble zůstávají samostatná.",
	    previewPalette: "Náhled barev",
	    previewDay: "Denní",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Jen náhled. Hodinky přepínají palety podle režimu Quiet Time v Pebble."
	  },
	  sk: {
	    notificationAppOnly: 'Iba názov aplikácie',
	    notificationAppOnlyHelp: 'Zobrazí aplikáciu bez odosielateľa a textu správy.',
	    notificationVibration: "Vibrácia navyše",
	    vibrationShort: 'Krátke zavibrovanie',
	    vibrationDouble: 'Dvojité zavibrovanie',
	    vibrationHelp: "Jedna vibrácia navyše pre každú novú sériu oznámení podľa filtra aplikácií. Rešpektuje Quiet Time. Vypnite ju, ak už pre tieto oznámenia vibruje Pebble.",
	    nightPalette: 'Farby pre Quiet Time',
	    nightPaletteHelp: 'Tieto farby hodiniek sa použijú, keď je v Pebble aktívny Quiet Time.',
	    nightBackground: 'Pozadie počas Quiet Time',
	    nightText: 'Text počas Quiet Time',
	    nightAccent: 'Zvýraznenie počas Quiet Time',
	    paletteCode: 'Zdieľať farby',
	    paletteCodeHelp: 'Kód obsahuje iba farby pozadia, textu a zvýraznenia.',
	    paletteCopy: 'Skopírovať kód',
	    paletteApply: 'Použiť kód',
	    paletteCopied: 'Kód farieb skopírovaný.',
	    paletteSelectCopy: 'Označte a skopírujte kód farieb.',
	    paletteInvalid: 'Použite kód v tvare DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Farby použité. Uložením ich odošlete do hodiniek.',
	    paletteInput: 'Kód farieb',
	    watchfaceBanners: "Aktivita oznámení",
	    notificationsHelp: "Nové oznámenia používajú rovnaké poradie aktivít a hlavné aj vedľajšie zobrazenie. Povoľte prístup k oznámeniam v Pebble. Systémové oznámenia Pebble zostávajú samostatné.",
	    previewPalette: "Náhľad farieb",
	    previewDay: "Denné",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Iba náhľad. Hodinky prepínajú palety podľa režimu Quiet Time v Pebble."
	  },
	  de: {
	    notificationAppOnly: 'Nur App-Name',
	    notificationAppOnlyHelp: 'Zeigt die App ohne Absender oder Nachrichtentext.',
	    notificationVibration: "Zusätzliche Vibration",
	    vibrationShort: 'Kurzer Impuls',
	    vibrationDouble: 'Doppelter Impuls',
	    vibrationHelp: "Eine zusätzliche Vibration pro neuer Mitteilungsserie gemäß deinem App-Filter. Beachtet Quiet Time. Deaktiviere dies, wenn Pebble für diese Mitteilungen bereits vibriert.",
	    nightPalette: 'Farben für Quiet Time',
	    nightPaletteHelp: 'Diese Uhrfarben verwenden, während Quiet Time in Pebble aktiv ist.',
	    nightBackground: 'Hintergrund bei Quiet Time',
	    nightText: 'Text bei Quiet Time',
	    nightAccent: 'Akzent bei Quiet Time',
	    paletteCode: 'Farben teilen',
	    paletteCodeHelp: 'Dieser Code enthält nur Hintergrund-, Text- und Akzentfarben.',
	    paletteCopy: 'Code kopieren',
	    paletteApply: 'Code anwenden',
	    paletteCopied: 'Farbcode kopiert.',
	    paletteSelectCopy: 'Wähle den Farbcode aus und kopiere ihn.',
	    paletteInvalid: 'Verwende einen Code wie DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Farben übernommen. Speichere, um sie an deine Uhr zu senden.',
	    paletteInput: 'Farbcode',
	    watchfaceBanners: "Mitteilungsaktivität",
	    notificationsHelp: "Neue Mitteilungen verwenden dieselbe Aktivitätsreihenfolge sowie die Haupt- und Nebenansicht. Erlaube den Mitteilungszugriff in Pebble. Systemmitteilungen von Pebble bleiben getrennt.",
	    previewPalette: "Farbvorschau",
	    previewDay: "Tagsüber",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Nur eine Vorschau. Die Uhr wechselt die Farbpaletten entsprechend Quiet Time in Pebble."
	  },
	  fr: {
	    notificationAppOnly: 'Nom de l’application seul',
	    notificationAppOnlyHelp: 'Affiche l’application sans expéditeur ni texte du message.',
	    notificationVibration: "Vibration supplémentaire",
	    vibrationShort: 'Impulsion courte',
	    vibrationDouble: 'Double impulsion',
	    vibrationHelp: "Une vibration supplémentaire par nouvelle série de notifications, selon votre filtre d’applications. Respecte Quiet Time. Désactivez cette option si Pebble vibre déjà pour ces notifications.",
	    nightPalette: 'Couleurs pour Quiet Time',
	    nightPaletteHelp: 'Utiliser ces couleurs sur la montre quand Quiet Time est actif dans Pebble.',
	    nightBackground: 'Fond pendant Quiet Time',
	    nightText: 'Texte pendant Quiet Time',
	    nightAccent: 'Accent pendant Quiet Time',
	    paletteCode: 'Partager les couleurs',
	    paletteCodeHelp: 'Ce code contient uniquement les couleurs de fond, de texte et d’accentuation.',
	    paletteCopy: 'Copier le code',
	    paletteApply: 'Appliquer le code',
	    paletteCopied: 'Code de couleurs copié.',
	    paletteSelectCopy: 'Sélectionnez et copiez le code de couleurs.',
	    paletteInvalid: 'Utilisez un code comme DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Couleurs appliquées. Enregistrez pour les envoyer à votre montre.',
	    paletteInput: 'Code de couleurs',
	    watchfaceBanners: "Activité de notification",
	    notificationsHelp: "Les nouvelles notifications suivent le même ordre des activités et les mêmes vues principale et secondaire. Autorisez l’accès aux notifications dans Pebble. Les notifications système de Pebble restent distinctes.",
	    previewPalette: "Aperçu des couleurs",
	    previewDay: "En journée",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Aperçu uniquement. La montre change de palette selon Quiet Time dans Pebble."
	  },
	  es: {
	    notificationAppOnly: 'Solo el nombre de la app',
	    notificationAppOnlyHelp: 'Muestra la app sin remitente ni texto del mensaje.',
	    notificationVibration: "Vibración adicional",
	    vibrationShort: 'Pulso corto',
	    vibrationDouble: 'Pulso doble',
	    vibrationHelp: "Una vibración adicional por cada nueva serie de notificaciones, según tu filtro de apps. Respeta Quiet Time. Desactívala si Pebble ya vibra para esas notificaciones.",
	    nightPalette: 'Colores para Quiet Time',
	    nightPaletteHelp: 'Usar estos colores en el reloj mientras Quiet Time esté activo en Pebble.',
	    nightBackground: 'Fondo en Quiet Time',
	    nightText: 'Texto en Quiet Time',
	    nightAccent: 'Acento en Quiet Time',
	    paletteCode: 'Compartir colores',
	    paletteCodeHelp: 'Este código solo contiene los colores de fondo, texto y acento.',
	    paletteCopy: 'Copiar código',
	    paletteApply: 'Aplicar código',
	    paletteCopied: 'Código de colores copiado.',
	    paletteSelectCopy: 'Selecciona y copia el código de colores.',
	    paletteInvalid: 'Usa un código como DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Colores aplicados. Guarda para enviarlos a tu reloj.',
	    paletteInput: 'Código de colores',
	    watchfaceBanners: "Actividad de notificaciones",
	    notificationsHelp: "Las nuevas notificaciones usan el mismo orden de actividades y las vistas principal y secundaria. Permite el acceso a notificaciones en Pebble. Las notificaciones del sistema de Pebble siguen siendo independientes.",
	    previewPalette: "Vista previa de colores",
	    previewDay: "De día",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Solo es una vista previa. El reloj cambia de paleta según Quiet Time en Pebble."
	  },
	  it: {
	    notificationAppOnly: 'Solo nome dell’app',
	    notificationAppOnlyHelp: 'Mostra l’app senza mittente o testo del messaggio.',
	    notificationVibration: "Vibrazione aggiuntiva",
	    vibrationShort: 'Impulso breve',
	    vibrationDouble: 'Doppio impulso',
	    vibrationHelp: "Una vibrazione aggiuntiva per ogni nuova serie di notifiche, secondo il filtro delle app. Rispetta Quiet Time. Disattivala se Pebble vibra già per queste notifiche.",
	    nightPalette: 'Colori per Quiet Time',
	    nightPaletteHelp: 'Usa questi colori sull’orologio quando Quiet Time è attivo in Pebble.',
	    nightBackground: 'Sfondo durante Quiet Time',
	    nightText: 'Testo durante Quiet Time',
	    nightAccent: 'Accento durante Quiet Time',
	    paletteCode: 'Condividi colori',
	    paletteCodeHelp: 'Questo codice contiene solo i colori di sfondo, testo e accento.',
	    paletteCopy: 'Copia codice',
	    paletteApply: 'Applica codice',
	    paletteCopied: 'Codice colori copiato.',
	    paletteSelectCopy: 'Seleziona e copia il codice colori.',
	    paletteInvalid: 'Usa un codice come DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Colori applicati. Salva per inviarli all’orologio.',
	    paletteInput: 'Codice colori',
	    watchfaceBanners: "Attività notifiche",
	    notificationsHelp: "Le nuove notifiche usano lo stesso ordine delle attività e le viste principale e secondaria. Consenti l’accesso alle notifiche in Pebble. Le notifiche di sistema di Pebble restano separate.",
	    previewPalette: "Anteprima colori",
	    previewDay: "Di giorno",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Solo un’anteprima. L’orologio cambia palette in base a Quiet Time in Pebble."
	  },
	  pt: {
	    notificationAppOnly: 'Só o nome da aplicação',
	    notificationAppOnlyHelp: 'Mostra a aplicação sem remetente nem texto da mensagem.',
	    notificationVibration: "Vibração adicional",
	    vibrationShort: 'Pulso curto',
	    vibrationDouble: 'Pulso duplo',
	    vibrationHelp: "Uma vibração adicional por cada nova série de notificações, conforme o filtro de aplicações. Respeita o Quiet Time. Desative-a se o Pebble já vibrar para essas notificações.",
	    nightPalette: 'Cores para Quiet Time',
	    nightPaletteHelp: 'Usar estas cores no relógio enquanto o Quiet Time estiver ativo no Pebble.',
	    nightBackground: 'Fundo durante Quiet Time',
	    nightText: 'Texto durante Quiet Time',
	    nightAccent: 'Destaque durante Quiet Time',
	    paletteCode: 'Partilhar cores',
	    paletteCodeHelp: 'Este código contém apenas as cores de fundo, texto e destaque.',
	    paletteCopy: 'Copiar código',
	    paletteApply: 'Aplicar código',
	    paletteCopied: 'Código de cores copiado.',
	    paletteSelectCopy: 'Selecione e copie o código de cores.',
	    paletteInvalid: 'Use um código como DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Cores aplicadas. Guarde para as enviar para o relógio.',
	    paletteInput: 'Código de cores',
	    watchfaceBanners: "Atividade de notificações",
	    notificationsHelp: "As novas notificações usam a mesma ordem das atividades e as vistas principal e secundária. Permita o acesso às notificações no Pebble. As notificações de sistema do Pebble continuam separadas.",
	    previewPalette: "Pré-visualizar cores",
	    previewDay: "Durante o dia",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Apenas uma pré-visualização. O relógio muda de paleta conforme o Quiet Time no Pebble."
	  },
	  nl: {
	    notificationAppOnly: 'Alleen appnaam',
	    notificationAppOnlyHelp: 'Toont de app zonder afzender of berichttekst.',
	    notificationVibration: "Extra trilling",
	    vibrationShort: 'Korte trilling',
	    vibrationDouble: 'Dubbele trilling',
	    vibrationHelp: "Eén extra trilling per nieuwe reeks meldingen, volgens je appfilter. Houdt rekening met Quiet Time. Schakel dit uit als Pebble al trilt voor deze meldingen.",
	    nightPalette: 'Kleuren voor Quiet Time',
	    nightPaletteHelp: 'Gebruik deze horlogekleuren wanneer Quiet Time in Pebble actief is.',
	    nightBackground: 'Achtergrond tijdens Quiet Time',
	    nightText: 'Tekst tijdens Quiet Time',
	    nightAccent: 'Accent tijdens Quiet Time',
	    paletteCode: 'Kleuren delen',
	    paletteCodeHelp: 'Deze code bevat alleen de kleuren voor achtergrond, tekst en accenten.',
	    paletteCopy: 'Code kopiëren',
	    paletteApply: 'Code toepassen',
	    paletteCopied: 'Kleurcode gekopieerd.',
	    paletteSelectCopy: 'Selecteer en kopieer de kleurcode.',
	    paletteInvalid: 'Gebruik een code zoals DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Kleuren toegepast. Sla op om ze naar je horloge te sturen.',
	    paletteInput: 'Kleurcode',
	    watchfaceBanners: "Meldingsactiviteit",
	    notificationsHelp: "Nieuwe meldingen gebruiken dezelfde activiteitsvolgorde en hoofd- en nevenweergave. Sta meldingentoegang toe in Pebble. Systeemmeldingen van Pebble blijven apart.",
	    previewPalette: "Kleurvoorbeeld",
	    previewDay: "Overdag",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Alleen een voorbeeld. Het horloge wisselt van kleuren volgens Quiet Time in Pebble."
	  },
	  pl: {
	    notificationAppOnly: 'Tylko nazwa aplikacji',
	    notificationAppOnlyHelp: 'Pokazuje aplikację bez nadawcy i treści wiadomości.',
	    notificationVibration: "Dodatkowa wibracja",
	    vibrationShort: 'Krótka wibracja',
	    vibrationDouble: 'Podwójna wibracja',
	    vibrationHelp: "Jedna dodatkowa wibracja na każdą nową serię powiadomień, zgodnie z filtrem aplikacji. Uwzględnia Quiet Time. Wyłącz ją, jeśli Pebble już wibruje dla tych powiadomień.",
	    nightPalette: 'Kolory w Quiet Time',
	    nightPaletteHelp: 'Używaj tych kolorów zegarka, gdy Quiet Time jest aktywny w Pebble.',
	    nightBackground: 'Tło w Quiet Time',
	    nightText: 'Tekst w Quiet Time',
	    nightAccent: 'Akcent w Quiet Time',
	    paletteCode: 'Udostępnij kolory',
	    paletteCodeHelp: 'Ten kod zawiera tylko kolory tła, tekstu i akcentu.',
	    paletteCopy: 'Kopiuj kod',
	    paletteApply: 'Zastosuj kod',
	    paletteCopied: 'Kod kolorów skopiowany.',
	    paletteSelectCopy: 'Zaznacz i skopiuj kod kolorów.',
	    paletteInvalid: 'Użyj kodu w formacie DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Kolory zastosowane. Zapisz, aby wysłać je do zegarka.',
	    paletteInput: 'Kod kolorów',
	    watchfaceBanners: "Aktywność powiadomień",
	    notificationsHelp: "Nowe powiadomienia używają tej samej kolejności aktywności oraz widoków głównego i dodatkowego. Zezwól na dostęp do powiadomień w Pebble. Powiadomienia systemowe Pebble pozostają osobne.",
	    previewPalette: "Podgląd kolorów",
	    previewDay: "W dzień",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Tylko podgląd. Zegarek zmienia palety zgodnie z trybem Quiet Time w Pebble."
	  },
	  da: {
	    notificationAppOnly: 'Kun appnavn',
	    notificationAppOnlyHelp: 'Viser appen uden afsender eller beskedtekst.',
	    notificationVibration: "Ekstra vibration",
	    vibrationShort: 'Kort vibration',
	    vibrationDouble: 'Dobbelt vibration',
	    vibrationHelp: "Én ekstra vibration for hver ny serie af notifikationer efter dit appfilter. Respekterer Quiet Time. Slå dette fra, hvis Pebble allerede vibrerer ved disse notifikationer.",
	    nightPalette: 'Farver til Quiet Time',
	    nightPaletteHelp: 'Brug disse urfarver, mens Quiet Time er aktiv i Pebble.',
	    nightBackground: 'Baggrund under Quiet Time',
	    nightText: 'Tekst under Quiet Time',
	    nightAccent: 'Accent under Quiet Time',
	    paletteCode: 'Del farver',
	    paletteCodeHelp: 'Denne kode indeholder kun baggrunds-, tekst- og accentfarver.',
	    paletteCopy: 'Kopiér kode',
	    paletteApply: 'Anvend kode',
	    paletteCopied: 'Farvekode kopieret.',
	    paletteSelectCopy: 'Markér og kopiér farvekoden.',
	    paletteInvalid: 'Brug en kode som DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Farver anvendt. Gem for at sende dem til dit ur.',
	    paletteInput: 'Farvekode',
	    watchfaceBanners: "Notifikationsaktivitet",
	    notificationsHelp: "Nye notifikationer bruger samme aktivitetsrækkefølge og hoved- og sekundærvisning. Tillad adgang til notifikationer i Pebble. Pebbles systemnotifikationer forbliver adskilte.",
	    previewPalette: "Farvevisning",
	    previewDay: "Om dagen",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Kun en forhåndsvisning. Uret skifter palet efter Quiet Time i Pebble."
	  },
	  sv: {
	    notificationAppOnly: 'Endast appnamn',
	    notificationAppOnlyHelp: 'Visar appen utan avsändare eller meddelandetext.',
	    notificationVibration: "Extra vibration",
	    vibrationShort: 'Kort vibration',
	    vibrationDouble: 'Dubbel vibration',
	    vibrationHelp: "En extra vibration för varje ny serie aviseringar enligt ditt appfilter. Respekterar Quiet Time. Stäng av detta om Pebble redan vibrerar för dessa aviseringar.",
	    nightPalette: 'Färger för Quiet Time',
	    nightPaletteHelp: 'Använd dessa klockfärger när Quiet Time är aktivt i Pebble.',
	    nightBackground: 'Bakgrund under Quiet Time',
	    nightText: 'Text under Quiet Time',
	    nightAccent: 'Accent under Quiet Time',
	    paletteCode: 'Dela färger',
	    paletteCodeHelp: 'Den här koden innehåller bara bakgrunds-, text- och accentfärger.',
	    paletteCopy: 'Kopiera kod',
	    paletteApply: 'Använd kod',
	    paletteCopied: 'Färgkod kopierad.',
	    paletteSelectCopy: 'Markera och kopiera färgkoden.',
	    paletteInvalid: 'Använd en kod som DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Färger tillämpade. Spara för att skicka dem till klockan.',
	    paletteInput: 'Färgkod',
	    watchfaceBanners: "Aviseringsaktivitet",
	    notificationsHelp: "Nya aviseringar använder samma aktivitetsordning och huvud- och sekundärvy. Tillåt åtkomst till aviseringar i Pebble. Pebbles systemaviseringar är fortsatt separata.",
	    previewPalette: "Förhandsvisa färger",
	    previewDay: "Dagtid",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Endast en förhandsvisning. Klockan byter palett enligt Quiet Time i Pebble."
	  },
	  no: {
	    notificationAppOnly: 'Bare appnavn',
	    notificationAppOnlyHelp: 'Viser appen uten avsender eller meldingstekst.',
	    notificationVibration: "Ekstra vibrasjon",
	    vibrationShort: 'Kort vibrasjon',
	    vibrationDouble: 'Dobbel vibrasjon',
	    vibrationHelp: "Én ekstra vibrasjon for hver nye varselserie etter appfilteret ditt. Respekterer Quiet Time. Slå dette av hvis Pebble allerede vibrerer for disse varslene.",
	    nightPalette: 'Farger for Quiet Time',
	    nightPaletteHelp: 'Bruk disse klokkefargene mens Quiet Time er aktiv i Pebble.',
	    nightBackground: 'Bakgrunn under Quiet Time',
	    nightText: 'Tekst under Quiet Time',
	    nightAccent: 'Aksent under Quiet Time',
	    paletteCode: 'Del farger',
	    paletteCodeHelp: 'Denne koden inneholder bare bakgrunns-, tekst- og aksentfarger.',
	    paletteCopy: 'Kopier kode',
	    paletteApply: 'Bruk kode',
	    paletteCopied: 'Fargekode kopiert.',
	    paletteSelectCopy: 'Marker og kopier fargekoden.',
	    paletteInvalid: 'Bruk en kode som DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Farger tatt i bruk. Lagre for å sende dem til klokken.',
	    paletteInput: 'Fargekode',
	    watchfaceBanners: "Varselaktivitet",
	    notificationsHelp: "Nye varsler bruker samme aktivitetsrekkefølge og hoved- og sekundærvisning. Tillat varseltilgang i Pebble. Pebbles systemvarsler forblir separate.",
	    previewPalette: "Forhåndsvis farger",
	    previewDay: "På dagtid",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Bare en forhåndsvisning. Klokken bytter palett etter Quiet Time i Pebble."
	  },
	  fi: {
	    notificationAppOnly: 'Vain sovelluksen nimi',
	    notificationAppOnlyHelp: 'Näyttää sovelluksen ilman lähettäjää tai viestin tekstiä.',
	    notificationVibration: "Lisävärinä",
	    vibrationShort: 'Lyhyt värinä',
	    vibrationDouble: 'Kaksinkertainen värinä',
	    vibrationHelp: "Yksi lisävärinä kutakin uutta ilmoitussarjaa kohden sovellussuodattimen mukaan. Noudattaa Quiet Time -tilaa. Poista käytöstä, jos Pebble värisee jo näistä ilmoituksista.",
	    nightPalette: 'Quiet Time -värit',
	    nightPaletteHelp: 'Käytä näitä kellon värejä, kun Quiet Time on käytössä Pebblessä.',
	    nightBackground: 'Quiet Time -tausta',
	    nightText: 'Quiet Time -teksti',
	    nightAccent: 'Quiet Time -korostus',
	    paletteCode: 'Jaa värit',
	    paletteCodeHelp: 'Tämä koodi sisältää vain taustan, tekstin ja korostuksen värit.',
	    paletteCopy: 'Kopioi koodi',
	    paletteApply: 'Käytä koodia',
	    paletteCopied: 'Värikoodi kopioitu.',
	    paletteSelectCopy: 'Valitse ja kopioi värikoodi.',
	    paletteInvalid: 'Käytä koodia, kuten DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Värit otettu käyttöön. Lähetä ne kelloon tallentamalla.',
	    paletteInput: 'Värikoodi',
	    watchfaceBanners: "Ilmoitustoiminto",
	    notificationsHelp: "Uudet ilmoitukset käyttävät samaa toimintojen järjestystä sekä pää- ja sivunäkymää. Salli ilmoitusten käyttö Pebblessä. Pebblen järjestelmäilmoitukset pysyvät erillisinä.",
	    previewPalette: "Värien esikatselu",
	    previewDay: "Päivällä",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Vain esikatselu. Kello vaihtaa väripalettia Pebblen Quiet Time -tilan mukaan."
	  },
	  hu: {
	    notificationAppOnly: 'Csak az alkalmazás neve',
	    notificationAppOnlyHelp: 'Az alkalmazást mutatja, feladó és üzenetszöveg nélkül.',
	    notificationVibration: "Kiegészítő rezgés",
	    vibrationShort: 'Rövid rezgés',
	    vibrationDouble: 'Dupla rezgés',
	    vibrationHelp: "Egy kiegészítő rezgés minden új értesítéssorozatnál, az alkalmazásszűrő szerint. Figyelembe veszi a Quiet Time módot. Kapcsold ki, ha a Pebble már rezeg ezeknél az értesítéseknél.",
	    nightPalette: 'Quiet Time színek',
	    nightPaletteHelp: 'Ezeket az óraszíneket használja, amikor a Pebble Quiet Time módja aktív.',
	    nightBackground: 'Quiet Time háttér',
	    nightText: 'Quiet Time szöveg',
	    nightAccent: 'Quiet Time kiemelés',
	    paletteCode: 'Színek megosztása',
	    paletteCodeHelp: 'Ez a kód csak a háttér, a szöveg és a kiemelés színeit tartalmazza.',
	    paletteCopy: 'Kód másolása',
	    paletteApply: 'Kód alkalmazása',
	    paletteCopied: 'Színkód másolva.',
	    paletteSelectCopy: 'Jelöld ki és másold a színkódot.',
	    paletteInvalid: 'Ilyen formátumú kódot használj: DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Színek alkalmazva. Mentsd az órára küldéshez.',
	    paletteInput: 'Színkód',
	    watchfaceBanners: "Értesítési tevékenység",
	    notificationsHelp: "Az új értesítések ugyanazt a tevékenységsorrendet és elsődleges, illetve másodlagos nézetet használják. Engedélyezd az értesítések elérését a Pebble-ben. A Pebble rendszerértesítései külön maradnak.",
	    previewPalette: "Színek előnézete",
	    previewDay: "Nappal",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Csak előnézet. Az óra a Pebble Quiet Time módja szerint vált színpalettát."
	  },
	  ro: {
	    notificationAppOnly: 'Doar numele aplicației',
	    notificationAppOnlyHelp: 'Arată aplicația fără expeditor sau textul mesajului.',
	    notificationVibration: "Vibrație suplimentară",
	    vibrationShort: 'Impuls scurt',
	    vibrationDouble: 'Impuls dublu',
	    vibrationHelp: "O vibrație suplimentară pentru fiecare serie nouă de notificări, conform filtrului de aplicații. Respectă Quiet Time. Dezactiveaz-o dacă Pebble vibrează deja pentru aceste notificări.",
	    nightPalette: 'Culori pentru Quiet Time',
	    nightPaletteHelp: 'Folosește aceste culori pe ceas când Quiet Time este activ în Pebble.',
	    nightBackground: 'Fundal în Quiet Time',
	    nightText: 'Text în Quiet Time',
	    nightAccent: 'Accent în Quiet Time',
	    paletteCode: 'Partajează culorile',
	    paletteCodeHelp: 'Acest cod conține doar culorile de fundal, text și accent.',
	    paletteCopy: 'Copiază codul',
	    paletteApply: 'Aplică codul',
	    paletteCopied: 'Codul de culori a fost copiat.',
	    paletteSelectCopy: 'Selectează și copiază codul de culori.',
	    paletteInvalid: 'Folosește un cod precum DYN1-FFFFFF-000000-55AAFF.',
	    paletteApplied: 'Culori aplicate. Salvează pentru a le trimite pe ceas.',
	    paletteInput: 'Cod de culori',
	    watchfaceBanners: "Activitate de notificări",
	    notificationsHelp: "Notificările noi folosesc aceeași ordine a activităților și aceleași vizualizări principală și secundară. Permite accesul la notificări în Pebble. Notificările de sistem Pebble rămân separate.",
	    previewPalette: "Previzualizează culorile",
	    previewDay: "Ziua",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Doar previzualizare. Ceasul schimbă paletele în funcție de Quiet Time din Pebble."
	  },
	  tr: {
	    notificationAppOnly: 'Yalnızca uygulama adı',
	    notificationAppOnlyHelp: 'Göndereni veya ileti metnini göstermeden uygulamayı gösterir.',
	    notificationVibration: "Ek titreşim",
	    vibrationShort: 'Kısa titreşim',
	    vibrationDouble: 'Çift titreşim',
	    vibrationHelp: "Uygulama filtrenize göre her yeni bildirim serisi için bir ek titreşim. Quiet Time’a uyar. Pebble bu bildirimler için zaten titreşiyorsa bunu kapatın.",
	    nightPalette: 'Quiet Time renkleri',
	    nightPaletteHelp: 'Pebble Quiet Time etkinken saatte bu renkleri kullan.',
	    nightBackground: 'Quiet Time arka planı',
	    nightText: 'Quiet Time metni',
	    nightAccent: 'Quiet Time vurgu rengi',
	    paletteCode: 'Renkleri paylaş',
	    paletteCodeHelp: 'Bu kod yalnızca arka plan, metin ve vurgu renklerini içerir.',
	    paletteCopy: 'Kodu kopyala',
	    paletteApply: 'Kodu uygula',
	    paletteCopied: 'Renk kodu kopyalandı.',
	    paletteSelectCopy: 'Renk kodunu seçip kopyalayın.',
	    paletteInvalid: 'DYN1-FFFFFF-000000-55AAFF gibi bir kod kullanın.',
	    paletteApplied: 'Renkler uygulandı. Saatinize göndermek için kaydedin.',
	    paletteInput: 'Renk kodu',
	    watchfaceBanners: "Bildirim etkinliği",
	    notificationsHelp: "Yeni bildirimler aynı etkinlik sırasını, birincil ve ikincil görünümleri kullanır. Pebble’da bildirim erişimine izin verin. Pebble sistem bildirimleri ayrı kalır.",
	    previewPalette: "Renk önizlemesi",
	    previewDay: "Gündüz",
	    previewQuietTime: "Quiet Time",
	    previewPaletteHelp: "Yalnızca önizleme. Saat, Pebble Quiet Time durumuna göre palet değiştirir."
	  }
	};
	
	Object.keys(SETTINGS_MESSAGES).forEach(function(language) {
	  var row = MESSAGES[language];
	  Object.keys(SETTINGS_MESSAGES[language]).forEach(function(key) {
	    row[key] = SETTINGS_MESSAGES[language][key];
	  });
	  Object.keys(UX_MESSAGES[language]).forEach(function(key) {
	    row[key] = UX_MESSAGES[language][key];
	  });
	  Object.keys(ALERT_MESSAGES[language]).forEach(function(key) {
	    row[key] = ALERT_MESSAGES[language][key];
	  });
	  row.vibrationOff = row.stateOff;
	  row.musicSource = row.previewMusic;
	  row.notificationsSource = row.notifications;
	  row.sourceOff = row.stateOff;
	  row.sourcePermission = row.sourceDenied;
	});
	var ACTIVITY_MESSAGES = {
	  "en": {
	    "showActivities": "Show activity plugins",
	    "activitiesHelp": "Compatible activity plugins connect automatically. Manage access permissions in Pebble.",
	    "activitiesSource": "Activity plugins"
	  },
	  "cs": {
	    "showActivities": "Zobrazovat pluginy aktivit",
	    "activitiesHelp": "Kompatibilní pluginy aktivit se připojí automaticky. Přístupová oprávnění spravujte v Pebble.",
	    "activitiesSource": "Pluginy aktivit"
	  },
	  "sk": {
	    "showActivities": "Zobrazovať pluginy aktivít",
	    "activitiesHelp": "Kompatibilné pluginy aktivít sa pripoja automaticky. Prístupové oprávnenia spravujte v Pebble.",
	    "activitiesSource": "Pluginy aktivít"
	  },
	  "de": {
	    "showActivities": "Aktivitätsplugins anzeigen",
	    "activitiesHelp": "Kompatible Aktivitätsplugins verbinden sich automatisch. Zugriffsrechte werden in Pebble verwaltet.",
	    "activitiesSource": "Aktivitätsplugins"
	  },
	  "fr": {
	    "showActivities": "Afficher les plugins d’activité",
	    "activitiesHelp": "Les plugins d’activité compatibles se connectent automatiquement. Gérez les autorisations dans Pebble.",
	    "activitiesSource": "Plugins d’activité"
	  },
	  "es": {
	    "showActivities": "Mostrar plugins de actividad",
	    "activitiesHelp": "Los plugins de actividad compatibles se conectan automáticamente. Gestiona los permisos en Pebble.",
	    "activitiesSource": "Plugins de actividad"
	  },
	  "it": {
	    "showActivities": "Mostra plugin attività",
	    "activitiesHelp": "I plugin attività compatibili si collegano automaticamente. Gestisci le autorizzazioni in Pebble.",
	    "activitiesSource": "Plugin attività"
	  },
	  "pt": {
	    "showActivities": "Mostrar plugins de atividade",
	    "activitiesHelp": "Os plugins de atividade compatíveis ligam-se automaticamente. Gere as permissões no Pebble.",
	    "activitiesSource": "Plugins de atividade"
	  },
	  "nl": {
	    "showActivities": "Activiteitsplugins tonen",
	    "activitiesHelp": "Compatibele activiteitsplugins verbinden automatisch. Beheer toegangsrechten in Pebble.",
	    "activitiesSource": "Activiteitsplugins"
	  },
	  "pl": {
	    "showActivities": "Pokaż wtyczki aktywności",
	    "activitiesHelp": "Zgodne wtyczki aktywności łączą się automatycznie. Uprawnieniami zarządzaj w Pebble.",
	    "activitiesSource": "Wtyczki aktywności"
	  },
	  "da": {
	    "showActivities": "Vis aktivitetsplugins",
	    "activitiesHelp": "Kompatible aktivitetsplugins forbindes automatisk. Administrer adgangstilladelser i Pebble.",
	    "activitiesSource": "Aktivitetsplugins"
	  },
	  "sv": {
	    "showActivities": "Visa aktivitetsplugin",
	    "activitiesHelp": "Kompatibla aktivitetsplugin ansluts automatiskt. Hantera åtkomstbehörigheter i Pebble.",
	    "activitiesSource": "Aktivitetsplugin"
	  },
	  "fi": {
	    "showActivities": "Näytä toimintolisäosat",
	    "activitiesHelp": "Yhteensopivat toimintolisäosat yhdistetään automaattisesti. Hallitse käyttöoikeuksia Pebblessä.",
	    "activitiesSource": "Toimintolisäosat"
	  },
	  "no": {
	    "showActivities": "Vis aktivitetsprogramtillegg",
	    "activitiesHelp": "Kompatible aktivitetsprogramtillegg kobles til automatisk. Administrer tilgangstillatelser i Pebble.",
	    "activitiesSource": "Aktivitetsprogramtillegg"
	  },
	  "hu": {
	    "showActivities": "Tevékenységbővítmények megjelenítése",
	    "activitiesHelp": "A kompatibilis tevékenységbővítmények automatikusan csatlakoznak. Az engedélyeket a Pebble-ben kezelheted.",
	    "activitiesSource": "Tevékenységbővítmények"
	  },
	  "ro": {
	    "showActivities": "Afișează pluginurile de activitate",
	    "activitiesHelp": "Pluginurile de activitate compatibile se conectează automat. Gestionează permisiunile în Pebble.",
	    "activitiesSource": "Pluginuri de activitate"
	  },
	  "tr": {
	    "showActivities": "Etkinlik eklentilerini göster",
	    "activitiesHelp": "Uyumlu etkinlik eklentileri otomatik bağlanır. Erişim izinlerini Pebble’da yönet.",
	    "activitiesSource": "Etkinlik eklentileri"
	  }
	};
	Object.keys(ACTIVITY_MESSAGES).forEach(function(language) {
	  Object.keys(ACTIVITY_MESSAGES[language]).forEach(function(key) {
	    MESSAGES[language][key]=ACTIVITY_MESSAGES[language][key];
	  });
	});
	var ACTIVITY_PRIORITY_MESSAGES = {
	  en:['Activity priority','Drag or use the arrows. The first available activity is large; the next is smaller. Any app can appear in either place. This order applies only to Dynamic.','Move up','Move down','Show','Show {name}','Move {name}','{name}: position {position}','Unavailable app','Not installed or unavailable. Its position is saved.'],
	  cs:['Pořadí aktivit','Přetáhněte aplikace nebo použijte šipky. První dostupná aktivita je velká, další menší. Kterákoli aplikace může být na obou místech. Pořadí platí jen pro Dynamic.','Posunout výš','Posunout níž','Zobrazit','Zobrazit {name}','Přesunout {name}','{name}: pozice {position}','Nedostupná aplikace','Není nainstalovaná nebo je nedostupná. Její pořadí zůstává uložené.'],
	  sk:['Poradie aktivít','Presuňte aplikácie alebo použite šípky. Prvá dostupná aktivita je veľká, ďalšia menšia. Ktorákoľvek aplikácia môže byť na oboch miestach. Poradie platí iba pre Dynamic.','Posunúť vyššie','Posunúť nižšie','Zobraziť','Zobraziť {name}','Presunúť {name}','{name}: pozícia {position}','Nedostupná aplikácia','Nie je nainštalovaná alebo je nedostupná. Jej poradie zostáva uložené.'],
	  de:['Reihenfolge der Aktivitäten','Ziehen oder die Pfeile verwenden. Die erste verfügbare Aktivität erscheint groß, die nächste kleiner. Jede App kann an beiden Stellen erscheinen. Die Reihenfolge gilt nur für Dynamic.','Nach oben','Nach unten','Anzeigen','{name} anzeigen','{name} verschieben','{name}: Position {position}','Nicht verfügbare App','Nicht installiert oder nicht verfügbar. Ihre Position bleibt gespeichert.'],
	  fr:['Priorité des activités','Faites glisser les apps ou utilisez les flèches. La première activité disponible est grande, la suivante plus petite. Chaque app peut occuper les deux places. Cet ordre concerne uniquement Dynamic.','Monter','Descendre','Afficher','Afficher {name}','Déplacer {name}','{name} : position {position}','Application indisponible','Non installée ou indisponible. Sa position est conservée.'],
	  es:['Prioridad de actividades','Arrastra o usa las flechas. La primera actividad disponible se muestra grande y la siguiente más pequeña. Cualquier app puede ocupar ambos lugares. Este orden solo se aplica a Dynamic.','Subir','Bajar','Mostrar','Mostrar {name}','Mover {name}','{name}: posición {position}','Aplicación no disponible','No está instalada o no está disponible. Se conserva su posición.'],
	  it:['Priorità delle attività','Trascina o usa le frecce. La prima attività disponibile è grande, la successiva più piccola. Ogni app può occupare entrambe le posizioni. Questo ordine vale solo per Dynamic.','Sposta su','Sposta giù','Mostra','Mostra {name}','Sposta {name}','{name}: posizione {position}','App non disponibile','Non installata o non disponibile. La posizione rimane salvata.'],
	  pt:['Prioridade das atividades','Arraste ou use as setas. A primeira atividade disponível é grande e a seguinte mais pequena. Qualquer app pode ocupar ambos os lugares. Esta ordem aplica-se apenas ao Dynamic.','Mover para cima','Mover para baixo','Mostrar','Mostrar {name}','Mover {name}','{name}: posição {position}','Aplicação indisponível','Não instalada ou indisponível. A posição fica guardada.'],
	  nl:['Prioriteit van activiteiten','Sleep of gebruik de pijlen. De eerste beschikbare activiteit is groot, de volgende kleiner. Elke app kan op beide plekken staan. Deze volgorde geldt alleen voor Dynamic.','Omhoog','Omlaag','Tonen','{name} tonen','{name} verplaatsen','{name}: positie {position}','App niet beschikbaar','Niet geïnstalleerd of niet beschikbaar. De positie blijft bewaard.'],
	  pl:['Kolejność aktywności','Przeciągnij lub użyj strzałek. Pierwsza dostępna aktywność jest duża, kolejna mniejsza. Każda aplikacja może zająć obie pozycje. Ta kolejność dotyczy tylko Dynamic.','Przesuń wyżej','Przesuń niżej','Pokaż','Pokaż {name}','Przenieś {name}','{name}: pozycja {position}','Niedostępna aplikacja','Nie jest zainstalowana lub jest niedostępna. Jej pozycja pozostaje zapisana.'],
	  da:['Aktivitetsrækkefølge','Træk eller brug pilene. Den første tilgængelige aktivitet er stor, den næste mindre. Alle apps kan stå begge steder. Rækkefølgen gælder kun for Dynamic.','Flyt op','Flyt ned','Vis','Vis {name}','Flyt {name}','{name} er på plads {position}','Utilgængelig app','Ikke installeret eller utilgængelig. Positionen gemmes.'],
	  sv:['Aktivitetsordning','Dra eller använd pilarna. Den första tillgängliga aktiviteten är stor, nästa mindre. Alla appar kan visas på båda platserna. Ordningen gäller bara Dynamic.','Flytta upp','Flytta ned','Visa','Visa {name}','Flytta {name}','{name}: plats {position}','Otillgänglig app','Inte installerad eller otillgänglig. Platsen sparas.'],
	  fi:['Toimintojen järjestys','Vedä tai käytä nuolia. Ensimmäinen saatavilla oleva toiminto on suuri, seuraava pienempi. Mikä tahansa sovellus voi olla kummassa tahansa paikassa. Järjestys koskee vain Dynamicia.','Siirrä ylös','Siirrä alas','Näytä','Näytä {name}','Siirrä {name}','{name}: paikka {position}','Sovellus ei saatavilla','Ei asennettu tai ei saatavilla. Sen paikka säilytetään.'],
	  no:['Aktivitetsrekkefølge','Dra eller bruk pilene. Den første tilgjengelige aktiviteten er stor, den neste mindre. Alle apper kan vises begge steder. Rekkefølgen gjelder bare Dynamic.','Flytt opp','Flytt ned','Vis','Vis {name}','Flytt {name}','{name}: plass {position}','Utilgjengelig app','Ikke installert eller utilgjengelig. Plassen beholdes.'],
	  hu:['Tevékenységek sorrendje','Húzd az alkalmazásokat, vagy használd a nyilakat. Az első elérhető tevékenység nagy, a következő kisebb. Bármely app megjelenhet mindkét helyen. Ez a sorrend csak a Dynamicra vonatkozik.','Feljebb','Lejjebb','Mutasd','{name} megjelenítése','{name} áthelyezése','{name}: {position}. hely','Nem elérhető alkalmazás','Nincs telepítve vagy nem érhető el. A helye megmarad.'],
	  ro:['Prioritatea activităților','Trage sau folosește săgețile. Prima activitate disponibilă este mare, următoarea mai mică. Orice aplicație poate ocupa ambele locuri. Ordinea se aplică doar în Dynamic.','Mută în sus','Mută în jos','Arată','Arată {name}','Mută {name}','{name}: poziția {position}','Aplicație indisponibilă','Nu este instalată sau nu este disponibilă. Poziția ei rămâne salvată.'],
	  tr:['Etkinlik önceliği','Sürükleyin veya okları kullanın. İlk kullanılabilir etkinlik büyük, sonraki daha küçük gösterilir. Her uygulama her iki yerde de görünebilir. Bu sıra yalnızca Dynamic için geçerlidir.','Yukarı taşı','Aşağı taşı','Göster','{name} göster','{name} taşı','{name}: {position}. sıra','Kullanılamayan uygulama','Yüklü değil veya kullanılamıyor. Sırası saklanır.']
	};
	Object.keys(ACTIVITY_PRIORITY_MESSAGES).forEach(function(language) {
	  ['activityPriority','activityPriorityHelp','activityUp','activityDown','activityVisible','activityShow','activityMove','activityMoved','activityUnavailableApp','activityUnavailable'].forEach(function(key,index) {
	    MESSAGES[language][key]=ACTIVITY_PRIORITY_MESSAGES[language][index];
	  });
	});
	var SETTINGS_CLEANUP_MESSAGES = {
	  en:['Content & priority','Title only','Short transitions when activities change.','Show activities from installed plugins. Music and Notifications have their own switches in the list below.','Notification details','Enable Notifications in the activity list to change its details.','Turn on activity plugins to show this app.'],
	  cs:['Obsah a pořadí','Jen titulek','Krátké přechody při změně aktivit.','Zobrazuje aktivity nainstalovaných pluginů. Hudba a Oznámení mají vlastní přepínače v seznamu níže.','Podrobnosti oznámení','Podrobnosti upravíte po zapnutí Oznámení v seznamu aktivit.','Pro zobrazení této aplikace zapněte pluginy aktivit.'],
	  sk:['Obsah a poradie','Iba nadpis','Krátke prechody pri zmene aktivít.','Zobrazuje aktivity nainštalovaných pluginov. Hudba a Oznámenia majú vlastné prepínače v zozname nižšie.','Podrobnosti oznámení','Podrobnosti upravíte po zapnutí Oznámení v zozname aktivít.','Na zobrazenie tejto aplikácie zapnite pluginy aktivít.'],
	  de:['Inhalte & Reihenfolge','Nur Titel','Kurze Übergänge bei Aktivitätswechseln.','Aktivitäten installierter Plugins anzeigen. Musik und Mitteilungen haben eigene Schalter in der Liste unten.','Mitteilungsdetails','Aktiviere Mitteilungen in der Aktivitätsliste, um die Details zu ändern.','Aktiviere Aktivitätsplugins, um diese App anzuzeigen.'],
	  fr:['Contenu et priorité','Titre seul','Transitions courtes lors des changements d’activité.','Affiche les activités des plugins installés. Musique et Notifications ont leurs propres commandes dans la liste ci-dessous.','Détails des notifications','Activez Notifications dans la liste des activités pour modifier les détails.','Activez les plugins d’activité pour afficher cette application.'],
	  es:['Contenido y prioridad','Solo título','Transiciones breves al cambiar las actividades.','Muestra actividades de los plugins instalados. Música y Notificaciones tienen sus propios interruptores en la lista inferior.','Detalles de notificaciones','Activa Notificaciones en la lista de actividades para cambiar sus detalles.','Activa los plugins de actividad para mostrar esta aplicación.'],
	  it:['Contenuti e priorità','Solo titolo','Brevi transizioni quando cambiano le attività.','Mostra le attività dei plugin installati. Musica e Notifiche hanno interruttori propri nell’elenco sotto.','Dettagli notifiche','Attiva Notifiche nell’elenco delle attività per modificarne i dettagli.','Attiva i plugin attività per mostrare questa app.'],
	  pt:['Conteúdo e prioridade','Só título','Transições curtas quando as atividades mudam.','Mostra atividades dos plugins instalados. Música e Notificações têm os seus próprios interruptores na lista abaixo.','Detalhes das notificações','Ative Notificações na lista de atividades para alterar os detalhes.','Ative os plugins de atividade para mostrar esta aplicação.'],
	  nl:['Inhoud en prioriteit','Alleen titel','Korte overgangen bij wijzigingen in activiteiten.','Toon activiteiten van geïnstalleerde plugins. Muziek en Meldingen hebben eigen schakelaars in de lijst hieronder.','Meldingsdetails','Schakel Meldingen in de activiteitenlijst in om de details te wijzigen.','Schakel activiteitsplugins in om deze app te tonen.'],
	  pl:['Treść i kolejność','Tylko tytuł','Krótkie przejścia przy zmianie aktywności.','Pokazuje aktywności zainstalowanych wtyczek. Muzyka i Powiadomienia mają osobne przełączniki na liście poniżej.','Szczegóły powiadomień','Włącz Powiadomienia na liście aktywności, aby zmienić ich szczegóły.','Włącz wtyczki aktywności, aby pokazać tę aplikację.'],
	  da:['Indhold og rækkefølge','Kun titel','Korte overgange, når aktiviteter ændres.','Vis aktiviteter fra installerede plugins. Musik og Notifikationer har egne kontakter på listen nedenfor.','Notifikationsdetaljer','Slå Notifikationer til på aktivitetslisten for at ændre detaljerne.','Slå aktivitetsplugins til for at vise denne app.'],
	  sv:['Innehåll och ordning','Bara rubrik','Korta övergångar när aktiviteter ändras.','Visa aktiviteter från installerade plugin. Musik och Aviseringar har egna reglage i listan nedan.','Aviseringsdetaljer','Aktivera Aviseringar i aktivitetslistan för att ändra detaljerna.','Aktivera aktivitetsplugin för att visa den här appen.'],
	  no:['Innhold og rekkefølge','Bare tittel','Korte overganger når aktiviteter endres.','Vis aktiviteter fra installerte programtillegg. Musikk og Varsler har egne brytere i listen nedenfor.','Varseldetaljer','Slå på Varsler i aktivitetslisten for å endre detaljene.','Slå på aktivitetsprogramtillegg for å vise denne appen.'],
	  fi:['Sisältö ja järjestys','Vain otsikko','Lyhyet siirtymät toimintojen vaihtuessa.','Näytä asennettujen lisäosien toiminnot. Musiikilla ja Ilmoituksilla on omat kytkimensä alla olevassa luettelossa.','Ilmoitusten tiedot','Ota Ilmoitukset käyttöön toimintoluettelossa muuttaaksesi tietoja.','Ota toimintolisäosat käyttöön näyttääksesi tämän sovelluksen.'],
	  hu:['Tartalom és sorrend','Csak cím','Rövid átmenetek a tevékenységek változásakor.','A telepített bővítmények tevékenységeinek megjelenítése. A Zene és az Értesítések külön kapcsolót kap az alábbi listában.','Értesítések részletei','A részletek módosításához kapcsold be az Értesítéseket a tevékenységlistában.','Az alkalmazás megjelenítéséhez kapcsold be a tevékenységbővítményeket.'],
	  ro:['Conținut și prioritate','Doar titlul','Tranziții scurte când se schimbă activitățile.','Arată activitățile pluginurilor instalate. Muzica și Notificările au comutatoare proprii în lista de mai jos.','Detalii notificări','Activează Notificări în lista de activități pentru a modifica detaliile.','Activează pluginurile de activitate pentru a afișa această aplicație.'],
	  tr:['İçerik ve öncelik','Yalnızca başlık','Etkinlikler değiştiğinde kısa geçişler.','Yüklü eklentilerin etkinliklerini gösterir. Müzik ve Bildirimler için aşağıdaki listede ayrı anahtarlar vardır.','Bildirim ayrıntıları','Ayrıntıları değiştirmek için etkinlik listesinde Bildirimleri açın.','Bu uygulamayı göstermek için etkinlik eklentilerini açın.']
	};
	Object.keys(SETTINGS_CLEANUP_MESSAGES).forEach(function(language) {
	  ['content','previewBanner','animationsHelp','activitiesHelp','notificationDetails','notificationDisabledHelp','activityPluginsOffHelp'].forEach(function(key,index) {
	    MESSAGES[language][key]=SETTINGS_CLEANUP_MESSAGES[language][index];
	  });
	});
	var PREVIEW_TIMER_MESSAGES = {"en":"Timer","cs":"Časovač","sk":"Časovač","de":"Timer","fr":"Minuteur","es":"Temporizador","it":"Timer","pt":"Temporizador","nl":"Timer","pl":"Minutnik","da":"Timer","sv":"Timer","no":"Tidtaker","fi":"Ajastin","hu":"Időzítő","ro":"Temporizator","tr":"Zamanlayıcı"};
	Object.keys(PREVIEW_TIMER_MESSAGES).forEach(function(language) { MESSAGES[language].previewTimer=PREVIEW_TIMER_MESSAGES[language]; });
	var LANGUAGES = Object.keys(MESSAGES);
	var LITERALS = Object.create(null);
	Object.keys(MESSAGES.en).forEach(function(key) { LITERALS[MESSAGES.en[key]] = key; });
	Object.keys(LEGACY_LITERALS).forEach(function(text) { LITERALS[text] = LEGACY_LITERALS[text]; });
	[
	  ['Help & connection','helpConnection'],
	  ['Watch settings delivered.','saveSaved'],
	  ['Saved on phone; waiting for watch.','savePending'],
	  ['Saved on phone. Reconnect and save again to update the watch.','saveFailed'],
	  ['App and title','notificationSummary'],
	  ['Notification vibration','notificationVibration'],
	  ['Content','content'],
	  ['Notification details','notificationDetails'],
	  ['Enable Notifications in the activity list to change its details.','notificationDisabledHelp'],
	  ['Short transitions when music or notifications change.','animationsHelp'],
	  ['Watchface banners','watchfaceBanners'],
	  ['Allow notification access in Pebble. Only new notifications appear.','notificationsHelp'],
	  ['One vibration per new notification burst. Respects Quiet Time and your app filter. Pebble may also vibrate for the same notification.','vibrationHelp']
	].forEach(function(pair) { LITERALS[pair[0]] = pair[1]; });
	
	function normalizeLanguage(locale) {
	  if (typeof locale !== 'string') { return ''; }
	  var base = locale.trim().toLowerCase().split(/[.@]/)[0].replace(/_/g, '-').split('-')[0];
	  if (base === 'nb' || base === 'nn') { base = 'no'; }
	  return LANGUAGES.indexOf(base) >= 0 ? base : '';
	}
	function resolveLanguage(watchLanguage, phoneLanguage) {
	  return normalizeLanguage(watchLanguage) || normalizeLanguage(phoneLanguage) || 'en';
	}
	function t(key, language, params) {
	  var resolved = Object.prototype.hasOwnProperty.call(MESSAGES.en, key) ? key :
	      Object.prototype.hasOwnProperty.call(LITERALS, key) ? LITERALS[key] : null;
	  var row = MESSAGES[resolveLanguage(language)];
	  var text = resolved ? row[resolved] || MESSAGES.en[resolved] : String(key);
	  return text.replace(/\{([a-zA-Z][a-zA-Z0-9_]*)\}/g, function(match, name) {
	    return params && Object.prototype.hasOwnProperty.call(params, name) ? String(params[name]) : match;
	  });
	}
	function translateConfig(config, language) {
	  function clone(value, type) {
	    if (Array.isArray(value)) { return value.map(function(item) { return clone(item, type); }); }
	    if (!value || typeof value !== 'object') { return value; }
	    var result = {};
	    type = value.type || type;
	    Object.keys(value).forEach(function(key) {
	      if ((key === 'label' || key === 'description' || key === 'defaultValue' &&
	          ['text','heading','submit'].indexOf(type) >= 0) && typeof value[key] === 'string') {
	        result[key] = t(value[key], language);
	      } else { result[key] = clone(value[key], type); }
	    });
	    return result;
	  }
	  return clone(config, '');
	}
	// Shared Save-and-stay wording. Existing page translations remain intact.
	var PHONE_SAVE = {
	  en:['✓ Saved','No changes to save.','Couldn’t save. Try again.','Save not confirmed. Reload saved settings or try again.','Could not load saved settings. Retry before editing.','Retry','Reload saved','Discard','Loading settings…','Save'],
	  cs:['✓ Uloženo','Žádné změny k uložení.','Nepodařilo se uložit. Zkuste to znovu.','Uložení není potvrzeno. Načtěte uložené nastavení nebo to zkuste znovu.','Uložené nastavení nelze načíst. Před úpravami to zkuste znovu.','Zkusit znovu','Načíst uložené','Zahodit změny','Načítání nastavení…','Uložit'],
	  sk:['✓ Uložené','Žiadne zmeny na uloženie.','Nepodarilo sa uložiť. Skúste to znova.','Uloženie nie je potvrdené. Načítajte uložené nastavenia alebo skúste znova.','Uložené nastavenia sa nepodarilo načítať. Skúste znova.','Skúsiť znova','Načítať uložené','Zahodiť zmeny','Načítavajú sa nastavenia…','Uložiť'],
	  de:['✓ Gespeichert','Keine Änderungen zu speichern.','Speichern fehlgeschlagen. Erneut versuchen.','Speichern nicht bestätigt. Gespeicherte Einstellungen laden oder erneut versuchen.','Gespeicherte Einstellungen konnten nicht geladen werden. Erneut versuchen.','Erneut versuchen','Gespeicherte laden','Verwerfen','Einstellungen werden geladen…','Speichern'],
	  fr:['✓ Enregistré','Aucune modification à enregistrer.','Échec de l’enregistrement. Réessayez.','Enregistrement non confirmé. Rechargez les réglages ou réessayez.','Impossible de charger les réglages enregistrés. Réessayez.','Réessayer','Recharger','Annuler les modifications','Chargement des réglages…','Enregistrer'],
	  es:['✓ Guardado','No hay cambios para guardar.','No se pudo guardar. Inténtalo de nuevo.','Guardado sin confirmar. Recarga los ajustes o inténtalo de nuevo.','No se pudieron cargar los ajustes guardados. Reinténtalo.','Reintentar','Recargar guardados','Descartar','Cargando ajustes…','Guardar'],
	  it:['✓ Salvato','Nessuna modifica da salvare.','Salvataggio non riuscito. Riprova.','Salvataggio non confermato. Ricarica le impostazioni o riprova.','Impossibile caricare le impostazioni salvate. Riprova.','Riprova','Ricarica salvate','Scarta','Caricamento impostazioni…','Salva'],
	  pt:['✓ Guardado','Não há alterações para guardar.','Não foi possível guardar. Tente novamente.','Gravação não confirmada. Recarregue as definições ou tente novamente.','Não foi possível carregar as definições guardadas. Tente novamente.','Tentar novamente','Recarregar guardadas','Descartar','A carregar definições…','Guardar'],
	  nl:['✓ Opgeslagen','Geen wijzigingen om op te slaan.','Opslaan mislukt. Probeer opnieuw.','Opslaan niet bevestigd. Laad opgeslagen instellingen of probeer opnieuw.','Opgeslagen instellingen konden niet worden geladen. Probeer opnieuw.','Opnieuw proberen','Opgeslagen laden','Verwerpen','Instellingen laden…','Opslaan'],
	  pl:['✓ Zapisano','Brak zmian do zapisania.','Nie udało się zapisać. Spróbuj ponownie.','Zapis niepotwierdzony. Wczytaj zapisane ustawienia lub spróbuj ponownie.','Nie można wczytać zapisanych ustawień. Spróbuj ponownie.','Spróbuj ponownie','Wczytaj zapisane','Odrzuć','Wczytywanie ustawień…','Zapisz'],
	  da:['✓ Gemt','Ingen ændringer at gemme.','Kunne ikke gemme. Prøv igen.','Lagring ikke bekræftet. Indlæs gemte indstillinger eller prøv igen.','Kunne ikke indlæse gemte indstillinger. Prøv igen.','Prøv igen','Indlæs gemte','Kassér','Indlæser indstillinger…','Gem'],
	  sv:['✓ Sparat','Inga ändringar att spara.','Kunde inte spara. Försök igen.','Sparandet är inte bekräftat. Läs in sparade inställningar eller försök igen.','Kunde inte läsa in sparade inställningar. Försök igen.','Försök igen','Läs in sparade','Kasta ändringar','Läser in inställningar…','Spara'],
	  no:['✓ Lagret','Ingen endringer å lagre.','Kunne ikke lagre. Prøv igjen.','Lagring er ikke bekreftet. Last lagrede innstillinger eller prøv igjen.','Kunne ikke laste lagrede innstillinger. Prøv igjen.','Prøv igjen','Last lagrede','Forkast','Laster innstillinger…','Lagre'],
	  fi:['✓ Tallennettu','Ei tallennettavia muutoksia.','Tallennus epäonnistui. Yritä uudelleen.','Tallennusta ei vahvistettu. Lataa tallennetut asetukset tai yritä uudelleen.','Tallennettuja asetuksia ei voitu ladata. Yritä uudelleen.','Yritä uudelleen','Lataa tallennetut','Hylkää','Ladataan asetuksia…','Tallenna'],
	  hu:['✓ Mentve','Nincs mentendő módosítás.','Nem sikerült menteni. Próbálja újra.','A mentés nincs megerősítve. Töltse be a mentett beállításokat vagy próbálja újra.','A mentett beállítások nem tölthetők be. Próbálja újra.','Újra','Mentettek betöltése','Elvetés','Beállítások betöltése…','Mentés'],
	  ro:['✓ Salvat','Nu sunt modificări de salvat.','Salvarea a eșuat. Încercați din nou.','Salvare neconfirmată. Reîncărcați setările sau încercați din nou.','Setările salvate nu pot fi încărcate. Încercați din nou.','Reîncercați','Reîncărcați salvate','Renunțați','Se încarcă setările…','Salvați'],
	  tr:['✓ Kaydedildi','Kaydedilecek değişiklik yok.','Kaydedilemedi. Tekrar deneyin.','Kayıt onaylanmadı. Kayıtlı ayarları yükleyin veya tekrar deneyin.','Kayıtlı ayarlar yüklenemedi. Tekrar deneyin.','Tekrar dene','Kayıtlı ayarları yükle','Vazgeç','Ayarlar yükleniyor…','Kaydet']
	};
	var PHONE_SAVE_KEYS = ['phoneSaved','phoneNoChanges','phoneSaveFailed','phoneSaveUncertain','phoneLoadFailed','phoneRetry','phoneReload','phoneDiscard','phoneLoading','save'];
	Object.keys(PHONE_SAVE).forEach(function(language){PHONE_SAVE_KEYS.forEach(function(key,index){MESSAGES[language][key]=PHONE_SAVE[language][index];});});
	LITERALS.Save = 'save';
	function settingsStrings(language) {
	  language = resolveLanguage(language);
	  var strings = {};
	  Object.keys(MESSAGES.en).forEach(function(key) { strings[key] = t(key, language); });
	  var keys = ['phoneSaved','phoneNoChanges','phoneSaveFailed','phoneSaveUncertain','phoneLoadFailed','phoneRetry','phoneReload','phoneDiscard','phoneLoading','save'];
	  var values = PHONE_SAVE[language] || PHONE_SAVE.en;
	  keys.forEach(function(key,index){strings[key]=values[index];});
	  return strings;
	}
	
	module.exports = {resolveLanguage:resolveLanguage, translateConfig:translateConfig,
	  t:t, settingsStrings:settingsStrings, languages:LANGUAGES.slice()};


/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	// The existing Clay key remains authoritative. Keeping the stable activity
	// preferences in this same verified record makes one Save one storage write.
	var selection = __webpack_require__(8).selection;
	var KEY = 'clay-settings';
	var PREFERENCES = '__dynamicActivityPreferences';
	var OLD_PREFERENCES = 'dynamic-activity-preferences-v1';
	var names = ['TEMPERATURE','REQUEST_WEATHER','BACKGROUND_COLOR','TEXT_COLOR','DEPTH_EFFECT','TEXT_SHADOW','LARGE_TEXT','USE_12_HOUR','USE_FAHRENHEIT','TEMPERATURE_FAHRENHEIT','WEATHER_UPDATED_AT','FORECAST_DATA','FOLLOW_PEBBLE_UNITS','WEATHER_LOCATION','WEATHER_CLEAR','SHOW_DAILY_RANGE','SHOW_RAIN_CHANCE','WEATHER_DETAILS','LAYOUT_STYLE','SHOW_WEATHER_ICON','WEATHER_CONDITION','COMPLICATION_DATA','REQUEST_COMPLICATIONS','CONTEXT_DATA','REQUEST_CONTEXT','SHOW_MUSIC','SHOW_NOTIFICATIONS','NOTIFICATION_PREVIEW','NOTIFICATION_APPS','SHOW_STATUS','PANEL_TRANSITIONS','ACCENT_COLOR','ANIMATIONS','CLOCK_FORMAT','NOTIFICATION_VIBRATION','NIGHT_PALETTE','NIGHT_BACKGROUND_COLOR','NIGHT_TEXT_COLOR','NIGHT_ACCENT_COLOR','NOTIFICATION_APP_ONLY','CONTEXT_STATE','ACTIVITY_DATA','REQUEST_ACTIVITIES','SHOW_ACTIVITIES','ACTIVITY_PRESENTED','REQUEST_PRESENTATION'];
	var defaults = {BACKGROUND_COLOR:0xffffff,TEXT_COLOR:0,ACCENT_COLOR:0x55aaff,CLOCK_FORMAT:0,ANIMATIONS:true,SHOW_STATUS:true,SHOW_ACTIVITIES:true,SHOW_MUSIC:true,SHOW_NOTIFICATIONS:false,NOTIFICATION_PREVIEW:false,NOTIFICATION_APP_ONLY:false,NOTIFICATION_VIBRATION:0,NIGHT_PALETTE:false,NIGHT_BACKGROUND_COLOR:0,NIGHT_TEXT_COLOR:0xffffff,NIGHT_ACCENT_COLOR:0x55aaff,NOTIFICATION_APPS:''};
	function object(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
	function unwrap(value) { return object(value) && Object.prototype.hasOwnProperty.call(value,'value') ? value.value : value; }
	function value(source,name) { return unwrap(source[name] !== undefined ? source[name] : source[names.indexOf(name)]); }
	function valid(name,input) {
	  if (/_COLOR$/.test(name)) return typeof input === 'number' && isFinite(input) && Math.floor(input) === input && input >= 0 && input <= 0xffffff;
	  if (name === 'CLOCK_FORMAT') return input === 0 || input === 12 || input === 24;
	  if (name === 'NOTIFICATION_VIBRATION') return input === 0 || input === 1 || input === 2;
	  if (name === 'NOTIFICATION_APPS') return typeof input === 'string' && input.length <= 160 && !/[\u0000-\u001f]/.test(input);
	  return input === true || input === false || input === 0 || input === 1;
	}
	function normalize(source,strict) {
	  if (!object(source)) return null;
	  var result = {}, invalid = false;
	  Object.keys(defaults).forEach(function(name) {
	    var input = value(source,name);
	    if (!strict && typeof defaults[name] === 'boolean' && ['true','false','0','1'].indexOf(input) >= 0) input = input === 'true' || input === '1';
	    if (input === undefined && name === 'CLOCK_FORMAT') {
	      var old = value(source,'USE_12_HOUR');
	      if (old === true || old === 1) input = 12;
	      else if (old === false || old === 0) input = 24;
	    }
	    if (!valid(name,input)) { if (strict) invalid = true; input = defaults[name]; }
	    result[name] = typeof defaults[name] === 'boolean' ? !!input : input;
	  });
	  var preferences = source[PREFERENCES];
	  preferences = unwrap(preferences);
	  if (typeof preferences === 'string') { try { preferences = JSON.parse(preferences); } catch (ignored) { invalid = true; } }
	  if (strict && !object(preferences)) invalid = true;
	  result[PREFERENCES] = selection.normalizePreferences(preferences);
	  return invalid ? null : result;
	}
	function read(storage) {
	  var raw = storage.getItem(KEY), source = {};
	  if (raw !== null && raw !== undefined && raw !== '') {
	    try { source = JSON.parse(raw); } catch (ignored) { return null; }
	    if (!object(source)) return null;
	  }
	  if (source[PREFERENCES] === undefined) {
	    try { source[PREFERENCES] = JSON.parse(storage.getItem(OLD_PREFERENCES)); } catch (ignored) {}
	  }
	  return normalize(source,false);
	}
	function save(storage,candidate) {
	  var selected = normalize(candidate,true);
	  if (!selected) return {ok:false,notSaved:true};
	  try {
	    // Preserve retired/unknown saved keys for compatibility, but never accept
	    // new unrecognised fields or activity content from the configuration page.
	    var previous = {}, raw = storage.getItem(KEY);
	    if (raw) { try { var parsed = JSON.parse(raw); if (object(parsed)) previous = parsed; } catch (ignored) {} }
	    Object.keys(selected).forEach(function(name) { previous[name] = selected[name]; });
	    var serialized = JSON.stringify(previous);
	    if (raw !== serialized) storage.setItem(KEY,serialized);
	    if (storage.getItem(KEY) !== serialized) return {ok:false};
	    var actual = read(storage);
	    if (JSON.stringify(actual) !== JSON.stringify(selected)) return {ok:false};
	    return {ok:true,settings:actual};
	  } catch (ignored) { return {ok:false}; }
	}
	module.exports = {read:read,save:save,normalize:normalize,defaults:defaults,names:names,preferencesKey:PREFERENCES};


/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

	var require;var require;/* WEBPACK VAR INJECTION */(function(require) {/* Clay - https://github.com/pebble-dev/clay - Version: 1.1.0 - Build Date: 2026-08-24T18:32:42.177Z */
	!function(g){if(true)module.exports=g();else if("function"==typeof define&&define.amd)define([],g);else{var n;n="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:this,n.rebbleclay=g()}}(function(){var g;return function(){function g(n,I,t){function e(A,i){if(!I[A]){if(!n[A]){var l="function"==typeof require&&require;if(!i&&l)return require(A,!0);if(C)return C(A,!0);var c=new Error("Cannot find module '"+A+"'");throw c.code="MODULE_NOT_FOUND",c}var a=I[A]={exports:{}};n[A][0].call(a.exports,function(g){var I=n[A][1][g];return e(I||g)},a,a.exports,g,n,I,t)}return I[A].exports}for(var C="function"==typeof require&&require,A=0;A<t.length;A++)e(t[A]);return e}return g}()({1:[function(g,n,I){"use strict";function t(g){var n=g.length;if(n%4>0)throw new Error("Invalid string. Length must be a multiple of 4");var I=g.indexOf("=");I===-1&&(I=n);var t=I===n?0:4-I%4;return[I,t]}function e(g){var n=t(g),I=n[0],e=n[1];return 3*(I+e)/4-e}function C(g,n,I){return 3*(n+I)/4-I}function A(g){var n,I,e=t(g),A=e[0],i=e[1],l=new r(C(g,A,i)),c=0,a=i>0?A-4:A;for(I=0;I<a;I+=4)n=o[g.charCodeAt(I)]<<18|o[g.charCodeAt(I+1)]<<12|o[g.charCodeAt(I+2)]<<6|o[g.charCodeAt(I+3)],l[c++]=n>>16&255,l[c++]=n>>8&255,l[c++]=255&n;return 2===i&&(n=o[g.charCodeAt(I)]<<2|o[g.charCodeAt(I+1)]>>4,l[c++]=255&n),1===i&&(n=o[g.charCodeAt(I)]<<10|o[g.charCodeAt(I+1)]<<4|o[g.charCodeAt(I+2)]>>2,l[c++]=n>>8&255,l[c++]=255&n),l}function i(g){return a[g>>18&63]+a[g>>12&63]+a[g>>6&63]+a[63&g]}function l(g,n,I){for(var t,e=[],C=n;C<I;C+=3)t=(g[C]<<16&16711680)+(g[C+1]<<8&65280)+(255&g[C+2]),e.push(i(t));return e.join("")}function c(g){for(var n,I=g.length,t=I%3,e=[],C=16383,A=0,i=I-t;A<i;A+=C)e.push(l(g,A,A+C>i?i:A+C));return 1===t?(n=g[I-1],e.push(a[n>>2]+a[n<<4&63]+"==")):2===t&&(n=(g[I-2]<<8)+g[I-1],e.push(a[n>>10]+a[n>>4&63]+a[n<<2&63]+"=")),e.join("")}I.byteLength=e,I.toByteArray=A,I.fromByteArray=c;for(var a=[],o=[],r="undefined"!=typeof Uint8Array?Uint8Array:Array,s="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",u=0,b=s.length;u<b;++u)a[u]=s[u],o[s.charCodeAt(u)]=u;o["-".charCodeAt(0)]=62,o["_".charCodeAt(0)]=63},{}],2:[function(g,n,I){(function(n,t){(function(){/*!
	 * The buffer module from node.js, for the browser.
	 *
	 * @author   Feross Aboukhadijeh <http://feross.org>
	 * @license  MIT
	 */
	"use strict";function t(){try{var g=new Uint8Array(1);return g.__proto__={__proto__:Uint8Array.prototype,foo:function(){return 42}},42===g.foo()&&"function"==typeof g.subarray&&0===g.subarray(1,1).byteLength}catch(n){return!1}}function e(){return A.TYPED_ARRAY_SUPPORT?2147483647:1073741823}function C(g,n){if(e()<n)throw new RangeError("Invalid typed array length");return A.TYPED_ARRAY_SUPPORT?(g=new Uint8Array(n),g.__proto__=A.prototype):(null===g&&(g=new A(n)),g.length=n),g}function A(g,n,I){if(!(A.TYPED_ARRAY_SUPPORT||this instanceof A))return new A(g,n,I);if("number"==typeof g){if("string"==typeof n)throw new Error("If encoding is specified then the first argument must be a string");return a(this,g)}return i(this,g,n,I)}function i(g,n,I,t){if("number"==typeof n)throw new TypeError('"value" argument must not be a number');return"undefined"!=typeof ArrayBuffer&&n instanceof ArrayBuffer?s(g,n,I,t):"string"==typeof n?o(g,n,I):u(g,n)}function l(g){if("number"!=typeof g)throw new TypeError('"size" argument must be a number');if(g<0)throw new RangeError('"size" argument must not be negative')}function c(g,n,I,t){return l(n),n<=0?C(g,n):void 0!==I?"string"==typeof t?C(g,n).fill(I,t):C(g,n).fill(I):C(g,n)}function a(g,n){if(l(n),g=C(g,n<0?0:0|b(n)),!A.TYPED_ARRAY_SUPPORT)for(var I=0;I<n;++I)g[I]=0;return g}function o(g,n,I){if("string"==typeof I&&""!==I||(I="utf8"),!A.isEncoding(I))throw new TypeError('"encoding" must be a valid string encoding');var t=0|d(n,I);g=C(g,t);var e=g.write(n,I);return e!==t&&(g=g.slice(0,e)),g}function r(g,n){var I=n.length<0?0:0|b(n.length);g=C(g,I);for(var t=0;t<I;t+=1)g[t]=255&n[t];return g}function s(g,n,I,t){if(n.byteLength,I<0||n.byteLength<I)throw new RangeError("'offset' is out of bounds");if(n.byteLength<I+(t||0))throw new RangeError("'length' is out of bounds");return n=void 0===I&&void 0===t?new Uint8Array(n):void 0===t?new Uint8Array(n,I):new Uint8Array(n,I,t),A.TYPED_ARRAY_SUPPORT?(g=n,g.__proto__=A.prototype):g=r(g,n),g}function u(g,n){if(A.isBuffer(n)){var I=0|b(n.length);return g=C(g,I),0===g.length?g:(n.copy(g,0,0,I),g)}if(n){if("undefined"!=typeof ArrayBuffer&&n.buffer instanceof ArrayBuffer||"length"in n)return"number"!=typeof n.length||P(n.length)?C(g,0):r(g,n);if("Buffer"===n.type&&$(n.data))return r(g,n.data)}throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.")}function b(g){if(g>=e())throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x"+e().toString(16)+" bytes");return 0|g}function B(g){return+g!=g&&(g=0),A.alloc(+g)}function d(g,n){if(A.isBuffer(g))return g.length;if("undefined"!=typeof ArrayBuffer&&"function"==typeof ArrayBuffer.isView&&(ArrayBuffer.isView(g)||g instanceof ArrayBuffer))return g.byteLength;"string"!=typeof g&&(g=""+g);var I=g.length;if(0===I)return 0;for(var t=!1;;)switch(n){case"ascii":case"latin1":case"binary":return I;case"utf8":case"utf-8":case void 0:return K(g).length;case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return 2*I;case"hex":return I>>>1;case"base64":return M(g).length;default:if(t)return K(g).length;n=(""+n).toLowerCase(),t=!0}}function m(g,n,I){var t=!1;if((void 0===n||n<0)&&(n=0),n>this.length)return"";if((void 0===I||I>this.length)&&(I=this.length),I<=0)return"";if(I>>>=0,n>>>=0,I<=n)return"";for(g||(g="utf8");;)switch(g){case"hex":return Y(this,n,I);case"utf8":case"utf-8":return x(this,n,I);case"ascii":return V(this,n,I);case"latin1":case"binary":return N(this,n,I);case"base64":return W(this,n,I);case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return v(this,n,I);default:if(t)throw new TypeError("Unknown encoding: "+g);g=(g+"").toLowerCase(),t=!0}}function p(g,n,I){var t=g[n];g[n]=g[I],g[I]=t}function Q(g,n,I,t,e){if(0===g.length)return-1;if("string"==typeof I?(t=I,I=0):I>2147483647?I=2147483647:I<-2147483648&&(I=-2147483648),I=+I,isNaN(I)&&(I=e?0:g.length-1),I<0&&(I=g.length+I),I>=g.length){if(e)return-1;I=g.length-1}else if(I<0){if(!e)return-1;I=0}if("string"==typeof n&&(n=A.from(n,t)),A.isBuffer(n))return 0===n.length?-1:G(g,n,I,t,e);if("number"==typeof n)return n=255&n,A.TYPED_ARRAY_SUPPORT&&"function"==typeof Uint8Array.prototype.indexOf?e?Uint8Array.prototype.indexOf.call(g,n,I):Uint8Array.prototype.lastIndexOf.call(g,n,I):G(g,[n],I,t,e);throw new TypeError("val must be string, number or Buffer")}function G(g,n,I,t,e){function C(g,n){return 1===A?g[n]:g.readUInt16BE(n*A)}var A=1,i=g.length,l=n.length;if(void 0!==t&&(t=String(t).toLowerCase(),"ucs2"===t||"ucs-2"===t||"utf16le"===t||"utf-16le"===t)){if(g.length<2||n.length<2)return-1;A=2,i/=2,l/=2,I/=2}var c;if(e){var a=-1;for(c=I;c<i;c++)if(C(g,c)===C(n,a===-1?0:c-a)){if(a===-1&&(a=c),c-a+1===l)return a*A}else a!==-1&&(c-=c-a),a=-1}else for(I+l>i&&(I=i-l),c=I;c>=0;c--){for(var o=!0,r=0;r<l;r++)if(C(g,c+r)!==C(n,r)){o=!1;break}if(o)return c}return-1}function F(g,n,I,t){I=Number(I)||0;var e=g.length-I;t?(t=Number(t),t>e&&(t=e)):t=e;var C=n.length;if(C%2!==0)throw new TypeError("Invalid hex string");t>C/2&&(t=C/2);for(var A=0;A<t;++A){var i=parseInt(n.substr(2*A,2),16);if(isNaN(i))return A;g[I+A]=i}return A}function h(g,n,I,t){return L(K(n,g.length-I),g,I,t)}function Z(g,n,I,t){return L(z(n),g,I,t)}function f(g,n,I,t){return Z(g,n,I,t)}function X(g,n,I,t){return L(M(n),g,I,t)}function y(g,n,I,t){return L(j(n,g.length-I),g,I,t)}function W(g,n,I){return 0===n&&I===g.length?q.fromByteArray(g):q.fromByteArray(g.slice(n,I))}function x(g,n,I){I=Math.min(g.length,I);for(var t=[],e=n;e<I;){var C=g[e],A=null,i=C>239?4:C>223?3:C>191?2:1;if(e+i<=I){var l,c,a,o;switch(i){case 1:C<128&&(A=C);break;case 2:l=g[e+1],128===(192&l)&&(o=(31&C)<<6|63&l,o>127&&(A=o));break;case 3:l=g[e+1],c=g[e+2],128===(192&l)&&128===(192&c)&&(o=(15&C)<<12|(63&l)<<6|63&c,o>2047&&(o<55296||o>57343)&&(A=o));break;case 4:l=g[e+1],c=g[e+2],a=g[e+3],128===(192&l)&&128===(192&c)&&128===(192&a)&&(o=(15&C)<<18|(63&l)<<12|(63&c)<<6|63&a,o>65535&&o<1114112&&(A=o))}}null===A?(A=65533,i=1):A>65535&&(A-=65536,t.push(A>>>10&1023|55296),A=56320|1023&A),t.push(A),e+=i}return U(t)}function U(g){var n=g.length;if(n<=gg)return String.fromCharCode.apply(String,g);for(var I="",t=0;t<n;)I+=String.fromCharCode.apply(String,g.slice(t,t+=gg));return I}function V(g,n,I){var t="";I=Math.min(g.length,I);for(var e=n;e<I;++e)t+=String.fromCharCode(127&g[e]);return t}function N(g,n,I){var t="";I=Math.min(g.length,I);for(var e=n;e<I;++e)t+=String.fromCharCode(g[e]);return t}function Y(g,n,I){var t=g.length;(!n||n<0)&&(n=0),(!I||I<0||I>t)&&(I=t);for(var e="",C=n;C<I;++C)e+=w(g[C]);return e}function v(g,n,I){for(var t=g.slice(n,I),e="",C=0;C<t.length;C+=2)e+=String.fromCharCode(t[C]+256*t[C+1]);return e}function R(g,n,I){if(g%1!==0||g<0)throw new RangeError("offset is not uint");if(g+n>I)throw new RangeError("Trying to access beyond buffer length")}function T(g,n,I,t,e,C){if(!A.isBuffer(g))throw new TypeError('"buffer" argument must be a Buffer instance');if(n>e||n<C)throw new RangeError('"value" argument is out of bounds');if(I+t>g.length)throw new RangeError("Index out of range")}function H(g,n,I,t){n<0&&(n=65535+n+1);for(var e=0,C=Math.min(g.length-I,2);e<C;++e)g[I+e]=(n&255<<8*(t?e:1-e))>>>8*(t?e:1-e)}function O(g,n,I,t){n<0&&(n=4294967295+n+1);for(var e=0,C=Math.min(g.length-I,4);e<C;++e)g[I+e]=n>>>8*(t?e:3-e)&255}function S(g,n,I,t,e,C){if(I+t>g.length)throw new RangeError("Index out of range");if(I<0)throw new RangeError("Index out of range")}function J(g,n,I,t,e){return e||S(g,n,I,4,3.4028234663852886e38,-3.4028234663852886e38),_.write(g,n,I,t,23,4),I+4}function D(g,n,I,t,e){return e||S(g,n,I,8,1.7976931348623157e308,-1.7976931348623157e308),_.write(g,n,I,t,52,8),I+8}function k(g){if(g=E(g).replace(ng,""),g.length<2)return"";for(;g.length%4!==0;)g+="=";return g}function E(g){return g.trim?g.trim():g.replace(/^\s+|\s+$/g,"")}function w(g){return g<16?"0"+g.toString(16):g.toString(16)}function K(g,n){n=n||1/0;for(var I,t=g.length,e=null,C=[],A=0;A<t;++A){if(I=g.charCodeAt(A),I>55295&&I<57344){if(!e){if(I>56319){(n-=3)>-1&&C.push(239,191,189);continue}if(A+1===t){(n-=3)>-1&&C.push(239,191,189);continue}e=I;continue}if(I<56320){(n-=3)>-1&&C.push(239,191,189),e=I;continue}I=(e-55296<<10|I-56320)+65536}else e&&(n-=3)>-1&&C.push(239,191,189);if(e=null,I<128){if((n-=1)<0)break;C.push(I)}else if(I<2048){if((n-=2)<0)break;C.push(I>>6|192,63&I|128)}else if(I<65536){if((n-=3)<0)break;C.push(I>>12|224,I>>6&63|128,63&I|128)}else{if(!(I<1114112))throw new Error("Invalid code point");if((n-=4)<0)break;C.push(I>>18|240,I>>12&63|128,I>>6&63|128,63&I|128)}}return C}function z(g){for(var n=[],I=0;I<g.length;++I)n.push(255&g.charCodeAt(I));return n}function j(g,n){for(var I,t,e,C=[],A=0;A<g.length&&!((n-=2)<0);++A)I=g.charCodeAt(A),t=I>>8,e=I%256,C.push(e),C.push(t);return C}function M(g){return q.toByteArray(k(g))}function L(g,n,I,t){for(var e=0;e<t&&!(e+I>=n.length||e>=g.length);++e)n[e+I]=g[e];return e}function P(g){return g!==g}var q=g("base64-js"),_=g("ieee754"),$=g("isarray");I.Buffer=A,I.SlowBuffer=B,I.INSPECT_MAX_BYTES=50,A.TYPED_ARRAY_SUPPORT=void 0!==n.TYPED_ARRAY_SUPPORT?n.TYPED_ARRAY_SUPPORT:t(),I.kMaxLength=e(),A.poolSize=8192,A._augment=function(g){return g.__proto__=A.prototype,g},A.from=function(g,n,I){return i(null,g,n,I)},A.TYPED_ARRAY_SUPPORT&&(A.prototype.__proto__=Uint8Array.prototype,A.__proto__=Uint8Array,"undefined"!=typeof Symbol&&Symbol.species&&A[Symbol.species]===A&&Object.defineProperty(A,Symbol.species,{value:null,configurable:!0})),A.alloc=function(g,n,I){return c(null,g,n,I)},A.allocUnsafe=function(g){return a(null,g)},A.allocUnsafeSlow=function(g){return a(null,g)},A.isBuffer=function(g){return!(null==g||!g._isBuffer)},A.compare=function(g,n){if(!A.isBuffer(g)||!A.isBuffer(n))throw new TypeError("Arguments must be Buffers");if(g===n)return 0;for(var I=g.length,t=n.length,e=0,C=Math.min(I,t);e<C;++e)if(g[e]!==n[e]){I=g[e],t=n[e];break}return I<t?-1:t<I?1:0},A.isEncoding=function(g){switch(String(g).toLowerCase()){case"hex":case"utf8":case"utf-8":case"ascii":case"latin1":case"binary":case"base64":case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return!0;default:return!1}},A.concat=function(g,n){if(!$(g))throw new TypeError('"list" argument must be an Array of Buffers');if(0===g.length)return A.alloc(0);var I;if(void 0===n)for(n=0,I=0;I<g.length;++I)n+=g[I].length;var t=A.allocUnsafe(n),e=0;for(I=0;I<g.length;++I){var C=g[I];if(!A.isBuffer(C))throw new TypeError('"list" argument must be an Array of Buffers');C.copy(t,e),e+=C.length}return t},A.byteLength=d,A.prototype._isBuffer=!0,A.prototype.swap16=function(){var g=this.length;if(g%2!==0)throw new RangeError("Buffer size must be a multiple of 16-bits");for(var n=0;n<g;n+=2)p(this,n,n+1);return this},A.prototype.swap32=function(){var g=this.length;if(g%4!==0)throw new RangeError("Buffer size must be a multiple of 32-bits");for(var n=0;n<g;n+=4)p(this,n,n+3),p(this,n+1,n+2);return this},A.prototype.swap64=function(){var g=this.length;if(g%8!==0)throw new RangeError("Buffer size must be a multiple of 64-bits");for(var n=0;n<g;n+=8)p(this,n,n+7),p(this,n+1,n+6),p(this,n+2,n+5),p(this,n+3,n+4);return this},A.prototype.toString=function(){var g=0|this.length;return 0===g?"":0===arguments.length?x(this,0,g):m.apply(this,arguments)},A.prototype.equals=function(g){if(!A.isBuffer(g))throw new TypeError("Argument must be a Buffer");return this===g||0===A.compare(this,g)},A.prototype.inspect=function(){var g="",n=I.INSPECT_MAX_BYTES;return this.length>0&&(g=this.toString("hex",0,n).match(/.{2}/g).join(" "),this.length>n&&(g+=" ... ")),"<Buffer "+g+">"},A.prototype.compare=function(g,n,I,t,e){if(!A.isBuffer(g))throw new TypeError("Argument must be a Buffer");if(void 0===n&&(n=0),void 0===I&&(I=g?g.length:0),void 0===t&&(t=0),void 0===e&&(e=this.length),n<0||I>g.length||t<0||e>this.length)throw new RangeError("out of range index");if(t>=e&&n>=I)return 0;if(t>=e)return-1;if(n>=I)return 1;if(n>>>=0,I>>>=0,t>>>=0,e>>>=0,this===g)return 0;for(var C=e-t,i=I-n,l=Math.min(C,i),c=this.slice(t,e),a=g.slice(n,I),o=0;o<l;++o)if(c[o]!==a[o]){C=c[o],i=a[o];break}return C<i?-1:i<C?1:0},A.prototype.includes=function(g,n,I){return this.indexOf(g,n,I)!==-1},A.prototype.indexOf=function(g,n,I){return Q(this,g,n,I,!0)},A.prototype.lastIndexOf=function(g,n,I){return Q(this,g,n,I,!1)},A.prototype.write=function(g,n,I,t){if(void 0===n)t="utf8",I=this.length,n=0;else if(void 0===I&&"string"==typeof n)t=n,I=this.length,n=0;else{if(!isFinite(n))throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");n=0|n,isFinite(I)?(I=0|I,void 0===t&&(t="utf8")):(t=I,I=void 0)}var e=this.length-n;if((void 0===I||I>e)&&(I=e),g.length>0&&(I<0||n<0)||n>this.length)throw new RangeError("Attempt to write outside buffer bounds");t||(t="utf8");for(var C=!1;;)switch(t){case"hex":return F(this,g,n,I);case"utf8":case"utf-8":return h(this,g,n,I);case"ascii":return Z(this,g,n,I);case"latin1":case"binary":return f(this,g,n,I);case"base64":return X(this,g,n,I);case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return y(this,g,n,I);default:if(C)throw new TypeError("Unknown encoding: "+t);t=(""+t).toLowerCase(),C=!0}},A.prototype.toJSON=function(){return{type:"Buffer",data:Array.prototype.slice.call(this._arr||this,0)}};var gg=4096;A.prototype.slice=function(g,n){var I=this.length;g=~~g,n=void 0===n?I:~~n,g<0?(g+=I,g<0&&(g=0)):g>I&&(g=I),n<0?(n+=I,n<0&&(n=0)):n>I&&(n=I),n<g&&(n=g);var t;if(A.TYPED_ARRAY_SUPPORT)t=this.subarray(g,n),t.__proto__=A.prototype;else{var e=n-g;t=new A(e,(void 0));for(var C=0;C<e;++C)t[C]=this[C+g]}return t},A.prototype.readUIntLE=function(g,n,I){g=0|g,n=0|n,I||R(g,n,this.length);for(var t=this[g],e=1,C=0;++C<n&&(e*=256);)t+=this[g+C]*e;return t},A.prototype.readUIntBE=function(g,n,I){g=0|g,n=0|n,I||R(g,n,this.length);for(var t=this[g+--n],e=1;n>0&&(e*=256);)t+=this[g+--n]*e;return t},A.prototype.readUInt8=function(g,n){return n||R(g,1,this.length),this[g]},A.prototype.readUInt16LE=function(g,n){return n||R(g,2,this.length),this[g]|this[g+1]<<8},A.prototype.readUInt16BE=function(g,n){return n||R(g,2,this.length),this[g]<<8|this[g+1]},A.prototype.readUInt32LE=function(g,n){return n||R(g,4,this.length),(this[g]|this[g+1]<<8|this[g+2]<<16)+16777216*this[g+3]},A.prototype.readUInt32BE=function(g,n){return n||R(g,4,this.length),16777216*this[g]+(this[g+1]<<16|this[g+2]<<8|this[g+3])},A.prototype.readIntLE=function(g,n,I){g=0|g,n=0|n,I||R(g,n,this.length);for(var t=this[g],e=1,C=0;++C<n&&(e*=256);)t+=this[g+C]*e;return e*=128,t>=e&&(t-=Math.pow(2,8*n)),t},A.prototype.readIntBE=function(g,n,I){g=0|g,n=0|n,I||R(g,n,this.length);for(var t=n,e=1,C=this[g+--t];t>0&&(e*=256);)C+=this[g+--t]*e;return e*=128,C>=e&&(C-=Math.pow(2,8*n)),C},A.prototype.readInt8=function(g,n){return n||R(g,1,this.length),128&this[g]?(255-this[g]+1)*-1:this[g]},A.prototype.readInt16LE=function(g,n){n||R(g,2,this.length);var I=this[g]|this[g+1]<<8;return 32768&I?4294901760|I:I},A.prototype.readInt16BE=function(g,n){n||R(g,2,this.length);var I=this[g+1]|this[g]<<8;return 32768&I?4294901760|I:I},A.prototype.readInt32LE=function(g,n){return n||R(g,4,this.length),this[g]|this[g+1]<<8|this[g+2]<<16|this[g+3]<<24},A.prototype.readInt32BE=function(g,n){return n||R(g,4,this.length),this[g]<<24|this[g+1]<<16|this[g+2]<<8|this[g+3]},A.prototype.readFloatLE=function(g,n){return n||R(g,4,this.length),_.read(this,g,!0,23,4)},A.prototype.readFloatBE=function(g,n){return n||R(g,4,this.length),_.read(this,g,!1,23,4)},A.prototype.readDoubleLE=function(g,n){return n||R(g,8,this.length),_.read(this,g,!0,52,8)},A.prototype.readDoubleBE=function(g,n){return n||R(g,8,this.length),_.read(this,g,!1,52,8)},A.prototype.writeUIntLE=function(g,n,I,t){if(g=+g,n=0|n,I=0|I,!t){var e=Math.pow(2,8*I)-1;T(this,g,n,I,e,0)}var C=1,A=0;for(this[n]=255&g;++A<I&&(C*=256);)this[n+A]=g/C&255;return n+I},A.prototype.writeUIntBE=function(g,n,I,t){if(g=+g,n=0|n,I=0|I,!t){var e=Math.pow(2,8*I)-1;T(this,g,n,I,e,0)}var C=I-1,A=1;for(this[n+C]=255&g;--C>=0&&(A*=256);)this[n+C]=g/A&255;return n+I},A.prototype.writeUInt8=function(g,n,I){return g=+g,n=0|n,I||T(this,g,n,1,255,0),A.TYPED_ARRAY_SUPPORT||(g=Math.floor(g)),this[n]=255&g,n+1},A.prototype.writeUInt16LE=function(g,n,I){return g=+g,n=0|n,I||T(this,g,n,2,65535,0),A.TYPED_ARRAY_SUPPORT?(this[n]=255&g,this[n+1]=g>>>8):H(this,g,n,!0),n+2},A.prototype.writeUInt16BE=function(g,n,I){return g=+g,n=0|n,I||T(this,g,n,2,65535,0),A.TYPED_ARRAY_SUPPORT?(this[n]=g>>>8,this[n+1]=255&g):H(this,g,n,!1),n+2},A.prototype.writeUInt32LE=function(g,n,I){return g=+g,n=0|n,I||T(this,g,n,4,4294967295,0),A.TYPED_ARRAY_SUPPORT?(this[n+3]=g>>>24,this[n+2]=g>>>16,this[n+1]=g>>>8,this[n]=255&g):O(this,g,n,!0),n+4},A.prototype.writeUInt32BE=function(g,n,I){return g=+g,n=0|n,I||T(this,g,n,4,4294967295,0),A.TYPED_ARRAY_SUPPORT?(this[n]=g>>>24,this[n+1]=g>>>16,this[n+2]=g>>>8,this[n+3]=255&g):O(this,g,n,!1),n+4},A.prototype.writeIntLE=function(g,n,I,t){if(g=+g,n=0|n,!t){var e=Math.pow(2,8*I-1);T(this,g,n,I,e-1,-e)}var C=0,A=1,i=0;for(this[n]=255&g;++C<I&&(A*=256);)g<0&&0===i&&0!==this[n+C-1]&&(i=1),this[n+C]=(g/A>>0)-i&255;return n+I},A.prototype.writeIntBE=function(g,n,I,t){if(g=+g,n=0|n,!t){var e=Math.pow(2,8*I-1);T(this,g,n,I,e-1,-e)}var C=I-1,A=1,i=0;for(this[n+C]=255&g;--C>=0&&(A*=256);)g<0&&0===i&&0!==this[n+C+1]&&(i=1),this[n+C]=(g/A>>0)-i&255;return n+I},A.prototype.writeInt8=function(g,n,I){return g=+g,n=0|n,I||T(this,g,n,1,127,-128),A.TYPED_ARRAY_SUPPORT||(g=Math.floor(g)),g<0&&(g=255+g+1),this[n]=255&g,n+1},A.prototype.writeInt16LE=function(g,n,I){return g=+g,n=0|n,I||T(this,g,n,2,32767,-32768),A.TYPED_ARRAY_SUPPORT?(this[n]=255&g,this[n+1]=g>>>8):H(this,g,n,!0),n+2},A.prototype.writeInt16BE=function(g,n,I){return g=+g,n=0|n,I||T(this,g,n,2,32767,-32768),A.TYPED_ARRAY_SUPPORT?(this[n]=g>>>8,this[n+1]=255&g):H(this,g,n,!1),n+2},A.prototype.writeInt32LE=function(g,n,I){return g=+g,n=0|n,I||T(this,g,n,4,2147483647,-2147483648),A.TYPED_ARRAY_SUPPORT?(this[n]=255&g,this[n+1]=g>>>8,this[n+2]=g>>>16,this[n+3]=g>>>24):O(this,g,n,!0),n+4},A.prototype.writeInt32BE=function(g,n,I){return g=+g,n=0|n,I||T(this,g,n,4,2147483647,-2147483648),g<0&&(g=4294967295+g+1),A.TYPED_ARRAY_SUPPORT?(this[n]=g>>>24,this[n+1]=g>>>16,this[n+2]=g>>>8,this[n+3]=255&g):O(this,g,n,!1),n+4},A.prototype.writeFloatLE=function(g,n,I){return J(this,g,n,!0,I)},A.prototype.writeFloatBE=function(g,n,I){return J(this,g,n,!1,I)},A.prototype.writeDoubleLE=function(g,n,I){return D(this,g,n,!0,I)},A.prototype.writeDoubleBE=function(g,n,I){return D(this,g,n,!1,I)},A.prototype.copy=function(g,n,I,t){if(I||(I=0),t||0===t||(t=this.length),n>=g.length&&(n=g.length),n||(n=0),t>0&&t<I&&(t=I),t===I)return 0;if(0===g.length||0===this.length)return 0;if(n<0)throw new RangeError("targetStart out of bounds");if(I<0||I>=this.length)throw new RangeError("sourceStart out of bounds");if(t<0)throw new RangeError("sourceEnd out of bounds");t>this.length&&(t=this.length),g.length-n<t-I&&(t=g.length-n+I);var e,C=t-I;if(this===g&&I<n&&n<t)for(e=C-1;e>=0;--e)g[e+n]=this[e+I];else if(C<1e3||!A.TYPED_ARRAY_SUPPORT)for(e=0;e<C;++e)g[e+n]=this[e+I];else Uint8Array.prototype.set.call(g,this.subarray(I,I+C),n);return C},A.prototype.fill=function(g,n,I,t){if("string"==typeof g){if("string"==typeof n?(t=n,n=0,I=this.length):"string"==typeof I&&(t=I,I=this.length),1===g.length){var e=g.charCodeAt(0);e<256&&(g=e)}if(void 0!==t&&"string"!=typeof t)throw new TypeError("encoding must be a string");if("string"==typeof t&&!A.isEncoding(t))throw new TypeError("Unknown encoding: "+t)}else"number"==typeof g&&(g=255&g);if(n<0||this.length<n||this.length<I)throw new RangeError("Out of range index");if(I<=n)return this;n>>>=0,I=void 0===I?this.length:I>>>0,g||(g=0);var C;if("number"==typeof g)for(C=n;C<I;++C)this[C]=g;else{var i=A.isBuffer(g)?g:K(new A(g,t).toString()),l=i.length;for(C=0;C<I-n;++C)this[C+n]=i[C%l]}return this};var ng=/[^+\/0-9A-Za-z-_]/g}).call(this)}).call(this,"undefined"!=typeof global?global:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{},g("buffer").Buffer)},{"base64-js":1,buffer:2,ieee754:4,isarray:5}],3:[function(n,I,t){(function(n){(function(){/*!
	 * @license deepcopy.js Copyright(c) 2013 sasa+1
	 * https://github.com/sasaplus1/deepcopy.js
	 * Released under the MIT license.
	 */
	!function(n,e){"object"==typeof t&&"object"==typeof I?I.exports=e():"function"==typeof g&&g.amd?g([],e):"object"==typeof t?t.deepcopy=e():n.deepcopy=e()}(this,function(){return function(g){function n(t){if(I[t])return I[t].exports;var e=I[t]={exports:{},id:t,loaded:!1};return g[t].call(e.exports,e,e.exports,n),e.loaded=!0,e.exports}var I={};return n.m=g,n.c=I,n.p="",n(0)}([function(g,n,I){"use strict";g.exports=I(3)},function(g,I){"use strict";function t(g,n){if("[object Array]"!==e.call(g))throw new TypeError("array must be an Array");var I=void 0,t=void 0,C=void 0;for(I=0,t=g.length;t>I;++I)if(C=g[I],C===n||C!==C&&n!==n)return I;return-1}I.__esModule=!0;var e=Object.prototype.toString,C="undefined"!=typeof n?function(g){return n.isBuffer(g)}:function(){return!1},A="function"==typeof Object.keys?function(g){return Object.keys(g)}:function(g){var n=typeof g;if(null===g||"function"!==n&&"object"!==n)throw new TypeError("obj must be an Object");var I=[],t=void 0;for(t in g)Object.prototype.hasOwnProperty.call(g,t)&&I.push(t);return I},i="function"==typeof Symbol?function(g){return Object.getOwnPropertySymbols(g)}:function(){return[]};I.getKeys=A,I.getSymbols=i,I.indexOf=t,I.isBuffer=C},function(g,I,t){"use strict";function e(g,n){var I=A(g);return null!==I?I:C(g,n)}function C(g,I){if("function"!=typeof I)throw new TypeError("customizer is must be a Function");if("function"==typeof g){var t=String(g);return/^\s*function\s*\S*\([^\)]*\)\s*{\s*\[native code\]\s*}/.test(t)?g:new Function("return "+String(t))()}var e=l.call(g);if("[object Array]"===e)return[];if("[object Object]"===e&&g.constructor===Object)return{};if("[object Date]"===e)return new Date(g.getTime());if("[object RegExp]"===e){var C=String(g),A=C.lastIndexOf("/");return new RegExp(C.slice(1,A),C.slice(A+1))}if((0,i.isBuffer)(g)){var c=new n(g.length);return g.copy(c),c}var a=I(g);return void 0!==a?a:null}function A(g){var n=typeof g;return null!==g&&"object"!==n&&"function"!==n?g:null}I.__esModule=!0,I.copyValue=I.copyCollection=I.copy=void 0;var i=t(1),l=Object.prototype.toString;I.copy=e,I.copyCollection=C,I.copyValue=A},function(g,n,I){"use strict";function t(g){}function e(g){var n=arguments.length<=1||void 0===arguments[1]?t:arguments[1];if(null===g)return null;var I=(0,A.copyValue)(g);if(null!==I)return I;var e=(0,A.copyCollection)(g,n),i=null!==e?e:g,l=[g],c=[i];return C(g,n,i,l,c)}function C(g,n,I,t,e){if(null===g)return null;var l=(0,A.copyValue)(g);if(null!==l)return l;var c=(0,i.getKeys)(g).concat((0,i.getSymbols)(g)),a=void 0,o=void 0,r=void 0,s=void 0,u=void 0,b=void 0,B=void 0,d=void 0;for(a=0,o=c.length;o>a;++a)r=c[a],s=g[r],u=(0,i.indexOf)(t,s),b=void 0,B=void 0,d=void 0,-1===u?(b=(0,A.copy)(s,n),B=null!==b?b:s,null!==s&&/^(?:function|object)$/.test(typeof s)&&(t.push(s),e.push(B))):d=e[u],I[r]=d||C(s,n,B,t,e);return I}n.__esModule=!0;var A=I(2),i=I(1);n["default"]=e,g.exports=n["default"]}])})}).call(this)}).call(this,n("buffer").Buffer)},{buffer:2}],4:[function(g,n,I){/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
	I.read=function(g,n,I,t,e){var C,A,i=8*e-t-1,l=(1<<i)-1,c=l>>1,a=-7,o=I?e-1:0,r=I?-1:1,s=g[n+o];for(o+=r,C=s&(1<<-a)-1,s>>=-a,a+=i;a>0;C=256*C+g[n+o],o+=r,a-=8);for(A=C&(1<<-a)-1,C>>=-a,a+=t;a>0;A=256*A+g[n+o],o+=r,a-=8);if(0===C)C=1-c;else{if(C===l)return A?NaN:(s?-1:1)*(1/0);A+=Math.pow(2,t),C-=c}return(s?-1:1)*A*Math.pow(2,C-t)},I.write=function(g,n,I,t,e,C){var A,i,l,c=8*C-e-1,a=(1<<c)-1,o=a>>1,r=23===e?Math.pow(2,-24)-Math.pow(2,-77):0,s=t?0:C-1,u=t?1:-1,b=n<0||0===n&&1/n<0?1:0;for(n=Math.abs(n),isNaN(n)||n===1/0?(i=isNaN(n)?1:0,A=a):(A=Math.floor(Math.log(n)/Math.LN2),n*(l=Math.pow(2,-A))<1&&(A--,l*=2),n+=A+o>=1?r/l:r*Math.pow(2,1-o),n*l>=2&&(A++,l/=2),A+o>=a?(i=0,A=a):A+o>=1?(i=(n*l-1)*Math.pow(2,e),A+=o):(i=n*Math.pow(2,o-1)*Math.pow(2,e),A=0));e>=8;g[I+s]=255&i,s+=u,i/=256,e-=8);for(A=A<<e|i,c+=e;c>0;g[I+s]=255&A,s+=u,A/=256,c-=8);g[I+s-u]|=128*b}},{}],5:[function(g,n,I){var t={}.toString;n.exports=Array.isArray||function(g){return"[object Array]"==t.call(g)}},{}],6:[function(g,n,I){function t(g){return/^[a-z_$][0-9a-z_$]*$/gi.test(g)&&!C.test(g)}function e(g){if(A)return g.toString();var n=g.source.replace(/\//g,function(g,n,I){return 0===n||"\\"!==I[n-1]?"\\/":"/"}),I=(g.global&&"g"||"")+(g.ignoreCase&&"i"||"")+(g.multiline&&"m"||"");return"/"+n+"/"+I}/* toSource by Marcello Bastea-Forte - zlib license */
	n.exports=function(g,n,I,C){function A(g,n,I,C,i){function l(g){return I.slice(1)+g.join(","+(I&&"\n")+c)+(I?" ":"")}var c=C+I;switch(g=n?n(g):g,typeof g){case"string":return JSON.stringify(g);case"boolean":case"number":case"undefined":return""+g;case"function":return g.toString()}if(null===g)return"null";if(g instanceof RegExp)return e(g);if(g instanceof Date)return"new Date("+g.getTime()+")";var a=i.indexOf(g)+1;if(a>0)return"{$circularReference:"+a+"}";if(i.push(g),Array.isArray(g))return"["+l(g.map(function(g){return A(g,n,I,c,i.slice())}))+"]";var o=Object.keys(g);return o.length?"{"+l(o.map(function(e){return(t(e)?e:JSON.stringify(e))+":"+A(g[e],n,I,c,i.slice())}))+"}":"{}"}var i=[];return A(g,n,void 0===I?"  ":I||"",C||"",i)};var C=/^(abstract|boolean|break|byte|case|catch|char|class|const|continue|debugger|default|delete|do|double|else|enum|export|extends|false|final|finally|float|for|function|goto|if|implements|import|in|instanceof|int|interface|long|native|new|null|package|private|protected|public|return|short|static|super|switch|synchronized|this|throw|throws|transient|true|try|typeof|undefined|var|void|volatile|while|with)$/,A="\\/"===new RegExp("/").source},{}],7:[function(g,n,I){n.exports={name:"@rebble/clay",version:"1.1.0",description:"Pebble Config Framework",types:"index.d.ts",scripts:{"test-travis":"./node_modules/.bin/gulp && ./node_modules/.bin/karma start ./test/karma.conf.js --single-run --browsers chromeTravisCI","test-debug":"(export DEBUG=true && ./node_modules/.bin/gulp && ./node_modules/.bin/karma start ./test/karma.conf.js --no-single-run)",test:"./node_modules/.bin/gulp && ./node_modules/.bin/karma start ./test/karma.conf.js --single-run",lint:"./node_modules/.bin/eslint ./",build:"gulp","build:types":"tsc -p tsconfig.declarations.json","check:types":"tsc -p tsconfig.typecheck.json",dev:"gulp dev","pebble-clean":"rm -rf tmp src/js/index.js && pebble clean","pebble-publish":"npm run pebble-clean && npm run build && pebble build && pebble package publish && npm run pebble-clean","pebble-build":"npm run build && pebble build"},repository:{type:"git",url:"git+https://github.com/pebble-dev/clay.git"},keywords:["pebble","config","configuration","pebble-package"],author:"Pebble Technology",license:"MIT",bugs:{url:"https://github.com/pebble-dev/clay/issues"},pebble:{projectType:"package",sdkVersion:"3",targetPlatforms:["aplite","basalt","chalk","diorite","emery","flint","gabbro"],resources:{media:[]},capabilities:["configurable"]},homepage:"https://github.com/pebble-dev/clay#readme",devDependencies:{autoprefixer:"^10.4.23",bourbon:"^4.2.6",browserify:"^13.0.0","browserify-istanbul":"^3.0.1",chai:"^3.4.1",deamdify:"^0.2.0",deepcopy:"^0.6.1",del:"^2.0.2",eslint:"^1.5.1","eslint-config-pebble":"^1.2.0","eslint-plugin-standard":"^1.3.1",gulp:"^5.0.1","gulp-autoprefixer":"^3.1.0","gulp-htmlmin":"^1.3.0","gulp-inline":"^0.1.3","gulp-insert":"^0.5.0","gulp-sass":"^6.0.1","gulp-sourcemaps":"^1.6.0","gulp-uglify":"^1.5.2",joi:"^6.10.1",karma:"^6.4.0","karma-browserify":"^8.1.0","karma-chrome-launcher":"^3.2.0","karma-coverage":"^2.2.1","karma-mocha":"^2.0.1","karma-mocha-reporter":"^2.2.5","karma-source-map-support":"^1.4.0","karma-threshold-reporter":"^0.1.15",mocha:"^11.7.5",postcss:"8.5.6","require-from-string":"^2.0.2",sass:"^1.94.2",sinon:"^1.17.3",stringify:"^3.2.0",through:"^2.3.8",tosource:"^1.0.0",typescript:"6.0.2","vinyl-buffer":"^1.0.0","vinyl-source-stream":"^2.0.0",watchify:"^3.11.1"}}},{}],8:[function(g,n,I){"use strict";n.exports={name:"button",template:g("../../templates/components/button.tpl"),style:g("../../../tmp/button.css"),manipulator:"button",defaults:{primary:!1,attributes:{},description:""}}},{"../../../tmp/button.css":33,"../../templates/components/button.tpl":21}],9:[function(g,n,I){"use strict";n.exports={name:"checkboxgroup",template:g("../../templates/components/checkboxgroup.tpl"),style:g("../../../tmp/checkboxgroup.css"),manipulator:"checkboxgroup",defaults:{label:"",options:[],description:""}}},{"../../../tmp/checkboxgroup.css":34,"../../templates/components/checkboxgroup.tpl":22}],10:[function(g,n,I){"use strict";n.exports={name:"color",template:g("../../templates/components/color.tpl"),style:g("../../../tmp/color.css"),manipulator:"color",defaults:{label:"",description:""},initialize:function(g,n){function I(g){if("number"==typeof g)g=g.toString(16);else if(!g)return"transparent";return g=t(g),"#"+(o?r[g]:g)}function t(g){for(g=g.toLowerCase();g.length<6;)g="0"+g;return g}function e(g){switch(typeof g){case"number":return t(g.toString(16));case"string":return g.replace(/^#|^0x/,"");default:return g}}function C(g){return g.reduce(function(g,n){return g.concat(n)},[])}function A(g){g=g.replace(/^#|^0x/,"");var n=parseInt(g.slice(0,2),16)/255,I=parseInt(g.slice(2,4),16)/255,t=parseInt(g.slice(4),16)/255;n=n>.04045?Math.pow((n+.055)/1.055,2.4):n/12.92,I=I>.04045?Math.pow((I+.055)/1.055,2.4):I/12.92,t=t>.04045?Math.pow((t+.055)/1.055,2.4):t/12.92;var e=(.4124*n+.3576*I+.1805*t)/.95047,C=(.2126*n+.7152*I+.0722*t)/1,A=(.0193*n+.1192*I+.9505*t)/1.08883;return e=e>.008856?Math.pow(e,1/3):7.787*e+16/116,C=C>.008856?Math.pow(C,1/3):7.787*C+16/116,A=A>.008856?Math.pow(A,1/3):7.787*A+16/116,[116*C-16,500*(e-C),200*(C-A)]}function i(g,n){var I=g[0]-n[0],t=g[1]-n[1],e=g[2]-n[2];return Math.sqrt(Math.pow(I,2)+Math.pow(t,2)+Math.pow(e,2))}function l(){var g=["aplite","diorite","flint"];return!n.meta.activeWatchInfo||2===n.meta.activeWatchInfo.firmware.major||g.indexOf(n.meta.activeWatchInfo.platform)>-1&&!a.config.allowGray?s.BLACK_WHITE:g.indexOf(n.meta.activeWatchInfo.platform)>-1&&a.config.allowGray?s.GRAY:s.COLOR}var c=g.HTML,a=this;a.roundColorToLayout=function(g){var n=e(g);if(b.indexOf(n)===-1){var I=A(n),t=b.map(function(g){var n=A(e(g));return i(I,n)}),C=Math.min.apply(Math,t),l=t.indexOf(C);n=b[l]}return parseInt(n,16)};var o=a.config.sunlight!==!1,r={"000000":"000000","000055":"001e41","0000aa":"004387","0000ff":"0068ca","005500":"2b4a2c","005555":"27514f","0055aa":"16638d","0055ff":"007dce","00aa00":"5e9860","00aa55":"5c9b72","00aaaa":"57a5a2","00aaff":"4cb4db","00ff00":"8ee391","00ff55":"8ee69e","00ffaa":"8aebc0","00ffff":"84f5f1",550000:"4a161b",550055:"482748","5500aa":"40488a","5500ff":"2f6bcc",555500:"564e36",555555:"545454","5555aa":"4f6790","5555ff":"4180d0","55aa00":"759a64","55aa55":"759d76","55aaaa":"71a6a4","55aaff":"69b5dd","55ff00":"9ee594","55ff55":"9de7a0","55ffaa":"9becc2","55ffff":"95f6f2",aa0000:"99353f",aa0055:"983e5a",aa00aa:"955694",aa00ff:"8f74d2",aa5500:"9d5b4d",aa5555:"9d6064",aa55aa:"9a7099",aa55ff:"9587d5",aaaa00:"afa072",aaaa55:"aea382",aaaaaa:"ababab",ffffff:"ffffff",aaaaff:"a7bae2",aaff00:"c9e89d",aaff55:"c9eaa7",aaffaa:"c7f0c8",aaffff:"c3f9f7",ff0000:"e35462",ff0055:"e25874",ff00aa:"e16aa3",ff00ff:"de83dc",ff5500:"e66e6b",ff5555:"e6727c",ff55aa:"e37fa7",ff55ff:"e194df",ffaa00:"f1aa86",ffaa55:"f1ad93",ffaaaa:"efb5b8",ffaaff:"ecc3eb",ffff00:"ffeeab",ffff55:"fff1b5",ffffaa:"fff6d3"},s={COLOR:[[!1,!1,"55ff00","aaff55",!1,"ffff55","ffffaa",!1,!1],[!1,"aaffaa","55ff55","00ff00","aaff00","ffff00","ffaa55","ffaaaa",!1],["55ffaa","00ff55","00aa00","55aa00","aaaa55","aaaa00","ffaa00","ff5500","ff5555"],["aaffff","00ffaa","00aa55","55aa55","005500","555500","aa5500","ff0000","ff0055"],[!1,"55aaaa","00aaaa","005555","ffffff","000000","aa5555","aa0000",!1],["55ffff","00ffff","00aaff","0055aa","aaaaaa","555555","550000","aa0055","ff55aa"],["55aaff","0055ff","0000ff","0000aa","000055","550055","aa00aa","ff00aa","ffaaff"],[!1,"5555aa","5555ff","5500ff","5500aa","aa00ff","ff00ff","ff55ff",!1],[!1,!1,!1,"aaaaff","aa55ff","aa55aa",!1,!1,!1]],GRAY:[["000000","aaaaaa","ffffff"]],BLACK_WHITE:[["000000","ffffff"]]},u=a.config.layout||l();"string"==typeof u&&(u=s[u]),Array.isArray(u[0])||(u=[u]);var b=C(u).map(function(g){return e(g)}).filter(function(g){return g}),B="",d=u.length,m=0;u.forEach(function(g){m=g.length>m?g.length:m});for(var p=100/m,Q=100/d,G=a.$element,F=0;F<d;F++)for(var h=0;h<m;h++){var Z=e(u[F][h]),f=Z?" selectable":"",X=0===F&&0===h||0===F&&!u[F][h-1]||!u[F][h-1]&&!u[F-1][h]?" rounded-tl":"",y=0===F&&!u[F][h+1]||!u[F][h+1]&&!u[F-1][h]?" rounded-tr ":"",W=F===u.length-1&&0===h||F===u.length-1&&!u[F][h-1]||!u[F][h-1]&&!u[F+1][h]?" rounded-bl":"",x=F===u.length-1&&!u[F][h+1]||!u[F][h+1]&&!u[F+1][h]?" rounded-br":"";B+='<i class="color-box '+f+X+y+W+x+'" '+(Z?'data-value="'+parseInt(Z,16)+'" ':"")+'style="width:'+p+"%; height:"+Q+"%; background:"+I(Z)+';"></i>'}var U=0;3===m&&(U=5),2===m&&(U=8);var V=U*p/Q+"%",N=U+"%";G.select(".color-box-container").add(c(B)).set("$paddingTop",V).set("$paddingRight",N).set("$paddingBottom",V).set("$paddingLeft",N),G.select(".color-box-wrap").set("$paddingBottom",p/Q*100+"%");var Y=G.select(".value"),v=G.select(".picker-wrap"),R=a.$manipulatorTarget.get("disabled");G.select("label").on("click",function(){R||v.set("show")}),a.on("change",function(){var g=a.get();Y.set("$background-color",I(g)),G.select(".color-box").set("-selected"),G.select('.color-box[data-value="'+g+'"]').set("+selected")}),G.select(".color-box.selectable").on("click",function(g){a.set(parseInt(g.target.dataset.value,10)),v.set("-show")}),v.on("click",function(){v.set("-show")}),a.on("disabled",function(){R=!0}),a.on("enabled",function(){R=!1}),a._layout=u}}},{"../../../tmp/color.css":35,"../../templates/components/color.tpl":23}],11:[function(g,n,I){"use strict";n.exports={name:"footer",template:g("../../templates/components/footer.tpl"),manipulator:"html"}},{"../../templates/components/footer.tpl":24}],12:[function(g,n,I){"use strict";n.exports={name:"heading",template:g("../../templates/components/heading.tpl"),manipulator:"html",defaults:{size:4}}},{"../../templates/components/heading.tpl":25}],13:[function(g,n,I){"use strict";n.exports={color:g("./color"),footer:g("./footer"),heading:g("./heading"),input:g("./input"),select:g("./select"),submit:g("./submit"),text:g("./text"),toggle:g("./toggle"),radiogroup:g("./radiogroup"),checkboxgroup:g("./checkboxgroup"),button:g("./button"),slider:g("./slider")}},{"./button":8,"./checkboxgroup":9,"./color":10,"./footer":11,"./heading":12,"./input":14,"./radiogroup":15,"./select":16,"./slider":17,"./submit":18,"./text":19,"./toggle":20}],14:[function(g,n,I){"use strict";n.exports={name:"input",template:g("../../templates/components/input.tpl"),style:g("../../../tmp/input.css"),manipulator:"val",defaults:{label:"",serializeValueAs:"string",description:"",attributes:{}}}},{"../../../tmp/input.css":37,"../../templates/components/input.tpl":26}],15:[function(g,n,I){"use strict";n.exports={name:"radiogroup",template:g("../../templates/components/radiogroup.tpl"),style:g("../../../tmp/radiogroup.css"),manipulator:"radiogroup",defaults:{label:"",options:[],serializeValueAs:"string",description:"",attributes:{}}}},{"../../../tmp/radiogroup.css":38,"../../templates/components/radiogroup.tpl":27}],16:[function(g,n,I){"use strict";n.exports={name:"select",template:g("../../templates/components/select.tpl"),style:g("../../../tmp/select.css"),manipulator:"val",defaults:{label:"",options:[],serializeValueAs:"string",description:"",attributes:{}},initialize:function(){function g(){var g=n.$manipulatorTarget.get("selectedIndex"),t=n.$manipulatorTarget.select("option"),e=t[g]&&t[g].innerHTML;I.set("innerHTML",e)}var n=this,I=n.$element.select(".value");g(),n.on("change",g)}}},{"../../../tmp/select.css":39,"../../templates/components/select.tpl":28}],17:[function(g,n,I){"use strict";n.exports={name:"slider",template:g("../../templates/components/slider.tpl"),style:g("../../../tmp/slider.css"),manipulator:"slider",defaults:{label:"",description:"",min:0,max:100,step:1,attributes:{}},initialize:function(){function g(){var g=n.get().toFixed(n.precision);I.set("value",g),t.set("innerHTML",g)}var n=this,I=n.$element.select(".value"),t=n.$element.select(".value-pad"),e=n.$manipulatorTarget,C=e.get("step");C=C.toString(10).split(".")[1],n.precision=C?C.length:0,n.on("change",g),e.on("|input",g),g(),I.on("|input",function(){t.set("innerHTML",this.get("value"))}),I.on("|change",function(){n.set(this.get("value")),g()})}}},{"../../../tmp/slider.css":40,"../../templates/components/slider.tpl":29}],18:[function(g,n,I){"use strict";n.exports={name:"submit",template:g("../../templates/components/submit.tpl"),style:g("../../../tmp/submit.css"),manipulator:"button",defaults:{attributes:{}}}},{"../../../tmp/submit.css":41,"../../templates/components/submit.tpl":30}],19:[function(g,n,I){"use strict";n.exports={name:"text",template:g("../../templates/components/text.tpl"),manipulator:"html"}},{"../../templates/components/text.tpl":31}],20:[function(g,n,I){"use strict";n.exports={name:"toggle",template:g("../../templates/components/toggle.tpl"),style:g("../../../tmp/toggle.css"),manipulator:"checked",defaults:{label:"",description:"",attributes:{}}}},{"../../../tmp/toggle.css":42,"../../templates/components/toggle.tpl":32}],21:[function(g,n,I){n.exports='<div class="component component-button">\n  <button\n    type="button"\n    data-manipulator-target\n    class="{{primary ? \'primary\' : \'\'}}"\n    {{each key: attributes}}{{key}}="{{this}}"{{/each}}\n  ></button>\n  {{if description}}\n    <div class="description">{{{description}}}</div>\n  {{/if}}\n</div>\n'},{}],22:[function(g,n,I){n.exports='<div class="component component-checkbox">\n  <span class="label">{{{label}}}</span>\n  <div class="checkbox-group">\n    {{each options}}\n      <label class="tap-highlight">\n        <span class="label">{{{this}}}</span>\n        <input type="checkbox" value="1" name="clay-{{clayId}}" />\n        <i></i>\n      </label>\n    {{/each}}\n  </div>\n  {{if description}}\n    <div class="description">{{{description}}}</div>\n  {{/if}}\n</div>\n'},{}],23:[function(g,n,I){n.exports='<div class="component component-color">\n  <label class="tap-highlight">\n    <input\n      data-manipulator-target\n      type="hidden"\n    />\n    <span class="label">{{{label}}}</span>\n    <span class="value"></span>\n  </label>\n  {{if description}}\n    <div class="description">{{{description}}}</div>\n  {{/if}}\n  <div class="picker-wrap">\n    <div class="picker">\n      <div class="color-box-wrap">\n        <div class="color-box-container"></div>\n      </div>\n    </div>\n  </div>\n</div>\n'},{}],24:[function(g,n,I){n.exports='<footer data-manipulator-target class="component component-footer"></footer>\n'},{}],25:[function(g,n,I){n.exports='<div class="component component-heading">\n  <h{{size}} data-manipulator-target></h{{size}}>\n</div>\n'},{}],26:[function(g,n,I){n.exports='<div class="component component-input">\n  <label class="tap-highlight">\n    <span class="label">{{{label}}}</span>\n    <span class="input">\n      <input\n      data-manipulator-target\n        {{each key: attributes}}{{key}}="{{this}}"{{/each}}\n    />\n    </span>\n  </label>\n\n  {{if description}}\n    <div class="description">{{{description}}}</div>\n  {{/if}}\n</div>\n'},{}],27:[function(g,n,I){n.exports='<div class="component component-radio">\n  <span class="label">{{{label}}}</span>\n  <div class="radio-group">\n    {{each options}}\n      <label class="tap-highlight">\n        <span class="label">{{{this.label}}}</span>\n        <input\n          type="radio"\n          value="{{this.value}}"\n          name="clay-{{clayId}}"\n          {{each key: attributes}}{{key}}="{{this}}"{{/each}}\n        />\n        <i></i>\n      </label>\n    {{/each}}\n  </div>\n  {{if description}}\n    <div class="description">{{{description}}}</div>\n  {{/if}}\n</div>\n'},{}],28:[function(g,n,I){n.exports='<div class="component component-select">\n  <label class="tap-highlight">\n    <span class="label">{{{label}}}</span>\n    <span class="value"></span>\n    <select data-manipulator-target {{each key: attributes}}{{key}}="{{this}}"{{/each}}>\n      {{each options}}\n        {{if Array.isArray(this.value)}}\n          <optgroup label="{{this.label}}">\n            {{each this.value}}\n              <option value="{{this.value}}" class="item-select-option">{{this.label}}</option>\n            {{/each}}\n          </optgroup>\n        {{else}}\n          <option value="{{this.value}}" class="item-select-option">{{this.label}}</option>\n        {{/if}}\n      {{/each}}\n    </select>\n  </label>\n  {{if description}}\n    <div class="description">{{{description}}}</div>\n  {{/if}}\n</div>\n'},{}],29:[function(g,n,I){n.exports='<div class="component component-slider">\n  <label class="tap-highlight">\n    <span class="label-container">\n      <span class="label">{{{label}}}</span>\n      <span class="value-wrap">\n        <span class="value-pad"></span>\n        <input type="text" class="value" />\n      </span>\n    </span>\n    <span class="input">\n      <input\n        data-manipulator-target\n        class="slider"\n        type="range"\n        min="{{min}}"\n        max="{{max}}"\n        step="{{step}}"\n        {{each key: attributes}}{{key}}="{{this}}"{{/each}}\n      />\n    </span>\n</label>\n  {{if description}}\n    <div class="description">{{{description}}}</div>\n  {{/if}}\n</div>\n'},{}],30:[function(g,n,I){n.exports='<div class="component component-submit">\n  <button\n    data-manipulator-target\n    type="submit"\n    {{each key: attributes}}{{key}}="{{this}}"{{/each}}\n  ></button>\n</div>\n'},{}],31:[function(g,n,I){n.exports='<div class="component component-text">\n  <p data-manipulator-target></p>\n</div>\n'},{}],32:[function(g,n,I){n.exports='<div class="component component-toggle">\n  <label class="tap-highlight">\n    <span class="label">{{{label}}}</span>\n    <span class="input">\n      <input\n        data-manipulator-target\n        type="checkbox"\n        {{each key: attributes}}{{key}}="{{this}}"{{/each}}\n      />\n      <span class="graphic">\n        <span class="slide"></span>\n        <span class="marker"></span>\n      </span>\n    </span>\n  </label>\n  {{if description}}\n    <div class="description">{{{description}}}</div>\n  {{/if}}\n</div>\n'},{}],33:[function(g,n,I){n.exports=".component-button {\n  text-align: center;\n}\n.section .component-button {\n  padding-bottom: 0;\n}\n.component-button .description {\n  padding-left: 0;\n  padding-right: 0;\n}\n/*# sourceMappingURL=button.css.map */\n"},{}],34:[function(g,n,I){n.exports='.component-checkbox {\n  display: block;\n}\n.section .component-checkbox {\n  padding-right: 0.375rem;\n}\n.component-checkbox > .label {\n  display: block;\n  padding-bottom: 0.35rem;\n}\n.component-checkbox .checkbox-group {\n  padding-bottom: 0.35rem;\n}\n.component-checkbox .checkbox-group label {\n  padding: 0.35rem 0.375rem;\n}\n.component-checkbox .checkbox-group .label {\n  font-size: 0.9em;\n}\n.component-checkbox .checkbox-group input {\n  opacity: 0;\n  position: absolute;\n}\n.component-checkbox .checkbox-group i {\n  display: block;\n  position: relative;\n  border-radius: 0.25rem;\n  width: 1.4rem;\n  height: 1.4rem;\n  border: 0.1176470588rem solid #767676;\n  -webkit-flex-shrink: 0;\n  flex-shrink: 0;\n}\n.component-checkbox .checkbox-group input:checked + i {\n  border-color: #ff4700;\n  background: #ff4700;\n}\n.component-checkbox .checkbox-group input:checked + i:after {\n  content: "";\n  box-sizing: border-box;\n  -webkit-transform: rotate(45deg);\n  transform: rotate(45deg);\n  position: absolute;\n  left: 0.35rem;\n  top: -0.05rem;\n  display: block;\n  width: 0.5rem;\n  height: 1rem;\n  border: 0 solid #ffffff;\n  border-right-width: 0.1176470588rem;\n  border-bottom-width: 0.1176470588rem;\n}\n.component-checkbox .description {\n  padding-left: 0;\n  padding-right: 0;\n}\n/*# sourceMappingURL=checkboxgroup.css.map */\n'},{}],35:[function(g,n,I){n.exports=".section .component-color {\n  padding: 0;\n}\n.component-color .value {\n  width: 2.2652rem;\n  height: 1.4rem;\n  border-radius: 0.7rem;\n  box-shadow: 0 0.1rem 0.1rem #2f2f2f;\n  display: block;\n  background: #000;\n}\n.component-color .picker-wrap {\n  left: 0;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  position: fixed;\n  padding: 0.7rem 0.375rem;\n  background: rgba(0, 0, 0, 0.65);\n  opacity: 0;\n  -webkit-transition: opacity 100ms ease-in 175ms;\n  transition: opacity 100ms ease-in 175ms;\n  pointer-events: none;\n  z-index: 100;\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n  -webkit-flex-direction: column;\n  flex-direction: column;\n  -webkit-box-pack: center;\n  -webkit-justify-content: center;\n  justify-content: center;\n  -webkit-box-align: center;\n  -webkit-align-items: center;\n  align-items: center;\n}\n.component-color .picker-wrap .picker {\n  padding: 0.7rem 0.75rem;\n  background: #484848;\n  box-shadow: 0 0.1764705882rem 0.8823529412rem rgba(0, 0, 0, 0.4);\n  border-radius: 0.25rem;\n  width: 100%;\n  max-width: 26rem;\n  overflow: auto;\n}\n.component-color .picker-wrap.show {\n  -webkit-transition-delay: 0ms;\n  transition-delay: 0ms;\n  pointer-events: auto;\n  opacity: 1;\n}\n.component-color .color-box-wrap {\n  box-sizing: border-box;\n  position: relative;\n  height: 0;\n  width: 100%;\n  padding: 0 0 100% 0;\n}\n.component-color .color-box-wrap .color-box-container {\n  position: absolute;\n  height: 99.97%;\n  width: 100%;\n  left: 0;\n  top: 0;\n}\n.component-color .color-box-wrap .color-box-container .color-box {\n  float: left;\n  cursor: pointer;\n  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\n}\n.component-color .color-box-wrap .color-box-container .color-box.rounded-tl {\n  border-top-left-radius: 0.25rem;\n}\n.component-color .color-box-wrap .color-box-container .color-box.rounded-tr {\n  border-top-right-radius: 0.25rem;\n}\n.component-color .color-box-wrap .color-box-container .color-box.rounded-bl {\n  border-bottom-left-radius: 0.25rem;\n}\n.component-color .color-box-wrap .color-box-container .color-box.rounded-br {\n  border-bottom-right-radius: 0.25rem;\n}\n.component-color .color-box-wrap .color-box-container .color-box.selected {\n  -webkit-transform: scale(1.1);\n  transform: scale(1.1);\n  border-radius: 0.25rem;\n  box-shadow: #111 0 0 0.24rem;\n  position: relative;\n  z-index: 100;\n}\n/*# sourceMappingURL=color.css.map */\n"},{}],36:[function(g,n,I){n.exports="<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"><style>@font-face{font-family:PFDinDisplayProRegularWebfont;src:url(data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAHOMABMAAAAA4WQAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAABqAAAABwAAAAcYTSeMUdERUYAAAHEAAAASwAAAGIH+QacR1BPUwAAAhAAAAXpAAAZnAabIkZHU1VCAAAH/AAAA5sAAA4oG8KgXk9TLzIAAAuYAAAAVwAAAGBvPnpuY21hcAAAC/AAAAINAAACijkkBJVjdnQgAAAOAAAAAGoAAABqGQYScmZwZ20AAA5sAAABsQAAAmVTtC+nZ2FzcAAAECAAAAAIAAAACAAAABBnbHlmAAAQKAAAWdoAAKNM+v+8zWhlYWQAAGoEAAAAMwAAADYMWobcaGhlYQAAajgAAAAgAAAAJA+GBpFobXR4AABqWAAAAoEAAAPs8ndWbmxvY2EAAGzcAAAB8AAAAfidAMfSbWF4cAAAbswAAAAgAAAAIAIaAd1uYW1lAABu7AAAAccAAAQgR9GTZ3Bvc3QAAHC0AAACBAAAAvKwKZv9cHJlcAAAcrgAAADKAAABVHLPfG13ZWJmAABzhAAAAAYAAAAG7HNWlgAAAAEAAAAAzD2izwAAAADCOl5wAAAAANK8nPF42h3M3Q1AUBAG0bkbCRJRoGLQCPrwUw5awJNhJ19ynpYE1K7hu6AikbvCgpJWdxb0DHq0YGLWC6ve2PVhwcmlbx6d/f94AQrxDpYAeNrNmdtPVFcUxr9zmARExgGHNtoqtBa1WsVGbb1h0zSKIyUNDGBvxKRptY0a02MaI/e+8GB684VEj4jcvITLCU2aRtvwxB+xjbRjbHycB59M2gdPv71hqmxWC8iQdL78xnPmzKxZ315777MY4QDIx1uoRs6nTWdOofjzM8dOouTUJ1+dxquI8CrCkE+zj/QnnZPHzpxGnj4yRODy3xwUuLcKtsBxT5h3lyKB9/ABjuKUU+7sdP5wHlKP3QL3BbeMKue1f+QWOOVuAT+RcHe7R93P3KOMuy8MGPlE6OEscZDP8xxUhApdZJy8jtjjRygiZaGPreEOHAgnUBmmcYgkSBWpJjWkliRJHaknDeQIozTxs82khbSSNtJOOshFxrtEfHKZdJMrpIdc5ed7SR/pJwNkkFwj13EcN7AfN3k8RIbJCBklARkjD5i3dpXAa/Rxnz7u00eAPby2l1SQKT+KfhT9KPpR9KCYv5rOPWDuAXMPmHvA3APmHjD3gKOUniN/xfwV81fMXzF/xXwV81XMVzFfxXwV81XMV4+4zvk+azCIYjpsMQ4zZ0meHedZISMrcodkru3ntSRrOckIKaKPFI+UOfJ45GEZvXs4F5bSk0dPHj159OTRk0dPHj3pWVDLqjjmfQ7nWCHjl2E9NmEbdmAX9mAv9qECtXgfH+McmtDMPFvRhnZ04TbGoXAHdzGJ35GCs6zGzNVCbMYXOBvZHXkntzc3yL2V+ygvkrcyb01eJfVlno+YmXc2XQLjAnpUAo5KwFEJ8NDMWpsiAT2rbfQst9GzxEavAptDAgmBKoFqgRqBWoGkQJ1AvUCDwJHp2f80ehXbNAu0CLQKtAm0C3QI6FVnc0nAF7gs0C1wRaBHQO9SNr0CfQL9AgMCgwLXBPSuaHPD7A4z0bumzZDAsMCIwKhAIDAmoHdpG71rBdy1uKbNzm1TJKB3dhu909vsFagQkNe8msUhgYRAlUBSoF5AXo/BLJoFWgRaBdoE2gU6BPSd0Ob/tUbVLHoF+gT6BQYEbgoMCQwLjAiMCgQCYwK6k7DRnYXNzG7vSdcQM12GjRK4I6Dvxj6v+jzzrY5Ff8cEv2OC/bHuVmxSAvkmL5uUQL7pdmxSAltNN2Sjux4b3S3ZNAu0CLQKtAm0C3QIOOyk1mMDu7FydmNv4E32YvtRyb8DMv3YXbgF3brnyv9l+QW8go38q6IznAh9SiGrj1BlNyLnRLYiBdP5BYuKkp4iy6OWzoxdtmOzys9YjzAR7ghLOdeffs0zWXYuugq+jhF6i6vFk5hmLjfq2cxjT0en9KudPA6ozgVH9LNZiYzPsFG86jHPRr0i5xnNn0fV0/Oru/luM0dY7QlKj5qaymTh1TER0ovbP2acNU7HLNU1nK6p/2yzxswElf2aPvPnfSz5g13zXLu1z3UezC+Xx4NzVt8L8zmP9IzysnlPyVIcL6v112ssnd05sTS+l/a++nSmmXm00MyzNW5mh/DNWvfNPhbM9f7FjYW500zMb/Vw9nlLu9ozPuS7zL8+Ni3NnPivEV/Aw2W/WkitZde6kT3sNioX26kIdlIR7KKWmd8go6igYjhArcRBapX+dRurcZh6Ee9Sa1DDvngNkqjj1QbqJRyhXsaH+Ajr0Eitw3kqgm9wgc9dVAwXcYUxe6jV6MUAn4cQMMIYtQo/U6twm8rFOBUzv3iuxSRVgt+oUqSoEtyjSulqC9+jpb0tRxEV4/tLeFZGFbGf30A/m6mocRs1bqPGrWPcusZtzrTbSvqMG58bUEXFUU0VG7fFdJvkK3VUMeqpuHFebJw/Z/434Hnjf4XxvwJN6GAOX1NRMwpRMwo5HIUeftdV+o9jEDcY4SYVN2MRN2MRx4/4idF+paJmLHLMWCw3YxExoxDBAyqGP/EXs3XwtnG9kZXdTo9TvydX0NVBejrMmmkPul4NzFZn2TjjF+bzzPBbfIfv8QMz7WKOl+DjMrpZsR7Wqg/9zHcIwxjBKPMcY60yv0lPsjIp3PsbqN24mAAAAHja7VdNSFRRFD73/b83/jvaIIMMIjo4IpOks4mQGHLCMBN/1oOmZjrGYEO5KTcuwkVEhESIhEiLWYS0CBKJcBVtkoFatAiJVi0lKgI777zLzBvnvWGkCIMY5jvXc8/57pzzzv14AgMAA1LsHIhjN5Mz4J1MXr4K7TPx+QREQcJdODgAFRiuVYwsg0qosvkFkEFDfzn5DWBDg30BCNCuhkEiKKCjv4L2TS8DD1TH4zPzMDWemJuFBOE84cL4tcQk3CZcIlyeSMbH4B7hCuHqzJXJOKwTphPXZ5OwSficcHsuOZ6AnblkYhZe4/lmfSZWEFYSlhNqhDqhSigSSoQColmbQn9Z6CEsIzQIGWEV1EALdEAansEW7MAbyMAH+ARfYB9+MomVMS/zs2YrminEdpoZrJ31sxvsMcsIknBGSAlpYVf4KvrFHnFCvCM+FTOSJHVK09KalJH25Qa5R56Ql+VN+b38TWlUokpK2VA+qj61X51XV9RtdU/TtHZtUEtpG1pGL9PP6in9gb6l7xma0WEMGQvGQ+OlVZ8xxe0St+vcvuJ2l9s9y3r83I5YVXjucnuf2xVuH3G7xu06t0+4TVM331HvarDjDHy0sp5UNfmj2HkGteCn+XGKGMyLEKABJ46B9xCLidUlRA46RvrxmTKox2+7LXaU5sQLdbRjMpnYhz4RMwLQRjl29j4+JflZ5gmN0EzVCTg7p2wZazxGIPTzSRsgjNFJjdAEQd6ZTlvmAD+rMNvMkyivherx5f3GGM8rzDX738DrDNgyRmzVj/LONhZ0dtTG6cZ0ibCOsNeVqTfLVOfKNExYXzJTvStTzFbdsCvTsEt1bXkdEPBTix+AE9hRlp0XZ05rWg7nmOx++sUCPr3OvFnJxdZl+XOzItBUWl0JF0yKU24sO8vNBbOcm5PDmSI/w35PweEem/1pcoxg/N75iM+bx/PvcP29HrgpVMRRoUJFFCp0ZIVadNSYMGGwqEKFXRUqWFShgkdWqG5b9RHX+xYpQaFO2hSq1ZWptQSF6rIpVClM7goVtFXX5crUVYJCRRwVKuTKGTqiQi06qkxuVtwUKuyqUMEiChX8r1DHRKGsedXQo+Ab8me82zX0PDTMN1eMIv9sVA1Fme/w3zH2AvnP5/l/oP9i1t+NngqspYkUR4JbuBuk1YvsahVXMVptZVfNOOFRem88Dgy59+nfXb+ldQueYeB3GlL0nxCe8gt+7MUlAHjaY2Bm4WWcwMDKwMI6i9WYgYFRHkIzX2RIY2JgYGBiYGVjBlEsCxiY9gcwPPjNAAUFRckZDA4MCr+Z2Bj+Afns15jqgfrng+RYtFlPASkFBlYAicsOigB42mNgYGBmgGAZBkYgycDYAuQxgvksjBlAOozBgYGVQYyhjmExw1KGjQxbGHYw7Ga4xvCf0ZDRgTGYsYJxEtNxprvMK5kPKHApiCpIKcgpKCuoKRgoWCm4KMQrrFFUUmJS4lcSVJJSklPSVvJQSlBKVT2l+uc30///QPMVGBYAzV0ONHcbwy6G/Qw3gObaMwaBzT3GdANsLoOCgIKEgoyCAtBcfQVLnOamgM1l/P///+P/h/4f/H/g/77/e//v+b/z/47/7f+r/mf+d/2v8/fn35d/5f5yPDj54MiDQw8OPjjwYN+DbQ/WPVj6oPuB/f1T917fu3/v3r1r9y7fO35v9b0p9ybe1r31h/UHJHxoARjZGOCGMzIBCSZ0BcAoYmFlY+fg5OLm4eXjFxAUEhYRFROXkJSSlpGVk1dQVFJWUVVT19DU0tbR1dM3MDQyNjE1M7ewtLK2sbWzd3B0cnZxdXP38PTy9vH18w8IDAoOCQ0Lj4iMio6JjYtPSGSorWto6uqfMnPGrDmz585fuGDR4qVLli1fuXrVmnVrN23cvOVBQUpq+qPi6XmZb4oyvtRP+Fj49Vsaw9v37058yio7Pm9DRXLOh32fGbLLnyRV1vTt3nP9xt17t26v/75978vXz1/8/PWw5M79Z9XNVS2Nbe0drT29DN2TJk/csf9o/sFDh0uPHTkAAIlf1lMAAAAAAAQpBcoAtQCXAJ8ApACoAKwAsADDANgA5wC5AIgAnwCkALIAuQC9AMUAyQDXAOYAlACEALcAzwCuAMEAvwBeALsAPgA4ADsAGwCGAJsAgQCmAFUAWwCPAIsALwAiACsALQDbAN0ARAURAAB42l1Ru05bQRDdDQ8DgcTYIDnaFLOZkMZ7oQUJxNWNYmQ7heUIaTdykYtxAR9AgUQN2q8ZoKGkSJsGIRdIfEI+IRIza4iiNDs7s3POmTNLypGqd+lrz1PnJJDC3QbNNv1OSLWzAPek6+uNjLSDB1psZvTKdfv+Cwab0ZQ7agDlPW8pDxlNO4FatKf+0fwKhvv8H/M7GLQ00/TUOgnpIQTmm3FLg+8ZzbrLD/qC1eFiMDCkmKbiLj+mUv63NOdqy7C1kdG8gzMR+ck0QFNrbQSa/tQh1fNxFEuQy6axNpiYsv4kE8GFyXRVU7XM+NrBXbKz6GCDKs2BB9jDVnkMHg4PJhTStyTKLA0R9mKrxAgRkxwKOeXcyf6kQPlIEsa8SUo744a1BsaR18CgNk+z/zybTW1vHcL4WRzBd78ZSzr4yIbaGBFiO2IpgAlEQkZV+YYaz70sBuRS+89AlIDl8Y9/nQi07thEPJe1dQ4xVgh6ftvc8suKu1a5zotCd2+qaqjSKc37Xs6+xwOeHgvDQWPBm8/7/kqB+jwsrjRoDgRDejd6/6K16oirvBc+sifTv7FaAAAAAAEAAf//AA942sy9C2BT5dk4ft5zcm/S5CRN02vaNG1DSNM0SdM0bZreW0pbKKWWrpRLrbUg9wIiIlamiIIiQ8YUBwoq43OK56RVhn5uqEMR567fcM65OT+//ew3N3Xb5z6Fht/zvufk0gvCvsvv/1eanJxczvtc3uf+PIeiqQaKom+QXkcxlJwq5hHlCoblEu+fPLxM+ptgmKHhkOIZfFqKT4flstJLwTDC572shS2wsJYGOjeSjx6KrJBe9+V3GyRvUfCT1I7Ln6MR6a+oJEpLNVJhJUU5eEY9HlbTlANxOhdHXeBlpnH8N6qVUQoHn6wd5zWGcZ5F+JjV80omEKB4NcPqueRAidtfWub1pBpTZNa8QoOXse4IVYUaG0PB6pwf6I5ucba1OctaW6QPX/w+uf5WSRNtgOtjuIIULJhycFLvGKWmkiQOTuIhZ8SXiFOQ9TDacY7R8RJYgBwWo0QOqsRtYL3k/60Hhg9ImtD+yFr8R65RRlESn/QClUnloAVUOANgDBtT071eb1gOvx5WJKnheIxCGXKNY5Rms7LzTV6ekoyPppjSMvNNnjGphLzF6Mw5+C0pvCVTqjTwFuJyXVzGBT4d1pSu4+WwJoV2PCxXqByjNXKJ0sEpdHwqnDXCWWMqPms0wFmjjk+Cs2pYvwU5uLKMF6oH/m6jjA7VC9VDf2/BB1yGbpTOkBvguuRRhh/hIqPKdAUcpOpGValJBvxToxqjGj6gI48seUzBj/gzJvIZ+FYa+Rb8Zmb0d7Kiv5ONPzNqjn4yB59nanQ0g4HUsRgLWdnmnOIp/3E1GRjxPq/BCn9ehvwZreTPasB/fnir7JeOH75deyD4l5qDoTfes59/r/pwzZ9Dj9Y/80nRX9D5Pah0N3o1UoX/dkd+tCdShs7jPzgPtENU+WUnE5HdRpVTH1HhVMwd6V4+Vz4eTs3FuEw1KYEtAi6OvcAXaMa5Ah3vA3SmevjS5HEuzcOVCjRxacb5CgHPf9r8yg8wepO5ZB2nOsPPUn7BFZ2BF6NJySpAgwY/crN0o/ZZRfDSgR/DcJy7O3e3VZbM6gOcIxCGT+GjpAB1SpWkSZ5ldxRF0YKmnQFEIb6AhQ2CAnypj9WPqiW5s/NNAd4lhw2UlY03UGouvJ8FG6gamZHXU+YrLaZtxYyvNET7fV65GZnkxcial0wbU8y0yczADpMDpn3FqHxFz+tD+75RtXTY1/Gtm5sDK+7r3CFd/s+Luzqf6fUOtBRX9t7k7Pr29rYPvy/dsfkXJ++rmzcy3NJTmpWkK19+72DXvlWNyjAn9ZU/6i7Lre4LBed5c1RGb+/+Tafe1v7sZ4ouipJSQ5fflc2XTlBGykG5QFIspm6mwrVYWrRKxsMyIAxfKBkfYzNrZRoHz8JhWTc5LJOMI66P7NtU2COpOj5X4HtOreNL4LAJDpt0fAccBmE3LIHn3FRAESsrcmEUdTTBC2dZbTG8IPscEOL1mGkjm5JMW/OKaT/gw+sJ0T4WMEYQZEBeJbqGzw25u9aGghu63PBcXbO+03U4y1lqSvc5c3KcvvQ0rzOrhdm/79IaWudZOOWD2U5v/IMeZzZTjQ5V9NVYrTV9FZEbK5bW5OXVLGnN95g1GrMnH20qcFvUaou74GKaLO+L3yIj+nbs0zcEllzp07AFQDIOXt4ru132KmB9ETVIPUuFTSLeuX4Xb4OnChcWSYi7kaC5GhBareOz4rjNg8Me3TjXo+OXwmERHBaRjcKrAOND8FxNAfPVB/imLHiuC/A9efCcE+CWss+bbNKK1oWYFFyRnpsX4HxsOEXjCQQCnErPscC5rSb4sC7A9bM1GkqjysorSvFVe+oXLobvAMFKQyjf65Gk6o0ptMjGtmSEKeIrLfMXI1+UUMDQ8HaZ3helT0oq/jAidINPMrZkxgDnQvCVQvyBwRUvI8NTP0AFrw4+tqP9aG9L/4/bl/1tc/9TIy0/PBQotbcPz23c2FVyaHvbqcE1d3ccGT+4+7eHFzpcOyrKUI+zY2Ww9/tLylb39+RVDLU5v3QXdW/oC9lKc7US545PT63d8bvI2yfejHx3ZO66gl2O+1rnXle26rGVD/1rT+cdjXVbutzwA1Xbv9O65m8b1yDzd+75/HtrF9x/aqjlQEtr96mJH81Z1VRQFarYseM2v6VxwRL6dOlgdcmNnaGFZnc5yLWfgY4aJHrPSk3WcZKojiN/0phy+5mo1igiF9dEInSfLA/2o4FCXCr5TlLKOG8SPl+qDyG/KZkhskJezKypXbt3/kDT6g5H8fy1NYvn71tfT+/bTV0eP98d7Hnr3fdXbf7o3fPdjd0/+Sgi/L4Dfj8j8felF3hd7PdNIYaIJz8WQ8m03FGztsPpaN9Q1z9/37qa+vX7O17qPv/uR5tXvf/uWz3B7vPjl3fvinz0k27ht4NMD/1z6QdUKkiSsATDnqym5KDudaBOTRiUMaUJn+DT4Gq8BGQurzUEMC/5TYyXwaDJTclIbsOsBBwUtH+Sut9YsS1g/9t3cipydt5jDuacqNwmOb1nEDGRiXRv+t7QK2lFae9/kOY0/VBrhTWEqIPMXyXdYPd0Uhzl4uReHsFOknrCFMKKhVIpHWFE4UPEYB2jdnGqCxzt4ZWgWMAuUarwe0o5fEylxIcqSungNQL6fRYgmMVoYa1sCB3cgw5EVu+hS+9FD0eG7o1cj44IeNgW+QAdpj4GDBdRnME1plRTCswBKS5OdmEs2URpAQVGbGbJWH2YZgAFAYJ8RHZNmbBpAP3b3EGJ09cYtPutWluo0/FmQU+ttMld0p7jDWUF1/TOMZDrrUOf0O/S+4Dn8jDMPJKO4z/McjyFHGOMgHRpFAbjOno1+uToUfzdYbAT11OfAr7sCVZi9ICgJ24pimhItASHQ8FQU2N1MBS1ACl0OXL5OP2kzATraadifJ9MbDsEUNPJhP2xzg7+8mMz1tkSjirm6GKO0vFM+hccDR9M/4IepRDNRPUsXFeOvIims/ZM/FuvbMMXDxAbsPvy58x7sN+w/qqgwixeeKYiqrmUAEGRoKMMcR0FNoNT1EY8Kwtcq/bp7thxtLPzsR0dHTse6+w6OtLxknveEoejb57XO6/P4Vgyz42G6Q979w16vYP7eieyFt/f7/X23797zrLq9PTq5c303c0DofT00A1NgHew0umw9Dwlowpgr2DLFRHLXO7iJIAtWKIClshIiG2BF4i8wHTyt1D5M6fPS15HzJdlkj8cF/itF5TJO4ADOxyFKYwBm2w8bMIY0GEMzHZx6AJvSxnnbIJ1mgXImOXhHXBoQ4AEQwoI/SR2VKYzWbA25nU2YEyZIQsrAxPLpcAW9RKDRZAP1jyZ3BZCMT5NZrKRxdgbXLGzJXTzsoCnc7C095HA9XPP39b7zM7Ojs33VNpXLq+nT59cfGjnRrett3+orKKrLD3k3hPqdvQdWNl58K7Vtqz2petryo8DPGmXP2MeB7veg+EpwfBIlONhM4bHpBgfUyeVmMEAUcsANC/s8AucHmABkKxgHRLBUgJYozBEPHIABGo9V4jh4DOs8Mqs5zITrbFCB/IRQk8FDLQWkYLA5WkDoZMd9x7fufrE0/au+lmu+Td4O54M3Nj4wa6Ob4/Mu2modH5Z1vy7Tvbv+u3O/f6aXbduO3jcHFpWW7Gg1Njg2RvstS16cOWa7xUa25at8q7/pw3lXxNsYKDbF8ADOtD+YS3mASI0KZlWonFwKnBV5GBNecIyIq5kCiyuWBenvcDJPXwyAKz0hJO1+L1kNYgrbTI+1GJxpRd9OE4KxJRRhIlg3/oykMGLsAwDAxNMzPJb//PW1yNmNPbSyMhLHz6KtDSww8VX0IuRxhMffkjWOAj768ewRhs1TIULiFiA3WXAtEhVjo9lqAsMQIsMFdBilovTX+BNBmA9PV6JyQj+kElHGDkXGNoOzyY93nMIyKBgw+qMAiz5eKZAoJeaDQM3Yp7L0HMmQqNUP1CmCglmgdxGZK9An2wkkGZw9a7Hc5b21q3pzrtuUWvaScY98cCCx6u77u7zto6cWLLn3H0HtiODb1nrD1YPZViLU5rod5+NLC4vLxvc0/Vp774hXw+RI0sBzl/CHiqg/NQQFbZgSB1ROaIBSFNLLdjsTWUA0nIiUgqBAnoPVyiYu7Cn+AA8lxSCWauRpeKNxGWxvEpJnIBSANEQ4DQspwpwMj2nDMSETmrUAchGk0CLyyABATL50rm3Hu+974dNq+q+0WXvm192I1fTeWefZ+6tR3uWPbal4fuulp6iWUtaPOsWtD3Ug26hf9W3f9DXEzoYDKUHr2/6W52/fPC+hXzfg0M+78C+nY3LqzIzq5c1jKxbUVOJad0P/PgLoLWCaqbC0qhM4uWABjlRnnIKs6CSQK9gx8MKwpgK0KO8CjvIlMhxCLwfjiEQWozICrKhnxme+OBNOjVikNSg3ce//I00+z1iA9dd/ivzMex1K+WFq+6mwjlEfsF+1+Br1wPmA64cDWA+oADMzyHXzgdRlq/jSnMvsLwCvEOFiy/V4FP8bFhGBrwbwm/pgela4ERpPlkXF2JHNTk2YvHO1nNGWKgL5ByfQQHHBVjeKIXnej2vVwQE85aeasSK4gATJlX05DDdDFFVIb6us1bOK168tHX7I50LDm9v7e0pn+8xLdj51KKlT420vf7A17d/w9Ey4C8faHEaHM29Hldfk8Pe1Ocu6Wt2oIPlq5fMSbFya4aOrPR5Vx1ZOXTSntbSe6Nr3RMrS0uHDq/fcseOW/192LFYSi/zL662WGoX+yt6q8zmql7g4zbg45eBj62UD/Mx0YdpSpGPSwCbFhuL+diC+bhMwKaAumxQybM9vBr42A9Iywdi8ilGQEk2O8qmyQTFkIad3ZQAZ2EBf5xNz5kxqnyTlWch2I9I4FvsDxQK2PLHzP+2OduO9XQf2dbSsu3Jxfe/0ry6bl+nva+jbOVTtU++9ML6ztaHu4vn9Dgci1s9zJPHlxwg7No3Udi3f0Dk5qr+pi9DgddfHx6sL/tl47JgZmbw+jqyj+8De2Y3cxvYMybKGbdoOKOL12J7Jg2DDEIVmzNYb2CrJn2aVcMmHN9XXRlqagpVVkefo5YO/aqzvd1Z1jYXX3cYbL4DcF0DlQPWL5ft4k34crnY5ONSPKLVx2V4cFjoqoYfk2hhecAILGuospdbk22hBUWF0XVMtwYlubEV4f08QO1ifixZBzYGZfAhoxIZB5hVE/X0S3TFDjT2UOTxyPGH8dpDaID5K/MAidVlCBYkmMwS0fmEzaWMWY4I/kLMc5damefQwL596PADD0y7lt+nRHC5AfqliXpm1a6HUS9a8lCkbQehTwj4cy34CNlgrVxPhW2YPhawOBnMnxmMYK1oL/DJmvHRTK05GRgRCJWsww4Kr0gdJ0YLVm1jTEqGxYYDCQrspiYBc2ZYAKuK5GysQRgWNAqsOW6lZCMr8KnEJ4hSQwKGQ0tfX9f9zfW1S4b7TtuDzUH7tv7Oh/w/x5ZtEzxIl84JVg7s6Vjy2KEH5vYvbr35+u7rllT0bvO7LnJRo5fANnD5d7IfyAzUfGop9WMqnAfeFm8HTLa6xhokVDaQ3wiwefmFkvGxEuFEr2ssWziqcI1JyRHilgnufjJx98FV4jvA3e/Q8T2wQ80e3gmvnKKbD6b0cvyBNNisBYUAdw/7vFGaZ69oaMVizqkP65vnYHz4WE4LKGpoBVzNCXBGlmsOcCV6Th/gexfCl51pwk6nVL5q/M08+L0iOGVnwXYijmdZ1NkXtjjZ2XjjVyIRpcRwSgUZkBoXhpJkZBTdfBP+Rn4hXSC87/dhWTBw70eo/OQplHP2pvrB7YH+bblNhzq37qteMuT4eMOiWatr5y/Y33T0VEO1rb26cNHxPz64P/LlqxtvHP3b/tBId8nQ44GTkV/9+ha6vz1kqautMP1LRrA0j/6Pp1H+L7du/UnkT4eGn1lXHvIU1Ny7pXlpVbp7SWNG6Zoa58GHIt8PeQs6t3Xu+PCp/hWjf7lv72fcQJr1LnvKlp+hvIyKKjY7V3NQluEmdM2iKMmfQS/KKQ14dMTC5hiv4N3LFBQCcSrDnJsMMgbbn0hBGBJsZnBYrIyFMViS4DmLlpyjZT/dNDG6cRT9ZMta5Srp+S/LUHtklEaoH30t8h3YgdvgWkfgWnrYIbNgVwn2vAEkONHFs5jxMXM2uaQZm/Z2wioG0HhmD2cQdokGa0es/+Tg12OFaML6TwXUzzbAgQZMYGKFzNJzcrxI1hIL0hDiFlhE1WbxWQghC62WbfSNg4fX+DsHV1/vW/nYUKQF7btrp7NteWlkE9rtXlxv/+amyC7p+Zo198/r+adA+UvLOx65dV747m3Bvtq8cFZ5V9mmAUFObL78mcRJ9FOlqOvTmKiVhXGYHwWIL8CoTMshwVOwm3hVZuCKlhMwXQKTFdObe/a/smrrz7sGKp5dGLp1aUVw2c0VXScblzX+5o5VP9zfjd6mzevDI3U1jYfc5bYFO5ZE3L13LrC5yh8qn1e3/TlM8+1Ah2NABw2VSZWIVEiOUiETrzSLrDQ5hUinFCydjONYiVIxlLIiNqNOpGU7XbTyhd1t83afvinyCCoPjtxQE7zh9trIOen5+u1j6ycurRq7vZGzdt6+FL3ad0cnjmfcCetYDutIwjYZWYUyugoJ8IJUYD8pE3PVlSlCGIOYZkowzTiVR4hniN67EMAQ/u5k3rs0Tj85sZgxSc8/F5k9GikMC3SKXldJ1QjXnfmaqpmvKV4wacoFY5fDFyt6bmJTnCc2E/91vehjJPLEWLa5AFss2aIrK/I7MHsmdixSxsOZJGWQmQ1XxNohE7g8rJFh34LLjRrg2SAhudwArzGTvcDJ2K9mJNbqs7DJDGGm3kNvbdj2s4UDgWe7Gu9YEarov63BfajjY/Ssc+PIXZWrXzvYewWGyqxCveGJ4942p5GwFYYV8PoioWe1KEnk3lh2jFERzDJxaiYBpLSHSyJeFOCYlxvHY3TECUAcFbCwm8/Sp86fn2iRnp8YoXd8WUYfmFgt4PZpeBiG6zGUJYGOsagM7DP8J4394tOvYaEkfNcCfjiOURhwPI9YkkD+sIp8P8XFKS/waviukbjcrODCqVjiaQrONeZ7r2gSWvra9tS1jfR6znbsOT00+K/9j7rstoU7r2devpSy8fmRRhw7xbLvQ7ieOrrjOEUMN4jTkBWrCUL4ZCJnsYnKqAIBYelenB2wKhG77ayW3vznSB6t+yiyMPKZ9PylCENPnLo0Qr8X+X5kkMC2F64F8peSRiU6z4j7CnGyKG7CDOFoRgqcJY8j3bj3NbxfvvxI3CsgK6QvEzy1iutWiuuWewmmRJaliYjGnpJSwBuvAlYFKwsYVcmCMBZBkiSJIIG3LsR9rKA/4B+7/SXkeFHzPLKdei1p1xff/PhYElD8icjNaDfd92UZ81nk9xEl+jGac0mL1zUCMH5MZNi8KfiUebG2wuvCykKjwwzAK2BRWqw/sBtHBzgpS1bCKbDMnWFpmPcQY2VHXqRNr+nO/mDii5/rANfvRd6SdMNiZKjx4nNEf66D/f381BhddIcXMvEYnTEeozP+12J06zr2vXnLlvP7F3QdOLfpljf3dbxRvnSkcc5ty8vhubl5pK8cfYgur3/hzjlz7jy9IYKGT+9obt5x+t7eHQtssG970c8W71hosy3csRjWjffqCOAvGXyJukQpaAKppNGSvUqUVlpMFWg9WBsYcAY7RXAseBOOwyQqWli7JR0RJQuadTN946rDK0orVx26IbIM3bLpwIFNkXuk5ztGDnfMPzzSMfEMo9p969a9GI/bIl+XYN+ukApSX6ME9PmZcexspOFwbxVZhhjnw26GngUfR8e7RYSG8ClsI8uK/Fg4ulk+g6Qo/SAcw2we2HuBqWiWg/mGTGCx+Y1gKtsKq1AxMx3t2zoeOL91yxv7Oxu2PzVgdNlSMlIzXfa7mvtuOLGl5vXy5bc3Nt/WX16+7PbmObcvmUKCoadHOlT28uYCKUMflgXb7xlUd4z808gMFCE4AJocBJqw4KlcJ3K1RuBq7D6M6fSELDpMlkyCDzaFhGlYIV2PyYIzaKkgsPhkNYZerwMCqQNcBjuFTHJsvMUpBTbQuqNDrrzG/hAy/ubLyB1o6+YHDxC7B1MrdOuqr2VM3EMvjJOM5Ln/Klkp/QPlRflU2B2VoTjhzWfjNZaSFHcerDFPyGgXAaF8QnT8L++8vFTIaKtJRrtA8wVnP/PCn1545alooptXqxTkrQzy1mcnXj4KbyXBF0aT1CqDg7wfTYG/8Mm5V0z4bTEXXqAbLSywGxyjNvI4Cz+G4UxCRtwGZmI0KU7VqNQ2nAIvKJxlj1cLoJlPk9x4npAb5+TsqCQ12y3kGvn0DKKRJeDEUYjNKMKnU1kufcYceaJyjibI8e7PL18/8N6mg8/UrxwJ9jyxvb1+O7dux+fr+pb9qL9iqN1ZM7DJu4Tb3dV63ys3Pxz521N7G9t3bGrpK89Rs/6l9w31HVlX62o6UV5iDi0Phdo95iRj2bKDNw8cWVOxiNDNCnxWQ2x+kFiy2M6nYLsxHlKwIrvAS43jYakMqwgpGD1hmZTEaXEANu4x41yRVZIdWfSG1HDq1Jd/koo5GyITz1PplJ8KGzFfKBhB/3DJIJwzBBVkJEkT0Pe8DtgC2zsaXI5jDIi5w9hG9EZF4joi8OruWF5xrufga+vXvfHNbvQvzOeXXNH9xPzskmp4bHtNDTZIEMhkSnKC2HmbhGhJmMJwIpnXG7XuUOo4h3S8DO8ecMCTBOZ85bOPf06qWSgdpzyTDJ/gmDPgyTDAQ/AY5yGKx0kcFKYZZZQtZAiAUBAgvJkI/0NW4zu/3qc5+ItfR/LeBp02N2JGF+nD2BIha5QXwhqNqE3ElTbF6yULHUUyuTrf5I2mSsW1qjGmUklWE6/15d98ykfXaoyu9YVQ8DMDPivlZMXJnOQMr8/6QsqlnHnh5Y8/XU8+roXz7BleqYHzcjj/009/T3YX0gmAvhDK/VTYbxLdqFQigzMvvy+eketGFXIl7DJWN6pjtfjD6k/nk7dSdKOGFP1UPIXhBxJewSfwE/xGwkn4IWEj0oxEqlCC4DIkbkQtPi2TK5Ra/E6KcXpdDwLUkHquBNxHKSDYGMa3T2xW3fz0z7jhpPVPvx255XcnV6s3PP07oEl3JBV9TJ+YqIvMRr+lnwcr81F0LlIysRLTCLhaspfYtYVxW4OO2m5qFzFaeZrYEILFpkTCP7DYDOityII/oHJU8YfIQvSjP0S+E/ku/Xf6FxM/o10Tzgklfd3Ed+EaGXCNIXINDxVWRXmVGDMki0vMKrxZlCp8GVK+RqmioegonLAfM955+hHto9/5VST0uvR85NHIk2gQLbq0fuI1uhzD0gHXSSd7oli0DeVgG+LcjGCaq1zEs+HlQmIFrgTPMpIjQxYcJLMYO+h3J+qYpyey6d+flAw9992LD4q24pHLZlop/S3IlSqxPkAioViJg6NI/IeNVcONyU2UGs6DsSvVjkdfMR5RtJjADLWyXuMRtOrNNz+Qndn6pWcrdYXcK0omm4KZnHt91TEt94qE3CszQ+6VAQah76Mz98hMXzwAcFRcNqPHCRxNYq6fEeCQu8aoOBzyC7DkMZmweBlcQQtLAdmpiwIkj0YXTV7iclkqzp1DKyPfWin98dYvagScuelXgB4XKBlo/ViaFDtEQl4Uc5AbjYohze/QrzAplz6mb524G3+XivxR4r28GvCRTXEMWVu2xCE+kQy54PsYQVJLvBffOrCDXBMdlTxG/1HWAt/LJd9DakoVq+IYo02UJpZRR36DHB09+e2NMkNZ5OsOIRbYefk/mR9KfHDVIuo2KpyJd4TRy1tk42EWxwVVcnCkZ2Wy2JHGUVYnoZTZMM6ZdXwhUEjm4Y2acVxPmKoDs9jFFwP5zHj/aJLBditkR1WsKZME5S2ZwH9poKlxzJNXSYUgD8uSsk2cx/BapoTorK6EyDyOxVlAveJErQ+V37ap/Fhn79Aven/2xrFU2cjR2kOnX1rZae/pmpcT+T/W+Y1OVN6zda6lc11PTv2eDtfzL02EBiTNs54+MK/NlGdn31TnNAD8/Zc/Z34qY4BiFmoJFdZg+Ckvb8KpCAy/mcGMgLg8ArdeQ7w6Vkfs1QzsGWnGeSsxYYUapAyWl2nwhjZpyAleZhY3NvZDopFHHM21yQ1mBtsQrABz//fufqT8JHfuUf9jW41Ga3dPp7nrphXddd/tkjETp9pcZ09FTp86W9gyiExps83s0DaUvn1gXpmY+xwGGibEqhTi8jWKeKxK84/FqrLR5FjVYOOmh7v6ftC2ds7WEntPs9PR2OMs2eXe2Pb8kqXf3lCN1qNg74NDPnfnffW56VX9DZ81LatKL/TsaPP7B+4jvIbX+QvAtZGaRS0T/CtO7eXTo7jOV4yDzIoGC1M1xMsyA48pPbgYAhfsaQDzGheJFppTsYeQzJLUbDpLtAUvwyHESdBg708s94pyEYsBtMrkMuNg5Q275wUO33TqmHHkocp5X1/uO72i27ygu7ug+1v1DNNZEUTDqBkXSGTk0aovJta1Fjv79q3ZttiQV5xOW835yFO6PQbbyxIvZQbfcblQ48sb5CJghbCJcjQZODqUI4m5kckAUg7xw7AnmRSt9kgmJQ0ZAVLqwKeaMHiGDBZnmnFaNjXR9cHlDJOpZLDE0leDtRuOLF326HBoYomjtd9b9kDdps5zg72Pb2t+Ef3BVtfjcXc32tCtKGPZodUV/hUHlvyiqaY3kD47NNJV5V6+H82z1y2rzsyuWlIl1ADQ+4F2BpDXYT2xMxFxaXhKRtxJpYuX4UqHFJxdJ5tEQ4oCWJJjZ7VKkKGesJ7Fr/TY9DSKpqfXV1pWiYywBTA02Awtv/OJjWdOwgbOjbx/itl5/OW99x7rLH/6+KVtzE6M675IPXOe8HsptVXMgc/Cmg8Rdc67Yc9qXXgTIM43NXXo9OA9y6l0vEJHMrJl0SSi3kBSC2NySZpWzCJil1hPsogGEoc2gxJ1i26yQUi+mfzeeDaRmZRNxO4oidFhfpMZ+84drjhyi/GJ1pEnFi17q3s4o761Obv0+nbnqu9WHD532uvpZJg6rn0+X90zCLup5dRZd9vGi9/se6DfXTv3nrTCDG161bKG7XXOV3+yzecJudFHFXMHRvD+pyjml4Q2jaJNo/IKjKcVpVdKVAKIsZ0kUXLh2E6SgVgFFC/TTpdUVlE4sYOndzwRePap06sX1D3TCQLp2S4QSBPN9NHtAzX+S58LtfygkIak75Na/hAVVmMuIfkypXo8rEHTC/rVpKBfqxGK+bXqaDE/1gYJRfywnB0Nxa7GRldxg+mUdI2rocEFr758ReK4+EuKvvxOpAXtJj0EJmoBFdbiSxqTwOXB/JDkwuUpJPYhucDLNcAmcsyDkiTMkbrRErk+GdxPsMfB+NOnkmAIL5fgkj8jWYogo4HIMgdKXJatq7vm1OPfXPlOqNhZXe0sDkU+a1sjGbm4YvSb8nxnKOR01tREc44U8+9AnyxqJJonwX6BAmFrJJNSaEhQjxAqm+AnSyBUlhCvN4BLZRadmTN/Wi+41CnYQwBScvozFK8HCxqRR2I6p2TB6hWghTgDS0JiTCZRtWL40VNWjbxMMpKbGZPByhQzDsQOPH+kbrXj5p/syGmodVbZ0lV3/2g9a3fXzf6+jLn0gqfno8hnoe40rbuqwRpZj7rLmuy6if/AsIUv/5Vmif7MEbQntkEJKHrBNQTiGmI1pGRLREVV+FRhbp1GKzGXpbUtDhiQRHL5YnpXCotOSKQFTYOxmjHpZdjrdmqtiLuUXBF3PNJ5vXwBsHi6Jxpxt8PlaNjXdiGwlAuIzNURNk/RCDlZO024HO9pRYDLxQkwzsjyunQsZxUFOFIbjR2aQgze4OQxvhXMKGFb9D5hqOhrC5n77y2oWdFZY36YO925tHxXl4Q+3ddYP9IrcWxzeHMUXfO9tQWqE2MTNjq86oamGoM5daKNPr1msSd06RMC51LgkR8DnGlUm7iH1QKUHPLyKdiaTycApokApgnuNq4RxGZImgiVBkMFcKTEt3LC+m2waLLspU8Ym9Z0N2Qd4b5XVjqPYWqe7ZQ4tjhKMxTipva463ywq2lqCPTaO7CuaXWLRK8p4jFRzX+xbrEKxarhm7cc7V1+bEtN862P9S559ObG0/bGpWWO3jaXq63X4YRndAsq6/vGoM83+I2+yPm+fQNe78C+HdjOSK9a3vhZ43J80I9blahVkW5Ytxf40hq163ijaGhglJqBSylX1DbCukrvIYhl43YdWEs8KyI2ZtcZp9p1BoziRLsuPZZUEMvBVoF18TCI+HMnKx5Zff2eOkdbee5Qt7mzZ1FepFv6iw1trtOvgm33mqkokkvvtacb3F0h5N62xGh1pmFY+iNdhDdYKo9aJVTg4fqusJa082hBkMVUXw5OPlljtqqeiHouM67ztETn5WO5j0vcJFpS4kZi+qlaEl/kJTnTNZyVnVmn9Z87HPj2iPHR57cdCRx5/Xv+0naGqT/e0zVa0b0Cm06nzjpaVnzpoDVNBWd/st1bUlGO/lJaP7SN8DxYheAx+alkql6MWitF6qhwnZ42aiVhuoRpkuKgVWA56HBpBaaLBFatVCWwuhd43QiSjb3vcQOd3T2wLrDvnz0Sx5HsoDv3VXWbZUJK6r8v/5XZD/gsps5S4SIS65SOh1MxR2djE8ZFYp25LJEdSlx8CmsoESTwZ/6XX4x176jP8HlpX3D5pHtHk4w7nvJ0o9a8fIMjDI8JARF4EwdEnlNrkvOs+WIcZNIrIrlzxTikksQhScDRFo1DSoqE1FU2O4rYDBsJRuoTgpEkAz41GCkD81AilkIEb+w4PmDrCNkG2jof29FZtWpP59bT3X1tezuXbl52/xN7l9WuP7Rk3S9GdtV5UmwhR2NQo7bUruqZu6XT6Q7tKbF9rc4fyM2q2XxD26YuRwXgseby5/SENI9Kp34lxLu4FC9OPoM5KFiHUsE6BLsvXsk+qjMyCgfHCsHDNKGkXSPkZdNiJe1ppKQ9DexETqkTirJd+AgXjGYSSnCFgC9WX/wGqD+2+A1MGwV/5iEhUMbqOO0Z4H4u5Qyn1Y3qtKzB8ULSjpeTJse14DEh/scZitGoVmdISQgngHnq92Kfe1LivtDH1jziuAfZI2+b7FW2/B63ueqe3O8eBFv1738/PvH3mi43q5IfNmoPjdG1gh4T5KgD5Ps8KpyKcaX1knCNaEZH5TvoSxxKxYFBsItg8bwOhJLORYQS7nHk2VTMDXIQrhwbiKlVv7AribPDwAqHTvt9WLA/1X36CWPdjR2hrKdeQsP06YnFt3vcqKGaoS/+cniWBwS+sD4gH/gvdkoJvpkYX0VizEpFYsg4oUuiSZRyaqTKanxzz4hm673nInc/J7FHlkY2onvR8Ytvkz4O0N8/ALiN1CMijyR7hZ9Wx4OhhngwVBMLhgbf/dgl7DSJjpOe4Q3SL8DYeeFV3cfDwmkgsu4Mr5B9wSnPUKemxhnRtDOxsCKfbCQhNyNW9rJA4EohRscPBm5UjAy+uH69qm/FqcjvuK+vU6y+nZc4IreBEXQ3skW4yONoK3rk4i/RXtQeeSZyC0ViW4DLRwDmyTFGdOUYo1VJrqvEV6XRysjT7/32g3cj/4SG3v/kP+g8Whm5D22auDjxa7Qvsh7TKjKf8FISWA0El2IYXEjFIyHzTszFOZ9oBVxROi7pzFfEvsM0k1QsRL+TErg/hhCDzfjGjs2Kg8fOTrz/2mEwayKzI4vQP6ELX+ajH7bCGnoA5k2Ef2KxSJngkQGKry0W2UO7J/5MT0z8mPbsp//6xLcm9E9E8/t5dC7Y905qNUXS+mMaIYZnc43lx6KSSIzmFRMspOtIP+xsIUKVo8X6PZwzG0uVnEKQKkke3kW4OR+oYJ4NWhCxfBoYgZxGz8uFZh9fiAEdLjinydE0o5khtRfkZCFW8RZHyGEY7trfk2NNV9i8ZXrW77Up0vPNPfu7hhfQzWtk3rnXe1H+qu0brb6GnMhfGwcbC2RyWUHDQH1k3FLnt2xcfSsqGj5IYD0IHJUH9jSDKxyxGR1rSyF/8Xasg/dFHpcv/8/HSB9CHp0m/amAnwyMn3QBK85ojJMriGKK4EdGWhHsWlyNFZbZSTYoA5BCebDhrE5y8AW6cQE/BZhL5XbASz7La9TwnA6eshnjxyQaOTguV8yQJCtpUUglCDKBHjYSpymtN7swVVXgLWfZcm8BnWLP7907NJgyK1S0aP5w14FVFn+dBZnqbmggWAHsIE1uvc+6aqQ/8hvv9XM98jVJ39oQ+ZeV20meEn0gocGpNFFuCtxanpGMjyqYFOxGSomXJySzU3BjOGUKBHhGAUdJ6kC8yDIhWoKN4fLAN7s8Q4P9zrI5jo3BO29wDA4NOgNzHHT7QKfdY6+s6Orvs3vtvoDg40Y60QjYDtjHrabCDBLc26mebTLxbMVoVTIgUxvtWNfM7OTCLjPsaKgOVlcHQ42W5GNaZqystaXcOW/el29K6nCzOo4xSZhhqQY8LTu1WYzVpnl5qwKsVk8400qqi4COghkl8/I6eCcf9KouqlejbpLoF2GdIrN6PGPpyZg3eIXOQ7ptKN6aSdJ3nA6IjptulNgyFM14v89rFNsoWdLlh+S4DZjxp6Sa2GTGOFh1wz3zlnc+Xru2fNDhXGnfWHekc3nX7ht8p4fbCurLcnGksGvPQLXs17+WlDXfV2aTTGRLHLYddZWSv/1NFrr+rm1bNqnp9+T5Fd0VZE9sBdnyV+kF0EyXRNlSCLKFuPmpODwto7TgQsvBL8Qxai7PQ0KIqgs4bpiZMs5lecKqzGiLHCf1jEoyVUAdKzsetkrweessXApmzQPbcrYoOU//6W6SWpMXS3DakM8xfyHhskD9HPj3PxAjQqkbVShxI3uWbjQ7Kwf3r+PHMBwn5KXNgTB8iph+CmW8hx2NyRXRF0QtZeIGqsIAZ2W5XFBNhaKUTMX11yocmCKSErBt9Xmjxf6T881gowAhLMat7SulLx5Iq/GvOLDs/rc6d4e+1ZrTVG1PyTIrUHfkBUlpK71/942f7t3ffby35b5VNb3Da7uq07xdFc7uri7H/s0fbngimldOJ3nf26iwLpbDknjH9AYdpQEBCkdCRbDGM2ZKI+dk3jGTcE7hIeadDteU81oj+B6esJawoVYBNFB7wjrSEKQzwSuQRThljJOBPEMT1ZxGSnuwBkLkf6NFbhSCg6AsfDaLz2t9B2Ulo+wLkVcuRc6bUVfk6XORE6gnN3IuIj0/0UmfnCi/q2H1rZGnUdetNzXdhffPmss7mR7px1SIaqfup4BH+BJgFz1oJhyUnRdrXpbholSTjpQ14+rlfDhM9nDN+LQZ9vJ8vG0whYoCXDXLM04QMz4Tq69RJuntJZX1Da1t2DpvZrlMEJt6XmvBMJXYhW/o2edk2nxnA/lMkl5MfsQbkRPIKnbZi/Wu8X4FsewAu9CkGRleydZUtlsKy/t3tDR+y9vsHAxZan25a9r2b2oOVWc4gwNfb+o8GKh2rG61NQRy9KXdtaG113m/XTewye1x1A1udvXRn9Xsrc67LtC2udNRYN6dnZuSX1bQF3I0L9rQ3bWjwtwf6hrptNvtO832FHvQnldR5s3JCHWs7A3O9bqtGZ2O0s46X2YTxvM5yd+YaulZEo9zUbgPx+jlmSTsF+CnaB2SDNhCJph9YtxtikwsSDg+F3Q4QiGHI4ieqHIUVVcXOaqkS4sqK4sc1dUO8Rn36Wy9/IlsIehCA2WjWqkdVFiK9aGVcGXYhyNuxQKHal1YS+KjZtdYjZhmayMLSwF3I0XHz4KFVcJhJUlCkBr2dpx3qGT1p7TpUmuxu6GZhIlrmoGyDbh2/TlVipny1GPKFus595SCdFomIZXl/il9OFfLvGzd8CZijzyGDG9u2PBm5E+PPR759I11u5Y88f6dd/3u+JIlx393153vP7HkYtXQzrld+yua7FsqHF21dnt9pz2w1VVf8lBv287BKvq9Y8h4fnj4fOSPx45FPsVHiD2684Mnly178oOdOz88sWzZiQ8j/4bS523vdjldq/NsGRU9NR+EFldk5NpW2nzORdsxbV10M/24NJ3KAh30dQrvcaN3LFdAZEG0NQCsvTFWRKmgcLJhW2XrcKaMJAy1QsIwmSQMcVQuO5YwtLJhFUuyH6k45UHxuWLuo+BKWcNK5COubjxraJvUzoNR6irv6i98nf5abf5gaN68faEDj+zRuLeE1u06EnKXrgUG9DoymbxgV2lqYb3T6Bn2F2y7I+JqzrdvGrI7nOkrZCkWIV+6lBpg7mXupKTA3RSZ82AVHpci/YnIf6CkE8sReyLyd6Q8gf6K7XXwFPYJz0SXkb5v+iX4fkm0gyXa8S1RCjWdEmLuhSUMCVNTsZpOg8/CWNkQ8xyNe7kn3kFHJvVUU5M6pkF8UwfpQZDhfyB7wUdVUU/FdwMb2wH4qNQ1VkaOwqVl+KKloA85t4erco3ZRasxRPLJKcROEDfHmE94VebhfDo83WTMKZxwkg0zphKMimogb4WP1T+nTbdKvSWk3YPlPKTB1Q30LStl9WOwb0oo/FYVyzmj2eBoFWJiBWVsywiSQW6y2qxGlpRiOdDBxq1PLlv+xNaGhq2P9y97cmtjd6B/Z3v73csDgeV3t8+7qz9w9kLNYn/xLYNretcVODs2SPL64VPwrf7lx7bW1W092t9+D/7wPe0duwbKywfuiTxDK+Y3elrZP7zzDpptszbinDsrVTELpN/9qj52RTzrjp0blq6RqoAsNLWVOUG/SGiSQ80R6ZEdk0gmEdu5iXIoQxQ+FtIziBMTUlKXBhqHV1GBGbEltP3hGPVW5/ybgpU3zXM6560MBm+a77ytv7Fx+fLGpuWSs0Fy+qZgcKjd6WwfCuLzjf39mM/ngjD9SLIBYNRS/aLVJXRbgeYnZpbSE5aQQjJJMpicUmJISYmNCaZw8gW8zzUAgMKDy/LgPY1Q4x9O1pBOYGyKSTzYJsblykLLVmxowVzmyKXr0e496N7Ilj27d9PD96KbI7vvjexGNwP+H5U8Rn90jTUPBhODHn3k5NuSN9HtZZH7yR4eivyW+Z30z5QafKwiLMN4DexCTQZZpYGYiKQoU3aBxJtAWuFSTCoqbViMYoR9Q5L5kw9Vrdzf9dpr3ftXVqKzAxt86iO25U/cJrm+Y9+a6kt/rFq17+JAkrdtICDt+vL+/m8OVciwHFiFfohupf8FpEgx1pBjjBr33YlPoiuP61F0cFJ4is52SFCKqzrK/R3zy8s76NbyBQvKy+fPJzUhpZFG+j2qm8qm1lEAR7RyRwvepBnbZKR+E4QvnxOPpGl1OJKm0wqRtKqKP4kVnVodl3yG0+k49gzFJ7M4z4QfSYCAl2QKIUkty6NUzIjIH21Wt85GcpvfFG9NR6V5zkXZPp+zWqZJqm9a7g11uo2m0u6q/OHIil5tkjM3s5K2/UFxTFLgC2ZmhXxWDenDA33Dgb4xgr4pozgW/DvgvXwXL5PE2izEuT5mcZ6VQywOiOUefLFseeL+SEw9hNzdG2vqNi8oKe3eUF2zscv98LK6rHI8Xac8K8tfYma6w8Eb59hsc24MhkM3NhUUNN3Y1TlHn19pv9deYWNZW4Udx+lBN+yJ6gZ/tG4M/vUjReQ/TyA28skbKCnyH+RoIKoWEtQD/MbBSAvzGqnHsVM3UWEL9i9t6nEu3cXrmRjE2lQSGiTV8LivWDeaqchPBrBN4NK7cCsiwYKWIqE6XgFKc0ytTyd9iBSvT4fTqQHOxoYpmZH4FqZSjA4v0EpiFNSmaHugBHY7OLnxcLnYjoioaNdpqO/ow/vmLu9tu7m/u3uZv3ebz3WwOVg5cK+kQXRmSS816VOTP0jJAU/s9E41dbxTDWxzA+mgUMOKtYmdan4kZ6Z2q2XdgUIdb09uWZPr7ox82Xvxx2Lj2pTra2a6vmKG68/cKWdAJun0bjk5Co1E9k/tmWMcSHbnewnXPwTXT6ZSpl9fG7++0YWLweH6QiFCwvXhWV4gndawZ0N1G5G3NvJW5Py8yYiQ7UKGyGcLT//zxR9Nx0U7rCWHKqAWTl1LbnQtXBa4SfJxzuAZ1SVlgfdskuLqFcQVungbWSIeH2YN8FkmUjPLJ+lIB3bCkmeMvkyDINWxvcbWMacpM7c2b0PJcIOtraXOUlAxyzkFnPt7b7TkW5y+6oG+rLysAvfFsAiWRITJDzAZwH8toFZMhSolBhXr4qxePgl8k2wCC6e4wCenkla5DJLCHMfQ8ck4iCTDgZAMdhTRpjRsquTqeSkJJKMUVpgDEQM1sXpB4JSEMwnA9lcJXk1VpwDdb0LC61AMzJ86gsTzudgnstFa8UQMzpOEjy2Uk9pwRU7msl1jBYIWcLjGDPFIYPKFsTzBaMsTbLo0wWhzAdCz8sBoo1GSOttAxIa4CXgHTpKnJQembock9BVmyPRtst5a3VHs7KyyWKo6ncUd1dYVTR53Y6Pb0zRt66x3dlZYrRWdTmdnMC8v2Okkn6uvB3kpoSj5hPQ8WCl6arFQc4Lr9xKbDzm9ZyxZp8aoSJbhtkB1rC3Q4OLUFzjWE+sMVEcjZfCIC0RoDy7BwBYKincjwp8SWVgJ86IkFG1LvGSd+EXkI7QD/TDWoIhORVroXvpFoZ8u0kj6SWtwDQiu0eOC3kntgyDZx9wCidw6rjj3AjvmFOlUm9hMWAqUKQDdXYcHRhhw0EEjS8vJne2sDBIq5RSz+nBBaSX2oNJYUuenF+v82Kv2pGpRTF/bpqjyYuZKzap1v9iWGloIyty7CJS5L6/4OnOZ1xnCat629Pj2pit3sZa1Shvj6j41ZgXcrZp36wlBH5L+TpDVON46/2qdpbqrdZbiCKySImnuKR2mCBRKQpfppbdGUHVHjJSCFpm6nub/ifVMWYcSVErCOiYeEJWJuBDZ/USLRNdxCNahvzpeDFdbR8oV8aIUFE0iavi4jomvK6pdsE4R1uYl8R8rtfGrV4dnDVi8vBZEcKYnWo9x5aWOqpU4sq4HGa0Uhg6YU4VKDb0yXrM1ibJXiCglgvQvIFKrq3F06fFqQQJXx0H7EZG45G3yjPny8jHcrwp8gGdR2MTJWFJS8q0QCs1SyGBYoZKMBDVL3Aw2WsBpWDoCdsrAawJTffGW2MhK4x5Y+tb4byZ0wSpiXbD4NxmSOZSLkHpZBnjm6deew5zyIP4xkUnIOh8kv3mIklEqPDlNjn9TQX4zCVe98yr4TRyBU8lBbCBaKkz6YETzAn58DaobRt6ayI8ib777WozMX7xJVs1cfht+vx10Ld4PmbgHm1T94Zk4OO6XLsT9DJ5oG7osVYj5JeHeGCG9jX2R1GhHOjOl7i9Rb9qjVPjla4oolWL68YvFBPLoS4JPjdgbL9YA4Sg2cIk4wyMHuBBROkYDqk+YvZcrsJ+OlCToU7B5E9aTmLU+DzxcHSlk1WG/VS9wnsooVFSTMoGEVnoLa0hopsdsqFkf76ifuHA2saUeaSOf0eEH6Z3xzno6PBGJN9dHSh4EWEiPLNhpGrBnbp/WJcvluXhWjgvhRlPZPNgf2WCdFQgWzfTmWZvYPMvTOOAmZZ+TJLHp2QXYplHoeSWpNol10fJ52UJpNYsrDjKmddUyM5p1ib22erDoCjtaGjMttXnrXRvBoptTb8mvsE/twZ1m0mFZQvrPYE8Ic1+rZuzKLZmpK9edMMf1HxndCnv06s25WryDr7VDl2kgyuP/A1hALlwdlr+gatAw1woM/XJUtkThOQTwZFEe3FNO4MmLwuNkhMF3OPxrJOFfmwhPqRjxFZzQ51hTWkaWDLOfGhc0zQid6PAwV++kHkX1RGCBerJfU1O11Bj1jF6bqZk3Cmc7wOmk6vF8OQKnNwpniBhvfDrsP4tn1Jw+G/ZfAew/J+y/BgJ+MYBfrOPLRfAb4blYBL8cwE+3FDij4OfB3ptdQN7j03GJYV5gRnTMuOuuATvHiHvV0pCdW2Nd59rQVNg2pyGnoMLecm2oypzqdT09Y/+zRMSZn/C6H7C2fAZux8X5tV7eBRqiMoYrkfWLAEceOPQIaAuB3gjFNwTGYLkHb4jMQtk/sCGuYApcfZMUVBY5qqocRZVgIMwmWih0zdtfIuokR1w3MbFZA5mg6b14lnUaluiZXt4BCFLSQmtFnth5zVzgKA+fBejIEob4GYw4I0mSk1m4JgyBzOZK2NE0Zc4szEgGPa/WYjHuwAOXKPxuHjiuWrMXv6uEd4n7Vo0KbVFvAMfqkIg7m9yQYkKie2CIVbPa1i1dgjCq1r7U3LV0udOL0fXh/vmrjHSLZ2c7xlOX+552jDeT++5tYQE/Nf4toT2hb35NwNGmYVrRGWAWuEswbiaqSp0CttpqqPgMBpCR6VQ27maa3nFsnqnjOEfsOA4bM7ICgSt3HRPpPr3z+Dcgzudfsf1Y+gyR3//ba8OW/0xd0d8lHsCVVzdbFMh0TB6nU7lUy0zrs8y0vjzRogTdzmnYMWNmljkXc4lOz2V/BSYFeTzDgp9B9RtQKTYYz1950fkxdyEmX/0kVuOm+qavHFc0u7x8NggKOwgKTyIYYpgGl7MU4rEEqWS2eBQ4LzwX5sIeMCq+ii2uJBemQ/e36Z7ClaFcM3Xn00JvsOg/lk7tDtbFuoNZsTs4LGG0gSv2B2PDP6FHuFr0ACZ3CkuuExgkPidEB5huTfAvxrQs8ca0YBIz6fHRPkJzP566TbMeD6cTGinw8jJxxI/03CnFrpIZR4acRUdnmhkS+axj5PD8jsMjHZF/Rhd3b7tlr1DntwrXyMoQFaTWUeF0MZKTKyfa1QEGepmLl8XnhwQ141xQR1w/3HzgxtUZSex42J2E7XR3lpKMicSzRNxBQGS6LBeHRApYTofl4myhXbOMFcK6bELoSm5mspFQyh+bDzll+i6OmqyqXneod923l9o1uV6bu8WVdu6wwZXN6K3amvl29faVNmNZqyctq7ynomZxWYZkTf+3hnwNq++ozGmb15BhmNM76PrhqbM0/RRNO+q6naPLNx501s3Ltc8L2ey1Cx0X7xRsLNKfK2sh/bkl2PK/aoeu+6odup4pHbrP4Q5dp+t/skfX4DfIr7VP13by0Iar9+pKjotNy1Nxsut/BSfPE5wU43Q1b8Sej+t/DjmZyMRcK3I+/vbJt6+OHGapkN2M4iYEuMkHu+K+OG5mTcKNK46bUoKbAgO5eYlzJtxgMwPXgY5qks35Qv6eoCcn1xpFD2/Jw1Jqlogg1z+MoGhC49oavXtICGpR5F8j77PX0vMt6UBzIy8u/PCjSwcTur9jvCR9H/Dloxqo5+L4CgC+LFgw2728Rz4+WmjxgF3vBLve50lAZE0ckY0EkWWAyDIdljvTEdkEiCyj8NS3ZDMWRiH2FMajpdDpiyHSPhsjMiAismY6InmPkyWdqJZCeJ59VcRewVO4Jjx3C8mYxqxc7LoPNxa2za3LBW9BcU1I37b4RktBrtMbun5JVl52gftSdyLyJSLuz5JcZzlg/0wc+85J3FoaRTJnc3F1sM/BEAh6ohifbRgfNc/GUcF8MAlm6/BejuOeq8aKIQBmQcDFV6dOJUdsz/P5oBJGMy02J+bwAMurWKCQR8+b8MTRVJYP1mHCOEXClP7jHJ4Y2kpEf2KA8sqk4KKWhGYy7g/G/JErUOEFsTrukjRBXnwWK5mL0kHWQORpDdVGXZgsUediE8Ej1AfNIF3Hgg0qj8YxFhSzFe2JshbkyVitkGCqTZS8o35jocIx1iy81ewa8wtHceLMm0ScWszzmbimckxlYYMeTKNCgTZfKZb5uQ3wE35n4B/TXl+RyLpWwT0vL0TyVVZrED+H8oaa3Z6GBo+7+RrE+SVnZ0VeXkX8B9xNTW53Q4NgE3Rd/ly2SuKjyqhGqpM6SYVLMbWcXr5CNs4VesIGJNymSg2mU7tnrCm31KBxcDVevoncYQRxCwmJ/EAivw7XZ2GiWGC3NHk4i45vxpg3jPNd8OzHFNDqArjQNaw2lGKpZdHzqSUBTItweqEzQG5VIIqtilL4+OwSYaAlZQfCqZtI5p4zsLwuNYEKxUycCqboOPnJwwwKbfLppEHx+QZdQIky5KcL63vL/A8tWDz0yuJtT3srjg8tfWxDNZ55sNzn21u3ufPc4JazobYZSESfRv9W0NDj9nQ32ESiBNudLCFLQ3WoHs9EeL0zNhNh/gLX3IJEMiGpOTYhgdyDINJI5nBMzvEljOK4eo5P87+T40usKP3KHN+VhnzMOdlrihfs+BJLeeztd/S6rzj9Y06AnjtTiu8+VXX/CLm31OfMy2DLmUlM9PqrTc4oucLkDLc4OWNMZsggIdL/5uwMbL9e0/wM7bNgvF7LDA3mtpj9+v9TmLFZek0wP3gIbNJrgZkuFYvuojCHAOYCyoN7+SfD7ASYCwWYCyWxsDGGuZDAbBNhxjsjGcuknIIAiR0D7LmWfKGUfjTVlGclG+QfgD9aSHMNY1PqSSqsG1ud+dcyQYV5V7Q6J87GR6mAviW4ALvHTM0msdHDU7EB9uaYQ8AG9ntnkTBp3qQwKUaNwzOak4ztngKhYqVIQNJoKKkITpbDyXIXjpyScGkBvotV3qwADjmPGjJkHnHIYWUtMURxLDpJKLj+B5A3qc4lhsFEg+bK2NwWjaTUJOByIBZUuSJWJY2i7TJRGme01+P2DH35ryCMl5D60ITcLErIzWpmys0aSG5WA/u54JQwIevicjJghMTW9sNv/uZafxMJ/V2woZIQ/Ob+R5791dJTYgVq7Efpy3+Eh5/DnpiUm0UJuVlNQm6WRtNzs8YYQ/7u3CnJ30Ruu7iUXIEhv99P+jAm5WbRlXKz8X6MaOvxNedmjVHr9P3nNSGBrqFYf8aXb+EFxV4KNbiXP5e4ZHkAdzW1Rpym7VKQWwnK4Mng4lNwqKdGsPA1xK6Hzc+pPOQePbVYM4LBPqaUGVJI5hIMDhPJXMoqcIedikw/AY/VlIHfTdGHjbi7M34XkFSTvxjZsNJDWA2ahFrVr5hOUbvpaH/zXpdEkpJ9rOZg7u5bzSO/qzhVezKvQEtXDJ9Ys+TwpnoyscK1pNnpbF7s8PU3O9At/6fv4fWAEbpjn2Nj36r8mpTDST1tI33bgrfec+T6yPeXHNpQlTjE4qXG/spMS81gI+k1oJgfg2+K8073xqeCpGOv1OLlZ4NXmphtio0LYXHwTmiDNYrjQozxcSG4tIv0HqeC7YZvsIDHhujHFOmWgtkkCcWSJJSCFWpHpyWjJo8UKZTjeSIzJ4ETpoysWVDzbOf9JBE8tyHLgnNPw404EZybXzlr8uiRQRqPHpHmTHEeYeeRHnrYg1Pyp5OmkZTMNI3kH8qfxkmOjYCrDyWxnXxk+BoHkzA7YzbA/2tYsHK/OiwcjjZdGyzw21HdLsASEvPA86J54CgsTkU8D6yJ54E18Twwn5pFtPkYa0rLFDOhwtSLr0gFG64+QKYFp4JLuyO/j7yfdU2zZJhfReNEF2eYKhODVdyT9ThvJ+SCAdYrbkuChBBGgpgN1sSzwZoZssHmWDZYjKr9t/PBX4Gizin5YFtrSz3OByuvCV8SZmqI58UZ8SYR8XYW8GYhNs9mEXO2KJd4QOrnEEMnfZKhkwcGTWoetnKyUsnw6SIBb6Mh9QxWTlYecFN6jmDlsDJbopUzMzNNispMRVeiJTMNdXfi4t3q2Y6qsmm4Whut450Za3XRkMxN07fVT6NakqGC1IhEJtlIenAycb+7xsXL1ePisAPcMpTu4g1q4R4fkguczsOrTOP45tPZ8RshXeFuUUHm/MTROV733Llu75zoM126a1fkNXdzs7u0uYkp9cyZ43G3tIh8/wmZA5VFzaJKMfVIvjrLyxcBAVXiKECrOHFPQvLV4mbHAgv7tckeMmovmxhImWSs+2iaKtc+KV9dhCe8IyozQDoB+ZxScpdf8iZOVxcjn0DBSenqwpny1UBE21Brvg1Tjdtc19lWYMOE6zpQ0bhSix4vXOLElGq19pVjyqW4+p2bmwRadXcH+l1bmgVyzSpajE7WOOhMSyYmT6TVLNAr6KSidowox9Px7DmDONNSFp3soooPyRYmuygF9k0YZol7n5UMSPRkQ2oacV9kBvFe9iRdmeqfNNmFaKXTazsnjXZ5GyshMt4F9GfidBdpT3zW6//7teL2q2lrRSuxlplpsRKdqFPoSTrlhiusNfur12qOlkoS7aJkx5INoF5woF2NhzAIU5W+GtWCppkGQSMpMboO65WZ4QiIaiRRZwiyz0ndPSM0WPY5BNmH6/aKo6CNpjJR2RcHcnSWWgkn87BAdPGzUhOhdkVrQogUzCOTK5X6cHKBI3B1eK+QB5+GgK0zZMFnRMTj01q0gbZkfg3wIfZLJk+w0cUm2LD/8xNssAk0aYpN36FnL0yZZCNZE20TxPM2It3kPpO4fnRRwgw5nDMXpwNPnSLH03qPZ+oMuQx8D4crT49jv3p63OCpm49VHD73xsmKQ8LwOL9lRXfOgp7uvEi3fNPEn796ehzmP4JvsR/fSj2egPHpxdfqC7i2ehTp1cBglHGc9Lcax6Mlr2Kx9X+bNLwegaBX4nJtHMIMSxQqIZCMJ5FOJhtzBaacRMqtUV2Mnoiq3imUlVLTWRHwcBzHCiSOxPsOoYT7DgEF8V/8vkPHT8VjAvF787DR+67E7s4zphTauMhsGP0MN+rB2xnfqkBtig7IFO7Zk6iw8f17IlJ/eUV1qLLcT+7kw9D25ma7p6EOro9nb56SMVQylUE1CLUk+D7iIFXwHBy9WpjDmZkoJfF9c4wm4dYiWka4xZSR5WXyeHVM6kytf+FTbT2xQZ1ZAX9FdXWFPyCO7JwlESZ20rfY58yxu8na1l3+TG6S/op02G6gwikYNyzgBo8+43OjRYA2ZpxL8oxpdKmy6D1qhAHjmcBymWReALkvCp4jbI3OESYTxvGAmnBKqowINR0r9J7Z8O7KT4x/JzTtyOKOkTi+MFof6VhUwPw21guQ19oXKwEs7iqwdRYnlkPKFGJbgDZa7afSSpq1SdFaUZD1stvBTppN1VDt1DeocC6mSqGXlIeWCM4AFv2VYO7O8YzVGnIx5LXxASQOHNgT5o6kwGGtB7eA40QAli548ojPAdKkEADnUlheie8UXacPq9NJdQvL8lnkTjnpuOYp2yqMgM0CeVM5dS72lXIu0VHZgikMiGIIoqTx8B4xhIefqwg8c9NSIbDXtrzUt7d+U+e5G9a+EKr63sqYb2nvneumaVdbDzGL6ZdIpM/tWdRgixrGzQ11zVNifA2NjQ0xl7O8txbJ6pdWEuPYlhBGJROycC2VX5Rr102uprqSaMOSTLy1FekgSYp3kFztdgxXkkQJJVi/SlCMQsVo9bR6rIem14Pi+yFUSxzSD8C6PkmBAYwnWgOHzNLxjHScvA7ryB2d5ONjSgWji847UkrGeVW2h0w8is4uqv7a578XBLMMC2bekvsFl3VGCq9G5bIkg2NUhR85i24025IFL3PxI0ONypKyLMLkPJlclZSVnWtJmJxH8cws0uzNm5TCrXV12LQoccv9pF3YYLV5/cK8XDHnpEVek5UhdgXtm1PR221ofpH+eVqSa8k3Vrl7Lfac+Wb3HJdZbvqQvtSgKe0eWeTc+NC+7Cd2oT8dODz30R1des1RldrRtsx74kAkdejE1joTyOunJMeY/SRmaqWwkJZ5x2ix/V+81wJPYw+DkpJYn2DAPRUvF4lFSclvHYffqoHfslCcLDpHgNw3J/pbSBYdROSXFpiQ9akulIuyF0Xe2ij9c+cfPuyK/DOeByE5y9wq/TXYdz5KYL8kL+5UJy3q4ohDLRlxmCS2qOPbXyYhMsERDynwCoPDfV7hRn6IPcwYC8uttoDN8LDE3Dzc07OlySL9tdFlz8iwu4yO5QsCgQXLxfs//IW+l8y+tlPxYdvRg+hMQHEsmThCIFGwo6MgzEMhEObSlfamJru7CTvsNGqW7GEksgYyp2IeFc7GKk0amxsyaU5FwlSQjPjYjytPq/iqNlHUPFPavLHR426WrrxyUhxRI5HtdBolgfU68ZSAMZU4fkaYfC5PFmady4WGeIpXsaIZbCot83tNMlNC03vhSIHzNroR+TwZ5YXFRTf6+zaddSwPSfobne5U3bo0M57BuE/yHrNH+j5IHp+AdzwWI0WeMIyOM3kmz6PDmwdPoxMmqc0YsNk3NRozdy6JxkyPhmIatUgeY54ScxIleBIGaP8oE0s90fuzyEyUXELu9ESGVsH2ILoeu2Z+PB2j5ZGTbx8/9OyvxPyEI2oAI6oP5OvvgLdc1NfF6HOql0dgXaR4BGOnGIRrmiechLnNKnavSC/wdjB07GQ0iN2FR4OQAYNS3DhlJzP4edY4HmaziT5PhQ9kk5sCZJtAteNggV0q3NcvG9dmckTYkBEh3pj3T+I3MrnXaBFGNEZLMsnYwb4fti3uPvD6xnVvHOjubXst4nB219vKl400zLl9Wbm9/rpiLvjsMPr9uud3NDTseG59JGf42SD3jqZs/romdHLxCC7aH1kc6ZyzZn6Z5h2Ch5WgbN6W2AHLroQOa2xDkzseCM15clDWch0vwU6nkAsS+hDJfS9XMmtPR2iJ/eLbzM5L26ivnNvzX3/PgT6RKOgD8J5JmEsjG8d/CXePwV9xMO+hT558Uvi8ovLqn1fo/oufPylh0U9lmbAniygsNaRqPBdH3JNjanKncbIt1bgmTqpQiuXxeMYgniqI554Rq+2kLdTpqHEHJU5fY9Dut2olLwXX9jYbuvK/ViNpdpe057qDcD1OYkA/l5mF6xlcY8r49WQXxDubk+tNvq25YdptzTlyK3O4VLk1ubB6QZFkiFzI45pncYeyK9f1NqVgfG+LfIAOU//+j15v+m3UtwFofocAGgaV3DG9xl/SmuMW75gu9EJLWPpPBJ82qgNjlLN6RaSSEfizEvCKIwIpII1zhVXYJ2MZTEdwtLhcfTgd24szY71g2pk743RoqMKLRc34Tu+1nirxzu8W3QyUyZlOK5raKTHQnxBaEVgMLs7mFRFIRjHMSsChOI1hLC8OSwJG8f0QU/CNwMOpJtuVKFow7cxOT1Dq9GMa52kLqzsdSO6uwnDhEzpb9QLHDETvmoENyP0uP2CyCB/8L8BiugZYpvIPCrmrpOUOgCVg0c3MUAtnYjF8D6vIeuZ7xJ5oE/UahdUKaZCVeqKjylRKh3gvMzK+mxW6tVWx8d0qZXTcZnRqUcJwJzda+zRaE3nwaaZ5L81MTOy9aJe8nXhtA76fuFy8tla4tiZ2bT0eHJUwhUq85QxPyzwenmXHeYXaM+m2M6rE287gmVPG2JIssWXFlhbZLy6PLBHl7kUPC6uMDO2d6KA5WOcxVEq/zdwI6yxOkGtTxJuKDAETn6KXnGL5HHO0raioGGovLm4fqqhY0eag2ytWzHU65+KzrU5n6xChyUlqL3NJQgOnUX4WnWTm7WU2RRYIsZ1dlz+X/p36VPSBGoXZ3bzRAr4Box7ntZkej3CKUcfuBAWWYGzwoike2jFFu5n9V/BzEo93hapCTU2hYDVdGgqGGhuqgyE6hGcANVZXVm9xtrU5ycSfyc+gQYcuv6vMlk6Iec9GajG1gdpFHaPCtVivrvHyrUDULR6xR1AyPsZm1mIPmYXDsm58yH3dy5fBh64Hyt+TOP8pVzCuseTDPXJNcNik4zvgMKglrSJ9cDgMh8M6/jY4XAGG+L0J2VTcAMF3NMELZ1ktTq3ytw2DvbTm+sC1N9x6legaPnctnxlyd60NBTd0ueG5umZ9p+twlrPUlO7DQ6l86Wne/1vZ+cc2cZ5x/N73fthOYgfnnMTBzg/nnJjMOMZ3iRMccEwaE0IKBDfywCSBELLuRyGDkQWSplOo0rRBhahlJaPbAmVibO3au4TCqm4aVEKt8lfViW4SdKqqqmq6/VNF1cqwz3vf984xDWPa/okvp/fOvrv33ud5n+d5vx+fs51+YTp5EK4SH1vRsNQnZRuKvlIYEB8bDDeRJgebI4d3rvul0yfZ7VoTe4noc9LN4FyoOyIIke6Q+p1Qb6SyMtLT4RbLzOYy0Q2OVgVceXmuQNU9O1d592+gEPx8ufWB9T0Pa62O/G/tCCOnHzqJdlYRpZOtsZIbcmUz6odEZbF/pbgifj/60LGrybGuzLFoWLrCLB+uMJqeLu7bKwS5lmW4KKBOp2/DOdQ3kW/FoomjOo1v8BNV+Ip1xteXTCcan7Cq6YSev8yhF+cq9FAWpsRWmDPQPgwULLGTHbrQKF4QjDzkog/l1SJmssprxTm2KINllWvFuSLiNRfhccouYmd4eaYiU1bZvF7xlJAIl1xhlYX1Orh1RVHWRuDBTK0V9Z+uwgF6W+qOtOfH0faZ5t2bbxwavTn16L59sembgz+4uqMvNB2NjuyRoBuKk5P1WJ+lYs05byg6fvVHsX9Mtg3+frzVJ80K1Vi/xTOpswNhPzeL7oeBciAfWRP3MOVLUvYGkMwkBtBaHgKglVlCjFccFhLvw3J7VgspOFIcRi08WaDrjpM64vtgtcAq8cVSA0+44wZaoD2CNQZfUr9+Gnw6fP0YN/SnoZ8Y4hf2zgwY2MRTT6Vy4VcpE31YPfvFF+B7ydNw12/VW4B/J3VZ0/VM/50p5vJRD5KoHgqjqj1ojPH7iZEx+xU+u1SmclUmDy0bRcVuJRxkZW0lGjjYVdZSkhXze5BNp+xGZMMVM6utNeOtGrBBfzRaBXR9sEEsA1gcdkXgTXtwva1D5xNdv+jmQt+feVxod3dtu/jJqXDH5B8G974y3Pqqf/uBxvjxLVVM/DfRyHfbqsH7g1fHWiMdY7cv7jXkPsuD8Tvqx7M31I9u9IdH58cSJ2KexPR8or9rQ9+Tmr0fSncybxN+cL3+BDkcnCWmlmOIJvzyDMeWneEULmb5nmSGM8RsXki1y9zI3WfYm/9qIuduSXfS/yQc1AA1Z8RvS65pUQuy0/o3ZXEInFFDn9BWEm8pNmHhTKyzVOhqAQPqy/SF1A7QrZ6FHyQ7GDgLn7t0LfVsagDbYyEdY85wc5SRakXvvwmvl1YYNLjnaPGw8P4v5zWAKF1rkeF1RmEsdy0ye52axxxaEvJSIJvNGVVh0RsBGATwLeAHwxfU0AvqazO0bX/yr9yBr8/TI5Jme+NUkv2APoO8vgaqjUpQeJlqiXTFq/X+jSIueolKGU3cfHQjt5AbucZCIns4qGtDnb0dfbassRa8yeaXCLWNpP9IXtSbKFtZjrv4Pn1PUneVdR88WrhI17nVArWsHkoi0ZR4MDESDR3au620emfPE5GWobi/LjG6uXGgJ+byxPCeo98OTAzvSLzo5zdsjfk8WxoFeKqiuXU72myoOLJtz0nY3nI8EfS2xb2B3Y9Ui7uOof+7g97WuNcfb6kJ7D6+NX7kaKyyrUkoD7bVoKMqK4LtNfHBwxRIy+pbcIk7QfnQc5G9RKtfdvgVG6OVp+V9qAgaZkARMPrN4sGBItqraUo6rPMgzy5oxXtEXY1uKAqSVyNYYK0LfjPYaLAAG4f+aCsGOgWf11q10VdqzDWZjOaajsHO8l6X4K6z+jZ6i40shCxjynHOni1/VP3zsRxYGjt5cByMgPzEpUj/T/sli3k0F5Z3Th3a8O5Ht3fumY3eesuMxohGUMdA+jIZ/+MP0gfktX7FwS7OVzhwYYqHJfEQbRD/DzgCZa0Hy6j50ZYDB+sF98MRBfT/BS448pD9YHZ/rCawDDQINoLLhHAQaurq66mpW1PfSPSJR+mvmHPIt62mZOiXrRJ5bPkitqtmSTEwOGODnVzdp20GQr2LR440L9FSoYtG76sh/PrrwLmgroaxhZcX3lMXFiCVevGN0c+ngfk0FsA8rS5Nf57RU+YYnilDb1MO+k5dERkXwGL3FNtrogwLCk2gsJd+M9lBzyeTNMNNTcHGE6D3Z+pdNTmjnQei85T81/NU1ZvwqfB5ttN0MkXPwampOzOAAYYZ9ZVx8nuG03+hl9gn0ZiFJkR8sKABex21qOsV4IkYPbzr5q6z4Ifq82e8vX37XgpPNkXGImn469+BsVdT3tS6rmtvX42PqEsj46lxaMBcX4piapga9Ls8D+YXsVKwgfHqH3oMJYBGU3wI5udAzN2kz7BpUjtwUsujoSkRKTZTynN1rXoTt/gNHKdVJMBaG5md8RqHk7fhIZ03IvNr4/GmDZtfXivy1ep959flOy2k4hcvwHIWaWRbIsuPiwkopcSkV1M8wO0kNgDZ5PtmCJjief5U1Af5a+qvrkEY9tWGw7W+MD1x6Y+nnrsYa7h87xaOhtET4BOCS9y0CfM90kuMl6ulqjDnHddJKKsENJfJz1RKlGtX6BKxIKURB5+q/bKbXKhgJjwTwU2QDi50oW6SM3TjCxW0SQ4uuMPVh3ZBI7srThyFLyEMtNzMZeng2GwmtJ6kC0uBVCgQPGnz45NbvRef7tjNlNeTlKino+7KZ59hVulrAxPby/Nc9xzLWdFNzGBu3huyTi+l/g1HKmoyAAB42mNgZGBgYGLi0W9tmhjPb/OVQZ6DAQQu7ZnzEUb/m/DPmVOWfR2Qy8HABBIFAGlvDYkAeNpjYGRgYL/2t5GBgbPl34R/EzhlGYAiKOA3AJ9tByh42m2TX0hUQRTGv/lz72qUILXQH2WRJSoWTFk1Fd1CImnpISokMqRNt8VcWzCkRBYRrQilrEDoZSMJIykRQwQRX5NAooeS9sGnImLrKXqR2ts3Vxcy9sKPM/fMmTlnvjMjv+M4+MkpogDxB4PyAfr0VdToIGrtecTsdUTlQbyX19BNAsqDBs6F5B70qzAS4iN65AsnS18LWSEXyG6znkRJG4mQJnKK60ZJD8ftZh9jVRoh+zfaLYUSvY5+HUevtQtJ/QpDOknW+F+OXlmKl/oSyvQKY5K4Z9cjaXViwNqPhJ5kzAn6zdwUc1+G3/LRvwSvpxFencJOPYi9ugOnZQVSpmbaeuavJNA+8VQfwhldjYh6zLqrSRHPPsK9KnBRBxAVX6lPofNJb0O7PItZu5VnDfB8jYjpOnRxHJHLGFXv0KC245jxqw/wWp+p2zMnq37Aq97gPPOWiTmM07o65bR38wapfxB+tYBuvQ/L9hL65BoOUyOjY8horl9jnPUWq2o3NszxE/YsJr6gS6VElcwwLs1zpDFuNM1HQRW00dnV+B9kqTNhdKZ9RFbZhx05jfPi24qrMXuhj1APo2ce7Dmcc89atBUpnJ9S4KFcdDIy7GRcXXP6/k+Q9zCP32jMHFFjudekuSdyEbOeDiTst4wx9QV5X32YcgmLYrf3PtEsWzFA35heECetGva8Dp1qFfBMAzkr77NXGdK8AX7R3qXtZgx7k4P1BQqubCBvYprMuG+mA0Pklhrh+BsqXeKY0Ecxbd/GHbNX4TBicph3bBgR0ZQdM/nMW/KUU7/raLNKqW8d39M8/HYJWuRzZ2bzvYXM/CY39AGuk/THUfsXj6fKaAAAAHjaY2Bg0IHCHIZ5jDVMDkz/mF+wcLBYsKSxrGB5xarE6sCaxbqA9Q+bElsX2z/2APYjHG4cDZwanCs4n3DpcTlxpXBVcD3jvsTDwVPBc4ZXgNeHt4n3B58Bnx9fG98evkf8evxF/OcExARmCHwQPCP4R8hBaJJwivA04VPCP0Q0RGJEJolsEDkj8kY0R/ScmJLYBHEGcTfxcxJCEn4S8yR5JG0kN0j+kYqQ2ietJZ0mwyWzQOaDrIzsNNljcgJydnJb5M7Ju8i3AOEhBTuFH4pJSmJKIcosyi3KS5TPKN9SaVNZovJD1U01TXWF6jU1G7VJalvU1dTT1Jepv9EI0zil6aO5QMtGq0XrhLaYdof2Ju07Ojw6UToHdG10F+lx6dXpS+ivMDAxaDK4ZKhnuMTwkZGR0R5jN+MrJjmmWqbvzI6ZT7LQsVhmqWC5zCrMqsFqldUtaw3rXTZONits+Wxb7BTsdtkz2PfYP3KwcJjnqOZY5XjPKcepy+mUs4TzFBcvlw2uLq5Zrn2uZ1x/uAW4dbidcvvlXue+Agfc5n7E/ZL7Kw8mDymPII8uj0OeGp59nl+8jLzavPZ5nfFW8VbxMfDx8ynyafJp8uXyLfB94yfl5+fX5S/l3+T/JUAnICCgJGBOwJ5Ak8BlANnKpqYAAQAAAPsAiAAHAAAAAAACAAEAAgAWAAABAAFRAAAAAHjalVNLSgNBFKyZiZ8gBNyIuJBBRKLomJ+iARExZCEugoJuXBh1EoNjEmcSNTuP4RFceQBPEHXnzht4CrH6TUdCElFpprv6dXW9et09AMbxBgtGJArgnl+IDcxwFmITMTxpbOEEbY0jSBkLGg9h1jjSeBiOcafxCArGo8ajiBufGkcxbc5pPAbHzGkcw7Hpa9zGhNnx9oyE+aHxC2LWpMavxFrn3cKUlcE2aqijBR8VlHGOBmzEcYp5jikk2FJY/MYrRAUUyS6Sc44m+S4ehHEjzaFa77pDZZ+9zbYFj83uyhfIzOXocrxmf0ZuAXnGc2RVpQ+o61G1JQ58ut4js8wMnuTrd3VIjs/VM7qqsHeRlb35gaqh5lKParar8t8d2T27D6SigNwa9yglR7TWelT/7idk2n35K3KKRX4NOQVV7aXsuGCshtIP9zYoZg84OcWrMqqyHBAHUpUnlTXlFht0k8Uy22/v4H/sZWZqcrUunhqMFqXyW2xil/lPyayKmyr5G0jSvcu/riRnrl5zUk79UN6VjR2pREXT0q/TR5pjFhl53epekliVqkvkqpNXbsObdDkPeGMd7X1cMVLhmnrB3hfRqaduAHjabdBVc5NREIDhd9tUUncv7vrla1PBa8GKu1NImwRCPUBxd7fBXQYY3GVgBncZ3OES/QNcQNoc7tiLfWZ3Zs/uHLyoiT9lTOF/8RvES7zxxoAPvvjhj5EAAgkimBBCCSOcCCKJIpoYYokjngQSSSKZWtSmDnWpR30a0JBGNKYJTWlGc1rQkla0RsOETgqpmEkjnQwyaUNb2tGeDnSkE1lkk0MueVjoTBe60o3u5NODnvSiN33oSz/6M4CBDGIwQxjKMIYzgpGMYjQFYmAP85jPBhawgqVs4yB7xYclvGUua1nOIq7zke0cYjdHuMttjjKGsazCyn0KucM9HvOAhzziK0U84wlPOYaN1bzkOS+w852fLGYcDsYzASfF7KSEMkoppwIXlUxkEt+Y7P7rKqYynWmcZxczmcEsZvODX1zklfiKH8c5wSX285ovvOM9H/jMGz6xgy3iL0YJkEAJkmAJkVAJk3CJkEiJkmhOckpiOMs5bnCaM9xkDtdYKLEcljhucYWrXJZ4SWAZG9nMJvaxhq0cYCXrWM8FSZQkSfa1OatK7SYPup+r2KFpWZoy15BvLak0ON2puqNrmqY0KXVlijJVaVamKdOVGcpMZZZHk3rXZAoocthc5YXWggq7saDI4b5C/zekqyW6xaPZYshzlZfUFGZLTrWWbM9lbvW/uq2l23jaRc3BDsFAEAbgXWW1qhSLA5K6iGQvQryBOnCRhqSbiMfgyMWRd/AGUyfxLp6lpox1m+/PPzMPnp6BX9gS7FWccH7VyVyouA++XoKMcDjpHgi1jRlYQQiWmoEThHfrlVMf2AjnQCgi7A1BIIoLQgEhJoQ8ojAklLJra4KLKA0IZYTb+YKDR99rmHq3nEqs+R7pI2tjw2oQPpnPp8wkFSxUu4b1rOAd03+hkSV1nv8nElcaO8MmUkaGLWRzZNhGtjo/apDqDQbBXuYAAAABVpbscgAA) format(\"woff\");font-weight:400;font-style:normal}a,abbr,acronym,address,applet,article,aside,audio,b,big,blockquote,body,canvas,caption,center,cite,code,dd,del,details,dfn,div,dl,dt,em,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,hgroup,html,i,iframe,img,ins,kbd,label,legend,li,mark,menu,nav,object,ol,p,pre,q,s,samp,section,small,span,strike,strong,sub,summary,sup,table,tbody,td,tfoot,th,thead,time,tr,tt,u,ul,var,video{margin:0;padding:0;border:0;outline:0;font-size:100%;font:inherit;vertical-align:baseline}button,input,textarea{outline:0}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote:after,blockquote:before,q:after,q:before{content:\"\";content:none}html{box-sizing:border-box}*,:after,:before{box-sizing:inherit}body,html{font-weight:400;font-family:PFDinDisplayPro-Regular,PFDinDisplayProRegularWebfont,sans-serif;-webkit-font-smoothing:antialiased;font-size:17px;line-height:1.4;height:100%;color:#fff}body.platform-ios,html.platform-ios{font-size:16px}body{background-color:#333;padding:0 .75rem .7rem}em{font-style:italic}strong{font-weight:400;font-family:PFDinDisplayPro-Medium,PFDinDisplayProRegularWebfont,sans-serif}.platform-android strong{font-family:PFDinDisplayProRegularWebfont,sans-serif;font-weight:700;letter-spacing:.025em}strong{color:#ff4700}a{color:#858585}a:hover{color:inherit}h1,h2,h3,h4{text-transform:uppercase;font-weight:400;font-family:PFDinDisplayPro-Medium,PFDinDisplayProRegularWebfont,sans-serif}.platform-android h1,.platform-android h2,.platform-android h3,.platform-android h4{font-family:PFDinDisplayProRegularWebfont,sans-serif;font-weight:700;letter-spacing:.025em}h1,h2,h3,h4{text-transform:uppercase;position:relative;top:.05rem;line-height:.9}h1{font-size:2rem;line-height:2.8rem}h2{font-size:1.8rem;line-height:2.8rem}h3{font-size:1.5rem;line-height:2.8rem}h4{font-size:1.2rem;line-height:1.4rem}h5{font-size:1rem;line-height:1.4rem}h6{font-size:.8rem;line-height:1.4rem}input{font-family:inherit;font-size:inherit;line-height:inherit}label{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;-webkit-box-align:center;-webkit-align-items:center;align-items:center;padding:.7rem .75rem}label .input{white-space:nowrap;display:-webkit-box;display:-webkit-flex;display:flex;max-width:50%;margin-left:.75rem}label.invalid .input:after{content:\"!\";display:inline-block;color:#fff;background:#ff4700;border-radius:.55rem;width:1.1rem;text-align:center;height:1.1rem;font-size:.825rem;vertical-align:middle;line-height:1.1rem;box-shadow:0 .1rem .1rem #2f2f2f;font-weight:400;font-family:PFDinDisplayPro-Medium,PFDinDisplayProRegularWebfont,sans-serif}.platform-android label.invalid .input:after{font-family:PFDinDisplayProRegularWebfont,sans-serif;font-weight:700;letter-spacing:.025em}label.invalid .input:after{-webkit-box-flex:0;-webkit-flex:0 0 1.1rem;flex:0 0 1.1rem;margin-left:.3rem}.hide{display:none!important}.tap-highlight{-webkit-tap-highlight-color:rgba(255,255,255,.1)}.tap-highlight:active{background-color:rgba(255,255,255,.1)}.tap-highlight{border-radius:.25rem}.component{padding-top:.7rem}.component.disabled{pointer-events:none}.component.disabled>*{opacity:.25}.section{background:#484848;border-radius:.25rem;box-shadow:#2f2f2f 0 .15rem .25rem}.section>.component{padding-bottom:.7rem;padding-right:.75rem;padding-left:.75rem;position:relative;margin-top:1rem}.section>.component:not(.hide)~.component{margin-top:0}.section>.component:first-child:after{display:none}.section>.component:after{content:\"\";background:#666;display:block;position:absolute;top:0;left:.375rem;right:.375rem;height:1px;pointer-events:none}.section>.component:not(.hide):after{display:none}.section>.component:not(.hide)~.component:not(.hide):after{display:block}.section>.component-heading:first-child{background:#414141;border-radius:.25rem .25rem 0 0}.section>.component-heading:first-child:after,.section>.component-heading:first-child~.component:not(.hide):after{display:none}.section>.component-heading:first-child~.component:not(.hide)~.component:not(.hide):after{display:block}.description{padding:0 .75rem .7rem;font-size:.9rem;line-height:1.4rem;color:#a4a4a4;text-align:left}.inputs{display:block;width:100%;border-collapse:collapse}.button,button{font-weight:400;font-family:PFDinDisplayPro-Medium,PFDinDisplayProRegularWebfont,sans-serif}.platform-android .button,.platform-android button{font-family:PFDinDisplayProRegularWebfont,sans-serif;font-weight:700;letter-spacing:.025em}.button,button{font-size:1rem;line-height:1.4rem;text-transform:uppercase;background-color:#767676;border-radius:.25rem;border:none;display:inline-block;color:#fff;min-width:12rem;text-align:center;margin:0 auto .7rem;padding:.6rem;-webkit-tap-highlight-color:#858585}.button:active,button:active{background-color:#858585}.platform-ios .button,.platform-ios button{padding:.5rem}.button.primary,.button[type=submit],button.primary,button[type=submit]{background-color:#ff4700;-webkit-tap-highlight-color:red}.button.primary:active,.button[type=submit]:active,button.primary:active,button[type=submit]:active{background-color:red}a.button{text-decoration:none;color:#fff}</style><meta name=\"viewport\"content=\"width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no\"><script>window.returnTo=\"$$RETURN_TO$$\",window.clayConfig=$$CONFIG$$,window.claySettings=$$SETTINGS$$,window.customFn=$$CUSTOM_FN$$,window.clayComponents=$$COMPONENTS$$,window.clayMeta=$$META$$</script></head><body><form id=\"main-form\"class=\"inputs\"></form><script>(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c=\"function\"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error(\"Cannot find module '\"+i+\"'\");throw a.code=\"MODULE_NOT_FOUND\",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u=\"function\"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){\n'use strict';\n\nvar minified = require('./vendor/minified');\nvar ClayConfig = require('./lib/clay-config');\n\nvar $ = minified.$;\nvar _ = minified._;\n\nvar config = _.extend([], window.clayConfig || []);\nvar settings = _.extend({}, window.claySettings || {});\nvar returnTo = window.returnTo || 'pebblejs://close#';\nvar customFn = window.customFn || function() {};\nvar clayComponents = window.clayComponents || {};\nvar clayMeta = window.clayMeta || {};\n\nvar platform = window.navigator.userAgent.match(/android/i) ? 'android' : 'ios';\ndocument.documentElement.classList.add('platform-' + platform);\n\n// Register the passed components\n_.eachObj(clayComponents, function(key, component) {\n  ClayConfig.registerComponent(component);\n});\n\nvar $mainForm = $('#main-form');\nvar clayConfig = new ClayConfig(settings, config, $mainForm, clayMeta);\n\n// add listeners here\n$mainForm.on('submit', function() {\n  // Set the return URL depending on the runtime environment\n  location.href = returnTo +\n                  encodeURIComponent(JSON.stringify(clayConfig.serialize()));\n});\n\n// Run the custom function in the context of the ClayConfig\ncustomFn.call(clayConfig, minified);\n\n// Now that we have given the dev's custom code to run and attach listeners,\n// we build the config\nclayConfig.build();\n\n},{\"./lib/clay-config\":2,\"./vendor/minified\":8}],2:[function(require,module,exports){\n'use strict';\n\n/**\n * A Clay config Item\n * @typedef {Object} Clay~ConfigItem\n * @property {string} type\n * @property {string|boolean|number} defaultValue\n * @property {string} [messageKey]\n * @property {string} [id]\n * @property {string} [label]\n * @property {Object} [attributes]\n * @property {Array} [options]\n * @property {Array} [items]\n * @property {Array} [capabilities]\n */\n\nvar HTML = require('../vendor/minified').HTML;\nvar _ = require('../vendor/minified')._;\nvar ClayItem = require('./clay-item');\nvar utils = require('../lib/utils');\nvar ClayEvents = require('./clay-events');\nvar componentStore = require('./component-registry');\nvar manipulators = require('./manipulators');\n\n/**\n * @extends ClayEvents\n * @param {Object} settings - setting that were set from a previous session\n * @param {Array|Object} config\n * @param {M} $rootContainer\n * @param {Object} meta\n * @constructor\n */\nfunction ClayConfig(settings, config, $rootContainer, meta) {\n  var self = this;\n\n  var _settings = _.copyObj(settings);\n  var _items;\n  var _itemsById;\n  var _itemsByMessageKey;\n  var _isBuilt;\n\n  /**\n   * Initialize the item arrays and objects\n   * @private\n   * @return {void}\n   */\n  function _initializeItems() {\n    _items = [];\n    _itemsById = {};\n    _itemsByMessageKey = {};\n    _isBuilt = false;\n  }\n\n  /**\n   * Add item(s) to the config\n   * @param {Clay~ConfigItem|Array} item\n   * @param {M} $container\n   * @return {void}\n   */\n  function _addItems(item, $container) {\n    if (Array.isArray(item)) {\n      item.forEach(function(item) {\n        _addItems(item, $container);\n      });\n    } else if (utils.includesCapability(meta.activeWatchInfo, item.capabilities)) {\n      if (item.type === 'section') {\n        var $wrapper = HTML('<div class=\"section\">');\n        $container.add($wrapper);\n        _addItems(item.items, $wrapper);\n      } else {\n        var _item = _.copyObj(item);\n        _item.clayId = _items.length;\n\n        var clayItem = new ClayItem(_item).initialize(self);\n\n        if (_item.id) {\n          _itemsById[_item.id] = clayItem;\n        }\n\n        if (_item.messageKey) {\n          _itemsByMessageKey[_item.messageKey] = clayItem;\n        }\n\n        _items.push(clayItem);\n\n        // set the value of the item via the manipulator to ensure consistency\n        var value = typeof _settings[_item.messageKey] !== 'undefined' ?\n          _settings[_item.messageKey] :\n          _item.defaultValue;\n\n        clayItem.set(typeof value !== 'undefined' ? value : '');\n\n        $container.add(clayItem.$element);\n      }\n    }\n  }\n\n  /**\n   * Throws if the config has not been built yet.\n   * @param {string} fnName\n   * @returns {boolean}\n   * @private\n   */\n  function _checkBuilt(fnName) {\n    if (!_isBuilt) {\n      throw new Error(\n        'ClayConfig not built. build() must be run before ' +\n        'you can run ' + fnName + '()'\n      );\n    }\n    return true;\n  }\n\n  self.meta = meta;\n  self.$rootContainer = $rootContainer;\n\n  self.EVENTS = {\n    /**\n     * Called before framework has initialized. This is when you would attach your\n     * custom components.\n     * @const\n     */\n    BEFORE_BUILD: 'BEFORE_BUILD',\n\n    /**\n     * Called after the config has been parsed and all components have their initial\n     * value set\n     * @const\n     */\n    AFTER_BUILD: 'AFTER_BUILD',\n\n    /**\n     * Called if .build() is executed after the page has already been built and\n     * before the existing content is destroyed\n     * @const\n     */\n    BEFORE_DESTROY: 'BEFORE_DESTROY',\n\n    /**\n     * Called if .build() is executed after the page has already been built and after\n     * the existing content is destroyed\n     * @const\n     */\n    AFTER_DESTROY: 'AFTER_DESTROY'\n  };\n  utils.updateProperties(self.EVENTS, {writable: false});\n\n  /**\n   * @returns {Array.<ClayItem>}\n   */\n  self.getAllItems = function() {\n    _checkBuilt('getAllItems');\n    return _items;\n  };\n\n  /**\n   * @param {string} messageKey\n   * @returns {ClayItem}\n   */\n  self.getItemByMessageKey = function(messageKey) {\n    _checkBuilt('getItemByMessageKey');\n    return _itemsByMessageKey[messageKey];\n  };\n\n  /**\n   * @param {string} id\n   * @returns {ClayItem}\n   */\n  self.getItemById = function(id) {\n    _checkBuilt('getItemById');\n    return _itemsById[id];\n  };\n\n  /**\n   * @param {string} type\n   * @returns {Array.<ClayItem>}\n   */\n  self.getItemsByType = function(type) {\n    _checkBuilt('getItemsByType');\n    return _items.filter(function(item) {\n      return item.config.type === type;\n    });\n  };\n\n  /**\n   * @param {string} group\n   * @returns {Array.<ClayItem>}\n   */\n  self.getItemsByGroup = function(group) {\n    _checkBuilt('getItemsByGroup');\n    return _items.filter(function(item) {\n      return item.config.group === group;\n    });\n  };\n\n  /**\n   * @returns {Object}\n   */\n  self.serialize = function() {\n    _checkBuilt('serialize');\n\n    _settings = {};\n\n    _.eachObj(_itemsByMessageKey, function(messageKey, item) {\n      _settings[messageKey] = {\n        value: item.get()\n      };\n\n      if (item.precision) {\n        _settings[messageKey].precision = item.precision;\n      }\n    });\n    return _settings;\n  };\n\n  // @todo maybe don't do this and force the static method\n  self.registerComponent = ClayConfig.registerComponent;\n\n  /**\n   * Empties the root container\n   * @returns {ClayConfig}\n   */\n  self.destroy = function() {\n    var el = $rootContainer[0];\n    self.trigger(self.EVENTS.BEFORE_DESTROY);\n    while (el.firstChild) {\n      el.removeChild(el.firstChild);\n    }\n    _initializeItems();\n    self.trigger(self.EVENTS.AFTER_DESTROY);\n    return self;\n  };\n\n  /**\n   * Build the config page. This must be run before any of the get methods can be run\n   * If you call this method after the page has already been built, teh page will be\n   * destroyed and built again.\n   * @returns {ClayConfig}\n   */\n  self.build = function() {\n    if (_isBuilt) {\n      self.destroy();\n    }\n    self.trigger(self.EVENTS.BEFORE_BUILD);\n    _addItems(self.config, $rootContainer);\n    _isBuilt = true;\n    self.trigger(self.EVENTS.AFTER_BUILD);\n    return self;\n  };\n\n  _initializeItems();\n\n  // attach event methods\n  ClayEvents.call(self, $rootContainer);\n\n  // prevent external modifications of properties\n  utils.updateProperties(self, { writable: false, configurable: false });\n\n  // expose the config to allow developers to update it before the build is run\n  self.config = config;\n}\n\n/**\n * Register a component to Clay. This must be called prior to .build();\n * @param {Object} component - the clay component to register\n * @param {string} component.name - the name of the component\n * @param {string} component.template - HTML template to use for the component\n * @param {string|Object} component.manipulator - methods to attach to the component\n * @param {function} component.manipulator.set - set manipulator method\n * @param {function} component.manipulator.get - get manipulator method\n * @param {Object} [component.defaults] - template defaults\n * @param {function} [component.initialize] - method to scaffold the component\n * @return {boolean} - Returns true if component was registered correctly\n */\nClayConfig.registerComponent = function(component) {\n  var _component = _.copyObj(component);\n\n  if (componentStore[_component.name]) {\n    console.warn('Component: ' + _component.name +\n                 ' is already registered. If you wish to override the existing' +\n                 ' functionality, you must provide a new name');\n    return false;\n  }\n\n  if (typeof _component.manipulator === 'string') {\n    _component.manipulator = manipulators[component.manipulator];\n\n    if (!_component.manipulator) {\n      throw new Error('The manipulator: ' + component.manipulator +\n                      ' does not exist in the built-in manipulators.');\n    }\n  }\n\n  if (!_component.manipulator) {\n    throw new Error('The manipulator must be defined');\n  }\n\n  if (typeof _component.manipulator.set !== 'function' ||\n      typeof _component.manipulator.get !== 'function') {\n    throw new Error('The manipulator must have both a `get` and `set` method');\n  }\n\n  if (_component.style) {\n    var style = document.createElement('style');\n    style.type = 'text/css';\n    style.appendChild(document.createTextNode(_component.style));\n    document.head.appendChild(style);\n  }\n\n  componentStore[_component.name] = _component;\n  return true;\n};\n\nmodule.exports = ClayConfig;\n\n},{\"../lib/utils\":7,\"../vendor/minified\":8,\"./clay-events\":3,\"./clay-item\":4,\"./component-registry\":5,\"./manipulators\":6}],3:[function(require,module,exports){\n'use strict';\n\nvar $ = require('../vendor/minified').$;\nvar _ = require('../vendor/minified')._;\n\n/**\n * Attaches event methods to the context.\n * Call with ClayEvents.call(yourObject, $eventTarget)\n * @param {EventEmitter|M} $eventTarget - An object that will be used as the event\n * target. Must implement EventEmitter\n * @constructor\n */\nfunction ClayEvents($eventTarget) {\n  var self = this;\n  var _eventProxies = [];\n\n  /**\n   * prefixes events with \"|\"\n   * @param {string} events\n   * @returns {string}\n   * @private\n   */\n  function _transformEventNames(events) {\n    return events.split(' ').map(function(event) {\n      return '|' + event.replace(/^\\|/, '');\n    }).join(' ');\n  }\n\n  /**\n   * @param {function} handler\n   * @param {function} proxy\n   * @returns {function}\n   * @private\n   */\n  function _registerEventProxy(handler, proxy) {\n    var eventProxy = _.find(_eventProxies, function(item) {\n      return item.handler === handler ? item : null;\n    });\n\n    if (!eventProxy) {\n      eventProxy = { handler: handler, proxy: proxy };\n      _eventProxies.push(eventProxy);\n    }\n    return eventProxy.proxy;\n  }\n\n  /**\n   * @param {function} handler\n   * @returns {function}\n   * @private\n   */\n  function _getEventProxy(handler) {\n    return _.find(_eventProxies, function(item) {\n      return item.handler === handler ? item.proxy : null;\n    });\n  }\n\n  /**\n   * Attach an event listener to the item.\n   * @param {string} events - a space separated list of events\n   * @param {function} handler\n   * @returns {ClayEvents}\n   */\n  self.on = function(events, handler) {\n    var _events = _transformEventNames(events);\n    var self = this;\n    var _proxy = _registerEventProxy(handler, function() {\n      handler.apply(self, arguments);\n    });\n    $eventTarget.on(_events, _proxy);\n    return self;\n  };\n\n  /**\n   * Remove the given event handler. NOTE: This will remove the handler from all\n   * registered events\n   * @param {function} handler\n   * @returns {ClayEvents}\n   */\n  self.off = function(handler) {\n    var _proxy = _getEventProxy(handler);\n    if (_proxy) {\n      $.off(_proxy);\n    }\n    return self;\n  };\n\n  /**\n   * Trigger an event.\n   * @param {string} name - a single event name to trigger\n   * @param {Object} [eventObj] - an object to pass to the event handler,\n   * provided the handler does not have custom arguments.\n   * @returns {ClayEvents}\n   */\n  self.trigger = function(name, eventObj) {\n    $eventTarget.trigger(name, eventObj);\n    return self;\n  };\n}\n\nmodule.exports = ClayEvents;\n\n},{\"../vendor/minified\":8}],4:[function(require,module,exports){\n'use strict';\n\nvar componentRegistry = require('./component-registry');\nvar minified = require('../vendor/minified');\nvar utils = require('../lib/utils');\nvar ClayEvents = require('./clay-events');\n\nvar _ = minified._;\nvar HTML = minified.HTML;\n\n/**\n * @extends ClayEvents\n * @param {Clay~ConfigItem} config\n * @constructor\n */\nfunction ClayItem(config) {\n  var self = this;\n\n  var _component = componentRegistry[config.type];\n\n  if (!_component) {\n    throw new Error('The component: ' + config.type + ' is not registered. ' +\n                    'Make sure to register it with ClayConfig.registerComponent()');\n  }\n\n  var _templateData = _.extend({}, _component.defaults || {}, config);\n\n  /** @type {string|null} */\n  self.id = config.id || null;\n\n  /** @type {string|null} */\n  self.messageKey = config.messageKey || null;\n\n  /** @type {Object} */\n  self.config = config;\n\n  /** @type {M} */\n  self.$element = HTML(_component.template.trim(), _templateData);\n\n  /** @type {M} */\n  self.$manipulatorTarget = self.$element.select('[data-manipulator-target]');\n\n  // this caters for situations where the manipulator target is the root element\n  if (!self.$manipulatorTarget.length) {\n    self.$manipulatorTarget = self.$element;\n  }\n\n  /**\n   * Run the initializer if it exists and attaches the css to the head.\n   * Passes minified as the first param\n   * @param {ClayConfig} clay\n   * @returns {ClayItem}\n   */\n  self.initialize = function(clay) {\n    if (typeof _component.initialize === 'function') {\n      _component.initialize.call(self, minified, clay);\n    }\n    return self;\n  };\n\n  // attach event methods\n  ClayEvents.call(self, self.$manipulatorTarget);\n\n  // attach the manipulator methods to the clayItem\n  _.eachObj(_component.manipulator, function(methodName, method) {\n    self[methodName] = method.bind(self);\n  });\n\n  // prevent external modifications of properties\n  utils.updateProperties(self, { writable: false, configurable: false });\n}\n\nmodule.exports = ClayItem;\n\n},{\"../lib/utils\":7,\"../vendor/minified\":8,\"./clay-events\":3,\"./component-registry\":5}],5:[function(require,module,exports){\n'use strict';\n\n// module is blank because we dynamically add components\nmodule.exports = {};\n\n},{}],6:[function(require,module,exports){\n'use strict';\n\nvar _ = require('../vendor/minified')._;\n\n/**\n * @returns {ClayItem|ClayEvents}\n * @extends {ClayItem}\n */\nfunction disable() {\n  if (this.$manipulatorTarget.get('disabled')) { return this; }\n  this.$element.set('+disabled');\n  this.$manipulatorTarget.set('disabled', true);\n  return this.trigger('disabled');\n}\n\n/**\n * @returns {ClayItem|ClayEvents}\n * @extends {ClayItem}\n */\nfunction enable() {\n  if (!this.$manipulatorTarget.get('disabled')) { return this; }\n  this.$element.set('-disabled');\n  this.$manipulatorTarget.set('disabled', false);\n  return this.trigger('enabled');\n}\n\n/**\n * @returns {ClayItem|ClayEvents}\n * @extends {ClayItem}\n */\nfunction hide() {\n  if (this.$element[0].classList.contains('hide')) { return this; }\n  this.$element.set('+hide');\n  return this.trigger('hide');\n}\n\n/**\n * @returns {ClayItem|ClayEvents}\n * @extends {ClayItem}\n */\nfunction show() {\n  if (!this.$element[0].classList.contains('hide')) { return this; }\n  this.$element.set('-hide');\n  return this.trigger('show');\n}\n\nmodule.exports = {\n  html: {\n    get: function() {\n      return this.$manipulatorTarget.get('innerHTML');\n    },\n    set: function(value) {\n      if (this.get() === value.toString(10)) { return this; }\n      this.$manipulatorTarget.set('innerHTML', value);\n      return this.trigger('change');\n    },\n    hide: hide,\n    show: show\n  },\n  button: {\n    get: function() {\n      return this.$manipulatorTarget.get('innerHTML');\n    },\n    set: function(value) {\n      if (this.get() === value.toString(10)) { return this; }\n      this.$manipulatorTarget.set('innerHTML', value);\n      return this.trigger('change');\n    },\n    disable: disable,\n    enable: enable,\n    hide: hide,\n    show: show\n  },\n  val: {\n    get: function() {\n      let value = this.$manipulatorTarget.get('value');\n      switch (this.config.serializeValueAs) {\n        case 'integer':\n          let integerValue = Math.trunc(Number.parseInt(value, 10));\n          return Number.isNaN(integerValue) ? 0 : integerValue;\n        default:\n          return value;\n      }\n    },\n    set: function(value) {\n      let currentValue = this.$manipulatorTarget.get('value');\n      if (typeof currentValue !== 'undefined' &&\n        currentValue === value.toString(10)) { return this; }\n      this.$manipulatorTarget.set('value', value);\n      return this.trigger('change');\n    },\n    disable: disable,\n    enable: enable,\n    hide: hide,\n    show: show\n  },\n  slider: {\n    get: function() {\n      return parseFloat(this.$manipulatorTarget.get('value'));\n    },\n    set: function(value) {\n      var initVal = this.get();\n      this.$manipulatorTarget.set('value', value);\n      if (this.get() === initVal) { return this; }\n      return this.trigger('change');\n    },\n    disable: disable,\n    enable: enable,\n    hide: hide,\n    show: show\n  },\n  checked: {\n    get: function() {\n      return this.$manipulatorTarget.get('checked');\n    },\n    set: function(value) {\n      if (!this.get() === !value) { return this; }\n      this.$manipulatorTarget.set('checked', !!value);\n      return this.trigger('change');\n    },\n    disable: disable,\n    enable: enable,\n    hide: hide,\n    show: show\n  },\n  radiogroup: {\n    get: function() {\n      let value = this.$element.select('input:checked').get('value');\n      switch (this.config.serializeValueAs) {\n        case 'integer':\n          let integerValue = Math.trunc(Number.parseInt(value, 10));\n          return Number.isNaN(integerValue) ? 0 : integerValue;\n        default:\n          return value;\n      }\n    },\n    set: function(value) {\n      let currentValue = this.$element.select('input:checked').get('value');\n      if (typeof currentValue !== 'undefined' &&\n        currentValue === value.toString(10)) { return this; }\n      this.$element\n        .select('input[value=\"' + value.toString(10).replace('\"', '\\\\\"') + '\"]')\n        .set('checked', true);\n      return this.trigger('change');\n    },\n    disable: disable,\n    enable: enable,\n    hide: hide,\n    show: show\n  },\n  checkboxgroup: {\n    get: function() {\n      var result = [];\n      this.$element.select('input').each(function(item) {\n        result.push(!!item.checked);\n      });\n      return result;\n    },\n    set: function(values) {\n      var self = this;\n      values = Array.isArray(values) ? values : [];\n\n      while (values.length < this.get().length) {\n        values.push(false);\n      }\n\n      if (_.equals(this.get(), values)) { return this; }\n\n      self.$element.select('input')\n        .set('checked', false)\n        .each(function(item, index) {\n          item.checked = !!values[index];\n        });\n\n      return self.trigger('change');\n    },\n    disable: disable,\n    enable: enable,\n    hide: hide,\n    show: show\n  },\n  color: {\n    get: function() {\n      return parseInt(this.$manipulatorTarget.get('value'), 10) || 0;\n    },\n    set: function(value) {\n      value = this.roundColorToLayout(value || 0);\n\n      if (this.get() === value) { return this; }\n      this.$manipulatorTarget.set('value', value);\n      return this.trigger('change');\n    },\n    disable: disable,\n    enable: enable,\n    hide: hide,\n    show: show\n  }\n};\n\n},{\"../vendor/minified\":8}],7:[function(require,module,exports){\n'use strict';\n\n/**\n * Batch update all the properties of an object.\n * @param {Object} obj\n * @param {Object} descriptor\n * @param {boolean} [descriptor.configurable]\n * @param {boolean} [descriptor.enumerable]\n * @param {*} [descriptor.value]\n * @param {boolean} [descriptor.writable]\n * @param {function} [descriptor.get]\n * @param {function} [descriptor.set]\n * @return {void}\n */\nmodule.exports.updateProperties = function(obj, descriptor) {\n  Object.getOwnPropertyNames(obj).forEach(function(prop) {\n    Object.defineProperty(obj, prop, descriptor);\n  });\n};\n\nmodule.exports.capabilityMap = {\n  PLATFORM_APLITE: {\n    platforms: ['aplite'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  PLATFORM_BASALT: {\n    platforms: ['basalt'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  PLATFORM_CHALK: {\n    platforms: ['chalk'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  PLATFORM_DIORITE: {\n    platforms: ['diorite'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  PLATFORM_EMERY: {\n    platforms: ['emery'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  PLATFORM_FLINT: {\n    platforms: ['flint'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  PLATFORM_GABBRO: {\n    platforms: ['gabbro'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  BW: {\n    platforms: ['aplite', 'diorite', 'flint'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  COLOR: {\n    platforms: ['basalt', 'chalk', 'emery', 'gabbro'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  COMPASS: {\n    platforms: ['aplite', 'basalt', 'chalk', 'emery', 'flint', 'gabbro'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  MICROPHONE: {\n    platforms: ['basalt', 'chalk', 'diorite', 'emery', 'flint', 'gabbro'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  RGB_BACKLIGHT: {\n    platforms: ['emery'],\n    minFwMajor: 4,\n    minFwMinor: 9\n  },\n  SMARTSTRAP: {\n    platforms: ['basalt', 'chalk', 'diorite', 'emery'],\n    minFwMajor: 3,\n    minFwMinor: 4\n  },\n  SMARTSTRAP_POWER: {\n    platforms: ['basalt', 'chalk', 'emery'],\n    minFwMajor: 3,\n    minFwMinor: 4\n  },\n  SPEAKER: {\n    platforms: ['emery', 'flint'],\n    minFwMajor: 4,\n    minFwMinor: 9\n  },\n  TOUCH: {\n    platforms: ['emery', 'gabbro'],\n    minFwMajor: 4,\n    minFwMinor: 9\n  },\n  HEALTH: {\n    platforms: ['basalt', 'chalk', 'diorite', 'emery', 'flint', 'gabbro'],\n    minFwMajor: 3,\n    minFwMinor: 10\n  },\n  RECT: {\n    platforms: ['aplite', 'basalt', 'diorite', 'emery', 'flint'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  ROUND: {\n    platforms: ['chalk', 'gabbro'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  DISPLAY_144x168: {\n    platforms: ['aplite', 'basalt', 'diorite', 'flint'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  DISPLAY_180x180_ROUND: {\n    platforms: ['chalk'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  DISPLAY_200x228: {\n    platforms: ['emery'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  },\n  DISPLAY_260x260_ROUND: {\n    platforms: ['gabbro'],\n    minFwMajor: 0,\n    minFwMinor: 0\n  }\n};\n\n/**\n * Checks if all of the provided capabilities are compatible with the watch\n * @param {Object} activeWatchInfo\n * @param {Array<string>} [capabilities]\n * @return {boolean}\n */\nmodule.exports.includesCapability = function(activeWatchInfo, capabilities) {\n  var notRegex = /^NOT_/;\n  var result = [];\n\n  if (!capabilities || !capabilities.length) {\n    return true;\n  }\n\n  for (var i = capabilities.length - 1; i >= 0; i--) {\n    var capability = capabilities[i];\n    var mapping = module.exports.capabilityMap[capability.replace(notRegex, '')];\n\n    if (!mapping ||\n        mapping.platforms.indexOf(activeWatchInfo.platform) === -1 ||\n        mapping.minFwMajor > activeWatchInfo.firmware.major ||\n        mapping.minFwMajor === activeWatchInfo.firmware.major &&\n        mapping.minFwMinor > activeWatchInfo.firmware.minor\n    ) {\n      result.push(!!capability.match(notRegex));\n    } else {\n      result.push(!capability.match(notRegex));\n    }\n  }\n\n  return result.indexOf(false) === -1;\n};\n\n},{}],8:[function(require,module,exports){\nmodule.exports = function () {\n    var _window = window;\n    var MINIFIED_MAGIC_NODEID = 'Nia';\n    var MINIFIED_MAGIC_PREV = 'NiaP';\n    var setter = {}, getter = {};\n    var idSequence = 1;\n    var DOMREADY_HANDLER = /^[ic]/.test(document['readyState']) ? _null : [];\n    var _null = null;\n    var undef;\n    function val3(v) {\n        return v.substr(0, 3);\n    }\n    var MONTH_LONG_NAMES = split('January,February,March,April,May,June,July,August,September,October,November,December', /,/g);\n    var MONTH_SHORT_NAMES = map(MONTH_LONG_NAMES, val3);\n    var WEEK_LONG_NAMES = split('Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday', /,/g);\n    var WEEK_SHORT_NAMES = map(WEEK_LONG_NAMES, val3);\n    var MERIDIAN_NAMES = split('am,pm', /,/g);\n    var MERIDIAN_NAMES_FULL = split('am,am,am,am,am,am,am,am,am,am,am,am,pm,pm,pm,pm,pm,pm,pm,pm,pm,pm,pm,pm', /,/g);\n    var FORMAT_DATE_MAP = {\n        'y': [\n            'FullYear',\n            nonOp\n        ],\n        'Y': [\n            'FullYear',\n            function (d) {\n                return d % 100;\n            }\n        ],\n        'M': [\n            'Month',\n            plusOne\n        ],\n        'n': [\n            'Month',\n            MONTH_SHORT_NAMES\n        ],\n        'N': [\n            'Month',\n            MONTH_LONG_NAMES\n        ],\n        'd': [\n            'Date',\n            nonOp\n        ],\n        'm': [\n            'Minutes',\n            nonOp\n        ],\n        'H': [\n            'Hours',\n            nonOp\n        ],\n        'h': [\n            'Hours',\n            function (d) {\n                return d % 12 || 12;\n            }\n        ],\n        'k': [\n            'Hours',\n            plusOne\n        ],\n        'K': [\n            'Hours',\n            function (d) {\n                return d % 12;\n            }\n        ],\n        's': [\n            'Seconds',\n            nonOp\n        ],\n        'S': [\n            'Milliseconds',\n            nonOp\n        ],\n        'a': [\n            'Hours',\n            MERIDIAN_NAMES_FULL\n        ],\n        'w': [\n            'Day',\n            WEEK_SHORT_NAMES\n        ],\n        'W': [\n            'Day',\n            WEEK_LONG_NAMES\n        ],\n        'z': [\n            'TimezoneOffset',\n            function (d, dummy, timezone) {\n                if (timezone)\n                    return timezone;\n                var sign = d > 0 ? '-' : '+';\n                var off = d < 0 ? -d : d;\n                return sign + pad(2, Math.floor(off / 60)) + pad(2, off % 60);\n            }\n        ]\n    };\n    var PARSE_DATE_MAP = {\n        'y': 0,\n        'Y': [\n            0,\n            -2000\n        ],\n        'M': [\n            1,\n            1\n        ],\n        'n': [\n            1,\n            MONTH_SHORT_NAMES\n        ],\n        'N': [\n            1,\n            MONTH_LONG_NAMES\n        ],\n        'd': 2,\n        'm': 4,\n        'H': 3,\n        'h': 3,\n        'K': [\n            3,\n            1\n        ],\n        'k': [\n            3,\n            1\n        ],\n        's': 5,\n        'S': 6,\n        'a': [\n            3,\n            MERIDIAN_NAMES\n        ]\n    };\n    var MAX_CACHED_TEMPLATES = 99;\n    var templateCache = {};\n    var templates = [];\n    function toString(s) {\n        return s != _null ? '' + s : '';\n    }\n    function isType(s, o) {\n        return typeof s == o;\n    }\n    function isString(s) {\n        return isType(s, 'string');\n    }\n    function isObject(f) {\n        return !!f && isType(f, 'object');\n    }\n    function isNode(n) {\n        return n && n['nodeType'];\n    }\n    function isNumber(n) {\n        return isType(n, 'number');\n    }\n    function isDate(n) {\n        return isObject(n) && !!n['getDay'];\n    }\n    function isBool(n) {\n        return n === true || n === false;\n    }\n    function isValue(n) {\n        var type = typeof n;\n        return type == 'object' ? !!(n && n['getDay']) : type == 'string' || type == 'number' || isBool(n);\n    }\n    function nonOp(v) {\n        return v;\n    }\n    function plusOne(d) {\n        return d + 1;\n    }\n    function replace(s, regexp, sub) {\n        return toString(s).replace(regexp, sub != _null ? sub : '');\n    }\n    function escapeRegExp(s) {\n        return replace(s, /[\\\\\\[\\]\\/{}()*+?.$|^-]/g, '\\\\$&');\n    }\n    function trim(s) {\n        return replace(s, /^\\s+|\\s+$/g);\n    }\n    function eachObj(obj, cb, ctx) {\n        for (var n in obj)\n            if (obj.hasOwnProperty(n))\n                cb.call(ctx || obj, n, obj[n]);\n        return obj;\n    }\n    function each(list, cb, ctx) {\n        if (list)\n            for (var i = 0; i < list.length; i++)\n                cb.call(ctx || list, list[i], i);\n        return list;\n    }\n    function filter(list, filterFuncOrObject, ctx) {\n        var r = [];\n        var f = isFunction(filterFuncOrObject) ? filterFuncOrObject : function (value) {\n            return filterFuncOrObject != value;\n        };\n        each(list, function (value, index) {\n            if (f.call(ctx || list, value, index))\n                r.push(value);\n        });\n        return r;\n    }\n    function collector(iterator, obj, collectFunc, ctx) {\n        var result = [];\n        iterator(obj, function (a, b) {\n            if (isList(a = collectFunc.call(ctx || obj, a, b)))\n                each(a, function (rr) {\n                    result.push(rr);\n                });\n            else if (a != _null)\n                result.push(a);\n        });\n        return result;\n    }\n    function collectObj(obj, collectFunc, ctx) {\n        return collector(eachObj, obj, collectFunc, ctx);\n    }\n    function collect(list, collectFunc, ctx) {\n        return collector(each, list, collectFunc, ctx);\n    }\n    function keyCount(obj) {\n        var c = 0;\n        eachObj(obj, function (key) {\n            c++;\n        });\n        return c;\n    }\n    function keys(obj) {\n        var list = [];\n        eachObj(obj, function (key) {\n            list.push(key);\n        });\n        return list;\n    }\n    function map(list, mapFunc, ctx) {\n        var result = [];\n        each(list, function (item, index) {\n            result.push(mapFunc.call(ctx || list, item, index));\n        });\n        return result;\n    }\n    function startsWith(base, start) {\n        if (isList(base)) {\n            var s2 = _(start);\n            return equals(sub(base, 0, s2.length), s2);\n        } else\n            return start != _null && base.substr(0, start.length) == start;\n    }\n    function endsWith(base, end) {\n        if (isList(base)) {\n            var e2 = _(end);\n            return equals(sub(base, -e2.length), e2) || !e2.length;\n        } else\n            return end != _null && base.substr(base.length - end.length) == end;\n    }\n    function reverse(list) {\n        var len = list.length;\n        if (isList(list))\n            return new M(map(list, function () {\n                return list[--len];\n            }));\n        else\n            return replace(list, /[\\s\\S]/g, function () {\n                return list.charAt(--len);\n            });\n    }\n    function toObject(list, value) {\n        var obj = {};\n        each(list, function (item, index) {\n            obj[item] = value;\n        });\n        return obj;\n    }\n    function copyObj(from, to) {\n        var dest = to || {};\n        for (var name in from)\n            dest[name] = from[name];\n        return dest;\n    }\n    function merge(list, target) {\n        var o = target;\n        for (var i = 0; i < list.length; i++)\n            o = copyObj(list[i], o);\n        return o;\n    }\n    function getFindFunc(findFunc) {\n        return isFunction(findFunc) ? findFunc : function (obj, index) {\n            if (findFunc === obj)\n                return index;\n        };\n    }\n    function getFindIndex(list, index, defaultIndex) {\n        return index == _null ? defaultIndex : index < 0 ? Math.max(list.length + index, 0) : Math.min(list.length, index);\n    }\n    function find(list, findFunc, startIndex, endIndex) {\n        var f = getFindFunc(findFunc);\n        var e = getFindIndex(list, endIndex, list.length);\n        var r;\n        for (var i = getFindIndex(list, startIndex, 0); i < e; i++)\n            if ((r = f.call(list, list[i], i)) != _null)\n                return r;\n    }\n    function findLast(list, findFunc, startIndex, endIndex) {\n        var f = getFindFunc(findFunc);\n        var e = getFindIndex(list, endIndex, -1);\n        var r;\n        for (var i = getFindIndex(list, startIndex, list.length - 1); i > e; i--)\n            if ((r = f.call(list, list[i], i)) != _null)\n                return r;\n    }\n    function sub(list, startIndex, endIndex) {\n        var r = [];\n        if (list) {\n            var e = getFindIndex(list, endIndex, list.length);\n            for (var i = getFindIndex(list, startIndex, 0); i < e; i++)\n                r.push(list[i]);\n        }\n        return r;\n    }\n    function array(list) {\n        return map(list, nonOp);\n    }\n    function unite(list) {\n        return function () {\n            return new M(callList(list, arguments));\n        };\n    }\n    function uniq(list) {\n        var found = {};\n        return filter(list, function (item) {\n            if (found[item])\n                return false;\n            else\n                return found[item] = 1;\n        });\n    }\n    function intersection(list, otherList) {\n        var keys = toObject(otherList, 1);\n        return filter(list, function (item) {\n            var r = keys[item];\n            keys[item] = 0;\n            return r;\n        });\n    }\n    function contains(list, value) {\n        for (var i = 0; i < list.length; i++)\n            if (list[i] == value)\n                return true;\n        return false;\n    }\n    function equals(x, y) {\n        var a = isFunction(x) ? x() : x;\n        var b = isFunction(y) ? y() : y;\n        var aKeys;\n        if (a == b)\n            return true;\n        else if (a == _null || b == _null)\n            return false;\n        else if (isValue(a) || isValue(b))\n            return isDate(a) && isDate(b) && +a == +b;\n        else if (isList(a)) {\n            return a.length == b.length && !find(a, function (val, index) {\n                if (!equals(val, b[index]))\n                    return true;\n            });\n        } else {\n            return !isList(b) && (aKeys = keys(a)).length == keyCount(b) && !find(aKeys, function (key) {\n                if (!equals(a[key], b[key]))\n                    return true;\n            });\n        }\n    }\n    function call(f, fThisOrArgs, args) {\n        if (isFunction(f))\n            return f.apply(args && fThisOrArgs, map(args || fThisOrArgs, nonOp));\n    }\n    function callList(list, fThisOrArgs, args) {\n        return map(list, function (f) {\n            return call(f, fThisOrArgs, args);\n        });\n    }\n    function bind(f, fThis, beforeArgs, afterArgs) {\n        return function () {\n            return call(f, fThis, collect([\n                beforeArgs,\n                arguments,\n                afterArgs\n            ], nonOp));\n        };\n    }\n    function partial(f, beforeArgs, afterArgs) {\n        return bind(f, this, beforeArgs, afterArgs);\n    }\n    function pad(digits, number) {\n        var signed = number < 0 ? '-' : '';\n        var preDecimal = (signed ? -number : number).toFixed(0);\n        while (preDecimal.length < digits)\n            preDecimal = '0' + preDecimal;\n        return signed + preDecimal;\n    }\n    function processNumCharTemplate(tpl, input, fwd) {\n        var inHash;\n        var inputPos = 0;\n        var rInput = fwd ? input : reverse(input);\n        var s = (fwd ? tpl : reverse(tpl)).replace(/./g, function (tplChar) {\n            if (tplChar == '0') {\n                inHash = false;\n                return rInput.charAt(inputPos++) || '0';\n            } else if (tplChar == '#') {\n                inHash = true;\n                return rInput.charAt(inputPos++) || '';\n            } else\n                return inHash && !rInput.charAt(inputPos) ? '' : tplChar;\n        });\n        return fwd ? s : input.substr(0, input.length - inputPos) + reverse(s);\n    }\n    function getTimezone(match, idx, refDate) {\n        if (idx == _null || !match)\n            return 0;\n        return parseFloat(match[idx] + match[idx + 1]) * 60 + parseFloat(match[idx] + match[idx + 2]) + refDate.getTimezoneOffset();\n    }\n    function formatValue(fmt, value) {\n        var format = replace(fmt, /^\\?/);\n        if (isDate(value)) {\n            var timezone, match;\n            if (match = /^\\[(([+-])(\\d\\d)(\\d\\d))\\]\\s*(.*)/.exec(format)) {\n                timezone = match[1];\n                value = dateAdd(value, 'minutes', getTimezone(match, 2, value));\n                format = match[5];\n            }\n            return replace(format, /(\\w)(\\1*)(?:\\[([^\\]]+)\\])?/g, function (s, placeholderChar, placeholderDigits, params) {\n                var val = FORMAT_DATE_MAP[placeholderChar];\n                if (val) {\n                    var d = value['get' + val[0]]();\n                    var optionArray = params && params.split(',');\n                    if (isList(val[1]))\n                        d = (optionArray || val[1])[d];\n                    else\n                        d = val[1](d, optionArray, timezone);\n                    if (d != _null && !isString(d))\n                        d = pad(placeholderDigits.length + 1, d);\n                    return d;\n                } else\n                    return s;\n            });\n        } else\n            return find(format.split(/\\s*\\|\\s*/), function (fmtPart) {\n                var match, numFmtOrResult;\n                if (match = /^([<>]?)(=?)([^:]*?)\\s*:\\s*(.*)$/.exec(fmtPart)) {\n                    var cmpVal1 = value, cmpVal2 = +match[3];\n                    if (isNaN(cmpVal2) || !isNumber(cmpVal1)) {\n                        cmpVal1 = cmpVal1 == _null ? 'null' : toString(cmpVal1);\n                        cmpVal2 = match[3];\n                    }\n                    if (match[1]) {\n                        if (!match[2] && cmpVal1 == cmpVal2 || match[1] == '<' && cmpVal1 > cmpVal2 || match[1] == '>' && cmpVal1 < cmpVal2)\n                            return _null;\n                    } else if (cmpVal1 != cmpVal2)\n                        return _null;\n                    numFmtOrResult = match[4];\n                } else\n                    numFmtOrResult = fmtPart;\n                if (isNumber(value))\n                    return numFmtOrResult.replace(/[0#](.*[0#])?/, function (numFmt) {\n                        var decimalFmt = /^([^.]+)(\\.)([^.]+)$/.exec(numFmt) || /^([^,]+)(,)([^,]+)$/.exec(numFmt);\n                        var signed = value < 0 ? '-' : '';\n                        var numData = /(\\d+)(\\.(\\d+))?/.exec((signed ? -value : value).toFixed(decimalFmt ? decimalFmt[3].length : 0));\n                        var preDecimalFmt = decimalFmt ? decimalFmt[1] : numFmt;\n                        var postDecimal = decimalFmt ? processNumCharTemplate(decimalFmt[3], replace(numData[3], /0+$/), true) : '';\n                        return (signed ? '-' : '') + (preDecimalFmt == '#' ? numData[1] : processNumCharTemplate(preDecimalFmt, numData[1])) + (postDecimal.length ? decimalFmt[2] : '') + postDecimal;\n                    });\n                else\n                    return numFmtOrResult;\n            });\n    }\n    function parseDate(fmt, date) {\n        var indexMap = {};\n        var reIndex = 1;\n        var timezoneOffsetMatch;\n        var timezoneIndex;\n        var match;\n        var format = replace(fmt, /^\\?/);\n        if (format != fmt && !trim(date))\n            return _null;\n        if (match = /^\\[([+-])(\\d\\d)(\\d\\d)\\]\\s*(.*)/.exec(format)) {\n            timezoneOffsetMatch = match;\n            format = match[4];\n        }\n        var parser = new RegExp(format.replace(/(.)(\\1*)(?:\\[([^\\]]*)\\])?/g, function (wholeMatch, placeholderChar, placeholderDigits, param) {\n            if (/[dmhkyhs]/i.test(placeholderChar)) {\n                indexMap[reIndex++] = placeholderChar;\n                var plen = placeholderDigits.length + 1;\n                return '(\\\\d' + (plen < 2 ? '+' : '{1,' + plen + '}') + ')';\n            } else if (placeholderChar == 'z') {\n                timezoneIndex = reIndex;\n                reIndex += 3;\n                return '([+-])(\\\\d\\\\d)(\\\\d\\\\d)';\n            } else if (/[Nna]/.test(placeholderChar)) {\n                indexMap[reIndex++] = [\n                    placeholderChar,\n                    param && param.split(',')\n                ];\n                return '([a-zA-Z\\\\u0080-\\\\u1fff]+)';\n            } else if (/w/i.test(placeholderChar))\n                return '[a-zA-Z\\\\u0080-\\\\u1fff]+';\n            else if (/\\s/.test(placeholderChar))\n                return '\\\\s+';\n            else\n                return escapeRegExp(wholeMatch);\n        }));\n        if (!(match = parser.exec(date)))\n            return undef;\n        var ctorArgs = [\n            0,\n            0,\n            0,\n            0,\n            0,\n            0,\n            0\n        ];\n        for (var i = 1; i < reIndex; i++) {\n            var matchVal = match[i];\n            var indexEntry = indexMap[i];\n            if (isList(indexEntry)) {\n                var placeholderChar = indexEntry[0];\n                var mapEntry = PARSE_DATE_MAP[placeholderChar];\n                var ctorIndex = mapEntry[0];\n                var valList = indexEntry[1] || mapEntry[1];\n                var listValue = find(valList, function (v, index) {\n                    if (startsWith(matchVal.toLowerCase(), v.toLowerCase()))\n                        return index;\n                });\n                if (listValue == _null)\n                    return undef;\n                if (placeholderChar == 'a')\n                    ctorArgs[ctorIndex] += listValue * 12;\n                else\n                    ctorArgs[ctorIndex] = listValue;\n            } else if (indexEntry) {\n                var value = parseFloat(matchVal);\n                var mapEntry = PARSE_DATE_MAP[indexEntry];\n                if (isList(mapEntry))\n                    ctorArgs[mapEntry[0]] += value - mapEntry[1];\n                else\n                    ctorArgs[mapEntry] += value;\n            }\n        }\n        var d = new Date(ctorArgs[0], ctorArgs[1], ctorArgs[2], ctorArgs[3], ctorArgs[4], ctorArgs[5], ctorArgs[6]);\n        return dateAdd(d, 'minutes', -getTimezone(timezoneOffsetMatch, 1, d) - getTimezone(match, timezoneIndex, d));\n    }\n    function parseNumber(fmt, value) {\n        var format = replace(fmt, /^\\?/);\n        if (format != fmt && !trim(value))\n            return _null;\n        var decSep = /(^|[^0#.,])(,|[0#.]*,[0#]+|[0#]+\\.[0#]+\\.[0#.,]*)($|[^0#.,])/.test(format) ? ',' : '.';\n        var r = parseFloat(replace(replace(replace(value, decSep == ',' ? /\\./g : /,/g), decSep, '.'), /^[^\\d-]*(-?\\d)/, '$1'));\n        return isNaN(r) ? undef : r;\n    }\n    function now() {\n        return new Date();\n    }\n    function dateClone(date) {\n        return new Date(+date);\n    }\n    function capWord(w) {\n        return w.charAt(0).toUpperCase() + w.substr(1);\n    }\n    function dateAddInline(d, cProp, value) {\n        d['set' + cProp](d['get' + cProp]() + value);\n        return d;\n    }\n    function dateAdd(date, property, value) {\n        if (value == _null)\n            return dateAdd(now(), date, property);\n        return dateAddInline(dateClone(date), capWord(property), value);\n    }\n    function dateMidnight(date) {\n        var od = date || now();\n        return new Date(od.getFullYear(), od.getMonth(), od.getDate());\n    }\n    function dateDiff(property, date1, date2) {\n        var d1t = +date1;\n        var d2t = +date2;\n        var dt = d2t - d1t;\n        if (dt < 0)\n            return -dateDiff(property, date2, date1);\n        var propValues = {\n            'milliseconds': 1,\n            'seconds': 1000,\n            'minutes': 60000,\n            'hours': 3600000\n        };\n        var ft = propValues[property];\n        if (ft)\n            return dt / ft;\n        var cProp = capWord(property);\n        var calApproxValues = {\n            'fullYear': 86400000 * 365,\n            'month': 86400000 * 365 / 12,\n            'date': 86400000\n        };\n        var minimumResult = Math.floor(dt / calApproxValues[property] - 2);\n        var d = dateAddInline(new Date(d1t), cProp, minimumResult);\n        for (var i = minimumResult; i < minimumResult * 1.2 + 4; i++) {\n            if (+dateAddInline(d, cProp, 1) > d2t)\n                return i;\n        }\n    }\n    function ucode(a) {\n        return '\\\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);\n    }\n    function escapeJavaScriptString(s) {\n        return replace(s, /[\\x00-\\x1f'\"\\u2028\\u2029]/g, ucode);\n    }\n    function split(str, regexp) {\n        return str.split(regexp);\n    }\n    function template(template, escapeFunction) {\n        if (templateCache[template])\n            return templateCache[template];\n        else {\n            var funcBody = 'with(_.isObject(obj)?obj:{}){' + map(split(template, /{{|}}}?/g), function (chunk, index) {\n                var match, c1 = trim(chunk), c2 = replace(c1, /^{/), escapeSnippet = c1 == c2 ? 'esc(' : '';\n                if (index % 2) {\n                    if (match = /^each\\b(\\s+([\\w_]+(\\s*,\\s*[\\w_]+)?)\\s*:)?(.*)/.exec(c2))\n                        return 'each(' + (trim(match[4]) ? match[4] : 'this') + ', function(' + match[2] + '){';\n                    else if (match = /^if\\b(.*)/.exec(c2))\n                        return 'if(' + match[1] + '){';\n                    else if (match = /^else\\b\\s*(if\\b(.*))?/.exec(c2))\n                        return '}else ' + (match[1] ? 'if(' + match[2] + ')' : '') + '{';\n                    else if (match = /^\\/(if)?/.exec(c2))\n                        return match[1] ? '}\\n' : '});\\n';\n                    else if (match = /^(var\\s.*)/.exec(c2))\n                        return match[1] + ';';\n                    else if (match = /^#(.*)/.exec(c2))\n                        return match[1];\n                    else if (match = /(.*)::\\s*(.*)/.exec(c2))\n                        return 'print(' + escapeSnippet + '_.formatValue(\"' + escapeJavaScriptString(match[2]) + '\",' + (trim(match[1]) ? match[1] : 'this') + (escapeSnippet && ')') + '));\\n';\n                    else\n                        return 'print(' + escapeSnippet + (trim(c2) ? c2 : 'this') + (escapeSnippet && ')') + ');\\n';\n                } else if (chunk) {\n                    return 'print(\"' + escapeJavaScriptString(chunk) + '\");\\n';\n                }\n            }).join('') + '}';\n            var f = new Function('obj', 'each', 'esc', 'print', '_', funcBody);\n            var t = function (obj, thisContext) {\n                var result = [];\n                f.call(thisContext || obj, obj, function (obj, func) {\n                    if (isList(obj))\n                        each(obj, function (value, index) {\n                            func.call(value, value, index);\n                        });\n                    else\n                        eachObj(obj, function (key, value) {\n                            func.call(value, key, value);\n                        });\n                }, escapeFunction || nonOp, function () {\n                    call(result['push'], result, arguments);\n                }, _);\n                return result.join('');\n            };\n            if (templates.push(t) > MAX_CACHED_TEMPLATES)\n                delete templateCache[templates.shift()];\n            return templateCache[template] = t;\n        }\n    }\n    function escapeHtml(s) {\n        return replace(s, /[<>'\"&]/g, function (s) {\n            return '&#' + s.charCodeAt(0) + ';';\n        });\n    }\n    function formatHtml(tpl, obj) {\n        return template(tpl, escapeHtml)(obj);\n    }\n    function listBindArray(func) {\n        return function (arg1, arg2) {\n            return new M(func(this, arg1, arg2));\n        };\n    }\n    function listBind(func) {\n        return function (arg1, arg2, arg3) {\n            return func(this, arg1, arg2, arg3);\n        };\n    }\n    function funcArrayBind(func) {\n        return function (arg1, arg2, arg3) {\n            return new M(func(arg1, arg2, arg3));\n        };\n    }\n    function isFunction(f) {\n        return typeof f == 'function' && !f['item'];\n    }\n    function isList(v) {\n        return v && v.length != _null && !isString(v) && !isNode(v) && !isFunction(v) && v !== _window;\n    }\n    function push(obj, prop, value) {\n        (obj[prop] = obj[prop] || []).push(value);\n    }\n    function removeFromArray(array, value) {\n        for (var i = 0; array && i < array.length; i++)\n            if (array[i] === value)\n                array['splice'](i--, 1);\n    }\n    function extractNumber(v) {\n        return parseFloat(replace(v, /^[^\\d-]+/));\n    }\n    function getNodeId(el) {\n        return el[MINIFIED_MAGIC_NODEID] = el[MINIFIED_MAGIC_NODEID] || ++idSequence;\n    }\n    function collectUniqNodes(list, func) {\n        var result = [];\n        var nodeIds = {};\n        var currentNodeId;\n        flexiEach(list, function (value) {\n            flexiEach(func(value), function (node) {\n                if (!nodeIds[currentNodeId = getNodeId(node)]) {\n                    result.push(node);\n                    nodeIds[currentNodeId] = true;\n                }\n            });\n        });\n        return result;\n    }\n    function getNaturalHeight(elementList, factor) {\n        var q = {\n            '$position': 'absolute',\n            '$visibility': 'hidden',\n            '$display': 'block',\n            '$height': _null\n        };\n        var oldStyles = elementList['get'](q);\n        var h = elementList['set'](q)['get']('clientHeight');\n        elementList['set'](oldStyles);\n        return h * factor + 'px';\n    }\n    function on(subSelector, eventSpec, handler, args, bubbleSelector) {\n        if (isFunction(eventSpec))\n            return this['on'](_null, subSelector, eventSpec, handler, args);\n        else if (isString(args))\n            return this['on'](subSelector, eventSpec, handler, _null, args);\n        else\n            return this['each'](function (baseElement, index) {\n                flexiEach(subSelector ? dollarRaw(subSelector, baseElement) : baseElement, function (registeredOn) {\n                    flexiEach(toString(eventSpec).split(/\\s/), function (namePrefixed) {\n                        var name = replace(namePrefixed, /[?|]/g);\n                        var prefix = replace(namePrefixed, /[^?|]/g);\n                        var capture = (name == 'blur' || name == 'focus') && !!bubbleSelector;\n                        var triggerId = idSequence++;\n                        function triggerHandler(eventName, event, target) {\n                            var match = !bubbleSelector;\n                            var el = bubbleSelector ? target : registeredOn;\n                            if (bubbleSelector) {\n                                var selectorFilter = getFilterFunc(bubbleSelector, registeredOn);\n                                while (el && el != registeredOn && !(match = selectorFilter(el)))\n                                    el = el['parentNode'];\n                            }\n                            return !match || name != eventName || (handler.apply($(el), args || [\n                                event,\n                                index\n                            ]) && prefix == '?' || prefix == '|');\n                        }\n                        ;\n                        function eventHandler(event) {\n                            if (!triggerHandler(name, event, event['target'])) {\n                                event['preventDefault']();\n                                event['stopPropagation']();\n                            }\n                        }\n                        ;\n                        registeredOn.addEventListener(name, eventHandler, capture);\n                        if (!registeredOn['M'])\n                            registeredOn['M'] = {};\n                        registeredOn['M'][triggerId] = triggerHandler;\n                        handler['M'] = collector(flexiEach, [\n                            handler['M'],\n                            function () {\n                                registeredOn.removeEventListener(name, eventHandler, capture);\n                                delete registeredOn['M'][triggerId];\n                            }\n                        ], nonOp);\n                    });\n                });\n            });\n    }\n    function off(handler) {\n        callList(handler['M']);\n        handler['M'] = _null;\n    }\n    function detachHandlerList(dummy, handlerList) {\n        flexiEach(handlerList, function (h) {\n            h.element.detachEvent('on' + h.eventType, h.handlerFunc);\n        });\n    }\n    function ready(handler) {\n        if (DOMREADY_HANDLER)\n            DOMREADY_HANDLER.push(handler);\n        else\n            setTimeout(handler, 0);\n    }\n    function $$(selector, context, childrenOnly) {\n        return dollarRaw(selector, context, childrenOnly)[0];\n    }\n    function EE(elementName, attributes, children) {\n        var e = $(document.createElement(elementName));\n        return isList(attributes) || attributes != _null && !isObject(attributes) ? e['add'](attributes) : e['set'](attributes)['add'](children);\n    }\n    function clone(listOrNode) {\n        return collector(flexiEach, listOrNode, function (e) {\n            var c;\n            if (isList(e))\n                return clone(e);\n            else if (isNode(e)) {\n                c = e['cloneNode'](true);\n                c['removeAttribute'] && c['removeAttribute']('id');\n                return c;\n            } else\n                return e;\n        });\n    }\n    function $(selector, context, childOnly) {\n        return isFunction(selector) ? ready(selector) : new M(dollarRaw(selector, context, childOnly));\n    }\n    function dollarRaw(selector, context, childOnly) {\n        function flatten(a) {\n            return isList(a) ? collector(flexiEach, a, flatten) : a;\n        }\n        function filterElements(list) {\n            return filter(collector(flexiEach, list, flatten), function (node) {\n                var a = node;\n                while (a = a['parentNode'])\n                    if (a == context[0] || childOnly)\n                        return a == context[0];\n            });\n        }\n        if (context) {\n            if ((context = dollarRaw(context)).length != 1)\n                return collectUniqNodes(context, function (ci) {\n                    return dollarRaw(selector, ci, childOnly);\n                });\n            else if (isString(selector)) {\n                if (isNode(context[0]) != 1)\n                    return [];\n                else\n                    return childOnly ? filterElements(context[0].querySelectorAll(selector)) : context[0].querySelectorAll(selector);\n            } else\n                return filterElements(selector);\n        } else if (isString(selector))\n            return document.querySelectorAll(selector);\n        else\n            return collector(flexiEach, selector, flatten);\n    }\n    ;\n    function getFilterFunc(selector, context) {\n        function wordRegExpTester(name, prop) {\n            var re = RegExp('(^|\\\\s+)' + name + '(?=$|\\\\s)', 'i');\n            return function (obj) {\n                return name ? re.test(obj[prop]) : true;\n            };\n        }\n        var nodeSet = {};\n        var dotPos = nodeSet;\n        if (isFunction(selector))\n            return selector;\n        else if (isNumber(selector))\n            return function (v, index) {\n                return index == selector;\n            };\n        else if (!selector || selector == '*' || isString(selector) && (dotPos = /^([\\w-]*)\\.?([\\w-]*)$/.exec(selector))) {\n            var nodeNameFilter = wordRegExpTester(dotPos[1], 'tagName');\n            var classNameFilter = wordRegExpTester(dotPos[2], 'className');\n            return function (v) {\n                return isNode(v) == 1 && nodeNameFilter(v) && classNameFilter(v);\n            };\n        } else if (context)\n            return function (v) {\n                return $(selector, context)['find'](v) != _null;\n            };\n        else {\n            $(selector)['each'](function (node) {\n                nodeSet[getNodeId(node)] = true;\n            });\n            return function (v) {\n                return nodeSet[getNodeId(v)];\n            };\n        }\n    }\n    function getInverseFilterFunc(selector) {\n        var f = getFilterFunc(selector);\n        return function (v) {\n            return f(v) ? _null : true;\n        };\n    }\n    function flexiEach(list, cb) {\n        if (isList(list))\n            each(list, cb);\n        else if (list != _null)\n            cb(list, 0);\n        return list;\n    }\n    function Promise() {\n        this['state'] = null;\n        this['values'] = [];\n        this['parent'] = null;\n    }\n    function promise() {\n        var deferred = [];\n        var assimilatedPromises = arguments;\n        var assimilatedNum = assimilatedPromises.length;\n        var numCompleted = 0;\n        var rejectionHandlerNum = 0;\n        var obj = new Promise();\n        obj['errHandled'] = function () {\n            rejectionHandlerNum++;\n            if (obj['parent'])\n                obj['parent']['errHandled']();\n        };\n        var fire = obj['fire'] = function (newState, newValues) {\n            if (obj['state'] == null && newState != null) {\n                obj['state'] = !!newState;\n                obj['values'] = isList(newValues) ? newValues : [newValues];\n                setTimeout(function () {\n                    each(deferred, function (f) {\n                        f();\n                    });\n                }, 0);\n            }\n            return obj;\n        };\n        each(assimilatedPromises, function assimilate(promise, index) {\n            try {\n                if (promise['then'])\n                    promise['then'](function (v) {\n                        var then;\n                        if ((isObject(v) || isFunction(v)) && isFunction(then = v['then']))\n                            assimilate(v, index);\n                        else {\n                            obj['values'][index] = array(arguments);\n                            if (++numCompleted == assimilatedNum)\n                                fire(true, assimilatedNum < 2 ? obj['values'][index] : obj['values']);\n                        }\n                    }, function (e) {\n                        obj['values'][index] = array(arguments);\n                        fire(false, assimilatedNum < 2 ? obj['values'][index] : [\n                            obj['values'][index][0],\n                            obj['values'],\n                            index\n                        ]);\n                    });\n                else\n                    promise(function () {\n                        fire(true, array(arguments));\n                    }, function () {\n                        fire(false, array(arguments));\n                    });\n            } catch (e) {\n                fire(false, [\n                    e,\n                    obj['values'],\n                    index\n                ]);\n            }\n        });\n        obj['stop'] = function () {\n            each(assimilatedPromises, function (promise) {\n                if (promise['stop'])\n                    promise['stop']();\n            });\n            return obj['stop0'] && call(obj['stop0']);\n        };\n        var then = obj['then'] = function (onFulfilled, onRejected) {\n            var promise2 = promise();\n            var callCallbacks = function () {\n                try {\n                    var f = obj['state'] ? onFulfilled : onRejected;\n                    if (isFunction(f)) {\n                        (function resolve(x) {\n                            try {\n                                var then, cbCalled = 0;\n                                if ((isObject(x) || isFunction(x)) && isFunction(then = x['then'])) {\n                                    if (x === promise2)\n                                        throw new TypeError();\n                                    then.call(x, function (x) {\n                                        if (!cbCalled++)\n                                            resolve(x);\n                                    }, function (value) {\n                                        if (!cbCalled++)\n                                            promise2['fire'](false, [value]);\n                                    });\n                                    promise2['stop0'] = x['stop'];\n                                } else\n                                    promise2['fire'](true, [x]);\n                            } catch (e) {\n                                if (!cbCalled++) {\n                                    promise2['fire'](false, [e]);\n                                    if (!rejectionHandlerNum)\n                                        throw e;\n                                }\n                            }\n                        }(call(f, undef, obj['values'])));\n                    } else\n                        promise2['fire'](obj['state'], obj['values']);\n                } catch (e) {\n                    promise2['fire'](false, [e]);\n                    if (!rejectionHandlerNum)\n                        throw e;\n                }\n            };\n            if (isFunction(onRejected))\n                obj['errHandled']();\n            promise2['stop0'] = obj['stop'];\n            promise2['parent'] = obj;\n            if (obj['state'] != null)\n                setTimeout(callCallbacks, 0);\n            else\n                deferred.push(callCallbacks);\n            return promise2;\n        };\n        obj['always'] = function (func) {\n            return then(func, func);\n        };\n        obj['error'] = function (func) {\n            return then(0, func);\n        };\n        return obj;\n    }\n    function M(list, assimilateSublists) {\n        var self = this, idx = 0;\n        if (list)\n            for (var i = 0, len = list.length; i < len; i++) {\n                var item = list[i];\n                if (assimilateSublists && isList(item))\n                    for (var j = 0, len2 = item.length; j < len2; j++)\n                        self[idx++] = item[j];\n                else\n                    self[idx++] = item;\n            }\n        else\n            self[idx++] = assimilateSublists;\n        self['length'] = idx;\n        self['_'] = true;\n    }\n    function _() {\n        return new M(arguments, true);\n    }\n    copyObj({\n        'each': listBind(each),\n        'equals': listBind(equals),\n        'find': listBind(find),\n        dummySort: 0,\n        'select': function (selector, childOnly) {\n            return $(selector, this, childOnly);\n        },\n        'get': function (spec, toNumber) {\n            var self = this;\n            var element = self[0];\n            if (element) {\n                if (isString(spec)) {\n                    var match = /^(\\W*)(.*)/.exec(replace(spec, /^%/, '@data-'));\n                    var prefix = match[1];\n                    var s;\n                    if (getter[prefix])\n                        s = getter[prefix](this, match[2]);\n                    else if (spec == '$')\n                        s = self['get']('className');\n                    else if (spec == '$$') {\n                        s = self['get']('@style');\n                    } else if (spec == '$$slide')\n                        s = self['get']('$height');\n                    else if (spec == '$$fade' || spec == '$$show') {\n                        if (self['get']('$visibility') == 'hidden' || self['get']('$display') == 'none')\n                            s = 0;\n                        else if (spec == '$$fade') {\n                            s = isNaN(self['get']('$opacity', true)) ? 1 : self['get']('$opacity', true);\n                        } else\n                            s = 1;\n                    } else if (prefix == '$') {\n                        s = _window['getComputedStyle'](element, _null)['getPropertyValue'](replace(match[2], /[A-Z]/g, function (match2) {\n                            return '-' + match2.toLowerCase();\n                        }));\n                    } else if (prefix == '@')\n                        s = element.getAttribute(match[2]);\n                    else\n                        s = element[match[2]];\n                    return toNumber ? extractNumber(s) : s;\n                } else {\n                    var r = {};\n                    (isList(spec) ? flexiEach : eachObj)(spec, function (name) {\n                        r[name] = self['get'](name, toNumber);\n                    });\n                    return r;\n                }\n            }\n        },\n        'set': function (name, value) {\n            var self = this;\n            if (value !== undef) {\n                var match = /^(\\W*)(.*)/.exec(replace(replace(name, /^\\$float$/, 'cssFloat'), /^%/, '@data-'));\n                var prefix = match[1];\n                if (setter[prefix])\n                    setter[prefix](this, match[2], value);\n                else if (name == '$$fade') {\n                    this['set']({\n                        '$visibility': value ? 'visible' : 'hidden',\n                        '$opacity': value\n                    });\n                } else if (name == '$$slide') {\n                    self['set']({\n                        '$visibility': value ? 'visible' : 'hidden',\n                        '$overflow': 'hidden',\n                        '$height': /px/.test(value) ? value : function (oldValue, idx, element) {\n                            return getNaturalHeight($(element), value);\n                        }\n                    });\n                } else if (name == '$$show') {\n                    if (value)\n                        self['set']({\n                            '$visibility': value ? 'visible' : 'hidden',\n                            '$display': ''\n                        })['set']({\n                            '$display': function (oldVal) {\n                                return oldVal == 'none' ? 'block' : oldVal;\n                            }\n                        });\n                    else\n                        self['set']({ '$display': 'none' });\n                } else if (name == '$$') {\n                    self['set']('@style', value);\n                } else\n                    flexiEach(this, function (obj, c) {\n                        var newValue = isFunction(value) ? value($(obj)['get'](name), c, obj) : value;\n                        if (prefix == '$') {\n                            if (match[2])\n                                obj['style'][match[2]] = newValue;\n                            else {\n                                flexiEach(newValue && newValue.split(/\\s+/), function (clzz) {\n                                    var cName = replace(clzz, /^[+-]/);\n                                    if (/^\\+/.test(clzz))\n                                        obj['classList'].add(cName);\n                                    else if (/^-/.test(clzz))\n                                        obj['classList'].remove(cName);\n                                    else\n                                        obj['classList'].toggle(cName);\n                                });\n                            }\n                        } else if (name == '$$scrollX')\n                            obj['scroll'](newValue, $(obj)['get']('$$scrollY'));\n                        else if (name == '$$scrollY')\n                            obj['scroll']($(obj)['get']('$$scrollX'), newValue);\n                        else if (prefix == '@') {\n                            if (newValue == _null)\n                                obj.removeAttribute(match[2]);\n                            else\n                                obj.setAttribute(match[2], newValue);\n                        } else\n                            obj[match[2]] = newValue;\n                    });\n            } else if (isString(name) || isFunction(name))\n                self['set']('$', name);\n            else\n                eachObj(name, function (n, v) {\n                    self['set'](n, v);\n                });\n            return self;\n        },\n        'add': function (children, addFunction) {\n            return this['each'](function (e, index) {\n                var lastAdded;\n                function appendChildren(c) {\n                    if (isList(c))\n                        flexiEach(c, appendChildren);\n                    else if (isFunction(c))\n                        appendChildren(c(e, index));\n                    else if (c != _null) {\n                        var n = isNode(c) ? c : document.createTextNode(c);\n                        if (lastAdded)\n                            lastAdded['parentNode']['insertBefore'](n, lastAdded['nextSibling']);\n                        else if (addFunction)\n                            addFunction(n, e, e['parentNode']);\n                        else\n                            e.appendChild(n);\n                        lastAdded = n;\n                    }\n                }\n                appendChildren(index && !isFunction(children) ? clone(children) : children);\n            });\n        },\n        'on': on,\n        'trigger': function (eventName, eventObj) {\n            return this['each'](function (element, index) {\n                var bubbleOn = true, el = element;\n                while (el && bubbleOn) {\n                    eachObj(el['M'], function (id, f) {\n                        bubbleOn = bubbleOn && f(eventName, eventObj, element);\n                    });\n                    el = el['parentNode'];\n                }\n            });\n        },\n        'ht': function (htmlTemplate, object) {\n            var o = arguments.length > 2 ? merge(sub(arguments, 1)) : object;\n            return this['set']('innerHTML', isFunction(htmlTemplate) ? htmlTemplate(o) : /{{/.test(htmlTemplate) ? formatHtml(htmlTemplate, o) : /^#\\S+$/.test(htmlTemplate) ? formatHtml($$(htmlTemplate)['text'], o) : htmlTemplate);\n        }\n    }, M.prototype);\n    copyObj({\n        'request': function (method, url, data, settings0) {\n            var settings = settings0 || {};\n            var xhr, callbackCalled = 0, prom = promise(), dataIsMap = data && data['constructor'] == settings['constructor'];\n            try {\n                prom['xhr'] = xhr = new XMLHttpRequest();\n                prom['stop0'] = function () {\n                    xhr['abort']();\n                };\n                if (dataIsMap) {\n                    data = collector(eachObj, data, function processParam(paramName, paramValue) {\n                        return collector(flexiEach, paramValue, function (v) {\n                            return encodeURIComponent(paramName) + (v != _null ? '=' + encodeURIComponent(v) : '');\n                        });\n                    }).join('&');\n                }\n                if (data != _null && !/post/i.test(method)) {\n                    url += '?' + data;\n                    data = _null;\n                }\n                xhr['open'](method, url, true, settings['user'], settings['pass']);\n                if (dataIsMap && /post/i.test(method))\n                    xhr['setRequestHeader']('Content-Type', 'application/x-www-form-urlencoded');\n                eachObj(settings['headers'], function (hdrName, hdrValue) {\n                    xhr['setRequestHeader'](hdrName, hdrValue);\n                });\n                eachObj(settings['xhr'], function (name, value) {\n                    xhr[name] = value;\n                });\n                xhr['onreadystatechange'] = function () {\n                    if (xhr['readyState'] == 4 && !callbackCalled++) {\n                        if (xhr['status'] >= 200 && xhr['status'] < 300)\n                            prom['fire'](true, [\n                                xhr['responseText'],\n                                xhr\n                            ]);\n                        else\n                            prom['fire'](false, [\n                                xhr['status'],\n                                xhr['responseText'],\n                                xhr\n                            ]);\n                    }\n                };\n                xhr['send'](data);\n            } catch (e) {\n                if (!callbackCalled)\n                    prom['fire'](false, [\n                        0,\n                        _null,\n                        toString(e)\n                    ]);\n            }\n            return prom;\n        },\n        'ready': ready,\n        'off': off,\n        'wait': function (durationMs, args) {\n            var p = promise();\n            var id = setTimeout(function () {\n                p['fire'](true, args);\n            }, durationMs);\n            p['stop0'] = function () {\n                p['fire'](false);\n                clearTimeout(id);\n            };\n            return p;\n        }\n    }, $);\n    copyObj({\n        'each': each,\n        'toObject': toObject,\n        'find': find,\n        'equals': equals,\n        'copyObj': copyObj,\n        'extend': function (target) {\n            return merge(sub(arguments, 1), target);\n        },\n        'eachObj': eachObj,\n        'isObject': isObject,\n        'format': function (tpl, object, escapeFunction) {\n            return template(tpl, escapeFunction)(object);\n        },\n        'template': template,\n        'formatHtml': formatHtml,\n        'promise': promise\n    }, _);\n    document.addEventListener('DOMContentLoaded', function () {\n        callList(DOMREADY_HANDLER);\n        DOMREADY_HANDLER = _null;\n    }, false);\n    return {\n        'HTML': function () {\n            var div = EE('div');\n            return _(call(div['ht'], div, arguments)[0].childNodes);\n        },\n        '_': _,\n        '$': $,\n        '$$': $$,\n        'M': M,\n        'getter': getter,\n        'setter': setter\n    };\n}();\n},{}]},{},[1])\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJzcmMvc2NyaXB0cy9jb25maWctcGFnZS5qcyIsInNyYy9zY3JpcHRzL2xpYi9jbGF5LWNvbmZpZy5qcyIsInNyYy9zY3JpcHRzL2xpYi9jbGF5LWV2ZW50cy5qcyIsInNyYy9zY3JpcHRzL2xpYi9jbGF5LWl0ZW0uanMiLCJzcmMvc2NyaXB0cy9saWIvY29tcG9uZW50LXJlZ2lzdHJ5LmpzIiwic3JjL3NjcmlwdHMvbGliL21hbmlwdWxhdG9ycy5qcyIsInNyYy9zY3JpcHRzL2xpYi91dGlscy5qcyIsInNyYy9zY3JpcHRzL3ZlbmRvci9taW5pZmllZC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3ZDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDMVRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNyR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN6RUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNKQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN0TUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uKCl7ZnVuY3Rpb24gcihlLG4sdCl7ZnVuY3Rpb24gbyhpLGYpe2lmKCFuW2ldKXtpZighZVtpXSl7dmFyIGM9XCJmdW5jdGlvblwiPT10eXBlb2YgcmVxdWlyZSYmcmVxdWlyZTtpZighZiYmYylyZXR1cm4gYyhpLCEwKTtpZih1KXJldHVybiB1KGksITApO3ZhciBhPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIraStcIidcIik7dGhyb3cgYS5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGF9dmFyIHA9bltpXT17ZXhwb3J0czp7fX07ZVtpXVswXS5jYWxsKHAuZXhwb3J0cyxmdW5jdGlvbihyKXt2YXIgbj1lW2ldWzFdW3JdO3JldHVybiBvKG58fHIpfSxwLHAuZXhwb3J0cyxyLGUsbix0KX1yZXR1cm4gbltpXS5leHBvcnRzfWZvcih2YXIgdT1cImZ1bmN0aW9uXCI9PXR5cGVvZiByZXF1aXJlJiZyZXF1aXJlLGk9MDtpPHQubGVuZ3RoO2krKylvKHRbaV0pO3JldHVybiBvfXJldHVybiByfSkoKSIsIid1c2Ugc3RyaWN0JztcblxudmFyIG1pbmlmaWVkID0gcmVxdWlyZSgnLi92ZW5kb3IvbWluaWZpZWQnKTtcbnZhciBDbGF5Q29uZmlnID0gcmVxdWlyZSgnLi9saWIvY2xheS1jb25maWcnKTtcblxudmFyICQgPSBtaW5pZmllZC4kO1xudmFyIF8gPSBtaW5pZmllZC5fO1xuXG52YXIgY29uZmlnID0gXy5leHRlbmQoW10sIHdpbmRvdy5jbGF5Q29uZmlnIHx8IFtdKTtcbnZhciBzZXR0aW5ncyA9IF8uZXh0ZW5kKHt9LCB3aW5kb3cuY2xheVNldHRpbmdzIHx8IHt9KTtcbnZhciByZXR1cm5UbyA9IHdpbmRvdy5yZXR1cm5UbyB8fCAncGViYmxlanM6Ly9jbG9zZSMnO1xudmFyIGN1c3RvbUZuID0gd2luZG93LmN1c3RvbUZuIHx8IGZ1bmN0aW9uKCkge307XG52YXIgY2xheUNvbXBvbmVudHMgPSB3aW5kb3cuY2xheUNvbXBvbmVudHMgfHwge307XG52YXIgY2xheU1ldGEgPSB3aW5kb3cuY2xheU1ldGEgfHwge307XG5cbnZhciBwbGF0Zm9ybSA9IHdpbmRvdy5uYXZpZ2F0b3IudXNlckFnZW50Lm1hdGNoKC9hbmRyb2lkL2kpID8gJ2FuZHJvaWQnIDogJ2lvcyc7XG5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xhc3NMaXN0LmFkZCgncGxhdGZvcm0tJyArIHBsYXRmb3JtKTtcblxuLy8gUmVnaXN0ZXIgdGhlIHBhc3NlZCBjb21wb25lbnRzXG5fLmVhY2hPYmooY2xheUNvbXBvbmVudHMsIGZ1bmN0aW9uKGtleSwgY29tcG9uZW50KSB7XG4gIENsYXlDb25maWcucmVnaXN0ZXJDb21wb25lbnQoY29tcG9uZW50KTtcbn0pO1xuXG52YXIgJG1haW5Gb3JtID0gJCgnI21haW4tZm9ybScpO1xudmFyIGNsYXlDb25maWcgPSBuZXcgQ2xheUNvbmZpZyhzZXR0aW5ncywgY29uZmlnLCAkbWFpbkZvcm0sIGNsYXlNZXRhKTtcblxuLy8gYWRkIGxpc3RlbmVycyBoZXJlXG4kbWFpbkZvcm0ub24oJ3N1Ym1pdCcsIGZ1bmN0aW9uKCkge1xuICAvLyBTZXQgdGhlIHJldHVybiBVUkwgZGVwZW5kaW5nIG9uIHRoZSBydW50aW1lIGVudmlyb25tZW50XG4gIGxvY2F0aW9uLmhyZWYgPSByZXR1cm5UbyArXG4gICAgICAgICAgICAgICAgICBlbmNvZGVVUklDb21wb25lbnQoSlNPTi5zdHJpbmdpZnkoY2xheUNvbmZpZy5zZXJpYWxpemUoKSkpO1xufSk7XG5cbi8vIFJ1biB0aGUgY3VzdG9tIGZ1bmN0aW9uIGluIHRoZSBjb250ZXh0IG9mIHRoZSBDbGF5Q29uZmlnXG5jdXN0b21Gbi5jYWxsKGNsYXlDb25maWcsIG1pbmlmaWVkKTtcblxuLy8gTm93IHRoYXQgd2UgaGF2ZSBnaXZlbiB0aGUgZGV2J3MgY3VzdG9tIGNvZGUgdG8gcnVuIGFuZCBhdHRhY2ggbGlzdGVuZXJzLFxuLy8gd2UgYnVpbGQgdGhlIGNvbmZpZ1xuY2xheUNvbmZpZy5idWlsZCgpO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG4vKipcbiAqIEEgQ2xheSBjb25maWcgSXRlbVxuICogQHR5cGVkZWYge09iamVjdH0gQ2xheX5Db25maWdJdGVtXG4gKiBAcHJvcGVydHkge3N0cmluZ30gdHlwZVxuICogQHByb3BlcnR5IHtzdHJpbmd8Ym9vbGVhbnxudW1iZXJ9IGRlZmF1bHRWYWx1ZVxuICogQHByb3BlcnR5IHtzdHJpbmd9IFttZXNzYWdlS2V5XVxuICogQHByb3BlcnR5IHtzdHJpbmd9IFtpZF1cbiAqIEBwcm9wZXJ0eSB7c3RyaW5nfSBbbGFiZWxdXG4gKiBAcHJvcGVydHkge09iamVjdH0gW2F0dHJpYnV0ZXNdXG4gKiBAcHJvcGVydHkge0FycmF5fSBbb3B0aW9uc11cbiAqIEBwcm9wZXJ0eSB7QXJyYXl9IFtpdGVtc11cbiAqIEBwcm9wZXJ0eSB7QXJyYXl9IFtjYXBhYmlsaXRpZXNdXG4gKi9cblxudmFyIEhUTUwgPSByZXF1aXJlKCcuLi92ZW5kb3IvbWluaWZpZWQnKS5IVE1MO1xudmFyIF8gPSByZXF1aXJlKCcuLi92ZW5kb3IvbWluaWZpZWQnKS5fO1xudmFyIENsYXlJdGVtID0gcmVxdWlyZSgnLi9jbGF5LWl0ZW0nKTtcbnZhciB1dGlscyA9IHJlcXVpcmUoJy4uL2xpYi91dGlscycpO1xudmFyIENsYXlFdmVudHMgPSByZXF1aXJlKCcuL2NsYXktZXZlbnRzJyk7XG52YXIgY29tcG9uZW50U3RvcmUgPSByZXF1aXJlKCcuL2NvbXBvbmVudC1yZWdpc3RyeScpO1xudmFyIG1hbmlwdWxhdG9ycyA9IHJlcXVpcmUoJy4vbWFuaXB1bGF0b3JzJyk7XG5cbi8qKlxuICogQGV4dGVuZHMgQ2xheUV2ZW50c1xuICogQHBhcmFtIHtPYmplY3R9IHNldHRpbmdzIC0gc2V0dGluZyB0aGF0IHdlcmUgc2V0IGZyb20gYSBwcmV2aW91cyBzZXNzaW9uXG4gKiBAcGFyYW0ge0FycmF5fE9iamVjdH0gY29uZmlnXG4gKiBAcGFyYW0ge019ICRyb290Q29udGFpbmVyXG4gKiBAcGFyYW0ge09iamVjdH0gbWV0YVxuICogQGNvbnN0cnVjdG9yXG4gKi9cbmZ1bmN0aW9uIENsYXlDb25maWcoc2V0dGluZ3MsIGNvbmZpZywgJHJvb3RDb250YWluZXIsIG1ldGEpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gIHZhciBfc2V0dGluZ3MgPSBfLmNvcHlPYmooc2V0dGluZ3MpO1xuICB2YXIgX2l0ZW1zO1xuICB2YXIgX2l0ZW1zQnlJZDtcbiAgdmFyIF9pdGVtc0J5TWVzc2FnZUtleTtcbiAgdmFyIF9pc0J1aWx0O1xuXG4gIC8qKlxuICAgKiBJbml0aWFsaXplIHRoZSBpdGVtIGFycmF5cyBhbmQgb2JqZWN0c1xuICAgKiBAcHJpdmF0ZVxuICAgKiBAcmV0dXJuIHt2b2lkfVxuICAgKi9cbiAgZnVuY3Rpb24gX2luaXRpYWxpemVJdGVtcygpIHtcbiAgICBfaXRlbXMgPSBbXTtcbiAgICBfaXRlbXNCeUlkID0ge307XG4gICAgX2l0ZW1zQnlNZXNzYWdlS2V5ID0ge307XG4gICAgX2lzQnVpbHQgPSBmYWxzZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGQgaXRlbShzKSB0byB0aGUgY29uZmlnXG4gICAqIEBwYXJhbSB7Q2xheX5Db25maWdJdGVtfEFycmF5fSBpdGVtXG4gICAqIEBwYXJhbSB7TX0gJGNvbnRhaW5lclxuICAgKiBAcmV0dXJuIHt2b2lkfVxuICAgKi9cbiAgZnVuY3Rpb24gX2FkZEl0ZW1zKGl0ZW0sICRjb250YWluZXIpIHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShpdGVtKSkge1xuICAgICAgaXRlbS5mb3JFYWNoKGZ1bmN0aW9uKGl0ZW0pIHtcbiAgICAgICAgX2FkZEl0ZW1zKGl0ZW0sICRjb250YWluZXIpO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmICh1dGlscy5pbmNsdWRlc0NhcGFiaWxpdHkobWV0YS5hY3RpdmVXYXRjaEluZm8sIGl0ZW0uY2FwYWJpbGl0aWVzKSkge1xuICAgICAgaWYgKGl0ZW0udHlwZSA9PT0gJ3NlY3Rpb24nKSB7XG4gICAgICAgIHZhciAkd3JhcHBlciA9IEhUTUwoJzxkaXYgY2xhc3M9XCJzZWN0aW9uXCI+Jyk7XG4gICAgICAgICRjb250YWluZXIuYWRkKCR3cmFwcGVyKTtcbiAgICAgICAgX2FkZEl0ZW1zKGl0ZW0uaXRlbXMsICR3cmFwcGVyKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHZhciBfaXRlbSA9IF8uY29weU9iaihpdGVtKTtcbiAgICAgICAgX2l0ZW0uY2xheUlkID0gX2l0ZW1zLmxlbmd0aDtcblxuICAgICAgICB2YXIgY2xheUl0ZW0gPSBuZXcgQ2xheUl0ZW0oX2l0ZW0pLmluaXRpYWxpemUoc2VsZik7XG5cbiAgICAgICAgaWYgKF9pdGVtLmlkKSB7XG4gICAgICAgICAgX2l0ZW1zQnlJZFtfaXRlbS5pZF0gPSBjbGF5SXRlbTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChfaXRlbS5tZXNzYWdlS2V5KSB7XG4gICAgICAgICAgX2l0ZW1zQnlNZXNzYWdlS2V5W19pdGVtLm1lc3NhZ2VLZXldID0gY2xheUl0ZW07XG4gICAgICAgIH1cblxuICAgICAgICBfaXRlbXMucHVzaChjbGF5SXRlbSk7XG5cbiAgICAgICAgLy8gc2V0IHRoZSB2YWx1ZSBvZiB0aGUgaXRlbSB2aWEgdGhlIG1hbmlwdWxhdG9yIHRvIGVuc3VyZSBjb25zaXN0ZW5jeVxuICAgICAgICB2YXIgdmFsdWUgPSB0eXBlb2YgX3NldHRpbmdzW19pdGVtLm1lc3NhZ2VLZXldICE9PSAndW5kZWZpbmVkJyA/XG4gICAgICAgICAgX3NldHRpbmdzW19pdGVtLm1lc3NhZ2VLZXldIDpcbiAgICAgICAgICBfaXRlbS5kZWZhdWx0VmFsdWU7XG5cbiAgICAgICAgY2xheUl0ZW0uc2V0KHR5cGVvZiB2YWx1ZSAhPT0gJ3VuZGVmaW5lZCcgPyB2YWx1ZSA6ICcnKTtcblxuICAgICAgICAkY29udGFpbmVyLmFkZChjbGF5SXRlbS4kZWxlbWVudCk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFRocm93cyBpZiB0aGUgY29uZmlnIGhhcyBub3QgYmVlbiBidWlsdCB5ZXQuXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBmbk5hbWVcbiAgICogQHJldHVybnMge2Jvb2xlYW59XG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBmdW5jdGlvbiBfY2hlY2tCdWlsdChmbk5hbWUpIHtcbiAgICBpZiAoIV9pc0J1aWx0KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdDbGF5Q29uZmlnIG5vdCBidWlsdC4gYnVpbGQoKSBtdXN0IGJlIHJ1biBiZWZvcmUgJyArXG4gICAgICAgICd5b3UgY2FuIHJ1biAnICsgZm5OYW1lICsgJygpJ1xuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICBzZWxmLm1ldGEgPSBtZXRhO1xuICBzZWxmLiRyb290Q29udGFpbmVyID0gJHJvb3RDb250YWluZXI7XG5cbiAgc2VsZi5FVkVOVFMgPSB7XG4gICAgLyoqXG4gICAgICogQ2FsbGVkIGJlZm9yZSBmcmFtZXdvcmsgaGFzIGluaXRpYWxpemVkLiBUaGlzIGlzIHdoZW4geW91IHdvdWxkIGF0dGFjaCB5b3VyXG4gICAgICogY3VzdG9tIGNvbXBvbmVudHMuXG4gICAgICogQGNvbnN0XG4gICAgICovXG4gICAgQkVGT1JFX0JVSUxEOiAnQkVGT1JFX0JVSUxEJyxcblxuICAgIC8qKlxuICAgICAqIENhbGxlZCBhZnRlciB0aGUgY29uZmlnIGhhcyBiZWVuIHBhcnNlZCBhbmQgYWxsIGNvbXBvbmVudHMgaGF2ZSB0aGVpciBpbml0aWFsXG4gICAgICogdmFsdWUgc2V0XG4gICAgICogQGNvbnN0XG4gICAgICovXG4gICAgQUZURVJfQlVJTEQ6ICdBRlRFUl9CVUlMRCcsXG5cbiAgICAvKipcbiAgICAgKiBDYWxsZWQgaWYgLmJ1aWxkKCkgaXMgZXhlY3V0ZWQgYWZ0ZXIgdGhlIHBhZ2UgaGFzIGFscmVhZHkgYmVlbiBidWlsdCBhbmRcbiAgICAgKiBiZWZvcmUgdGhlIGV4aXN0aW5nIGNvbnRlbnQgaXMgZGVzdHJveWVkXG4gICAgICogQGNvbnN0XG4gICAgICovXG4gICAgQkVGT1JFX0RFU1RST1k6ICdCRUZPUkVfREVTVFJPWScsXG5cbiAgICAvKipcbiAgICAgKiBDYWxsZWQgaWYgLmJ1aWxkKCkgaXMgZXhlY3V0ZWQgYWZ0ZXIgdGhlIHBhZ2UgaGFzIGFscmVhZHkgYmVlbiBidWlsdCBhbmQgYWZ0ZXJcbiAgICAgKiB0aGUgZXhpc3RpbmcgY29udGVudCBpcyBkZXN0cm95ZWRcbiAgICAgKiBAY29uc3RcbiAgICAgKi9cbiAgICBBRlRFUl9ERVNUUk9ZOiAnQUZURVJfREVTVFJPWSdcbiAgfTtcbiAgdXRpbHMudXBkYXRlUHJvcGVydGllcyhzZWxmLkVWRU5UUywge3dyaXRhYmxlOiBmYWxzZX0pO1xuXG4gIC8qKlxuICAgKiBAcmV0dXJucyB7QXJyYXkuPENsYXlJdGVtPn1cbiAgICovXG4gIHNlbGYuZ2V0QWxsSXRlbXMgPSBmdW5jdGlvbigpIHtcbiAgICBfY2hlY2tCdWlsdCgnZ2V0QWxsSXRlbXMnKTtcbiAgICByZXR1cm4gX2l0ZW1zO1xuICB9O1xuXG4gIC8qKlxuICAgKiBAcGFyYW0ge3N0cmluZ30gbWVzc2FnZUtleVxuICAgKiBAcmV0dXJucyB7Q2xheUl0ZW19XG4gICAqL1xuICBzZWxmLmdldEl0ZW1CeU1lc3NhZ2VLZXkgPSBmdW5jdGlvbihtZXNzYWdlS2V5KSB7XG4gICAgX2NoZWNrQnVpbHQoJ2dldEl0ZW1CeU1lc3NhZ2VLZXknKTtcbiAgICByZXR1cm4gX2l0ZW1zQnlNZXNzYWdlS2V5W21lc3NhZ2VLZXldO1xuICB9O1xuXG4gIC8qKlxuICAgKiBAcGFyYW0ge3N0cmluZ30gaWRcbiAgICogQHJldHVybnMge0NsYXlJdGVtfVxuICAgKi9cbiAgc2VsZi5nZXRJdGVtQnlJZCA9IGZ1bmN0aW9uKGlkKSB7XG4gICAgX2NoZWNrQnVpbHQoJ2dldEl0ZW1CeUlkJyk7XG4gICAgcmV0dXJuIF9pdGVtc0J5SWRbaWRdO1xuICB9O1xuXG4gIC8qKlxuICAgKiBAcGFyYW0ge3N0cmluZ30gdHlwZVxuICAgKiBAcmV0dXJucyB7QXJyYXkuPENsYXlJdGVtPn1cbiAgICovXG4gIHNlbGYuZ2V0SXRlbXNCeVR5cGUgPSBmdW5jdGlvbih0eXBlKSB7XG4gICAgX2NoZWNrQnVpbHQoJ2dldEl0ZW1zQnlUeXBlJyk7XG4gICAgcmV0dXJuIF9pdGVtcy5maWx0ZXIoZnVuY3Rpb24oaXRlbSkge1xuICAgICAgcmV0dXJuIGl0ZW0uY29uZmlnLnR5cGUgPT09IHR5cGU7XG4gICAgfSk7XG4gIH07XG5cbiAgLyoqXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBncm91cFxuICAgKiBAcmV0dXJucyB7QXJyYXkuPENsYXlJdGVtPn1cbiAgICovXG4gIHNlbGYuZ2V0SXRlbXNCeUdyb3VwID0gZnVuY3Rpb24oZ3JvdXApIHtcbiAgICBfY2hlY2tCdWlsdCgnZ2V0SXRlbXNCeUdyb3VwJyk7XG4gICAgcmV0dXJuIF9pdGVtcy5maWx0ZXIoZnVuY3Rpb24oaXRlbSkge1xuICAgICAgcmV0dXJuIGl0ZW0uY29uZmlnLmdyb3VwID09PSBncm91cDtcbiAgICB9KTtcbiAgfTtcblxuICAvKipcbiAgICogQHJldHVybnMge09iamVjdH1cbiAgICovXG4gIHNlbGYuc2VyaWFsaXplID0gZnVuY3Rpb24oKSB7XG4gICAgX2NoZWNrQnVpbHQoJ3NlcmlhbGl6ZScpO1xuXG4gICAgX3NldHRpbmdzID0ge307XG5cbiAgICBfLmVhY2hPYmooX2l0ZW1zQnlNZXNzYWdlS2V5LCBmdW5jdGlvbihtZXNzYWdlS2V5LCBpdGVtKSB7XG4gICAgICBfc2V0dGluZ3NbbWVzc2FnZUtleV0gPSB7XG4gICAgICAgIHZhbHVlOiBpdGVtLmdldCgpXG4gICAgICB9O1xuXG4gICAgICBpZiAoaXRlbS5wcmVjaXNpb24pIHtcbiAgICAgICAgX3NldHRpbmdzW21lc3NhZ2VLZXldLnByZWNpc2lvbiA9IGl0ZW0ucHJlY2lzaW9uO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBfc2V0dGluZ3M7XG4gIH07XG5cbiAgLy8gQHRvZG8gbWF5YmUgZG9uJ3QgZG8gdGhpcyBhbmQgZm9yY2UgdGhlIHN0YXRpYyBtZXRob2RcbiAgc2VsZi5yZWdpc3RlckNvbXBvbmVudCA9IENsYXlDb25maWcucmVnaXN0ZXJDb21wb25lbnQ7XG5cbiAgLyoqXG4gICAqIEVtcHRpZXMgdGhlIHJvb3QgY29udGFpbmVyXG4gICAqIEByZXR1cm5zIHtDbGF5Q29uZmlnfVxuICAgKi9cbiAgc2VsZi5kZXN0cm95ID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIGVsID0gJHJvb3RDb250YWluZXJbMF07XG4gICAgc2VsZi50cmlnZ2VyKHNlbGYuRVZFTlRTLkJFRk9SRV9ERVNUUk9ZKTtcbiAgICB3aGlsZSAoZWwuZmlyc3RDaGlsZCkge1xuICAgICAgZWwucmVtb3ZlQ2hpbGQoZWwuZmlyc3RDaGlsZCk7XG4gICAgfVxuICAgIF9pbml0aWFsaXplSXRlbXMoKTtcbiAgICBzZWxmLnRyaWdnZXIoc2VsZi5FVkVOVFMuQUZURVJfREVTVFJPWSk7XG4gICAgcmV0dXJuIHNlbGY7XG4gIH07XG5cbiAgLyoqXG4gICAqIEJ1aWxkIHRoZSBjb25maWcgcGFnZS4gVGhpcyBtdXN0IGJlIHJ1biBiZWZvcmUgYW55IG9mIHRoZSBnZXQgbWV0aG9kcyBjYW4gYmUgcnVuXG4gICAqIElmIHlvdSBjYWxsIHRoaXMgbWV0aG9kIGFmdGVyIHRoZSBwYWdlIGhhcyBhbHJlYWR5IGJlZW4gYnVpbHQsIHRlaCBwYWdlIHdpbGwgYmVcbiAgICogZGVzdHJveWVkIGFuZCBidWlsdCBhZ2Fpbi5cbiAgICogQHJldHVybnMge0NsYXlDb25maWd9XG4gICAqL1xuICBzZWxmLmJ1aWxkID0gZnVuY3Rpb24oKSB7XG4gICAgaWYgKF9pc0J1aWx0KSB7XG4gICAgICBzZWxmLmRlc3Ryb3koKTtcbiAgICB9XG4gICAgc2VsZi50cmlnZ2VyKHNlbGYuRVZFTlRTLkJFRk9SRV9CVUlMRCk7XG4gICAgX2FkZEl0ZW1zKHNlbGYuY29uZmlnLCAkcm9vdENvbnRhaW5lcik7XG4gICAgX2lzQnVpbHQgPSB0cnVlO1xuICAgIHNlbGYudHJpZ2dlcihzZWxmLkVWRU5UUy5BRlRFUl9CVUlMRCk7XG4gICAgcmV0dXJuIHNlbGY7XG4gIH07XG5cbiAgX2luaXRpYWxpemVJdGVtcygpO1xuXG4gIC8vIGF0dGFjaCBldmVudCBtZXRob2RzXG4gIENsYXlFdmVudHMuY2FsbChzZWxmLCAkcm9vdENvbnRhaW5lcik7XG5cbiAgLy8gcHJldmVudCBleHRlcm5hbCBtb2RpZmljYXRpb25zIG9mIHByb3BlcnRpZXNcbiAgdXRpbHMudXBkYXRlUHJvcGVydGllcyhzZWxmLCB7IHdyaXRhYmxlOiBmYWxzZSwgY29uZmlndXJhYmxlOiBmYWxzZSB9KTtcblxuICAvLyBleHBvc2UgdGhlIGNvbmZpZyB0byBhbGxvdyBkZXZlbG9wZXJzIHRvIHVwZGF0ZSBpdCBiZWZvcmUgdGhlIGJ1aWxkIGlzIHJ1blxuICBzZWxmLmNvbmZpZyA9IGNvbmZpZztcbn1cblxuLyoqXG4gKiBSZWdpc3RlciBhIGNvbXBvbmVudCB0byBDbGF5LiBUaGlzIG11c3QgYmUgY2FsbGVkIHByaW9yIHRvIC5idWlsZCgpO1xuICogQHBhcmFtIHtPYmplY3R9IGNvbXBvbmVudCAtIHRoZSBjbGF5IGNvbXBvbmVudCB0byByZWdpc3RlclxuICogQHBhcmFtIHtzdHJpbmd9IGNvbXBvbmVudC5uYW1lIC0gdGhlIG5hbWUgb2YgdGhlIGNvbXBvbmVudFxuICogQHBhcmFtIHtzdHJpbmd9IGNvbXBvbmVudC50ZW1wbGF0ZSAtIEhUTUwgdGVtcGxhdGUgdG8gdXNlIGZvciB0aGUgY29tcG9uZW50XG4gKiBAcGFyYW0ge3N0cmluZ3xPYmplY3R9IGNvbXBvbmVudC5tYW5pcHVsYXRvciAtIG1ldGhvZHMgdG8gYXR0YWNoIHRvIHRoZSBjb21wb25lbnRcbiAqIEBwYXJhbSB7ZnVuY3Rpb259IGNvbXBvbmVudC5tYW5pcHVsYXRvci5zZXQgLSBzZXQgbWFuaXB1bGF0b3IgbWV0aG9kXG4gKiBAcGFyYW0ge2Z1bmN0aW9ufSBjb21wb25lbnQubWFuaXB1bGF0b3IuZ2V0IC0gZ2V0IG1hbmlwdWxhdG9yIG1ldGhvZFxuICogQHBhcmFtIHtPYmplY3R9IFtjb21wb25lbnQuZGVmYXVsdHNdIC0gdGVtcGxhdGUgZGVmYXVsdHNcbiAqIEBwYXJhbSB7ZnVuY3Rpb259IFtjb21wb25lbnQuaW5pdGlhbGl6ZV0gLSBtZXRob2QgdG8gc2NhZmZvbGQgdGhlIGNvbXBvbmVudFxuICogQHJldHVybiB7Ym9vbGVhbn0gLSBSZXR1cm5zIHRydWUgaWYgY29tcG9uZW50IHdhcyByZWdpc3RlcmVkIGNvcnJlY3RseVxuICovXG5DbGF5Q29uZmlnLnJlZ2lzdGVyQ29tcG9uZW50ID0gZnVuY3Rpb24oY29tcG9uZW50KSB7XG4gIHZhciBfY29tcG9uZW50ID0gXy5jb3B5T2JqKGNvbXBvbmVudCk7XG5cbiAgaWYgKGNvbXBvbmVudFN0b3JlW19jb21wb25lbnQubmFtZV0pIHtcbiAgICBjb25zb2xlLndhcm4oJ0NvbXBvbmVudDogJyArIF9jb21wb25lbnQubmFtZSArXG4gICAgICAgICAgICAgICAgICcgaXMgYWxyZWFkeSByZWdpc3RlcmVkLiBJZiB5b3Ugd2lzaCB0byBvdmVycmlkZSB0aGUgZXhpc3RpbmcnICtcbiAgICAgICAgICAgICAgICAgJyBmdW5jdGlvbmFsaXR5LCB5b3UgbXVzdCBwcm92aWRlIGEgbmV3IG5hbWUnKTtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBpZiAodHlwZW9mIF9jb21wb25lbnQubWFuaXB1bGF0b3IgPT09ICdzdHJpbmcnKSB7XG4gICAgX2NvbXBvbmVudC5tYW5pcHVsYXRvciA9IG1hbmlwdWxhdG9yc1tjb21wb25lbnQubWFuaXB1bGF0b3JdO1xuXG4gICAgaWYgKCFfY29tcG9uZW50Lm1hbmlwdWxhdG9yKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1RoZSBtYW5pcHVsYXRvcjogJyArIGNvbXBvbmVudC5tYW5pcHVsYXRvciArXG4gICAgICAgICAgICAgICAgICAgICAgJyBkb2VzIG5vdCBleGlzdCBpbiB0aGUgYnVpbHQtaW4gbWFuaXB1bGF0b3JzLicpO1xuICAgIH1cbiAgfVxuXG4gIGlmICghX2NvbXBvbmVudC5tYW5pcHVsYXRvcikge1xuICAgIHRocm93IG5ldyBFcnJvcignVGhlIG1hbmlwdWxhdG9yIG11c3QgYmUgZGVmaW5lZCcpO1xuICB9XG5cbiAgaWYgKHR5cGVvZiBfY29tcG9uZW50Lm1hbmlwdWxhdG9yLnNldCAhPT0gJ2Z1bmN0aW9uJyB8fFxuICAgICAgdHlwZW9mIF9jb21wb25lbnQubWFuaXB1bGF0b3IuZ2V0ICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdUaGUgbWFuaXB1bGF0b3IgbXVzdCBoYXZlIGJvdGggYSBgZ2V0YCBhbmQgYHNldGAgbWV0aG9kJyk7XG4gIH1cblxuICBpZiAoX2NvbXBvbmVudC5zdHlsZSkge1xuICAgIHZhciBzdHlsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJyk7XG4gICAgc3R5bGUudHlwZSA9ICd0ZXh0L2Nzcyc7XG4gICAgc3R5bGUuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoX2NvbXBvbmVudC5zdHlsZSkpO1xuICAgIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoc3R5bGUpO1xuICB9XG5cbiAgY29tcG9uZW50U3RvcmVbX2NvbXBvbmVudC5uYW1lXSA9IF9jb21wb25lbnQ7XG4gIHJldHVybiB0cnVlO1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSBDbGF5Q29uZmlnO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgJCA9IHJlcXVpcmUoJy4uL3ZlbmRvci9taW5pZmllZCcpLiQ7XG52YXIgXyA9IHJlcXVpcmUoJy4uL3ZlbmRvci9taW5pZmllZCcpLl87XG5cbi8qKlxuICogQXR0YWNoZXMgZXZlbnQgbWV0aG9kcyB0byB0aGUgY29udGV4dC5cbiAqIENhbGwgd2l0aCBDbGF5RXZlbnRzLmNhbGwoeW91ck9iamVjdCwgJGV2ZW50VGFyZ2V0KVxuICogQHBhcmFtIHtFdmVudEVtaXR0ZXJ8TX0gJGV2ZW50VGFyZ2V0IC0gQW4gb2JqZWN0IHRoYXQgd2lsbCBiZSB1c2VkIGFzIHRoZSBldmVudFxuICogdGFyZ2V0LiBNdXN0IGltcGxlbWVudCBFdmVudEVtaXR0ZXJcbiAqIEBjb25zdHJ1Y3RvclxuICovXG5mdW5jdGlvbiBDbGF5RXZlbnRzKCRldmVudFRhcmdldCkge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIHZhciBfZXZlbnRQcm94aWVzID0gW107XG5cbiAgLyoqXG4gICAqIHByZWZpeGVzIGV2ZW50cyB3aXRoIFwifFwiXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBldmVudHNcbiAgICogQHJldHVybnMge3N0cmluZ31cbiAgICogQHByaXZhdGVcbiAgICovXG4gIGZ1bmN0aW9uIF90cmFuc2Zvcm1FdmVudE5hbWVzKGV2ZW50cykge1xuICAgIHJldHVybiBldmVudHMuc3BsaXQoJyAnKS5tYXAoZnVuY3Rpb24oZXZlbnQpIHtcbiAgICAgIHJldHVybiAnfCcgKyBldmVudC5yZXBsYWNlKC9eXFx8LywgJycpO1xuICAgIH0pLmpvaW4oJyAnKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBoYW5kbGVyXG4gICAqIEBwYXJhbSB7ZnVuY3Rpb259IHByb3h5XG4gICAqIEByZXR1cm5zIHtmdW5jdGlvbn1cbiAgICogQHByaXZhdGVcbiAgICovXG4gIGZ1bmN0aW9uIF9yZWdpc3RlckV2ZW50UHJveHkoaGFuZGxlciwgcHJveHkpIHtcbiAgICB2YXIgZXZlbnRQcm94eSA9IF8uZmluZChfZXZlbnRQcm94aWVzLCBmdW5jdGlvbihpdGVtKSB7XG4gICAgICByZXR1cm4gaXRlbS5oYW5kbGVyID09PSBoYW5kbGVyID8gaXRlbSA6IG51bGw7XG4gICAgfSk7XG5cbiAgICBpZiAoIWV2ZW50UHJveHkpIHtcbiAgICAgIGV2ZW50UHJveHkgPSB7IGhhbmRsZXI6IGhhbmRsZXIsIHByb3h5OiBwcm94eSB9O1xuICAgICAgX2V2ZW50UHJveGllcy5wdXNoKGV2ZW50UHJveHkpO1xuICAgIH1cbiAgICByZXR1cm4gZXZlbnRQcm94eS5wcm94eTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBoYW5kbGVyXG4gICAqIEByZXR1cm5zIHtmdW5jdGlvbn1cbiAgICogQHByaXZhdGVcbiAgICovXG4gIGZ1bmN0aW9uIF9nZXRFdmVudFByb3h5KGhhbmRsZXIpIHtcbiAgICByZXR1cm4gXy5maW5kKF9ldmVudFByb3hpZXMsIGZ1bmN0aW9uKGl0ZW0pIHtcbiAgICAgIHJldHVybiBpdGVtLmhhbmRsZXIgPT09IGhhbmRsZXIgPyBpdGVtLnByb3h5IDogbnVsbDtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBdHRhY2ggYW4gZXZlbnQgbGlzdGVuZXIgdG8gdGhlIGl0ZW0uXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBldmVudHMgLSBhIHNwYWNlIHNlcGFyYXRlZCBsaXN0IG9mIGV2ZW50c1xuICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBoYW5kbGVyXG4gICAqIEByZXR1cm5zIHtDbGF5RXZlbnRzfVxuICAgKi9cbiAgc2VsZi5vbiA9IGZ1bmN0aW9uKGV2ZW50cywgaGFuZGxlcikge1xuICAgIHZhciBfZXZlbnRzID0gX3RyYW5zZm9ybUV2ZW50TmFtZXMoZXZlbnRzKTtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgdmFyIF9wcm94eSA9IF9yZWdpc3RlckV2ZW50UHJveHkoaGFuZGxlciwgZnVuY3Rpb24oKSB7XG4gICAgICBoYW5kbGVyLmFwcGx5KHNlbGYsIGFyZ3VtZW50cyk7XG4gICAgfSk7XG4gICAgJGV2ZW50VGFyZ2V0Lm9uKF9ldmVudHMsIF9wcm94eSk7XG4gICAgcmV0dXJuIHNlbGY7XG4gIH07XG5cbiAgLyoqXG4gICAqIFJlbW92ZSB0aGUgZ2l2ZW4gZXZlbnQgaGFuZGxlci4gTk9URTogVGhpcyB3aWxsIHJlbW92ZSB0aGUgaGFuZGxlciBmcm9tIGFsbFxuICAgKiByZWdpc3RlcmVkIGV2ZW50c1xuICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBoYW5kbGVyXG4gICAqIEByZXR1cm5zIHtDbGF5RXZlbnRzfVxuICAgKi9cbiAgc2VsZi5vZmYgPSBmdW5jdGlvbihoYW5kbGVyKSB7XG4gICAgdmFyIF9wcm94eSA9IF9nZXRFdmVudFByb3h5KGhhbmRsZXIpO1xuICAgIGlmIChfcHJveHkpIHtcbiAgICAgICQub2ZmKF9wcm94eSk7XG4gICAgfVxuICAgIHJldHVybiBzZWxmO1xuICB9O1xuXG4gIC8qKlxuICAgKiBUcmlnZ2VyIGFuIGV2ZW50LlxuICAgKiBAcGFyYW0ge3N0cmluZ30gbmFtZSAtIGEgc2luZ2xlIGV2ZW50IG5hbWUgdG8gdHJpZ2dlclxuICAgKiBAcGFyYW0ge09iamVjdH0gW2V2ZW50T2JqXSAtIGFuIG9iamVjdCB0byBwYXNzIHRvIHRoZSBldmVudCBoYW5kbGVyLFxuICAgKiBwcm92aWRlZCB0aGUgaGFuZGxlciBkb2VzIG5vdCBoYXZlIGN1c3RvbSBhcmd1bWVudHMuXG4gICAqIEByZXR1cm5zIHtDbGF5RXZlbnRzfVxuICAgKi9cbiAgc2VsZi50cmlnZ2VyID0gZnVuY3Rpb24obmFtZSwgZXZlbnRPYmopIHtcbiAgICAkZXZlbnRUYXJnZXQudHJpZ2dlcihuYW1lLCBldmVudE9iaik7XG4gICAgcmV0dXJuIHNlbGY7XG4gIH07XG59XG5cbm1vZHVsZS5leHBvcnRzID0gQ2xheUV2ZW50cztcbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIGNvbXBvbmVudFJlZ2lzdHJ5ID0gcmVxdWlyZSgnLi9jb21wb25lbnQtcmVnaXN0cnknKTtcbnZhciBtaW5pZmllZCA9IHJlcXVpcmUoJy4uL3ZlbmRvci9taW5pZmllZCcpO1xudmFyIHV0aWxzID0gcmVxdWlyZSgnLi4vbGliL3V0aWxzJyk7XG52YXIgQ2xheUV2ZW50cyA9IHJlcXVpcmUoJy4vY2xheS1ldmVudHMnKTtcblxudmFyIF8gPSBtaW5pZmllZC5fO1xudmFyIEhUTUwgPSBtaW5pZmllZC5IVE1MO1xuXG4vKipcbiAqIEBleHRlbmRzIENsYXlFdmVudHNcbiAqIEBwYXJhbSB7Q2xheX5Db25maWdJdGVtfSBjb25maWdcbiAqIEBjb25zdHJ1Y3RvclxuICovXG5mdW5jdGlvbiBDbGF5SXRlbShjb25maWcpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gIHZhciBfY29tcG9uZW50ID0gY29tcG9uZW50UmVnaXN0cnlbY29uZmlnLnR5cGVdO1xuXG4gIGlmICghX2NvbXBvbmVudCkge1xuICAgIHRocm93IG5ldyBFcnJvcignVGhlIGNvbXBvbmVudDogJyArIGNvbmZpZy50eXBlICsgJyBpcyBub3QgcmVnaXN0ZXJlZC4gJyArXG4gICAgICAgICAgICAgICAgICAgICdNYWtlIHN1cmUgdG8gcmVnaXN0ZXIgaXQgd2l0aCBDbGF5Q29uZmlnLnJlZ2lzdGVyQ29tcG9uZW50KCknKTtcbiAgfVxuXG4gIHZhciBfdGVtcGxhdGVEYXRhID0gXy5leHRlbmQoe30sIF9jb21wb25lbnQuZGVmYXVsdHMgfHwge30sIGNvbmZpZyk7XG5cbiAgLyoqIEB0eXBlIHtzdHJpbmd8bnVsbH0gKi9cbiAgc2VsZi5pZCA9IGNvbmZpZy5pZCB8fCBudWxsO1xuXG4gIC8qKiBAdHlwZSB7c3RyaW5nfG51bGx9ICovXG4gIHNlbGYubWVzc2FnZUtleSA9IGNvbmZpZy5tZXNzYWdlS2V5IHx8IG51bGw7XG5cbiAgLyoqIEB0eXBlIHtPYmplY3R9ICovXG4gIHNlbGYuY29uZmlnID0gY29uZmlnO1xuXG4gIC8qKiBAdHlwZSB7TX0gKi9cbiAgc2VsZi4kZWxlbWVudCA9IEhUTUwoX2NvbXBvbmVudC50ZW1wbGF0ZS50cmltKCksIF90ZW1wbGF0ZURhdGEpO1xuXG4gIC8qKiBAdHlwZSB7TX0gKi9cbiAgc2VsZi4kbWFuaXB1bGF0b3JUYXJnZXQgPSBzZWxmLiRlbGVtZW50LnNlbGVjdCgnW2RhdGEtbWFuaXB1bGF0b3ItdGFyZ2V0XScpO1xuXG4gIC8vIHRoaXMgY2F0ZXJzIGZvciBzaXR1YXRpb25zIHdoZXJlIHRoZSBtYW5pcHVsYXRvciB0YXJnZXQgaXMgdGhlIHJvb3QgZWxlbWVudFxuICBpZiAoIXNlbGYuJG1hbmlwdWxhdG9yVGFyZ2V0Lmxlbmd0aCkge1xuICAgIHNlbGYuJG1hbmlwdWxhdG9yVGFyZ2V0ID0gc2VsZi4kZWxlbWVudDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSdW4gdGhlIGluaXRpYWxpemVyIGlmIGl0IGV4aXN0cyBhbmQgYXR0YWNoZXMgdGhlIGNzcyB0byB0aGUgaGVhZC5cbiAgICogUGFzc2VzIG1pbmlmaWVkIGFzIHRoZSBmaXJzdCBwYXJhbVxuICAgKiBAcGFyYW0ge0NsYXlDb25maWd9IGNsYXlcbiAgICogQHJldHVybnMge0NsYXlJdGVtfVxuICAgKi9cbiAgc2VsZi5pbml0aWFsaXplID0gZnVuY3Rpb24oY2xheSkge1xuICAgIGlmICh0eXBlb2YgX2NvbXBvbmVudC5pbml0aWFsaXplID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBfY29tcG9uZW50LmluaXRpYWxpemUuY2FsbChzZWxmLCBtaW5pZmllZCwgY2xheSk7XG4gICAgfVxuICAgIHJldHVybiBzZWxmO1xuICB9O1xuXG4gIC8vIGF0dGFjaCBldmVudCBtZXRob2RzXG4gIENsYXlFdmVudHMuY2FsbChzZWxmLCBzZWxmLiRtYW5pcHVsYXRvclRhcmdldCk7XG5cbiAgLy8gYXR0YWNoIHRoZSBtYW5pcHVsYXRvciBtZXRob2RzIHRvIHRoZSBjbGF5SXRlbVxuICBfLmVhY2hPYmooX2NvbXBvbmVudC5tYW5pcHVsYXRvciwgZnVuY3Rpb24obWV0aG9kTmFtZSwgbWV0aG9kKSB7XG4gICAgc2VsZlttZXRob2ROYW1lXSA9IG1ldGhvZC5iaW5kKHNlbGYpO1xuICB9KTtcblxuICAvLyBwcmV2ZW50IGV4dGVybmFsIG1vZGlmaWNhdGlvbnMgb2YgcHJvcGVydGllc1xuICB1dGlscy51cGRhdGVQcm9wZXJ0aWVzKHNlbGYsIHsgd3JpdGFibGU6IGZhbHNlLCBjb25maWd1cmFibGU6IGZhbHNlIH0pO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IENsYXlJdGVtO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG4vLyBtb2R1bGUgaXMgYmxhbmsgYmVjYXVzZSB3ZSBkeW5hbWljYWxseSBhZGQgY29tcG9uZW50c1xubW9kdWxlLmV4cG9ydHMgPSB7fTtcbiIsIid1c2Ugc3RyaWN0JztcblxudmFyIF8gPSByZXF1aXJlKCcuLi92ZW5kb3IvbWluaWZpZWQnKS5fO1xuXG4vKipcbiAqIEByZXR1cm5zIHtDbGF5SXRlbXxDbGF5RXZlbnRzfVxuICogQGV4dGVuZHMge0NsYXlJdGVtfVxuICovXG5mdW5jdGlvbiBkaXNhYmxlKCkge1xuICBpZiAodGhpcy4kbWFuaXB1bGF0b3JUYXJnZXQuZ2V0KCdkaXNhYmxlZCcpKSB7IHJldHVybiB0aGlzOyB9XG4gIHRoaXMuJGVsZW1lbnQuc2V0KCcrZGlzYWJsZWQnKTtcbiAgdGhpcy4kbWFuaXB1bGF0b3JUYXJnZXQuc2V0KCdkaXNhYmxlZCcsIHRydWUpO1xuICByZXR1cm4gdGhpcy50cmlnZ2VyKCdkaXNhYmxlZCcpO1xufVxuXG4vKipcbiAqIEByZXR1cm5zIHtDbGF5SXRlbXxDbGF5RXZlbnRzfVxuICogQGV4dGVuZHMge0NsYXlJdGVtfVxuICovXG5mdW5jdGlvbiBlbmFibGUoKSB7XG4gIGlmICghdGhpcy4kbWFuaXB1bGF0b3JUYXJnZXQuZ2V0KCdkaXNhYmxlZCcpKSB7IHJldHVybiB0aGlzOyB9XG4gIHRoaXMuJGVsZW1lbnQuc2V0KCctZGlzYWJsZWQnKTtcbiAgdGhpcy4kbWFuaXB1bGF0b3JUYXJnZXQuc2V0KCdkaXNhYmxlZCcsIGZhbHNlKTtcbiAgcmV0dXJuIHRoaXMudHJpZ2dlcignZW5hYmxlZCcpO1xufVxuXG4vKipcbiAqIEByZXR1cm5zIHtDbGF5SXRlbXxDbGF5RXZlbnRzfVxuICogQGV4dGVuZHMge0NsYXlJdGVtfVxuICovXG5mdW5jdGlvbiBoaWRlKCkge1xuICBpZiAodGhpcy4kZWxlbWVudFswXS5jbGFzc0xpc3QuY29udGFpbnMoJ2hpZGUnKSkgeyByZXR1cm4gdGhpczsgfVxuICB0aGlzLiRlbGVtZW50LnNldCgnK2hpZGUnKTtcbiAgcmV0dXJuIHRoaXMudHJpZ2dlcignaGlkZScpO1xufVxuXG4vKipcbiAqIEByZXR1cm5zIHtDbGF5SXRlbXxDbGF5RXZlbnRzfVxuICogQGV4dGVuZHMge0NsYXlJdGVtfVxuICovXG5mdW5jdGlvbiBzaG93KCkge1xuICBpZiAoIXRoaXMuJGVsZW1lbnRbMF0uY2xhc3NMaXN0LmNvbnRhaW5zKCdoaWRlJykpIHsgcmV0dXJuIHRoaXM7IH1cbiAgdGhpcy4kZWxlbWVudC5zZXQoJy1oaWRlJyk7XG4gIHJldHVybiB0aGlzLnRyaWdnZXIoJ3Nob3cnKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIGh0bWw6IHtcbiAgICBnZXQ6IGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIHRoaXMuJG1hbmlwdWxhdG9yVGFyZ2V0LmdldCgnaW5uZXJIVE1MJyk7XG4gICAgfSxcbiAgICBzZXQ6IGZ1bmN0aW9uKHZhbHVlKSB7XG4gICAgICBpZiAodGhpcy5nZXQoKSA9PT0gdmFsdWUudG9TdHJpbmcoMTApKSB7IHJldHVybiB0aGlzOyB9XG4gICAgICB0aGlzLiRtYW5pcHVsYXRvclRhcmdldC5zZXQoJ2lubmVySFRNTCcsIHZhbHVlKTtcbiAgICAgIHJldHVybiB0aGlzLnRyaWdnZXIoJ2NoYW5nZScpO1xuICAgIH0sXG4gICAgaGlkZTogaGlkZSxcbiAgICBzaG93OiBzaG93XG4gIH0sXG4gIGJ1dHRvbjoge1xuICAgIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICByZXR1cm4gdGhpcy4kbWFuaXB1bGF0b3JUYXJnZXQuZ2V0KCdpbm5lckhUTUwnKTtcbiAgICB9LFxuICAgIHNldDogZnVuY3Rpb24odmFsdWUpIHtcbiAgICAgIGlmICh0aGlzLmdldCgpID09PSB2YWx1ZS50b1N0cmluZygxMCkpIHsgcmV0dXJuIHRoaXM7IH1cbiAgICAgIHRoaXMuJG1hbmlwdWxhdG9yVGFyZ2V0LnNldCgnaW5uZXJIVE1MJywgdmFsdWUpO1xuICAgICAgcmV0dXJuIHRoaXMudHJpZ2dlcignY2hhbmdlJyk7XG4gICAgfSxcbiAgICBkaXNhYmxlOiBkaXNhYmxlLFxuICAgIGVuYWJsZTogZW5hYmxlLFxuICAgIGhpZGU6IGhpZGUsXG4gICAgc2hvdzogc2hvd1xuICB9LFxuICB2YWw6IHtcbiAgICBnZXQ6IGZ1bmN0aW9uKCkge1xuICAgICAgbGV0IHZhbHVlID0gdGhpcy4kbWFuaXB1bGF0b3JUYXJnZXQuZ2V0KCd2YWx1ZScpO1xuICAgICAgc3dpdGNoICh0aGlzLmNvbmZpZy5zZXJpYWxpemVWYWx1ZUFzKSB7XG4gICAgICAgIGNhc2UgJ2ludGVnZXInOlxuICAgICAgICAgIGxldCBpbnRlZ2VyVmFsdWUgPSBNYXRoLnRydW5jKE51bWJlci5wYXJzZUludCh2YWx1ZSwgMTApKTtcbiAgICAgICAgICByZXR1cm4gTnVtYmVyLmlzTmFOKGludGVnZXJWYWx1ZSkgPyAwIDogaW50ZWdlclZhbHVlO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgIH1cbiAgICB9LFxuICAgIHNldDogZnVuY3Rpb24odmFsdWUpIHtcbiAgICAgIGxldCBjdXJyZW50VmFsdWUgPSB0aGlzLiRtYW5pcHVsYXRvclRhcmdldC5nZXQoJ3ZhbHVlJyk7XG4gICAgICBpZiAodHlwZW9mIGN1cnJlbnRWYWx1ZSAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICAgICAgY3VycmVudFZhbHVlID09PSB2YWx1ZS50b1N0cmluZygxMCkpIHsgcmV0dXJuIHRoaXM7IH1cbiAgICAgIHRoaXMuJG1hbmlwdWxhdG9yVGFyZ2V0LnNldCgndmFsdWUnLCB2YWx1ZSk7XG4gICAgICByZXR1cm4gdGhpcy50cmlnZ2VyKCdjaGFuZ2UnKTtcbiAgICB9LFxuICAgIGRpc2FibGU6IGRpc2FibGUsXG4gICAgZW5hYmxlOiBlbmFibGUsXG4gICAgaGlkZTogaGlkZSxcbiAgICBzaG93OiBzaG93XG4gIH0sXG4gIHNsaWRlcjoge1xuICAgIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICByZXR1cm4gcGFyc2VGbG9hdCh0aGlzLiRtYW5pcHVsYXRvclRhcmdldC5nZXQoJ3ZhbHVlJykpO1xuICAgIH0sXG4gICAgc2V0OiBmdW5jdGlvbih2YWx1ZSkge1xuICAgICAgdmFyIGluaXRWYWwgPSB0aGlzLmdldCgpO1xuICAgICAgdGhpcy4kbWFuaXB1bGF0b3JUYXJnZXQuc2V0KCd2YWx1ZScsIHZhbHVlKTtcbiAgICAgIGlmICh0aGlzLmdldCgpID09PSBpbml0VmFsKSB7IHJldHVybiB0aGlzOyB9XG4gICAgICByZXR1cm4gdGhpcy50cmlnZ2VyKCdjaGFuZ2UnKTtcbiAgICB9LFxuICAgIGRpc2FibGU6IGRpc2FibGUsXG4gICAgZW5hYmxlOiBlbmFibGUsXG4gICAgaGlkZTogaGlkZSxcbiAgICBzaG93OiBzaG93XG4gIH0sXG4gIGNoZWNrZWQ6IHtcbiAgICBnZXQ6IGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIHRoaXMuJG1hbmlwdWxhdG9yVGFyZ2V0LmdldCgnY2hlY2tlZCcpO1xuICAgIH0sXG4gICAgc2V0OiBmdW5jdGlvbih2YWx1ZSkge1xuICAgICAgaWYgKCF0aGlzLmdldCgpID09PSAhdmFsdWUpIHsgcmV0dXJuIHRoaXM7IH1cbiAgICAgIHRoaXMuJG1hbmlwdWxhdG9yVGFyZ2V0LnNldCgnY2hlY2tlZCcsICEhdmFsdWUpO1xuICAgICAgcmV0dXJuIHRoaXMudHJpZ2dlcignY2hhbmdlJyk7XG4gICAgfSxcbiAgICBkaXNhYmxlOiBkaXNhYmxlLFxuICAgIGVuYWJsZTogZW5hYmxlLFxuICAgIGhpZGU6IGhpZGUsXG4gICAgc2hvdzogc2hvd1xuICB9LFxuICByYWRpb2dyb3VwOiB7XG4gICAgZ2V0OiBmdW5jdGlvbigpIHtcbiAgICAgIGxldCB2YWx1ZSA9IHRoaXMuJGVsZW1lbnQuc2VsZWN0KCdpbnB1dDpjaGVja2VkJykuZ2V0KCd2YWx1ZScpO1xuICAgICAgc3dpdGNoICh0aGlzLmNvbmZpZy5zZXJpYWxpemVWYWx1ZUFzKSB7XG4gICAgICAgIGNhc2UgJ2ludGVnZXInOlxuICAgICAgICAgIGxldCBpbnRlZ2VyVmFsdWUgPSBNYXRoLnRydW5jKE51bWJlci5wYXJzZUludCh2YWx1ZSwgMTApKTtcbiAgICAgICAgICByZXR1cm4gTnVtYmVyLmlzTmFOKGludGVnZXJWYWx1ZSkgPyAwIDogaW50ZWdlclZhbHVlO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgIH1cbiAgICB9LFxuICAgIHNldDogZnVuY3Rpb24odmFsdWUpIHtcbiAgICAgIGxldCBjdXJyZW50VmFsdWUgPSB0aGlzLiRlbGVtZW50LnNlbGVjdCgnaW5wdXQ6Y2hlY2tlZCcpLmdldCgndmFsdWUnKTtcbiAgICAgIGlmICh0eXBlb2YgY3VycmVudFZhbHVlICE9PSAndW5kZWZpbmVkJyAmJlxuICAgICAgICBjdXJyZW50VmFsdWUgPT09IHZhbHVlLnRvU3RyaW5nKDEwKSkgeyByZXR1cm4gdGhpczsgfVxuICAgICAgdGhpcy4kZWxlbWVudFxuICAgICAgICAuc2VsZWN0KCdpbnB1dFt2YWx1ZT1cIicgKyB2YWx1ZS50b1N0cmluZygxMCkucmVwbGFjZSgnXCInLCAnXFxcXFwiJykgKyAnXCJdJylcbiAgICAgICAgLnNldCgnY2hlY2tlZCcsIHRydWUpO1xuICAgICAgcmV0dXJuIHRoaXMudHJpZ2dlcignY2hhbmdlJyk7XG4gICAgfSxcbiAgICBkaXNhYmxlOiBkaXNhYmxlLFxuICAgIGVuYWJsZTogZW5hYmxlLFxuICAgIGhpZGU6IGhpZGUsXG4gICAgc2hvdzogc2hvd1xuICB9LFxuICBjaGVja2JveGdyb3VwOiB7XG4gICAgZ2V0OiBmdW5jdGlvbigpIHtcbiAgICAgIHZhciByZXN1bHQgPSBbXTtcbiAgICAgIHRoaXMuJGVsZW1lbnQuc2VsZWN0KCdpbnB1dCcpLmVhY2goZnVuY3Rpb24oaXRlbSkge1xuICAgICAgICByZXN1bHQucHVzaCghIWl0ZW0uY2hlY2tlZCk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfSxcbiAgICBzZXQ6IGZ1bmN0aW9uKHZhbHVlcykge1xuICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgdmFsdWVzID0gQXJyYXkuaXNBcnJheSh2YWx1ZXMpID8gdmFsdWVzIDogW107XG5cbiAgICAgIHdoaWxlICh2YWx1ZXMubGVuZ3RoIDwgdGhpcy5nZXQoKS5sZW5ndGgpIHtcbiAgICAgICAgdmFsdWVzLnB1c2goZmFsc2UpO1xuICAgICAgfVxuXG4gICAgICBpZiAoXy5lcXVhbHModGhpcy5nZXQoKSwgdmFsdWVzKSkgeyByZXR1cm4gdGhpczsgfVxuXG4gICAgICBzZWxmLiRlbGVtZW50LnNlbGVjdCgnaW5wdXQnKVxuICAgICAgICAuc2V0KCdjaGVja2VkJywgZmFsc2UpXG4gICAgICAgIC5lYWNoKGZ1bmN0aW9uKGl0ZW0sIGluZGV4KSB7XG4gICAgICAgICAgaXRlbS5jaGVja2VkID0gISF2YWx1ZXNbaW5kZXhdO1xuICAgICAgICB9KTtcblxuICAgICAgcmV0dXJuIHNlbGYudHJpZ2dlcignY2hhbmdlJyk7XG4gICAgfSxcbiAgICBkaXNhYmxlOiBkaXNhYmxlLFxuICAgIGVuYWJsZTogZW5hYmxlLFxuICAgIGhpZGU6IGhpZGUsXG4gICAgc2hvdzogc2hvd1xuICB9LFxuICBjb2xvcjoge1xuICAgIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICByZXR1cm4gcGFyc2VJbnQodGhpcy4kbWFuaXB1bGF0b3JUYXJnZXQuZ2V0KCd2YWx1ZScpLCAxMCkgfHwgMDtcbiAgICB9LFxuICAgIHNldDogZnVuY3Rpb24odmFsdWUpIHtcbiAgICAgIHZhbHVlID0gdGhpcy5yb3VuZENvbG9yVG9MYXlvdXQodmFsdWUgfHwgMCk7XG5cbiAgICAgIGlmICh0aGlzLmdldCgpID09PSB2YWx1ZSkgeyByZXR1cm4gdGhpczsgfVxuICAgICAgdGhpcy4kbWFuaXB1bGF0b3JUYXJnZXQuc2V0KCd2YWx1ZScsIHZhbHVlKTtcbiAgICAgIHJldHVybiB0aGlzLnRyaWdnZXIoJ2NoYW5nZScpO1xuICAgIH0sXG4gICAgZGlzYWJsZTogZGlzYWJsZSxcbiAgICBlbmFibGU6IGVuYWJsZSxcbiAgICBoaWRlOiBoaWRlLFxuICAgIHNob3c6IHNob3dcbiAgfVxufTtcbiIsIid1c2Ugc3RyaWN0JztcblxuLyoqXG4gKiBCYXRjaCB1cGRhdGUgYWxsIHRoZSBwcm9wZXJ0aWVzIG9mIGFuIG9iamVjdC5cbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmpcbiAqIEBwYXJhbSB7T2JqZWN0fSBkZXNjcmlwdG9yXG4gKiBAcGFyYW0ge2Jvb2xlYW59IFtkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZV1cbiAqIEBwYXJhbSB7Ym9vbGVhbn0gW2Rlc2NyaXB0b3IuZW51bWVyYWJsZV1cbiAqIEBwYXJhbSB7Kn0gW2Rlc2NyaXB0b3IudmFsdWVdXG4gKiBAcGFyYW0ge2Jvb2xlYW59IFtkZXNjcmlwdG9yLndyaXRhYmxlXVxuICogQHBhcmFtIHtmdW5jdGlvbn0gW2Rlc2NyaXB0b3IuZ2V0XVxuICogQHBhcmFtIHtmdW5jdGlvbn0gW2Rlc2NyaXB0b3Iuc2V0XVxuICogQHJldHVybiB7dm9pZH1cbiAqL1xubW9kdWxlLmV4cG9ydHMudXBkYXRlUHJvcGVydGllcyA9IGZ1bmN0aW9uKG9iaiwgZGVzY3JpcHRvcikge1xuICBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhvYmopLmZvckVhY2goZnVuY3Rpb24ocHJvcCkge1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmosIHByb3AsIGRlc2NyaXB0b3IpO1xuICB9KTtcbn07XG5cbm1vZHVsZS5leHBvcnRzLmNhcGFiaWxpdHlNYXAgPSB7XG4gIFBMQVRGT1JNX0FQTElURToge1xuICAgIHBsYXRmb3JtczogWydhcGxpdGUnXSxcbiAgICBtaW5Gd01ham9yOiAwLFxuICAgIG1pbkZ3TWlub3I6IDBcbiAgfSxcbiAgUExBVEZPUk1fQkFTQUxUOiB7XG4gICAgcGxhdGZvcm1zOiBbJ2Jhc2FsdCddLFxuICAgIG1pbkZ3TWFqb3I6IDAsXG4gICAgbWluRndNaW5vcjogMFxuICB9LFxuICBQTEFURk9STV9DSEFMSzoge1xuICAgIHBsYXRmb3JtczogWydjaGFsayddLFxuICAgIG1pbkZ3TWFqb3I6IDAsXG4gICAgbWluRndNaW5vcjogMFxuICB9LFxuICBQTEFURk9STV9ESU9SSVRFOiB7XG4gICAgcGxhdGZvcm1zOiBbJ2Rpb3JpdGUnXSxcbiAgICBtaW5Gd01ham9yOiAwLFxuICAgIG1pbkZ3TWlub3I6IDBcbiAgfSxcbiAgUExBVEZPUk1fRU1FUlk6IHtcbiAgICBwbGF0Zm9ybXM6IFsnZW1lcnknXSxcbiAgICBtaW5Gd01ham9yOiAwLFxuICAgIG1pbkZ3TWlub3I6IDBcbiAgfSxcbiAgUExBVEZPUk1fRkxJTlQ6IHtcbiAgICBwbGF0Zm9ybXM6IFsnZmxpbnQnXSxcbiAgICBtaW5Gd01ham9yOiAwLFxuICAgIG1pbkZ3TWlub3I6IDBcbiAgfSxcbiAgUExBVEZPUk1fR0FCQlJPOiB7XG4gICAgcGxhdGZvcm1zOiBbJ2dhYmJybyddLFxuICAgIG1pbkZ3TWFqb3I6IDAsXG4gICAgbWluRndNaW5vcjogMFxuICB9LFxuICBCVzoge1xuICAgIHBsYXRmb3JtczogWydhcGxpdGUnLCAnZGlvcml0ZScsICdmbGludCddLFxuICAgIG1pbkZ3TWFqb3I6IDAsXG4gICAgbWluRndNaW5vcjogMFxuICB9LFxuICBDT0xPUjoge1xuICAgIHBsYXRmb3JtczogWydiYXNhbHQnLCAnY2hhbGsnLCAnZW1lcnknLCAnZ2FiYnJvJ10sXG4gICAgbWluRndNYWpvcjogMCxcbiAgICBtaW5Gd01pbm9yOiAwXG4gIH0sXG4gIENPTVBBU1M6IHtcbiAgICBwbGF0Zm9ybXM6IFsnYXBsaXRlJywgJ2Jhc2FsdCcsICdjaGFsaycsICdlbWVyeScsICdmbGludCcsICdnYWJicm8nXSxcbiAgICBtaW5Gd01ham9yOiAwLFxuICAgIG1pbkZ3TWlub3I6IDBcbiAgfSxcbiAgTUlDUk9QSE9ORToge1xuICAgIHBsYXRmb3JtczogWydiYXNhbHQnLCAnY2hhbGsnLCAnZGlvcml0ZScsICdlbWVyeScsICdmbGludCcsICdnYWJicm8nXSxcbiAgICBtaW5Gd01ham9yOiAwLFxuICAgIG1pbkZ3TWlub3I6IDBcbiAgfSxcbiAgUkdCX0JBQ0tMSUdIVDoge1xuICAgIHBsYXRmb3JtczogWydlbWVyeSddLFxuICAgIG1pbkZ3TWFqb3I6IDQsXG4gICAgbWluRndNaW5vcjogOVxuICB9LFxuICBTTUFSVFNUUkFQOiB7XG4gICAgcGxhdGZvcm1zOiBbJ2Jhc2FsdCcsICdjaGFsaycsICdkaW9yaXRlJywgJ2VtZXJ5J10sXG4gICAgbWluRndNYWpvcjogMyxcbiAgICBtaW5Gd01pbm9yOiA0XG4gIH0sXG4gIFNNQVJUU1RSQVBfUE9XRVI6IHtcbiAgICBwbGF0Zm9ybXM6IFsnYmFzYWx0JywgJ2NoYWxrJywgJ2VtZXJ5J10sXG4gICAgbWluRndNYWpvcjogMyxcbiAgICBtaW5Gd01pbm9yOiA0XG4gIH0sXG4gIFNQRUFLRVI6IHtcbiAgICBwbGF0Zm9ybXM6IFsnZW1lcnknLCAnZmxpbnQnXSxcbiAgICBtaW5Gd01ham9yOiA0LFxuICAgIG1pbkZ3TWlub3I6IDlcbiAgfSxcbiAgVE9VQ0g6IHtcbiAgICBwbGF0Zm9ybXM6IFsnZW1lcnknLCAnZ2FiYnJvJ10sXG4gICAgbWluRndNYWpvcjogNCxcbiAgICBtaW5Gd01pbm9yOiA5XG4gIH0sXG4gIEhFQUxUSDoge1xuICAgIHBsYXRmb3JtczogWydiYXNhbHQnLCAnY2hhbGsnLCAnZGlvcml0ZScsICdlbWVyeScsICdmbGludCcsICdnYWJicm8nXSxcbiAgICBtaW5Gd01ham9yOiAzLFxuICAgIG1pbkZ3TWlub3I6IDEwXG4gIH0sXG4gIFJFQ1Q6IHtcbiAgICBwbGF0Zm9ybXM6IFsnYXBsaXRlJywgJ2Jhc2FsdCcsICdkaW9yaXRlJywgJ2VtZXJ5JywgJ2ZsaW50J10sXG4gICAgbWluRndNYWpvcjogMCxcbiAgICBtaW5Gd01pbm9yOiAwXG4gIH0sXG4gIFJPVU5EOiB7XG4gICAgcGxhdGZvcm1zOiBbJ2NoYWxrJywgJ2dhYmJybyddLFxuICAgIG1pbkZ3TWFqb3I6IDAsXG4gICAgbWluRndNaW5vcjogMFxuICB9LFxuICBESVNQTEFZXzE0NHgxNjg6IHtcbiAgICBwbGF0Zm9ybXM6IFsnYXBsaXRlJywgJ2Jhc2FsdCcsICdkaW9yaXRlJywgJ2ZsaW50J10sXG4gICAgbWluRndNYWpvcjogMCxcbiAgICBtaW5Gd01pbm9yOiAwXG4gIH0sXG4gIERJU1BMQVlfMTgweDE4MF9ST1VORDoge1xuICAgIHBsYXRmb3JtczogWydjaGFsayddLFxuICAgIG1pbkZ3TWFqb3I6IDAsXG4gICAgbWluRndNaW5vcjogMFxuICB9LFxuICBESVNQTEFZXzIwMHgyMjg6IHtcbiAgICBwbGF0Zm9ybXM6IFsnZW1lcnknXSxcbiAgICBtaW5Gd01ham9yOiAwLFxuICAgIG1pbkZ3TWlub3I6IDBcbiAgfSxcbiAgRElTUExBWV8yNjB4MjYwX1JPVU5EOiB7XG4gICAgcGxhdGZvcm1zOiBbJ2dhYmJybyddLFxuICAgIG1pbkZ3TWFqb3I6IDAsXG4gICAgbWluRndNaW5vcjogMFxuICB9XG59O1xuXG4vKipcbiAqIENoZWNrcyBpZiBhbGwgb2YgdGhlIHByb3ZpZGVkIGNhcGFiaWxpdGllcyBhcmUgY29tcGF0aWJsZSB3aXRoIHRoZSB3YXRjaFxuICogQHBhcmFtIHtPYmplY3R9IGFjdGl2ZVdhdGNoSW5mb1xuICogQHBhcmFtIHtBcnJheTxzdHJpbmc+fSBbY2FwYWJpbGl0aWVzXVxuICogQHJldHVybiB7Ym9vbGVhbn1cbiAqL1xubW9kdWxlLmV4cG9ydHMuaW5jbHVkZXNDYXBhYmlsaXR5ID0gZnVuY3Rpb24oYWN0aXZlV2F0Y2hJbmZvLCBjYXBhYmlsaXRpZXMpIHtcbiAgdmFyIG5vdFJlZ2V4ID0gL15OT1RfLztcbiAgdmFyIHJlc3VsdCA9IFtdO1xuXG4gIGlmICghY2FwYWJpbGl0aWVzIHx8ICFjYXBhYmlsaXRpZXMubGVuZ3RoKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICBmb3IgKHZhciBpID0gY2FwYWJpbGl0aWVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgdmFyIGNhcGFiaWxpdHkgPSBjYXBhYmlsaXRpZXNbaV07XG4gICAgdmFyIG1hcHBpbmcgPSBtb2R1bGUuZXhwb3J0cy5jYXBhYmlsaXR5TWFwW2NhcGFiaWxpdHkucmVwbGFjZShub3RSZWdleCwgJycpXTtcblxuICAgIGlmICghbWFwcGluZyB8fFxuICAgICAgICBtYXBwaW5nLnBsYXRmb3Jtcy5pbmRleE9mKGFjdGl2ZVdhdGNoSW5mby5wbGF0Zm9ybSkgPT09IC0xIHx8XG4gICAgICAgIG1hcHBpbmcubWluRndNYWpvciA+IGFjdGl2ZVdhdGNoSW5mby5maXJtd2FyZS5tYWpvciB8fFxuICAgICAgICBtYXBwaW5nLm1pbkZ3TWFqb3IgPT09IGFjdGl2ZVdhdGNoSW5mby5maXJtd2FyZS5tYWpvciAmJlxuICAgICAgICBtYXBwaW5nLm1pbkZ3TWlub3IgPiBhY3RpdmVXYXRjaEluZm8uZmlybXdhcmUubWlub3JcbiAgICApIHtcbiAgICAgIHJlc3VsdC5wdXNoKCEhY2FwYWJpbGl0eS5tYXRjaChub3RSZWdleCkpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXN1bHQucHVzaCghY2FwYWJpbGl0eS5tYXRjaChub3RSZWdleCkpO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiByZXN1bHQuaW5kZXhPZihmYWxzZSkgPT09IC0xO1xufTtcbiIsIm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciBfd2luZG93ID0gd2luZG93O1xuICAgIHZhciBNSU5JRklFRF9NQUdJQ19OT0RFSUQgPSAnTmlhJztcbiAgICB2YXIgTUlOSUZJRURfTUFHSUNfUFJFViA9ICdOaWFQJztcbiAgICB2YXIgc2V0dGVyID0ge30sIGdldHRlciA9IHt9O1xuICAgIHZhciBpZFNlcXVlbmNlID0gMTtcbiAgICB2YXIgRE9NUkVBRFlfSEFORExFUiA9IC9eW2ljXS8udGVzdChkb2N1bWVudFsncmVhZHlTdGF0ZSddKSA/IF9udWxsIDogW107XG4gICAgdmFyIF9udWxsID0gbnVsbDtcbiAgICB2YXIgdW5kZWY7XG4gICAgZnVuY3Rpb24gdmFsMyh2KSB7XG4gICAgICAgIHJldHVybiB2LnN1YnN0cigwLCAzKTtcbiAgICB9XG4gICAgdmFyIE1PTlRIX0xPTkdfTkFNRVMgPSBzcGxpdCgnSmFudWFyeSxGZWJydWFyeSxNYXJjaCxBcHJpbCxNYXksSnVuZSxKdWx5LEF1Z3VzdCxTZXB0ZW1iZXIsT2N0b2JlcixOb3ZlbWJlcixEZWNlbWJlcicsIC8sL2cpO1xuICAgIHZhciBNT05USF9TSE9SVF9OQU1FUyA9IG1hcChNT05USF9MT05HX05BTUVTLCB2YWwzKTtcbiAgICB2YXIgV0VFS19MT05HX05BTUVTID0gc3BsaXQoJ1N1bmRheSxNb25kYXksVHVlc2RheSxXZWRuZXNkYXksVGh1cnNkYXksRnJpZGF5LFNhdHVyZGF5JywgLywvZyk7XG4gICAgdmFyIFdFRUtfU0hPUlRfTkFNRVMgPSBtYXAoV0VFS19MT05HX05BTUVTLCB2YWwzKTtcbiAgICB2YXIgTUVSSURJQU5fTkFNRVMgPSBzcGxpdCgnYW0scG0nLCAvLC9nKTtcbiAgICB2YXIgTUVSSURJQU5fTkFNRVNfRlVMTCA9IHNwbGl0KCdhbSxhbSxhbSxhbSxhbSxhbSxhbSxhbSxhbSxhbSxhbSxhbSxwbSxwbSxwbSxwbSxwbSxwbSxwbSxwbSxwbSxwbSxwbSxwbScsIC8sL2cpO1xuICAgIHZhciBGT1JNQVRfREFURV9NQVAgPSB7XG4gICAgICAgICd5JzogW1xuICAgICAgICAgICAgJ0Z1bGxZZWFyJyxcbiAgICAgICAgICAgIG5vbk9wXG4gICAgICAgIF0sXG4gICAgICAgICdZJzogW1xuICAgICAgICAgICAgJ0Z1bGxZZWFyJyxcbiAgICAgICAgICAgIGZ1bmN0aW9uIChkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGQgJSAxMDA7XG4gICAgICAgICAgICB9XG4gICAgICAgIF0sXG4gICAgICAgICdNJzogW1xuICAgICAgICAgICAgJ01vbnRoJyxcbiAgICAgICAgICAgIHBsdXNPbmVcbiAgICAgICAgXSxcbiAgICAgICAgJ24nOiBbXG4gICAgICAgICAgICAnTW9udGgnLFxuICAgICAgICAgICAgTU9OVEhfU0hPUlRfTkFNRVNcbiAgICAgICAgXSxcbiAgICAgICAgJ04nOiBbXG4gICAgICAgICAgICAnTW9udGgnLFxuICAgICAgICAgICAgTU9OVEhfTE9OR19OQU1FU1xuICAgICAgICBdLFxuICAgICAgICAnZCc6IFtcbiAgICAgICAgICAgICdEYXRlJyxcbiAgICAgICAgICAgIG5vbk9wXG4gICAgICAgIF0sXG4gICAgICAgICdtJzogW1xuICAgICAgICAgICAgJ01pbnV0ZXMnLFxuICAgICAgICAgICAgbm9uT3BcbiAgICAgICAgXSxcbiAgICAgICAgJ0gnOiBbXG4gICAgICAgICAgICAnSG91cnMnLFxuICAgICAgICAgICAgbm9uT3BcbiAgICAgICAgXSxcbiAgICAgICAgJ2gnOiBbXG4gICAgICAgICAgICAnSG91cnMnLFxuICAgICAgICAgICAgZnVuY3Rpb24gKGQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZCAlIDEyIHx8IDEyO1xuICAgICAgICAgICAgfVxuICAgICAgICBdLFxuICAgICAgICAnayc6IFtcbiAgICAgICAgICAgICdIb3VycycsXG4gICAgICAgICAgICBwbHVzT25lXG4gICAgICAgIF0sXG4gICAgICAgICdLJzogW1xuICAgICAgICAgICAgJ0hvdXJzJyxcbiAgICAgICAgICAgIGZ1bmN0aW9uIChkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGQgJSAxMjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgXSxcbiAgICAgICAgJ3MnOiBbXG4gICAgICAgICAgICAnU2Vjb25kcycsXG4gICAgICAgICAgICBub25PcFxuICAgICAgICBdLFxuICAgICAgICAnUyc6IFtcbiAgICAgICAgICAgICdNaWxsaXNlY29uZHMnLFxuICAgICAgICAgICAgbm9uT3BcbiAgICAgICAgXSxcbiAgICAgICAgJ2EnOiBbXG4gICAgICAgICAgICAnSG91cnMnLFxuICAgICAgICAgICAgTUVSSURJQU5fTkFNRVNfRlVMTFxuICAgICAgICBdLFxuICAgICAgICAndyc6IFtcbiAgICAgICAgICAgICdEYXknLFxuICAgICAgICAgICAgV0VFS19TSE9SVF9OQU1FU1xuICAgICAgICBdLFxuICAgICAgICAnVyc6IFtcbiAgICAgICAgICAgICdEYXknLFxuICAgICAgICAgICAgV0VFS19MT05HX05BTUVTXG4gICAgICAgIF0sXG4gICAgICAgICd6JzogW1xuICAgICAgICAgICAgJ1RpbWV6b25lT2Zmc2V0JyxcbiAgICAgICAgICAgIGZ1bmN0aW9uIChkLCBkdW1teSwgdGltZXpvbmUpIHtcbiAgICAgICAgICAgICAgICBpZiAodGltZXpvbmUpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aW1lem9uZTtcbiAgICAgICAgICAgICAgICB2YXIgc2lnbiA9IGQgPiAwID8gJy0nIDogJysnO1xuICAgICAgICAgICAgICAgIHZhciBvZmYgPSBkIDwgMCA/IC1kIDogZDtcbiAgICAgICAgICAgICAgICByZXR1cm4gc2lnbiArIHBhZCgyLCBNYXRoLmZsb29yKG9mZiAvIDYwKSkgKyBwYWQoMiwgb2ZmICUgNjApO1xuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfTtcbiAgICB2YXIgUEFSU0VfREFURV9NQVAgPSB7XG4gICAgICAgICd5JzogMCxcbiAgICAgICAgJ1knOiBbXG4gICAgICAgICAgICAwLFxuICAgICAgICAgICAgLTIwMDBcbiAgICAgICAgXSxcbiAgICAgICAgJ00nOiBbXG4gICAgICAgICAgICAxLFxuICAgICAgICAgICAgMVxuICAgICAgICBdLFxuICAgICAgICAnbic6IFtcbiAgICAgICAgICAgIDEsXG4gICAgICAgICAgICBNT05USF9TSE9SVF9OQU1FU1xuICAgICAgICBdLFxuICAgICAgICAnTic6IFtcbiAgICAgICAgICAgIDEsXG4gICAgICAgICAgICBNT05USF9MT05HX05BTUVTXG4gICAgICAgIF0sXG4gICAgICAgICdkJzogMixcbiAgICAgICAgJ20nOiA0LFxuICAgICAgICAnSCc6IDMsXG4gICAgICAgICdoJzogMyxcbiAgICAgICAgJ0snOiBbXG4gICAgICAgICAgICAzLFxuICAgICAgICAgICAgMVxuICAgICAgICBdLFxuICAgICAgICAnayc6IFtcbiAgICAgICAgICAgIDMsXG4gICAgICAgICAgICAxXG4gICAgICAgIF0sXG4gICAgICAgICdzJzogNSxcbiAgICAgICAgJ1MnOiA2LFxuICAgICAgICAnYSc6IFtcbiAgICAgICAgICAgIDMsXG4gICAgICAgICAgICBNRVJJRElBTl9OQU1FU1xuICAgICAgICBdXG4gICAgfTtcbiAgICB2YXIgTUFYX0NBQ0hFRF9URU1QTEFURVMgPSA5OTtcbiAgICB2YXIgdGVtcGxhdGVDYWNoZSA9IHt9O1xuICAgIHZhciB0ZW1wbGF0ZXMgPSBbXTtcbiAgICBmdW5jdGlvbiB0b1N0cmluZyhzKSB7XG4gICAgICAgIHJldHVybiBzICE9IF9udWxsID8gJycgKyBzIDogJyc7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzVHlwZShzLCBvKSB7XG4gICAgICAgIHJldHVybiB0eXBlb2YgcyA9PSBvO1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc1N0cmluZyhzKSB7XG4gICAgICAgIHJldHVybiBpc1R5cGUocywgJ3N0cmluZycpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc09iamVjdChmKSB7XG4gICAgICAgIHJldHVybiAhIWYgJiYgaXNUeXBlKGYsICdvYmplY3QnKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaXNOb2RlKG4pIHtcbiAgICAgICAgcmV0dXJuIG4gJiYgblsnbm9kZVR5cGUnXTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaXNOdW1iZXIobikge1xuICAgICAgICByZXR1cm4gaXNUeXBlKG4sICdudW1iZXInKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaXNEYXRlKG4pIHtcbiAgICAgICAgcmV0dXJuIGlzT2JqZWN0KG4pICYmICEhblsnZ2V0RGF5J107XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzQm9vbChuKSB7XG4gICAgICAgIHJldHVybiBuID09PSB0cnVlIHx8IG4gPT09IGZhbHNlO1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc1ZhbHVlKG4pIHtcbiAgICAgICAgdmFyIHR5cGUgPSB0eXBlb2YgbjtcbiAgICAgICAgcmV0dXJuIHR5cGUgPT0gJ29iamVjdCcgPyAhIShuICYmIG5bJ2dldERheSddKSA6IHR5cGUgPT0gJ3N0cmluZycgfHwgdHlwZSA9PSAnbnVtYmVyJyB8fCBpc0Jvb2wobik7XG4gICAgfVxuICAgIGZ1bmN0aW9uIG5vbk9wKHYpIHtcbiAgICAgICAgcmV0dXJuIHY7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHBsdXNPbmUoZCkge1xuICAgICAgICByZXR1cm4gZCArIDE7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHJlcGxhY2UocywgcmVnZXhwLCBzdWIpIHtcbiAgICAgICAgcmV0dXJuIHRvU3RyaW5nKHMpLnJlcGxhY2UocmVnZXhwLCBzdWIgIT0gX251bGwgPyBzdWIgOiAnJyk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGVzY2FwZVJlZ0V4cChzKSB7XG4gICAgICAgIHJldHVybiByZXBsYWNlKHMsIC9bXFxcXFxcW1xcXVxcL3t9KCkqKz8uJHxeLV0vZywgJ1xcXFwkJicpO1xuICAgIH1cbiAgICBmdW5jdGlvbiB0cmltKHMpIHtcbiAgICAgICAgcmV0dXJuIHJlcGxhY2UocywgL15cXHMrfFxccyskL2cpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBlYWNoT2JqKG9iaiwgY2IsIGN0eCkge1xuICAgICAgICBmb3IgKHZhciBuIGluIG9iailcbiAgICAgICAgICAgIGlmIChvYmouaGFzT3duUHJvcGVydHkobikpXG4gICAgICAgICAgICAgICAgY2IuY2FsbChjdHggfHwgb2JqLCBuLCBvYmpbbl0pO1xuICAgICAgICByZXR1cm4gb2JqO1xuICAgIH1cbiAgICBmdW5jdGlvbiBlYWNoKGxpc3QsIGNiLCBjdHgpIHtcbiAgICAgICAgaWYgKGxpc3QpXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxpc3QubGVuZ3RoOyBpKyspXG4gICAgICAgICAgICAgICAgY2IuY2FsbChjdHggfHwgbGlzdCwgbGlzdFtpXSwgaSk7XG4gICAgICAgIHJldHVybiBsaXN0O1xuICAgIH1cbiAgICBmdW5jdGlvbiBmaWx0ZXIobGlzdCwgZmlsdGVyRnVuY09yT2JqZWN0LCBjdHgpIHtcbiAgICAgICAgdmFyIHIgPSBbXTtcbiAgICAgICAgdmFyIGYgPSBpc0Z1bmN0aW9uKGZpbHRlckZ1bmNPck9iamVjdCkgPyBmaWx0ZXJGdW5jT3JPYmplY3QgOiBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIHJldHVybiBmaWx0ZXJGdW5jT3JPYmplY3QgIT0gdmFsdWU7XG4gICAgICAgIH07XG4gICAgICAgIGVhY2gobGlzdCwgZnVuY3Rpb24gKHZhbHVlLCBpbmRleCkge1xuICAgICAgICAgICAgaWYgKGYuY2FsbChjdHggfHwgbGlzdCwgdmFsdWUsIGluZGV4KSlcbiAgICAgICAgICAgICAgICByLnB1c2godmFsdWUpO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHI7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNvbGxlY3RvcihpdGVyYXRvciwgb2JqLCBjb2xsZWN0RnVuYywgY3R4KSB7XG4gICAgICAgIHZhciByZXN1bHQgPSBbXTtcbiAgICAgICAgaXRlcmF0b3Iob2JqLCBmdW5jdGlvbiAoYSwgYikge1xuICAgICAgICAgICAgaWYgKGlzTGlzdChhID0gY29sbGVjdEZ1bmMuY2FsbChjdHggfHwgb2JqLCBhLCBiKSkpXG4gICAgICAgICAgICAgICAgZWFjaChhLCBmdW5jdGlvbiAocnIpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2gocnIpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgZWxzZSBpZiAoYSAhPSBfbnVsbClcbiAgICAgICAgICAgICAgICByZXN1bHQucHVzaChhKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNvbGxlY3RPYmoob2JqLCBjb2xsZWN0RnVuYywgY3R4KSB7XG4gICAgICAgIHJldHVybiBjb2xsZWN0b3IoZWFjaE9iaiwgb2JqLCBjb2xsZWN0RnVuYywgY3R4KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gY29sbGVjdChsaXN0LCBjb2xsZWN0RnVuYywgY3R4KSB7XG4gICAgICAgIHJldHVybiBjb2xsZWN0b3IoZWFjaCwgbGlzdCwgY29sbGVjdEZ1bmMsIGN0eCk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGtleUNvdW50KG9iaikge1xuICAgICAgICB2YXIgYyA9IDA7XG4gICAgICAgIGVhY2hPYmoob2JqLCBmdW5jdGlvbiAoa2V5KSB7XG4gICAgICAgICAgICBjKys7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gYztcbiAgICB9XG4gICAgZnVuY3Rpb24ga2V5cyhvYmopIHtcbiAgICAgICAgdmFyIGxpc3QgPSBbXTtcbiAgICAgICAgZWFjaE9iaihvYmosIGZ1bmN0aW9uIChrZXkpIHtcbiAgICAgICAgICAgIGxpc3QucHVzaChrZXkpO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIGxpc3Q7XG4gICAgfVxuICAgIGZ1bmN0aW9uIG1hcChsaXN0LCBtYXBGdW5jLCBjdHgpIHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IFtdO1xuICAgICAgICBlYWNoKGxpc3QsIGZ1bmN0aW9uIChpdGVtLCBpbmRleCkge1xuICAgICAgICAgICAgcmVzdWx0LnB1c2gobWFwRnVuYy5jYWxsKGN0eCB8fCBsaXN0LCBpdGVtLCBpbmRleCkpO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgZnVuY3Rpb24gc3RhcnRzV2l0aChiYXNlLCBzdGFydCkge1xuICAgICAgICBpZiAoaXNMaXN0KGJhc2UpKSB7XG4gICAgICAgICAgICB2YXIgczIgPSBfKHN0YXJ0KTtcbiAgICAgICAgICAgIHJldHVybiBlcXVhbHMoc3ViKGJhc2UsIDAsIHMyLmxlbmd0aCksIHMyKTtcbiAgICAgICAgfSBlbHNlXG4gICAgICAgICAgICByZXR1cm4gc3RhcnQgIT0gX251bGwgJiYgYmFzZS5zdWJzdHIoMCwgc3RhcnQubGVuZ3RoKSA9PSBzdGFydDtcbiAgICB9XG4gICAgZnVuY3Rpb24gZW5kc1dpdGgoYmFzZSwgZW5kKSB7XG4gICAgICAgIGlmIChpc0xpc3QoYmFzZSkpIHtcbiAgICAgICAgICAgIHZhciBlMiA9IF8oZW5kKTtcbiAgICAgICAgICAgIHJldHVybiBlcXVhbHMoc3ViKGJhc2UsIC1lMi5sZW5ndGgpLCBlMikgfHwgIWUyLmxlbmd0aDtcbiAgICAgICAgfSBlbHNlXG4gICAgICAgICAgICByZXR1cm4gZW5kICE9IF9udWxsICYmIGJhc2Uuc3Vic3RyKGJhc2UubGVuZ3RoIC0gZW5kLmxlbmd0aCkgPT0gZW5kO1xuICAgIH1cbiAgICBmdW5jdGlvbiByZXZlcnNlKGxpc3QpIHtcbiAgICAgICAgdmFyIGxlbiA9IGxpc3QubGVuZ3RoO1xuICAgICAgICBpZiAoaXNMaXN0KGxpc3QpKVxuICAgICAgICAgICAgcmV0dXJuIG5ldyBNKG1hcChsaXN0LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGxpc3RbLS1sZW5dO1xuICAgICAgICAgICAgfSkpO1xuICAgICAgICBlbHNlXG4gICAgICAgICAgICByZXR1cm4gcmVwbGFjZShsaXN0LCAvW1xcc1xcU10vZywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBsaXN0LmNoYXJBdCgtLWxlbik7XG4gICAgICAgICAgICB9KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gdG9PYmplY3QobGlzdCwgdmFsdWUpIHtcbiAgICAgICAgdmFyIG9iaiA9IHt9O1xuICAgICAgICBlYWNoKGxpc3QsIGZ1bmN0aW9uIChpdGVtLCBpbmRleCkge1xuICAgICAgICAgICAgb2JqW2l0ZW1dID0gdmFsdWU7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gb2JqO1xuICAgIH1cbiAgICBmdW5jdGlvbiBjb3B5T2JqKGZyb20sIHRvKSB7XG4gICAgICAgIHZhciBkZXN0ID0gdG8gfHwge307XG4gICAgICAgIGZvciAodmFyIG5hbWUgaW4gZnJvbSlcbiAgICAgICAgICAgIGRlc3RbbmFtZV0gPSBmcm9tW25hbWVdO1xuICAgICAgICByZXR1cm4gZGVzdDtcbiAgICB9XG4gICAgZnVuY3Rpb24gbWVyZ2UobGlzdCwgdGFyZ2V0KSB7XG4gICAgICAgIHZhciBvID0gdGFyZ2V0O1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxpc3QubGVuZ3RoOyBpKyspXG4gICAgICAgICAgICBvID0gY29weU9iaihsaXN0W2ldLCBvKTtcbiAgICAgICAgcmV0dXJuIG87XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldEZpbmRGdW5jKGZpbmRGdW5jKSB7XG4gICAgICAgIHJldHVybiBpc0Z1bmN0aW9uKGZpbmRGdW5jKSA/IGZpbmRGdW5jIDogZnVuY3Rpb24gKG9iaiwgaW5kZXgpIHtcbiAgICAgICAgICAgIGlmIChmaW5kRnVuYyA9PT0gb2JqKVxuICAgICAgICAgICAgICAgIHJldHVybiBpbmRleDtcbiAgICAgICAgfTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0RmluZEluZGV4KGxpc3QsIGluZGV4LCBkZWZhdWx0SW5kZXgpIHtcbiAgICAgICAgcmV0dXJuIGluZGV4ID09IF9udWxsID8gZGVmYXVsdEluZGV4IDogaW5kZXggPCAwID8gTWF0aC5tYXgobGlzdC5sZW5ndGggKyBpbmRleCwgMCkgOiBNYXRoLm1pbihsaXN0Lmxlbmd0aCwgaW5kZXgpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBmaW5kKGxpc3QsIGZpbmRGdW5jLCBzdGFydEluZGV4LCBlbmRJbmRleCkge1xuICAgICAgICB2YXIgZiA9IGdldEZpbmRGdW5jKGZpbmRGdW5jKTtcbiAgICAgICAgdmFyIGUgPSBnZXRGaW5kSW5kZXgobGlzdCwgZW5kSW5kZXgsIGxpc3QubGVuZ3RoKTtcbiAgICAgICAgdmFyIHI7XG4gICAgICAgIGZvciAodmFyIGkgPSBnZXRGaW5kSW5kZXgobGlzdCwgc3RhcnRJbmRleCwgMCk7IGkgPCBlOyBpKyspXG4gICAgICAgICAgICBpZiAoKHIgPSBmLmNhbGwobGlzdCwgbGlzdFtpXSwgaSkpICE9IF9udWxsKVxuICAgICAgICAgICAgICAgIHJldHVybiByO1xuICAgIH1cbiAgICBmdW5jdGlvbiBmaW5kTGFzdChsaXN0LCBmaW5kRnVuYywgc3RhcnRJbmRleCwgZW5kSW5kZXgpIHtcbiAgICAgICAgdmFyIGYgPSBnZXRGaW5kRnVuYyhmaW5kRnVuYyk7XG4gICAgICAgIHZhciBlID0gZ2V0RmluZEluZGV4KGxpc3QsIGVuZEluZGV4LCAtMSk7XG4gICAgICAgIHZhciByO1xuICAgICAgICBmb3IgKHZhciBpID0gZ2V0RmluZEluZGV4KGxpc3QsIHN0YXJ0SW5kZXgsIGxpc3QubGVuZ3RoIC0gMSk7IGkgPiBlOyBpLS0pXG4gICAgICAgICAgICBpZiAoKHIgPSBmLmNhbGwobGlzdCwgbGlzdFtpXSwgaSkpICE9IF9udWxsKVxuICAgICAgICAgICAgICAgIHJldHVybiByO1xuICAgIH1cbiAgICBmdW5jdGlvbiBzdWIobGlzdCwgc3RhcnRJbmRleCwgZW5kSW5kZXgpIHtcbiAgICAgICAgdmFyIHIgPSBbXTtcbiAgICAgICAgaWYgKGxpc3QpIHtcbiAgICAgICAgICAgIHZhciBlID0gZ2V0RmluZEluZGV4KGxpc3QsIGVuZEluZGV4LCBsaXN0Lmxlbmd0aCk7XG4gICAgICAgICAgICBmb3IgKHZhciBpID0gZ2V0RmluZEluZGV4KGxpc3QsIHN0YXJ0SW5kZXgsIDApOyBpIDwgZTsgaSsrKVxuICAgICAgICAgICAgICAgIHIucHVzaChsaXN0W2ldKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcjtcbiAgICB9XG4gICAgZnVuY3Rpb24gYXJyYXkobGlzdCkge1xuICAgICAgICByZXR1cm4gbWFwKGxpc3QsIG5vbk9wKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gdW5pdGUobGlzdCkge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBNKGNhbGxMaXN0KGxpc3QsIGFyZ3VtZW50cykpO1xuICAgICAgICB9O1xuICAgIH1cbiAgICBmdW5jdGlvbiB1bmlxKGxpc3QpIHtcbiAgICAgICAgdmFyIGZvdW5kID0ge307XG4gICAgICAgIHJldHVybiBmaWx0ZXIobGlzdCwgZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgICAgIGlmIChmb3VuZFtpdGVtXSlcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZvdW5kW2l0ZW1dID0gMTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGludGVyc2VjdGlvbihsaXN0LCBvdGhlckxpc3QpIHtcbiAgICAgICAgdmFyIGtleXMgPSB0b09iamVjdChvdGhlckxpc3QsIDEpO1xuICAgICAgICByZXR1cm4gZmlsdGVyKGxpc3QsIGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICAgICAgICB2YXIgciA9IGtleXNbaXRlbV07XG4gICAgICAgICAgICBrZXlzW2l0ZW1dID0gMDtcbiAgICAgICAgICAgIHJldHVybiByO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gY29udGFpbnMobGlzdCwgdmFsdWUpIHtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsaXN0Lmxlbmd0aDsgaSsrKVxuICAgICAgICAgICAgaWYgKGxpc3RbaV0gPT0gdmFsdWUpXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZXF1YWxzKHgsIHkpIHtcbiAgICAgICAgdmFyIGEgPSBpc0Z1bmN0aW9uKHgpID8geCgpIDogeDtcbiAgICAgICAgdmFyIGIgPSBpc0Z1bmN0aW9uKHkpID8geSgpIDogeTtcbiAgICAgICAgdmFyIGFLZXlzO1xuICAgICAgICBpZiAoYSA9PSBiKVxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIGVsc2UgaWYgKGEgPT0gX251bGwgfHwgYiA9PSBfbnVsbClcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgZWxzZSBpZiAoaXNWYWx1ZShhKSB8fCBpc1ZhbHVlKGIpKVxuICAgICAgICAgICAgcmV0dXJuIGlzRGF0ZShhKSAmJiBpc0RhdGUoYikgJiYgK2EgPT0gK2I7XG4gICAgICAgIGVsc2UgaWYgKGlzTGlzdChhKSkge1xuICAgICAgICAgICAgcmV0dXJuIGEubGVuZ3RoID09IGIubGVuZ3RoICYmICFmaW5kKGEsIGZ1bmN0aW9uICh2YWwsIGluZGV4KSB7XG4gICAgICAgICAgICAgICAgaWYgKCFlcXVhbHModmFsLCBiW2luZGV4XSkpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gIWlzTGlzdChiKSAmJiAoYUtleXMgPSBrZXlzKGEpKS5sZW5ndGggPT0ga2V5Q291bnQoYikgJiYgIWZpbmQoYUtleXMsIGZ1bmN0aW9uIChrZXkpIHtcbiAgICAgICAgICAgICAgICBpZiAoIWVxdWFscyhhW2tleV0sIGJba2V5XSkpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gY2FsbChmLCBmVGhpc09yQXJncywgYXJncykge1xuICAgICAgICBpZiAoaXNGdW5jdGlvbihmKSlcbiAgICAgICAgICAgIHJldHVybiBmLmFwcGx5KGFyZ3MgJiYgZlRoaXNPckFyZ3MsIG1hcChhcmdzIHx8IGZUaGlzT3JBcmdzLCBub25PcCkpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBjYWxsTGlzdChsaXN0LCBmVGhpc09yQXJncywgYXJncykge1xuICAgICAgICByZXR1cm4gbWFwKGxpc3QsIGZ1bmN0aW9uIChmKSB7XG4gICAgICAgICAgICByZXR1cm4gY2FsbChmLCBmVGhpc09yQXJncywgYXJncyk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBmdW5jdGlvbiBiaW5kKGYsIGZUaGlzLCBiZWZvcmVBcmdzLCBhZnRlckFyZ3MpIHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJldHVybiBjYWxsKGYsIGZUaGlzLCBjb2xsZWN0KFtcbiAgICAgICAgICAgICAgICBiZWZvcmVBcmdzLFxuICAgICAgICAgICAgICAgIGFyZ3VtZW50cyxcbiAgICAgICAgICAgICAgICBhZnRlckFyZ3NcbiAgICAgICAgICAgIF0sIG5vbk9wKSk7XG4gICAgICAgIH07XG4gICAgfVxuICAgIGZ1bmN0aW9uIHBhcnRpYWwoZiwgYmVmb3JlQXJncywgYWZ0ZXJBcmdzKSB7XG4gICAgICAgIHJldHVybiBiaW5kKGYsIHRoaXMsIGJlZm9yZUFyZ3MsIGFmdGVyQXJncyk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHBhZChkaWdpdHMsIG51bWJlcikge1xuICAgICAgICB2YXIgc2lnbmVkID0gbnVtYmVyIDwgMCA/ICctJyA6ICcnO1xuICAgICAgICB2YXIgcHJlRGVjaW1hbCA9IChzaWduZWQgPyAtbnVtYmVyIDogbnVtYmVyKS50b0ZpeGVkKDApO1xuICAgICAgICB3aGlsZSAocHJlRGVjaW1hbC5sZW5ndGggPCBkaWdpdHMpXG4gICAgICAgICAgICBwcmVEZWNpbWFsID0gJzAnICsgcHJlRGVjaW1hbDtcbiAgICAgICAgcmV0dXJuIHNpZ25lZCArIHByZURlY2ltYWw7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHByb2Nlc3NOdW1DaGFyVGVtcGxhdGUodHBsLCBpbnB1dCwgZndkKSB7XG4gICAgICAgIHZhciBpbkhhc2g7XG4gICAgICAgIHZhciBpbnB1dFBvcyA9IDA7XG4gICAgICAgIHZhciBySW5wdXQgPSBmd2QgPyBpbnB1dCA6IHJldmVyc2UoaW5wdXQpO1xuICAgICAgICB2YXIgcyA9IChmd2QgPyB0cGwgOiByZXZlcnNlKHRwbCkpLnJlcGxhY2UoLy4vZywgZnVuY3Rpb24gKHRwbENoYXIpIHtcbiAgICAgICAgICAgIGlmICh0cGxDaGFyID09ICcwJykge1xuICAgICAgICAgICAgICAgIGluSGFzaCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHJldHVybiBySW5wdXQuY2hhckF0KGlucHV0UG9zKyspIHx8ICcwJztcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodHBsQ2hhciA9PSAnIycpIHtcbiAgICAgICAgICAgICAgICBpbkhhc2ggPSB0cnVlO1xuICAgICAgICAgICAgICAgIHJldHVybiBySW5wdXQuY2hhckF0KGlucHV0UG9zKyspIHx8ICcnO1xuICAgICAgICAgICAgfSBlbHNlXG4gICAgICAgICAgICAgICAgcmV0dXJuIGluSGFzaCAmJiAhcklucHV0LmNoYXJBdChpbnB1dFBvcykgPyAnJyA6IHRwbENoYXI7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gZndkID8gcyA6IGlucHV0LnN1YnN0cigwLCBpbnB1dC5sZW5ndGggLSBpbnB1dFBvcykgKyByZXZlcnNlKHMpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXRUaW1lem9uZShtYXRjaCwgaWR4LCByZWZEYXRlKSB7XG4gICAgICAgIGlmIChpZHggPT0gX251bGwgfHwgIW1hdGNoKVxuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIHJldHVybiBwYXJzZUZsb2F0KG1hdGNoW2lkeF0gKyBtYXRjaFtpZHggKyAxXSkgKiA2MCArIHBhcnNlRmxvYXQobWF0Y2hbaWR4XSArIG1hdGNoW2lkeCArIDJdKSArIHJlZkRhdGUuZ2V0VGltZXpvbmVPZmZzZXQoKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZm9ybWF0VmFsdWUoZm10LCB2YWx1ZSkge1xuICAgICAgICB2YXIgZm9ybWF0ID0gcmVwbGFjZShmbXQsIC9eXFw/Lyk7XG4gICAgICAgIGlmIChpc0RhdGUodmFsdWUpKSB7XG4gICAgICAgICAgICB2YXIgdGltZXpvbmUsIG1hdGNoO1xuICAgICAgICAgICAgaWYgKG1hdGNoID0gL15cXFsoKFsrLV0pKFxcZFxcZCkoXFxkXFxkKSlcXF1cXHMqKC4qKS8uZXhlYyhmb3JtYXQpKSB7XG4gICAgICAgICAgICAgICAgdGltZXpvbmUgPSBtYXRjaFsxXTtcbiAgICAgICAgICAgICAgICB2YWx1ZSA9IGRhdGVBZGQodmFsdWUsICdtaW51dGVzJywgZ2V0VGltZXpvbmUobWF0Y2gsIDIsIHZhbHVlKSk7XG4gICAgICAgICAgICAgICAgZm9ybWF0ID0gbWF0Y2hbNV07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcmVwbGFjZShmb3JtYXQsIC8oXFx3KShcXDEqKSg/OlxcWyhbXlxcXV0rKVxcXSk/L2csIGZ1bmN0aW9uIChzLCBwbGFjZWhvbGRlckNoYXIsIHBsYWNlaG9sZGVyRGlnaXRzLCBwYXJhbXMpIHtcbiAgICAgICAgICAgICAgICB2YXIgdmFsID0gRk9STUFUX0RBVEVfTUFQW3BsYWNlaG9sZGVyQ2hhcl07XG4gICAgICAgICAgICAgICAgaWYgKHZhbCkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgZCA9IHZhbHVlWydnZXQnICsgdmFsWzBdXSgpO1xuICAgICAgICAgICAgICAgICAgICB2YXIgb3B0aW9uQXJyYXkgPSBwYXJhbXMgJiYgcGFyYW1zLnNwbGl0KCcsJyk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc0xpc3QodmFsWzFdKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGQgPSAob3B0aW9uQXJyYXkgfHwgdmFsWzFdKVtkXTtcbiAgICAgICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgZCA9IHZhbFsxXShkLCBvcHRpb25BcnJheSwgdGltZXpvbmUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZCAhPSBfbnVsbCAmJiAhaXNTdHJpbmcoZCkpXG4gICAgICAgICAgICAgICAgICAgICAgICBkID0gcGFkKHBsYWNlaG9sZGVyRGlnaXRzLmxlbmd0aCArIDEsIGQpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZDtcbiAgICAgICAgICAgICAgICB9IGVsc2VcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHM7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlXG4gICAgICAgICAgICByZXR1cm4gZmluZChmb3JtYXQuc3BsaXQoL1xccypcXHxcXHMqLyksIGZ1bmN0aW9uIChmbXRQYXJ0KSB7XG4gICAgICAgICAgICAgICAgdmFyIG1hdGNoLCBudW1GbXRPclJlc3VsdDtcbiAgICAgICAgICAgICAgICBpZiAobWF0Y2ggPSAvXihbPD5dPykoPT8pKFteOl0qPylcXHMqOlxccyooLiopJC8uZXhlYyhmbXRQYXJ0KSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgY21wVmFsMSA9IHZhbHVlLCBjbXBWYWwyID0gK21hdGNoWzNdO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXNOYU4oY21wVmFsMikgfHwgIWlzTnVtYmVyKGNtcFZhbDEpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjbXBWYWwxID0gY21wVmFsMSA9PSBfbnVsbCA/ICdudWxsJyA6IHRvU3RyaW5nKGNtcFZhbDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY21wVmFsMiA9IG1hdGNoWzNdO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChtYXRjaFsxXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFtYXRjaFsyXSAmJiBjbXBWYWwxID09IGNtcFZhbDIgfHwgbWF0Y2hbMV0gPT0gJzwnICYmIGNtcFZhbDEgPiBjbXBWYWwyIHx8IG1hdGNoWzFdID09ICc+JyAmJiBjbXBWYWwxIDwgY21wVmFsMilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gX251bGw7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoY21wVmFsMSAhPSBjbXBWYWwyKVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF9udWxsO1xuICAgICAgICAgICAgICAgICAgICBudW1GbXRPclJlc3VsdCA9IG1hdGNoWzRdO1xuICAgICAgICAgICAgICAgIH0gZWxzZVxuICAgICAgICAgICAgICAgICAgICBudW1GbXRPclJlc3VsdCA9IGZtdFBhcnQ7XG4gICAgICAgICAgICAgICAgaWYgKGlzTnVtYmVyKHZhbHVlKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bUZtdE9yUmVzdWx0LnJlcGxhY2UoL1swI10oLipbMCNdKT8vLCBmdW5jdGlvbiAobnVtRm10KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGVjaW1hbEZtdCA9IC9eKFteLl0rKShcXC4pKFteLl0rKSQvLmV4ZWMobnVtRm10KSB8fCAvXihbXixdKykoLCkoW14sXSspJC8uZXhlYyhudW1GbXQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHNpZ25lZCA9IHZhbHVlIDwgMCA/ICctJyA6ICcnO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG51bURhdGEgPSAvKFxcZCspKFxcLihcXGQrKSk/Ly5leGVjKChzaWduZWQgPyAtdmFsdWUgOiB2YWx1ZSkudG9GaXhlZChkZWNpbWFsRm10ID8gZGVjaW1hbEZtdFszXS5sZW5ndGggOiAwKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcHJlRGVjaW1hbEZtdCA9IGRlY2ltYWxGbXQgPyBkZWNpbWFsRm10WzFdIDogbnVtRm10O1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHBvc3REZWNpbWFsID0gZGVjaW1hbEZtdCA/IHByb2Nlc3NOdW1DaGFyVGVtcGxhdGUoZGVjaW1hbEZtdFszXSwgcmVwbGFjZShudW1EYXRhWzNdLCAvMCskLyksIHRydWUpIDogJyc7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKHNpZ25lZCA/ICctJyA6ICcnKSArIChwcmVEZWNpbWFsRm10ID09ICcjJyA/IG51bURhdGFbMV0gOiBwcm9jZXNzTnVtQ2hhclRlbXBsYXRlKHByZURlY2ltYWxGbXQsIG51bURhdGFbMV0pKSArIChwb3N0RGVjaW1hbC5sZW5ndGggPyBkZWNpbWFsRm10WzJdIDogJycpICsgcG9zdERlY2ltYWw7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bUZtdE9yUmVzdWx0O1xuICAgICAgICAgICAgfSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHBhcnNlRGF0ZShmbXQsIGRhdGUpIHtcbiAgICAgICAgdmFyIGluZGV4TWFwID0ge307XG4gICAgICAgIHZhciByZUluZGV4ID0gMTtcbiAgICAgICAgdmFyIHRpbWV6b25lT2Zmc2V0TWF0Y2g7XG4gICAgICAgIHZhciB0aW1lem9uZUluZGV4O1xuICAgICAgICB2YXIgbWF0Y2g7XG4gICAgICAgIHZhciBmb3JtYXQgPSByZXBsYWNlKGZtdCwgL15cXD8vKTtcbiAgICAgICAgaWYgKGZvcm1hdCAhPSBmbXQgJiYgIXRyaW0oZGF0ZSkpXG4gICAgICAgICAgICByZXR1cm4gX251bGw7XG4gICAgICAgIGlmIChtYXRjaCA9IC9eXFxbKFsrLV0pKFxcZFxcZCkoXFxkXFxkKVxcXVxccyooLiopLy5leGVjKGZvcm1hdCkpIHtcbiAgICAgICAgICAgIHRpbWV6b25lT2Zmc2V0TWF0Y2ggPSBtYXRjaDtcbiAgICAgICAgICAgIGZvcm1hdCA9IG1hdGNoWzRdO1xuICAgICAgICB9XG4gICAgICAgIHZhciBwYXJzZXIgPSBuZXcgUmVnRXhwKGZvcm1hdC5yZXBsYWNlKC8oLikoXFwxKikoPzpcXFsoW15cXF1dKilcXF0pPy9nLCBmdW5jdGlvbiAod2hvbGVNYXRjaCwgcGxhY2Vob2xkZXJDaGFyLCBwbGFjZWhvbGRlckRpZ2l0cywgcGFyYW0pIHtcbiAgICAgICAgICAgIGlmICgvW2RtaGt5aHNdL2kudGVzdChwbGFjZWhvbGRlckNoYXIpKSB7XG4gICAgICAgICAgICAgICAgaW5kZXhNYXBbcmVJbmRleCsrXSA9IHBsYWNlaG9sZGVyQ2hhcjtcbiAgICAgICAgICAgICAgICB2YXIgcGxlbiA9IHBsYWNlaG9sZGVyRGlnaXRzLmxlbmd0aCArIDE7XG4gICAgICAgICAgICAgICAgcmV0dXJuICcoXFxcXGQnICsgKHBsZW4gPCAyID8gJysnIDogJ3sxLCcgKyBwbGVuICsgJ30nKSArICcpJztcbiAgICAgICAgICAgIH0gZWxzZSBpZiAocGxhY2Vob2xkZXJDaGFyID09ICd6Jykge1xuICAgICAgICAgICAgICAgIHRpbWV6b25lSW5kZXggPSByZUluZGV4O1xuICAgICAgICAgICAgICAgIHJlSW5kZXggKz0gMztcbiAgICAgICAgICAgICAgICByZXR1cm4gJyhbKy1dKShcXFxcZFxcXFxkKShcXFxcZFxcXFxkKSc7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKC9bTm5hXS8udGVzdChwbGFjZWhvbGRlckNoYXIpKSB7XG4gICAgICAgICAgICAgICAgaW5kZXhNYXBbcmVJbmRleCsrXSA9IFtcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXJDaGFyLFxuICAgICAgICAgICAgICAgICAgICBwYXJhbSAmJiBwYXJhbS5zcGxpdCgnLCcpXG4gICAgICAgICAgICAgICAgXTtcbiAgICAgICAgICAgICAgICByZXR1cm4gJyhbYS16QS1aXFxcXHUwMDgwLVxcXFx1MWZmZl0rKSc7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKC93L2kudGVzdChwbGFjZWhvbGRlckNoYXIpKVxuICAgICAgICAgICAgICAgIHJldHVybiAnW2EtekEtWlxcXFx1MDA4MC1cXFxcdTFmZmZdKyc7XG4gICAgICAgICAgICBlbHNlIGlmICgvXFxzLy50ZXN0KHBsYWNlaG9sZGVyQ2hhcikpXG4gICAgICAgICAgICAgICAgcmV0dXJuICdcXFxccysnO1xuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgIHJldHVybiBlc2NhcGVSZWdFeHAod2hvbGVNYXRjaCk7XG4gICAgICAgIH0pKTtcbiAgICAgICAgaWYgKCEobWF0Y2ggPSBwYXJzZXIuZXhlYyhkYXRlKSkpXG4gICAgICAgICAgICByZXR1cm4gdW5kZWY7XG4gICAgICAgIHZhciBjdG9yQXJncyA9IFtcbiAgICAgICAgICAgIDAsXG4gICAgICAgICAgICAwLFxuICAgICAgICAgICAgMCxcbiAgICAgICAgICAgIDAsXG4gICAgICAgICAgICAwLFxuICAgICAgICAgICAgMCxcbiAgICAgICAgICAgIDBcbiAgICAgICAgXTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDE7IGkgPCByZUluZGV4OyBpKyspIHtcbiAgICAgICAgICAgIHZhciBtYXRjaFZhbCA9IG1hdGNoW2ldO1xuICAgICAgICAgICAgdmFyIGluZGV4RW50cnkgPSBpbmRleE1hcFtpXTtcbiAgICAgICAgICAgIGlmIChpc0xpc3QoaW5kZXhFbnRyeSkpIHtcbiAgICAgICAgICAgICAgICB2YXIgcGxhY2Vob2xkZXJDaGFyID0gaW5kZXhFbnRyeVswXTtcbiAgICAgICAgICAgICAgICB2YXIgbWFwRW50cnkgPSBQQVJTRV9EQVRFX01BUFtwbGFjZWhvbGRlckNoYXJdO1xuICAgICAgICAgICAgICAgIHZhciBjdG9ySW5kZXggPSBtYXBFbnRyeVswXTtcbiAgICAgICAgICAgICAgICB2YXIgdmFsTGlzdCA9IGluZGV4RW50cnlbMV0gfHwgbWFwRW50cnlbMV07XG4gICAgICAgICAgICAgICAgdmFyIGxpc3RWYWx1ZSA9IGZpbmQodmFsTGlzdCwgZnVuY3Rpb24gKHYsIGluZGV4KSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChzdGFydHNXaXRoKG1hdGNoVmFsLnRvTG93ZXJDYXNlKCksIHYudG9Mb3dlckNhc2UoKSkpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gaW5kZXg7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgaWYgKGxpc3RWYWx1ZSA9PSBfbnVsbClcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHVuZGVmO1xuICAgICAgICAgICAgICAgIGlmIChwbGFjZWhvbGRlckNoYXIgPT0gJ2EnKVxuICAgICAgICAgICAgICAgICAgICBjdG9yQXJnc1tjdG9ySW5kZXhdICs9IGxpc3RWYWx1ZSAqIDEyO1xuICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgY3RvckFyZ3NbY3RvckluZGV4XSA9IGxpc3RWYWx1ZTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoaW5kZXhFbnRyeSkge1xuICAgICAgICAgICAgICAgIHZhciB2YWx1ZSA9IHBhcnNlRmxvYXQobWF0Y2hWYWwpO1xuICAgICAgICAgICAgICAgIHZhciBtYXBFbnRyeSA9IFBBUlNFX0RBVEVfTUFQW2luZGV4RW50cnldO1xuICAgICAgICAgICAgICAgIGlmIChpc0xpc3QobWFwRW50cnkpKVxuICAgICAgICAgICAgICAgICAgICBjdG9yQXJnc1ttYXBFbnRyeVswXV0gKz0gdmFsdWUgLSBtYXBFbnRyeVsxXTtcbiAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgIGN0b3JBcmdzW21hcEVudHJ5XSArPSB2YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB2YXIgZCA9IG5ldyBEYXRlKGN0b3JBcmdzWzBdLCBjdG9yQXJnc1sxXSwgY3RvckFyZ3NbMl0sIGN0b3JBcmdzWzNdLCBjdG9yQXJnc1s0XSwgY3RvckFyZ3NbNV0sIGN0b3JBcmdzWzZdKTtcbiAgICAgICAgcmV0dXJuIGRhdGVBZGQoZCwgJ21pbnV0ZXMnLCAtZ2V0VGltZXpvbmUodGltZXpvbmVPZmZzZXRNYXRjaCwgMSwgZCkgLSBnZXRUaW1lem9uZShtYXRjaCwgdGltZXpvbmVJbmRleCwgZCkpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBwYXJzZU51bWJlcihmbXQsIHZhbHVlKSB7XG4gICAgICAgIHZhciBmb3JtYXQgPSByZXBsYWNlKGZtdCwgL15cXD8vKTtcbiAgICAgICAgaWYgKGZvcm1hdCAhPSBmbXQgJiYgIXRyaW0odmFsdWUpKVxuICAgICAgICAgICAgcmV0dXJuIF9udWxsO1xuICAgICAgICB2YXIgZGVjU2VwID0gLyhefFteMCMuLF0pKCx8WzAjLl0qLFswI10rfFswI10rXFwuWzAjXStcXC5bMCMuLF0qKSgkfFteMCMuLF0pLy50ZXN0KGZvcm1hdCkgPyAnLCcgOiAnLic7XG4gICAgICAgIHZhciByID0gcGFyc2VGbG9hdChyZXBsYWNlKHJlcGxhY2UocmVwbGFjZSh2YWx1ZSwgZGVjU2VwID09ICcsJyA/IC9cXC4vZyA6IC8sL2cpLCBkZWNTZXAsICcuJyksIC9eW15cXGQtXSooLT9cXGQpLywgJyQxJykpO1xuICAgICAgICByZXR1cm4gaXNOYU4ocikgPyB1bmRlZiA6IHI7XG4gICAgfVxuICAgIGZ1bmN0aW9uIG5vdygpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBEYXRlKCk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGRhdGVDbG9uZShkYXRlKSB7XG4gICAgICAgIHJldHVybiBuZXcgRGF0ZSgrZGF0ZSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNhcFdvcmQodykge1xuICAgICAgICByZXR1cm4gdy5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIHcuc3Vic3RyKDEpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBkYXRlQWRkSW5saW5lKGQsIGNQcm9wLCB2YWx1ZSkge1xuICAgICAgICBkWydzZXQnICsgY1Byb3BdKGRbJ2dldCcgKyBjUHJvcF0oKSArIHZhbHVlKTtcbiAgICAgICAgcmV0dXJuIGQ7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGRhdGVBZGQoZGF0ZSwgcHJvcGVydHksIHZhbHVlKSB7XG4gICAgICAgIGlmICh2YWx1ZSA9PSBfbnVsbClcbiAgICAgICAgICAgIHJldHVybiBkYXRlQWRkKG5vdygpLCBkYXRlLCBwcm9wZXJ0eSk7XG4gICAgICAgIHJldHVybiBkYXRlQWRkSW5saW5lKGRhdGVDbG9uZShkYXRlKSwgY2FwV29yZChwcm9wZXJ0eSksIHZhbHVlKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZGF0ZU1pZG5pZ2h0KGRhdGUpIHtcbiAgICAgICAgdmFyIG9kID0gZGF0ZSB8fCBub3coKTtcbiAgICAgICAgcmV0dXJuIG5ldyBEYXRlKG9kLmdldEZ1bGxZZWFyKCksIG9kLmdldE1vbnRoKCksIG9kLmdldERhdGUoKSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGRhdGVEaWZmKHByb3BlcnR5LCBkYXRlMSwgZGF0ZTIpIHtcbiAgICAgICAgdmFyIGQxdCA9ICtkYXRlMTtcbiAgICAgICAgdmFyIGQydCA9ICtkYXRlMjtcbiAgICAgICAgdmFyIGR0ID0gZDJ0IC0gZDF0O1xuICAgICAgICBpZiAoZHQgPCAwKVxuICAgICAgICAgICAgcmV0dXJuIC1kYXRlRGlmZihwcm9wZXJ0eSwgZGF0ZTIsIGRhdGUxKTtcbiAgICAgICAgdmFyIHByb3BWYWx1ZXMgPSB7XG4gICAgICAgICAgICAnbWlsbGlzZWNvbmRzJzogMSxcbiAgICAgICAgICAgICdzZWNvbmRzJzogMTAwMCxcbiAgICAgICAgICAgICdtaW51dGVzJzogNjAwMDAsXG4gICAgICAgICAgICAnaG91cnMnOiAzNjAwMDAwXG4gICAgICAgIH07XG4gICAgICAgIHZhciBmdCA9IHByb3BWYWx1ZXNbcHJvcGVydHldO1xuICAgICAgICBpZiAoZnQpXG4gICAgICAgICAgICByZXR1cm4gZHQgLyBmdDtcbiAgICAgICAgdmFyIGNQcm9wID0gY2FwV29yZChwcm9wZXJ0eSk7XG4gICAgICAgIHZhciBjYWxBcHByb3hWYWx1ZXMgPSB7XG4gICAgICAgICAgICAnZnVsbFllYXInOiA4NjQwMDAwMCAqIDM2NSxcbiAgICAgICAgICAgICdtb250aCc6IDg2NDAwMDAwICogMzY1IC8gMTIsXG4gICAgICAgICAgICAnZGF0ZSc6IDg2NDAwMDAwXG4gICAgICAgIH07XG4gICAgICAgIHZhciBtaW5pbXVtUmVzdWx0ID0gTWF0aC5mbG9vcihkdCAvIGNhbEFwcHJveFZhbHVlc1twcm9wZXJ0eV0gLSAyKTtcbiAgICAgICAgdmFyIGQgPSBkYXRlQWRkSW5saW5lKG5ldyBEYXRlKGQxdCksIGNQcm9wLCBtaW5pbXVtUmVzdWx0KTtcbiAgICAgICAgZm9yICh2YXIgaSA9IG1pbmltdW1SZXN1bHQ7IGkgPCBtaW5pbXVtUmVzdWx0ICogMS4yICsgNDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoK2RhdGVBZGRJbmxpbmUoZCwgY1Byb3AsIDEpID4gZDJ0KVxuICAgICAgICAgICAgICAgIHJldHVybiBpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIHVjb2RlKGEpIHtcbiAgICAgICAgcmV0dXJuICdcXFxcdScgKyAoJzAwMDAnICsgYS5jaGFyQ29kZUF0KDApLnRvU3RyaW5nKDE2KSkuc2xpY2UoLTQpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBlc2NhcGVKYXZhU2NyaXB0U3RyaW5nKHMpIHtcbiAgICAgICAgcmV0dXJuIHJlcGxhY2UocywgL1tcXHgwMC1cXHgxZidcIlxcdTIwMjhcXHUyMDI5XS9nLCB1Y29kZSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHNwbGl0KHN0ciwgcmVnZXhwKSB7XG4gICAgICAgIHJldHVybiBzdHIuc3BsaXQocmVnZXhwKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gdGVtcGxhdGUodGVtcGxhdGUsIGVzY2FwZUZ1bmN0aW9uKSB7XG4gICAgICAgIGlmICh0ZW1wbGF0ZUNhY2hlW3RlbXBsYXRlXSlcbiAgICAgICAgICAgIHJldHVybiB0ZW1wbGF0ZUNhY2hlW3RlbXBsYXRlXTtcbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB2YXIgZnVuY0JvZHkgPSAnd2l0aChfLmlzT2JqZWN0KG9iaik/b2JqOnt9KXsnICsgbWFwKHNwbGl0KHRlbXBsYXRlLCAve3t8fX19Py9nKSwgZnVuY3Rpb24gKGNodW5rLCBpbmRleCkge1xuICAgICAgICAgICAgICAgIHZhciBtYXRjaCwgYzEgPSB0cmltKGNodW5rKSwgYzIgPSByZXBsYWNlKGMxLCAvXnsvKSwgZXNjYXBlU25pcHBldCA9IGMxID09IGMyID8gJ2VzYygnIDogJyc7XG4gICAgICAgICAgICAgICAgaWYgKGluZGV4ICUgMikge1xuICAgICAgICAgICAgICAgICAgICBpZiAobWF0Y2ggPSAvXmVhY2hcXGIoXFxzKyhbXFx3X10rKFxccyosXFxzKltcXHdfXSspPylcXHMqOik/KC4qKS8uZXhlYyhjMikpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gJ2VhY2goJyArICh0cmltKG1hdGNoWzRdKSA/IG1hdGNoWzRdIDogJ3RoaXMnKSArICcsIGZ1bmN0aW9uKCcgKyBtYXRjaFsyXSArICcpeyc7XG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKG1hdGNoID0gL15pZlxcYiguKikvLmV4ZWMoYzIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICdpZignICsgbWF0Y2hbMV0gKyAnKXsnO1xuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChtYXRjaCA9IC9eZWxzZVxcYlxccyooaWZcXGIoLiopKT8vLmV4ZWMoYzIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICd9ZWxzZSAnICsgKG1hdGNoWzFdID8gJ2lmKCcgKyBtYXRjaFsyXSArICcpJyA6ICcnKSArICd7JztcbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAobWF0Y2ggPSAvXlxcLyhpZik/Ly5leGVjKGMyKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBtYXRjaFsxXSA/ICd9XFxuJyA6ICd9KTtcXG4nO1xuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChtYXRjaCA9IC9eKHZhclxccy4qKS8uZXhlYyhjMikpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbWF0Y2hbMV0gKyAnOyc7XG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKG1hdGNoID0gL14jKC4qKS8uZXhlYyhjMikpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbWF0Y2hbMV07XG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKG1hdGNoID0gLyguKik6OlxccyooLiopLy5leGVjKGMyKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAncHJpbnQoJyArIGVzY2FwZVNuaXBwZXQgKyAnXy5mb3JtYXRWYWx1ZShcIicgKyBlc2NhcGVKYXZhU2NyaXB0U3RyaW5nKG1hdGNoWzJdKSArICdcIiwnICsgKHRyaW0obWF0Y2hbMV0pID8gbWF0Y2hbMV0gOiAndGhpcycpICsgKGVzY2FwZVNuaXBwZXQgJiYgJyknKSArICcpKTtcXG4nO1xuICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gJ3ByaW50KCcgKyBlc2NhcGVTbmlwcGV0ICsgKHRyaW0oYzIpID8gYzIgOiAndGhpcycpICsgKGVzY2FwZVNuaXBwZXQgJiYgJyknKSArICcpO1xcbic7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChjaHVuaykge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gJ3ByaW50KFwiJyArIGVzY2FwZUphdmFTY3JpcHRTdHJpbmcoY2h1bmspICsgJ1wiKTtcXG4nO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pLmpvaW4oJycpICsgJ30nO1xuICAgICAgICAgICAgdmFyIGYgPSBuZXcgRnVuY3Rpb24oJ29iaicsICdlYWNoJywgJ2VzYycsICdwcmludCcsICdfJywgZnVuY0JvZHkpO1xuICAgICAgICAgICAgdmFyIHQgPSBmdW5jdGlvbiAob2JqLCB0aGlzQ29udGV4dCkge1xuICAgICAgICAgICAgICAgIHZhciByZXN1bHQgPSBbXTtcbiAgICAgICAgICAgICAgICBmLmNhbGwodGhpc0NvbnRleHQgfHwgb2JqLCBvYmosIGZ1bmN0aW9uIChvYmosIGZ1bmMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGlzTGlzdChvYmopKVxuICAgICAgICAgICAgICAgICAgICAgICAgZWFjaChvYmosIGZ1bmN0aW9uICh2YWx1ZSwgaW5kZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmdW5jLmNhbGwodmFsdWUsIHZhbHVlLCBpbmRleCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgZWFjaE9iaihvYmosIGZ1bmN0aW9uIChrZXksIHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZnVuYy5jYWxsKHZhbHVlLCBrZXksIHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0sIGVzY2FwZUZ1bmN0aW9uIHx8IG5vbk9wLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGNhbGwocmVzdWx0WydwdXNoJ10sIHJlc3VsdCwgYXJndW1lbnRzKTtcbiAgICAgICAgICAgICAgICB9LCBfKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0LmpvaW4oJycpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGlmICh0ZW1wbGF0ZXMucHVzaCh0KSA+IE1BWF9DQUNIRURfVEVNUExBVEVTKVxuICAgICAgICAgICAgICAgIGRlbGV0ZSB0ZW1wbGF0ZUNhY2hlW3RlbXBsYXRlcy5zaGlmdCgpXTtcbiAgICAgICAgICAgIHJldHVybiB0ZW1wbGF0ZUNhY2hlW3RlbXBsYXRlXSA9IHQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gZXNjYXBlSHRtbChzKSB7XG4gICAgICAgIHJldHVybiByZXBsYWNlKHMsIC9bPD4nXCImXS9nLCBmdW5jdGlvbiAocykge1xuICAgICAgICAgICAgcmV0dXJuICcmIycgKyBzLmNoYXJDb2RlQXQoMCkgKyAnOyc7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBmdW5jdGlvbiBmb3JtYXRIdG1sKHRwbCwgb2JqKSB7XG4gICAgICAgIHJldHVybiB0ZW1wbGF0ZSh0cGwsIGVzY2FwZUh0bWwpKG9iaik7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGxpc3RCaW5kQXJyYXkoZnVuYykge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gKGFyZzEsIGFyZzIpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgTShmdW5jKHRoaXMsIGFyZzEsIGFyZzIpKTtcbiAgICAgICAgfTtcbiAgICB9XG4gICAgZnVuY3Rpb24gbGlzdEJpbmQoZnVuYykge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gKGFyZzEsIGFyZzIsIGFyZzMpIHtcbiAgICAgICAgICAgIHJldHVybiBmdW5jKHRoaXMsIGFyZzEsIGFyZzIsIGFyZzMpO1xuICAgICAgICB9O1xuICAgIH1cbiAgICBmdW5jdGlvbiBmdW5jQXJyYXlCaW5kKGZ1bmMpIHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIChhcmcxLCBhcmcyLCBhcmczKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IE0oZnVuYyhhcmcxLCBhcmcyLCBhcmczKSk7XG4gICAgICAgIH07XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzRnVuY3Rpb24oZikge1xuICAgICAgICByZXR1cm4gdHlwZW9mIGYgPT0gJ2Z1bmN0aW9uJyAmJiAhZlsnaXRlbSddO1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc0xpc3Qodikge1xuICAgICAgICByZXR1cm4gdiAmJiB2Lmxlbmd0aCAhPSBfbnVsbCAmJiAhaXNTdHJpbmcodikgJiYgIWlzTm9kZSh2KSAmJiAhaXNGdW5jdGlvbih2KSAmJiB2ICE9PSBfd2luZG93O1xuICAgIH1cbiAgICBmdW5jdGlvbiBwdXNoKG9iaiwgcHJvcCwgdmFsdWUpIHtcbiAgICAgICAgKG9ialtwcm9wXSA9IG9ialtwcm9wXSB8fCBbXSkucHVzaCh2YWx1ZSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHJlbW92ZUZyb21BcnJheShhcnJheSwgdmFsdWUpIHtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGFycmF5ICYmIGkgPCBhcnJheS5sZW5ndGg7IGkrKylcbiAgICAgICAgICAgIGlmIChhcnJheVtpXSA9PT0gdmFsdWUpXG4gICAgICAgICAgICAgICAgYXJyYXlbJ3NwbGljZSddKGktLSwgMSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGV4dHJhY3ROdW1iZXIodikge1xuICAgICAgICByZXR1cm4gcGFyc2VGbG9hdChyZXBsYWNlKHYsIC9eW15cXGQtXSsvKSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldE5vZGVJZChlbCkge1xuICAgICAgICByZXR1cm4gZWxbTUlOSUZJRURfTUFHSUNfTk9ERUlEXSA9IGVsW01JTklGSUVEX01BR0lDX05PREVJRF0gfHwgKytpZFNlcXVlbmNlO1xuICAgIH1cbiAgICBmdW5jdGlvbiBjb2xsZWN0VW5pcU5vZGVzKGxpc3QsIGZ1bmMpIHtcbiAgICAgICAgdmFyIHJlc3VsdCA9IFtdO1xuICAgICAgICB2YXIgbm9kZUlkcyA9IHt9O1xuICAgICAgICB2YXIgY3VycmVudE5vZGVJZDtcbiAgICAgICAgZmxleGlFYWNoKGxpc3QsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgZmxleGlFYWNoKGZ1bmModmFsdWUpLCBmdW5jdGlvbiAobm9kZSkge1xuICAgICAgICAgICAgICAgIGlmICghbm9kZUlkc1tjdXJyZW50Tm9kZUlkID0gZ2V0Tm9kZUlkKG5vZGUpXSkge1xuICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaChub2RlKTtcbiAgICAgICAgICAgICAgICAgICAgbm9kZUlkc1tjdXJyZW50Tm9kZUlkXSA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXROYXR1cmFsSGVpZ2h0KGVsZW1lbnRMaXN0LCBmYWN0b3IpIHtcbiAgICAgICAgdmFyIHEgPSB7XG4gICAgICAgICAgICAnJHBvc2l0aW9uJzogJ2Fic29sdXRlJyxcbiAgICAgICAgICAgICckdmlzaWJpbGl0eSc6ICdoaWRkZW4nLFxuICAgICAgICAgICAgJyRkaXNwbGF5JzogJ2Jsb2NrJyxcbiAgICAgICAgICAgICckaGVpZ2h0JzogX251bGxcbiAgICAgICAgfTtcbiAgICAgICAgdmFyIG9sZFN0eWxlcyA9IGVsZW1lbnRMaXN0WydnZXQnXShxKTtcbiAgICAgICAgdmFyIGggPSBlbGVtZW50TGlzdFsnc2V0J10ocSlbJ2dldCddKCdjbGllbnRIZWlnaHQnKTtcbiAgICAgICAgZWxlbWVudExpc3RbJ3NldCddKG9sZFN0eWxlcyk7XG4gICAgICAgIHJldHVybiBoICogZmFjdG9yICsgJ3B4JztcbiAgICB9XG4gICAgZnVuY3Rpb24gb24oc3ViU2VsZWN0b3IsIGV2ZW50U3BlYywgaGFuZGxlciwgYXJncywgYnViYmxlU2VsZWN0b3IpIHtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb24oZXZlbnRTcGVjKSlcbiAgICAgICAgICAgIHJldHVybiB0aGlzWydvbiddKF9udWxsLCBzdWJTZWxlY3RvciwgZXZlbnRTcGVjLCBoYW5kbGVyLCBhcmdzKTtcbiAgICAgICAgZWxzZSBpZiAoaXNTdHJpbmcoYXJncykpXG4gICAgICAgICAgICByZXR1cm4gdGhpc1snb24nXShzdWJTZWxlY3RvciwgZXZlbnRTcGVjLCBoYW5kbGVyLCBfbnVsbCwgYXJncyk7XG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIHJldHVybiB0aGlzWydlYWNoJ10oZnVuY3Rpb24gKGJhc2VFbGVtZW50LCBpbmRleCkge1xuICAgICAgICAgICAgICAgIGZsZXhpRWFjaChzdWJTZWxlY3RvciA/IGRvbGxhclJhdyhzdWJTZWxlY3RvciwgYmFzZUVsZW1lbnQpIDogYmFzZUVsZW1lbnQsIGZ1bmN0aW9uIChyZWdpc3RlcmVkT24pIHtcbiAgICAgICAgICAgICAgICAgICAgZmxleGlFYWNoKHRvU3RyaW5nKGV2ZW50U3BlYykuc3BsaXQoL1xccy8pLCBmdW5jdGlvbiAobmFtZVByZWZpeGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbmFtZSA9IHJlcGxhY2UobmFtZVByZWZpeGVkLCAvWz98XS9nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwcmVmaXggPSByZXBsYWNlKG5hbWVQcmVmaXhlZCwgL1teP3xdL2cpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNhcHR1cmUgPSAobmFtZSA9PSAnYmx1cicgfHwgbmFtZSA9PSAnZm9jdXMnKSAmJiAhIWJ1YmJsZVNlbGVjdG9yO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHRyaWdnZXJJZCA9IGlkU2VxdWVuY2UrKztcbiAgICAgICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIHRyaWdnZXJIYW5kbGVyKGV2ZW50TmFtZSwgZXZlbnQsIHRhcmdldCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBtYXRjaCA9ICFidWJibGVTZWxlY3RvcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZWwgPSBidWJibGVTZWxlY3RvciA/IHRhcmdldCA6IHJlZ2lzdGVyZWRPbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYnViYmxlU2VsZWN0b3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHNlbGVjdG9yRmlsdGVyID0gZ2V0RmlsdGVyRnVuYyhidWJibGVTZWxlY3RvciwgcmVnaXN0ZXJlZE9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2hpbGUgKGVsICYmIGVsICE9IHJlZ2lzdGVyZWRPbiAmJiAhKG1hdGNoID0gc2VsZWN0b3JGaWx0ZXIoZWwpKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsID0gZWxbJ3BhcmVudE5vZGUnXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICFtYXRjaCB8fCBuYW1lICE9IGV2ZW50TmFtZSB8fCAoaGFuZGxlci5hcHBseSgkKGVsKSwgYXJncyB8fCBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0pICYmIHByZWZpeCA9PSAnPycgfHwgcHJlZml4ID09ICd8Jyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA7XG4gICAgICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBldmVudEhhbmRsZXIoZXZlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXRyaWdnZXJIYW5kbGVyKG5hbWUsIGV2ZW50LCBldmVudFsndGFyZ2V0J10pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50WydwcmV2ZW50RGVmYXVsdCddKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50WydzdG9wUHJvcGFnYXRpb24nXSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlZ2lzdGVyZWRPbi5hZGRFdmVudExpc3RlbmVyKG5hbWUsIGV2ZW50SGFuZGxlciwgY2FwdHVyZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXJlZ2lzdGVyZWRPblsnTSddKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlZ2lzdGVyZWRPblsnTSddID0ge307XG4gICAgICAgICAgICAgICAgICAgICAgICByZWdpc3RlcmVkT25bJ00nXVt0cmlnZ2VySWRdID0gdHJpZ2dlckhhbmRsZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVyWydNJ10gPSBjb2xsZWN0b3IoZmxleGlFYWNoLCBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlclsnTSddLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVnaXN0ZXJlZE9uLnJlbW92ZUV2ZW50TGlzdGVuZXIobmFtZSwgZXZlbnRIYW5kbGVyLCBjYXB0dXJlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlIHJlZ2lzdGVyZWRPblsnTSddW3RyaWdnZXJJZF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgXSwgbm9uT3ApO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgIH1cbiAgICBmdW5jdGlvbiBvZmYoaGFuZGxlcikge1xuICAgICAgICBjYWxsTGlzdChoYW5kbGVyWydNJ10pO1xuICAgICAgICBoYW5kbGVyWydNJ10gPSBfbnVsbDtcbiAgICB9XG4gICAgZnVuY3Rpb24gZGV0YWNoSGFuZGxlckxpc3QoZHVtbXksIGhhbmRsZXJMaXN0KSB7XG4gICAgICAgIGZsZXhpRWFjaChoYW5kbGVyTGlzdCwgZnVuY3Rpb24gKGgpIHtcbiAgICAgICAgICAgIGguZWxlbWVudC5kZXRhY2hFdmVudCgnb24nICsgaC5ldmVudFR5cGUsIGguaGFuZGxlckZ1bmMpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcmVhZHkoaGFuZGxlcikge1xuICAgICAgICBpZiAoRE9NUkVBRFlfSEFORExFUilcbiAgICAgICAgICAgIERPTVJFQURZX0hBTkRMRVIucHVzaChoYW5kbGVyKTtcbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgc2V0VGltZW91dChoYW5kbGVyLCAwKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gJCQoc2VsZWN0b3IsIGNvbnRleHQsIGNoaWxkcmVuT25seSkge1xuICAgICAgICByZXR1cm4gZG9sbGFyUmF3KHNlbGVjdG9yLCBjb250ZXh0LCBjaGlsZHJlbk9ubHkpWzBdO1xuICAgIH1cbiAgICBmdW5jdGlvbiBFRShlbGVtZW50TmFtZSwgYXR0cmlidXRlcywgY2hpbGRyZW4pIHtcbiAgICAgICAgdmFyIGUgPSAkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoZWxlbWVudE5hbWUpKTtcbiAgICAgICAgcmV0dXJuIGlzTGlzdChhdHRyaWJ1dGVzKSB8fCBhdHRyaWJ1dGVzICE9IF9udWxsICYmICFpc09iamVjdChhdHRyaWJ1dGVzKSA/IGVbJ2FkZCddKGF0dHJpYnV0ZXMpIDogZVsnc2V0J10oYXR0cmlidXRlcylbJ2FkZCddKGNoaWxkcmVuKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gY2xvbmUobGlzdE9yTm9kZSkge1xuICAgICAgICByZXR1cm4gY29sbGVjdG9yKGZsZXhpRWFjaCwgbGlzdE9yTm9kZSwgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgIHZhciBjO1xuICAgICAgICAgICAgaWYgKGlzTGlzdChlKSlcbiAgICAgICAgICAgICAgICByZXR1cm4gY2xvbmUoZSk7XG4gICAgICAgICAgICBlbHNlIGlmIChpc05vZGUoZSkpIHtcbiAgICAgICAgICAgICAgICBjID0gZVsnY2xvbmVOb2RlJ10odHJ1ZSk7XG4gICAgICAgICAgICAgICAgY1sncmVtb3ZlQXR0cmlidXRlJ10gJiYgY1sncmVtb3ZlQXR0cmlidXRlJ10oJ2lkJyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGM7XG4gICAgICAgICAgICB9IGVsc2VcbiAgICAgICAgICAgICAgICByZXR1cm4gZTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uICQoc2VsZWN0b3IsIGNvbnRleHQsIGNoaWxkT25seSkge1xuICAgICAgICByZXR1cm4gaXNGdW5jdGlvbihzZWxlY3RvcikgPyByZWFkeShzZWxlY3RvcikgOiBuZXcgTShkb2xsYXJSYXcoc2VsZWN0b3IsIGNvbnRleHQsIGNoaWxkT25seSkpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBkb2xsYXJSYXcoc2VsZWN0b3IsIGNvbnRleHQsIGNoaWxkT25seSkge1xuICAgICAgICBmdW5jdGlvbiBmbGF0dGVuKGEpIHtcbiAgICAgICAgICAgIHJldHVybiBpc0xpc3QoYSkgPyBjb2xsZWN0b3IoZmxleGlFYWNoLCBhLCBmbGF0dGVuKSA6IGE7XG4gICAgICAgIH1cbiAgICAgICAgZnVuY3Rpb24gZmlsdGVyRWxlbWVudHMobGlzdCkge1xuICAgICAgICAgICAgcmV0dXJuIGZpbHRlcihjb2xsZWN0b3IoZmxleGlFYWNoLCBsaXN0LCBmbGF0dGVuKSwgZnVuY3Rpb24gKG5vZGUpIHtcbiAgICAgICAgICAgICAgICB2YXIgYSA9IG5vZGU7XG4gICAgICAgICAgICAgICAgd2hpbGUgKGEgPSBhWydwYXJlbnROb2RlJ10pXG4gICAgICAgICAgICAgICAgICAgIGlmIChhID09IGNvbnRleHRbMF0gfHwgY2hpbGRPbmx5KVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGEgPT0gY29udGV4dFswXTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjb250ZXh0KSB7XG4gICAgICAgICAgICBpZiAoKGNvbnRleHQgPSBkb2xsYXJSYXcoY29udGV4dCkpLmxlbmd0aCAhPSAxKVxuICAgICAgICAgICAgICAgIHJldHVybiBjb2xsZWN0VW5pcU5vZGVzKGNvbnRleHQsIGZ1bmN0aW9uIChjaSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZG9sbGFyUmF3KHNlbGVjdG9yLCBjaSwgY2hpbGRPbmx5KTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGVsc2UgaWYgKGlzU3RyaW5nKHNlbGVjdG9yKSkge1xuICAgICAgICAgICAgICAgIGlmIChpc05vZGUoY29udGV4dFswXSkgIT0gMSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtdO1xuICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNoaWxkT25seSA/IGZpbHRlckVsZW1lbnRzKGNvbnRleHRbMF0ucXVlcnlTZWxlY3RvckFsbChzZWxlY3RvcikpIDogY29udGV4dFswXS5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yKTtcbiAgICAgICAgICAgIH0gZWxzZVxuICAgICAgICAgICAgICAgIHJldHVybiBmaWx0ZXJFbGVtZW50cyhzZWxlY3Rvcik7XG4gICAgICAgIH0gZWxzZSBpZiAoaXNTdHJpbmcoc2VsZWN0b3IpKVxuICAgICAgICAgICAgcmV0dXJuIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsZWN0b3IpO1xuICAgICAgICBlbHNlXG4gICAgICAgICAgICByZXR1cm4gY29sbGVjdG9yKGZsZXhpRWFjaCwgc2VsZWN0b3IsIGZsYXR0ZW4pO1xuICAgIH1cbiAgICA7XG4gICAgZnVuY3Rpb24gZ2V0RmlsdGVyRnVuYyhzZWxlY3RvciwgY29udGV4dCkge1xuICAgICAgICBmdW5jdGlvbiB3b3JkUmVnRXhwVGVzdGVyKG5hbWUsIHByb3ApIHtcbiAgICAgICAgICAgIHZhciByZSA9IFJlZ0V4cCgnKF58XFxcXHMrKScgKyBuYW1lICsgJyg/PSR8XFxcXHMpJywgJ2knKTtcbiAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAob2JqKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5hbWUgPyByZS50ZXN0KG9ialtwcm9wXSkgOiB0cnVlO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgbm9kZVNldCA9IHt9O1xuICAgICAgICB2YXIgZG90UG9zID0gbm9kZVNldDtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb24oc2VsZWN0b3IpKVxuICAgICAgICAgICAgcmV0dXJuIHNlbGVjdG9yO1xuICAgICAgICBlbHNlIGlmIChpc051bWJlcihzZWxlY3RvcikpXG4gICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gKHYsIGluZGV4KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGluZGV4ID09IHNlbGVjdG9yO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgZWxzZSBpZiAoIXNlbGVjdG9yIHx8IHNlbGVjdG9yID09ICcqJyB8fCBpc1N0cmluZyhzZWxlY3RvcikgJiYgKGRvdFBvcyA9IC9eKFtcXHctXSopXFwuPyhbXFx3LV0qKSQvLmV4ZWMoc2VsZWN0b3IpKSkge1xuICAgICAgICAgICAgdmFyIG5vZGVOYW1lRmlsdGVyID0gd29yZFJlZ0V4cFRlc3Rlcihkb3RQb3NbMV0sICd0YWdOYW1lJyk7XG4gICAgICAgICAgICB2YXIgY2xhc3NOYW1lRmlsdGVyID0gd29yZFJlZ0V4cFRlc3Rlcihkb3RQb3NbMl0sICdjbGFzc05hbWUnKTtcbiAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAodikge1xuICAgICAgICAgICAgICAgIHJldHVybiBpc05vZGUodikgPT0gMSAmJiBub2RlTmFtZUZpbHRlcih2KSAmJiBjbGFzc05hbWVGaWx0ZXIodik7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9IGVsc2UgaWYgKGNvbnRleHQpXG4gICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gKHYpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJChzZWxlY3RvciwgY29udGV4dClbJ2ZpbmQnXSh2KSAhPSBfbnVsbDtcbiAgICAgICAgICAgIH07XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgJChzZWxlY3RvcilbJ2VhY2gnXShmdW5jdGlvbiAobm9kZSkge1xuICAgICAgICAgICAgICAgIG5vZGVTZXRbZ2V0Tm9kZUlkKG5vZGUpXSA9IHRydWU7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAodikge1xuICAgICAgICAgICAgICAgIHJldHVybiBub2RlU2V0W2dldE5vZGVJZCh2KV07XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldEludmVyc2VGaWx0ZXJGdW5jKHNlbGVjdG9yKSB7XG4gICAgICAgIHZhciBmID0gZ2V0RmlsdGVyRnVuYyhzZWxlY3Rvcik7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAodikge1xuICAgICAgICAgICAgcmV0dXJuIGYodikgPyBfbnVsbCA6IHRydWU7XG4gICAgICAgIH07XG4gICAgfVxuICAgIGZ1bmN0aW9uIGZsZXhpRWFjaChsaXN0LCBjYikge1xuICAgICAgICBpZiAoaXNMaXN0KGxpc3QpKVxuICAgICAgICAgICAgZWFjaChsaXN0LCBjYik7XG4gICAgICAgIGVsc2UgaWYgKGxpc3QgIT0gX251bGwpXG4gICAgICAgICAgICBjYihsaXN0LCAwKTtcbiAgICAgICAgcmV0dXJuIGxpc3Q7XG4gICAgfVxuICAgIGZ1bmN0aW9uIFByb21pc2UoKSB7XG4gICAgICAgIHRoaXNbJ3N0YXRlJ10gPSBudWxsO1xuICAgICAgICB0aGlzWyd2YWx1ZXMnXSA9IFtdO1xuICAgICAgICB0aGlzWydwYXJlbnQnXSA9IG51bGw7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHByb21pc2UoKSB7XG4gICAgICAgIHZhciBkZWZlcnJlZCA9IFtdO1xuICAgICAgICB2YXIgYXNzaW1pbGF0ZWRQcm9taXNlcyA9IGFyZ3VtZW50cztcbiAgICAgICAgdmFyIGFzc2ltaWxhdGVkTnVtID0gYXNzaW1pbGF0ZWRQcm9taXNlcy5sZW5ndGg7XG4gICAgICAgIHZhciBudW1Db21wbGV0ZWQgPSAwO1xuICAgICAgICB2YXIgcmVqZWN0aW9uSGFuZGxlck51bSA9IDA7XG4gICAgICAgIHZhciBvYmogPSBuZXcgUHJvbWlzZSgpO1xuICAgICAgICBvYmpbJ2VyckhhbmRsZWQnXSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHJlamVjdGlvbkhhbmRsZXJOdW0rKztcbiAgICAgICAgICAgIGlmIChvYmpbJ3BhcmVudCddKVxuICAgICAgICAgICAgICAgIG9ialsncGFyZW50J11bJ2VyckhhbmRsZWQnXSgpO1xuICAgICAgICB9O1xuICAgICAgICB2YXIgZmlyZSA9IG9ialsnZmlyZSddID0gZnVuY3Rpb24gKG5ld1N0YXRlLCBuZXdWYWx1ZXMpIHtcbiAgICAgICAgICAgIGlmIChvYmpbJ3N0YXRlJ10gPT0gbnVsbCAmJiBuZXdTdGF0ZSAhPSBudWxsKSB7XG4gICAgICAgICAgICAgICAgb2JqWydzdGF0ZSddID0gISFuZXdTdGF0ZTtcbiAgICAgICAgICAgICAgICBvYmpbJ3ZhbHVlcyddID0gaXNMaXN0KG5ld1ZhbHVlcykgPyBuZXdWYWx1ZXMgOiBbbmV3VmFsdWVzXTtcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZWFjaChkZWZlcnJlZCwgZnVuY3Rpb24gKGYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGYoKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSwgMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gb2JqO1xuICAgICAgICB9O1xuICAgICAgICBlYWNoKGFzc2ltaWxhdGVkUHJvbWlzZXMsIGZ1bmN0aW9uIGFzc2ltaWxhdGUocHJvbWlzZSwgaW5kZXgpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgaWYgKHByb21pc2VbJ3RoZW4nXSlcbiAgICAgICAgICAgICAgICAgICAgcHJvbWlzZVsndGhlbiddKGZ1bmN0aW9uICh2KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgdGhlbjtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICgoaXNPYmplY3QodikgfHwgaXNGdW5jdGlvbih2KSkgJiYgaXNGdW5jdGlvbih0aGVuID0gdlsndGhlbiddKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3NpbWlsYXRlKHYsIGluZGV4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9ialsndmFsdWVzJ11baW5kZXhdID0gYXJyYXkoYXJndW1lbnRzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoKytudW1Db21wbGV0ZWQgPT0gYXNzaW1pbGF0ZWROdW0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpcmUodHJ1ZSwgYXNzaW1pbGF0ZWROdW0gPCAyID8gb2JqWyd2YWx1ZXMnXVtpbmRleF0gOiBvYmpbJ3ZhbHVlcyddKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9ialsndmFsdWVzJ11baW5kZXhdID0gYXJyYXkoYXJndW1lbnRzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpcmUoZmFsc2UsIGFzc2ltaWxhdGVkTnVtIDwgMiA/IG9ialsndmFsdWVzJ11baW5kZXhdIDogW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9ialsndmFsdWVzJ11baW5kZXhdWzBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9ialsndmFsdWVzJ10sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXhcbiAgICAgICAgICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgIHByb21pc2UoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmlyZSh0cnVlLCBhcnJheShhcmd1bWVudHMpKTtcbiAgICAgICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmlyZShmYWxzZSwgYXJyYXkoYXJndW1lbnRzKSk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIGZpcmUoZmFsc2UsIFtcbiAgICAgICAgICAgICAgICAgICAgZSxcbiAgICAgICAgICAgICAgICAgICAgb2JqWyd2YWx1ZXMnXSxcbiAgICAgICAgICAgICAgICAgICAgaW5kZXhcbiAgICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIG9ialsnc3RvcCddID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgZWFjaChhc3NpbWlsYXRlZFByb21pc2VzLCBmdW5jdGlvbiAocHJvbWlzZSkge1xuICAgICAgICAgICAgICAgIGlmIChwcm9taXNlWydzdG9wJ10pXG4gICAgICAgICAgICAgICAgICAgIHByb21pc2VbJ3N0b3AnXSgpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXR1cm4gb2JqWydzdG9wMCddICYmIGNhbGwob2JqWydzdG9wMCddKTtcbiAgICAgICAgfTtcbiAgICAgICAgdmFyIHRoZW4gPSBvYmpbJ3RoZW4nXSA9IGZ1bmN0aW9uIChvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCkge1xuICAgICAgICAgICAgdmFyIHByb21pc2UyID0gcHJvbWlzZSgpO1xuICAgICAgICAgICAgdmFyIGNhbGxDYWxsYmFja3MgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGYgPSBvYmpbJ3N0YXRlJ10gPyBvbkZ1bGZpbGxlZCA6IG9uUmVqZWN0ZWQ7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc0Z1bmN0aW9uKGYpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAoZnVuY3Rpb24gcmVzb2x2ZSh4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHRoZW4sIGNiQ2FsbGVkID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKChpc09iamVjdCh4KSB8fCBpc0Z1bmN0aW9uKHgpKSAmJiBpc0Z1bmN0aW9uKHRoZW4gPSB4Wyd0aGVuJ10pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoeCA9PT0gcHJvbWlzZTIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhlbi5jYWxsKHgsIGZ1bmN0aW9uICh4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFjYkNhbGxlZCsrKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFjYkNhbGxlZCsrKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9taXNlMlsnZmlyZSddKGZhbHNlLCBbdmFsdWVdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvbWlzZTJbJ3N0b3AwJ10gPSB4WydzdG9wJ107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvbWlzZTJbJ2ZpcmUnXSh0cnVlLCBbeF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFjYkNhbGxlZCsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9taXNlMlsnZmlyZSddKGZhbHNlLCBbZV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFyZWplY3Rpb25IYW5kbGVyTnVtKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9KGNhbGwoZiwgdW5kZWYsIG9ialsndmFsdWVzJ10pKSk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvbWlzZTJbJ2ZpcmUnXShvYmpbJ3N0YXRlJ10sIG9ialsndmFsdWVzJ10pO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgcHJvbWlzZTJbJ2ZpcmUnXShmYWxzZSwgW2VdKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFyZWplY3Rpb25IYW5kbGVyTnVtKVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKGlzRnVuY3Rpb24ob25SZWplY3RlZCkpXG4gICAgICAgICAgICAgICAgb2JqWydlcnJIYW5kbGVkJ10oKTtcbiAgICAgICAgICAgIHByb21pc2UyWydzdG9wMCddID0gb2JqWydzdG9wJ107XG4gICAgICAgICAgICBwcm9taXNlMlsncGFyZW50J10gPSBvYmo7XG4gICAgICAgICAgICBpZiAob2JqWydzdGF0ZSddICE9IG51bGwpXG4gICAgICAgICAgICAgICAgc2V0VGltZW91dChjYWxsQ2FsbGJhY2tzLCAwKTtcbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICBkZWZlcnJlZC5wdXNoKGNhbGxDYWxsYmFja3MpO1xuICAgICAgICAgICAgcmV0dXJuIHByb21pc2UyO1xuICAgICAgICB9O1xuICAgICAgICBvYmpbJ2Fsd2F5cyddID0gZnVuY3Rpb24gKGZ1bmMpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGVuKGZ1bmMsIGZ1bmMpO1xuICAgICAgICB9O1xuICAgICAgICBvYmpbJ2Vycm9yJ10gPSBmdW5jdGlvbiAoZnVuYykge1xuICAgICAgICAgICAgcmV0dXJuIHRoZW4oMCwgZnVuYyk7XG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiBvYmo7XG4gICAgfVxuICAgIGZ1bmN0aW9uIE0obGlzdCwgYXNzaW1pbGF0ZVN1Ymxpc3RzKSB7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcywgaWR4ID0gMDtcbiAgICAgICAgaWYgKGxpc3QpXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gbGlzdC5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgICAgICAgICAgIHZhciBpdGVtID0gbGlzdFtpXTtcbiAgICAgICAgICAgICAgICBpZiAoYXNzaW1pbGF0ZVN1Ymxpc3RzICYmIGlzTGlzdChpdGVtKSlcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDAsIGxlbjIgPSBpdGVtLmxlbmd0aDsgaiA8IGxlbjI7IGorKylcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGZbaWR4KytdID0gaXRlbVtqXTtcbiAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgIHNlbGZbaWR4KytdID0gaXRlbTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgc2VsZltpZHgrK10gPSBhc3NpbWlsYXRlU3VibGlzdHM7XG4gICAgICAgIHNlbGZbJ2xlbmd0aCddID0gaWR4O1xuICAgICAgICBzZWxmWydfJ10gPSB0cnVlO1xuICAgIH1cbiAgICBmdW5jdGlvbiBfKCkge1xuICAgICAgICByZXR1cm4gbmV3IE0oYXJndW1lbnRzLCB0cnVlKTtcbiAgICB9XG4gICAgY29weU9iaih7XG4gICAgICAgICdlYWNoJzogbGlzdEJpbmQoZWFjaCksXG4gICAgICAgICdlcXVhbHMnOiBsaXN0QmluZChlcXVhbHMpLFxuICAgICAgICAnZmluZCc6IGxpc3RCaW5kKGZpbmQpLFxuICAgICAgICBkdW1teVNvcnQ6IDAsXG4gICAgICAgICdzZWxlY3QnOiBmdW5jdGlvbiAoc2VsZWN0b3IsIGNoaWxkT25seSkge1xuICAgICAgICAgICAgcmV0dXJuICQoc2VsZWN0b3IsIHRoaXMsIGNoaWxkT25seSk7XG4gICAgICAgIH0sXG4gICAgICAgICdnZXQnOiBmdW5jdGlvbiAoc3BlYywgdG9OdW1iZXIpIHtcbiAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgICAgIHZhciBlbGVtZW50ID0gc2VsZlswXTtcbiAgICAgICAgICAgIGlmIChlbGVtZW50KSB7XG4gICAgICAgICAgICAgICAgaWYgKGlzU3RyaW5nKHNwZWMpKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBtYXRjaCA9IC9eKFxcVyopKC4qKS8uZXhlYyhyZXBsYWNlKHNwZWMsIC9eJS8sICdAZGF0YS0nKSk7XG4gICAgICAgICAgICAgICAgICAgIHZhciBwcmVmaXggPSBtYXRjaFsxXTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHM7XG4gICAgICAgICAgICAgICAgICAgIGlmIChnZXR0ZXJbcHJlZml4XSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHMgPSBnZXR0ZXJbcHJlZml4XSh0aGlzLCBtYXRjaFsyXSk7XG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKHNwZWMgPT0gJyQnKVxuICAgICAgICAgICAgICAgICAgICAgICAgcyA9IHNlbGZbJ2dldCddKCdjbGFzc05hbWUnKTtcbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoc3BlYyA9PSAnJCQnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzID0gc2VsZlsnZ2V0J10oJ0BzdHlsZScpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHNwZWMgPT0gJyQkc2xpZGUnKVxuICAgICAgICAgICAgICAgICAgICAgICAgcyA9IHNlbGZbJ2dldCddKCckaGVpZ2h0Jyk7XG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKHNwZWMgPT0gJyQkZmFkZScgfHwgc3BlYyA9PSAnJCRzaG93Jykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNlbGZbJ2dldCddKCckdmlzaWJpbGl0eScpID09ICdoaWRkZW4nIHx8IHNlbGZbJ2dldCddKCckZGlzcGxheScpID09ICdub25lJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKHNwZWMgPT0gJyQkZmFkZScpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzID0gaXNOYU4oc2VsZlsnZ2V0J10oJyRvcGFjaXR5JywgdHJ1ZSkpID8gMSA6IHNlbGZbJ2dldCddKCckb3BhY2l0eScsIHRydWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcyA9IDE7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAocHJlZml4ID09ICckJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgcyA9IF93aW5kb3dbJ2dldENvbXB1dGVkU3R5bGUnXShlbGVtZW50LCBfbnVsbClbJ2dldFByb3BlcnR5VmFsdWUnXShyZXBsYWNlKG1hdGNoWzJdLCAvW0EtWl0vZywgZnVuY3Rpb24gKG1hdGNoMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAnLScgKyBtYXRjaDIudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChwcmVmaXggPT0gJ0AnKVxuICAgICAgICAgICAgICAgICAgICAgICAgcyA9IGVsZW1lbnQuZ2V0QXR0cmlidXRlKG1hdGNoWzJdKTtcbiAgICAgICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgcyA9IGVsZW1lbnRbbWF0Y2hbMl1dO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdG9OdW1iZXIgPyBleHRyYWN0TnVtYmVyKHMpIDogcztcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB2YXIgciA9IHt9O1xuICAgICAgICAgICAgICAgICAgICAoaXNMaXN0KHNwZWMpID8gZmxleGlFYWNoIDogZWFjaE9iaikoc3BlYywgZnVuY3Rpb24gKG5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJbbmFtZV0gPSBzZWxmWydnZXQnXShuYW1lLCB0b051bWJlcik7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgICdzZXQnOiBmdW5jdGlvbiAobmFtZSwgdmFsdWUpIHtcbiAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgICAgIGlmICh2YWx1ZSAhPT0gdW5kZWYpIHtcbiAgICAgICAgICAgICAgICB2YXIgbWF0Y2ggPSAvXihcXFcqKSguKikvLmV4ZWMocmVwbGFjZShyZXBsYWNlKG5hbWUsIC9eXFwkZmxvYXQkLywgJ2Nzc0Zsb2F0JyksIC9eJS8sICdAZGF0YS0nKSk7XG4gICAgICAgICAgICAgICAgdmFyIHByZWZpeCA9IG1hdGNoWzFdO1xuICAgICAgICAgICAgICAgIGlmIChzZXR0ZXJbcHJlZml4XSlcbiAgICAgICAgICAgICAgICAgICAgc2V0dGVyW3ByZWZpeF0odGhpcywgbWF0Y2hbMl0sIHZhbHVlKTtcbiAgICAgICAgICAgICAgICBlbHNlIGlmIChuYW1lID09ICckJGZhZGUnKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXNbJ3NldCddKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICckdmlzaWJpbGl0eSc6IHZhbHVlID8gJ3Zpc2libGUnIDogJ2hpZGRlbicsXG4gICAgICAgICAgICAgICAgICAgICAgICAnJG9wYWNpdHknOiB2YWx1ZVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKG5hbWUgPT0gJyQkc2xpZGUnKSB7XG4gICAgICAgICAgICAgICAgICAgIHNlbGZbJ3NldCddKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICckdmlzaWJpbGl0eSc6IHZhbHVlID8gJ3Zpc2libGUnIDogJ2hpZGRlbicsXG4gICAgICAgICAgICAgICAgICAgICAgICAnJG92ZXJmbG93JzogJ2hpZGRlbicsXG4gICAgICAgICAgICAgICAgICAgICAgICAnJGhlaWdodCc6IC9weC8udGVzdCh2YWx1ZSkgPyB2YWx1ZSA6IGZ1bmN0aW9uIChvbGRWYWx1ZSwgaWR4LCBlbGVtZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGdldE5hdHVyYWxIZWlnaHQoJChlbGVtZW50KSwgdmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKG5hbWUgPT0gJyQkc2hvdycpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlKVxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZlsnc2V0J10oe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICckdmlzaWJpbGl0eSc6IHZhbHVlID8gJ3Zpc2libGUnIDogJ2hpZGRlbicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJyRkaXNwbGF5JzogJydcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pWydzZXQnXSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJyRkaXNwbGF5JzogZnVuY3Rpb24gKG9sZFZhbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gb2xkVmFsID09ICdub25lJyA/ICdibG9jaycgOiBvbGRWYWw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGZbJ3NldCddKHsgJyRkaXNwbGF5JzogJ25vbmUnIH0pO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAobmFtZSA9PSAnJCQnKSB7XG4gICAgICAgICAgICAgICAgICAgIHNlbGZbJ3NldCddKCdAc3R5bGUnLCB2YWx1ZSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlXG4gICAgICAgICAgICAgICAgICAgIGZsZXhpRWFjaCh0aGlzLCBmdW5jdGlvbiAob2JqLCBjKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbmV3VmFsdWUgPSBpc0Z1bmN0aW9uKHZhbHVlKSA/IHZhbHVlKCQob2JqKVsnZ2V0J10obmFtZSksIGMsIG9iaikgOiB2YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmVmaXggPT0gJyQnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1hdGNoWzJdKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmpbJ3N0eWxlJ11bbWF0Y2hbMl1dID0gbmV3VmFsdWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZsZXhpRWFjaChuZXdWYWx1ZSAmJiBuZXdWYWx1ZS5zcGxpdCgvXFxzKy8pLCBmdW5jdGlvbiAoY2x6eikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNOYW1lID0gcmVwbGFjZShjbHp6LCAvXlsrLV0vKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICgvXlxcKy8udGVzdChjbHp6KSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmpbJ2NsYXNzTGlzdCddLmFkZChjTmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICgvXi0vLnRlc3QoY2x6eikpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqWydjbGFzc0xpc3QnXS5yZW1vdmUoY05hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9ialsnY2xhc3NMaXN0J10udG9nZ2xlKGNOYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChuYW1lID09ICckJHNjcm9sbFgnKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9ialsnc2Nyb2xsJ10obmV3VmFsdWUsICQob2JqKVsnZ2V0J10oJyQkc2Nyb2xsWScpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKG5hbWUgPT0gJyQkc2Nyb2xsWScpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqWydzY3JvbGwnXSgkKG9iailbJ2dldCddKCckJHNjcm9sbFgnKSwgbmV3VmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAocHJlZml4ID09ICdAJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChuZXdWYWx1ZSA9PSBfbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqLnJlbW92ZUF0dHJpYnV0ZShtYXRjaFsyXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmouc2V0QXR0cmlidXRlKG1hdGNoWzJdLCBuZXdWYWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmpbbWF0Y2hbMl1dID0gbmV3VmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChpc1N0cmluZyhuYW1lKSB8fCBpc0Z1bmN0aW9uKG5hbWUpKVxuICAgICAgICAgICAgICAgIHNlbGZbJ3NldCddKCckJywgbmFtZSk7XG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgZWFjaE9iaihuYW1lLCBmdW5jdGlvbiAobiwgdikge1xuICAgICAgICAgICAgICAgICAgICBzZWxmWydzZXQnXShuLCB2KTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiBzZWxmO1xuICAgICAgICB9LFxuICAgICAgICAnYWRkJzogZnVuY3Rpb24gKGNoaWxkcmVuLCBhZGRGdW5jdGlvbikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXNbJ2VhY2gnXShmdW5jdGlvbiAoZSwgaW5kZXgpIHtcbiAgICAgICAgICAgICAgICB2YXIgbGFzdEFkZGVkO1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGFwcGVuZENoaWxkcmVuKGMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGlzTGlzdChjKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGZsZXhpRWFjaChjLCBhcHBlbmRDaGlsZHJlbik7XG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGlzRnVuY3Rpb24oYykpXG4gICAgICAgICAgICAgICAgICAgICAgICBhcHBlbmRDaGlsZHJlbihjKGUsIGluZGV4KSk7XG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGMgIT0gX251bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBuID0gaXNOb2RlKGMpID8gYyA6IGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGxhc3RBZGRlZClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXN0QWRkZWRbJ3BhcmVudE5vZGUnXVsnaW5zZXJ0QmVmb3JlJ10obiwgbGFzdEFkZGVkWyduZXh0U2libGluZyddKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGFkZEZ1bmN0aW9uKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZEZ1bmN0aW9uKG4sIGUsIGVbJ3BhcmVudE5vZGUnXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZS5hcHBlbmRDaGlsZChuKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RBZGRlZCA9IG47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYXBwZW5kQ2hpbGRyZW4oaW5kZXggJiYgIWlzRnVuY3Rpb24oY2hpbGRyZW4pID8gY2xvbmUoY2hpbGRyZW4pIDogY2hpbGRyZW4pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgICdvbic6IG9uLFxuICAgICAgICAndHJpZ2dlcic6IGZ1bmN0aW9uIChldmVudE5hbWUsIGV2ZW50T2JqKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpc1snZWFjaCddKGZ1bmN0aW9uIChlbGVtZW50LCBpbmRleCkge1xuICAgICAgICAgICAgICAgIHZhciBidWJibGVPbiA9IHRydWUsIGVsID0gZWxlbWVudDtcbiAgICAgICAgICAgICAgICB3aGlsZSAoZWwgJiYgYnViYmxlT24pIHtcbiAgICAgICAgICAgICAgICAgICAgZWFjaE9iaihlbFsnTSddLCBmdW5jdGlvbiAoaWQsIGYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1YmJsZU9uID0gYnViYmxlT24gJiYgZihldmVudE5hbWUsIGV2ZW50T2JqLCBlbGVtZW50KTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIGVsID0gZWxbJ3BhcmVudE5vZGUnXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSxcbiAgICAgICAgJ2h0JzogZnVuY3Rpb24gKGh0bWxUZW1wbGF0ZSwgb2JqZWN0KSB7XG4gICAgICAgICAgICB2YXIgbyA9IGFyZ3VtZW50cy5sZW5ndGggPiAyID8gbWVyZ2Uoc3ViKGFyZ3VtZW50cywgMSkpIDogb2JqZWN0O1xuICAgICAgICAgICAgcmV0dXJuIHRoaXNbJ3NldCddKCdpbm5lckhUTUwnLCBpc0Z1bmN0aW9uKGh0bWxUZW1wbGF0ZSkgPyBodG1sVGVtcGxhdGUobykgOiAve3svLnRlc3QoaHRtbFRlbXBsYXRlKSA/IGZvcm1hdEh0bWwoaHRtbFRlbXBsYXRlLCBvKSA6IC9eI1xcUyskLy50ZXN0KGh0bWxUZW1wbGF0ZSkgPyBmb3JtYXRIdG1sKCQkKGh0bWxUZW1wbGF0ZSlbJ3RleHQnXSwgbykgOiBodG1sVGVtcGxhdGUpO1xuICAgICAgICB9XG4gICAgfSwgTS5wcm90b3R5cGUpO1xuICAgIGNvcHlPYmooe1xuICAgICAgICAncmVxdWVzdCc6IGZ1bmN0aW9uIChtZXRob2QsIHVybCwgZGF0YSwgc2V0dGluZ3MwKSB7XG4gICAgICAgICAgICB2YXIgc2V0dGluZ3MgPSBzZXR0aW5nczAgfHwge307XG4gICAgICAgICAgICB2YXIgeGhyLCBjYWxsYmFja0NhbGxlZCA9IDAsIHByb20gPSBwcm9taXNlKCksIGRhdGFJc01hcCA9IGRhdGEgJiYgZGF0YVsnY29uc3RydWN0b3InXSA9PSBzZXR0aW5nc1snY29uc3RydWN0b3InXTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgcHJvbVsneGhyJ10gPSB4aHIgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICAgICAgICAgICAgICBwcm9tWydzdG9wMCddID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICB4aHJbJ2Fib3J0J10oKTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGlmIChkYXRhSXNNYXApIHtcbiAgICAgICAgICAgICAgICAgICAgZGF0YSA9IGNvbGxlY3RvcihlYWNoT2JqLCBkYXRhLCBmdW5jdGlvbiBwcm9jZXNzUGFyYW0ocGFyYW1OYW1lLCBwYXJhbVZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gY29sbGVjdG9yKGZsZXhpRWFjaCwgcGFyYW1WYWx1ZSwgZnVuY3Rpb24gKHYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZW5jb2RlVVJJQ29tcG9uZW50KHBhcmFtTmFtZSkgKyAodiAhPSBfbnVsbCA/ICc9JyArIGVuY29kZVVSSUNvbXBvbmVudCh2KSA6ICcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9KS5qb2luKCcmJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChkYXRhICE9IF9udWxsICYmICEvcG9zdC9pLnRlc3QobWV0aG9kKSkge1xuICAgICAgICAgICAgICAgICAgICB1cmwgKz0gJz8nICsgZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgZGF0YSA9IF9udWxsO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB4aHJbJ29wZW4nXShtZXRob2QsIHVybCwgdHJ1ZSwgc2V0dGluZ3NbJ3VzZXInXSwgc2V0dGluZ3NbJ3Bhc3MnXSk7XG4gICAgICAgICAgICAgICAgaWYgKGRhdGFJc01hcCAmJiAvcG9zdC9pLnRlc3QobWV0aG9kKSlcbiAgICAgICAgICAgICAgICAgICAgeGhyWydzZXRSZXF1ZXN0SGVhZGVyJ10oJ0NvbnRlbnQtVHlwZScsICdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQnKTtcbiAgICAgICAgICAgICAgICBlYWNoT2JqKHNldHRpbmdzWydoZWFkZXJzJ10sIGZ1bmN0aW9uIChoZHJOYW1lLCBoZHJWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICB4aHJbJ3NldFJlcXVlc3RIZWFkZXInXShoZHJOYW1lLCBoZHJWYWx1ZSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgZWFjaE9iaihzZXR0aW5nc1sneGhyJ10sIGZ1bmN0aW9uIChuYW1lLCB2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICB4aHJbbmFtZV0gPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB4aHJbJ29ucmVhZHlzdGF0ZWNoYW5nZSddID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoeGhyWydyZWFkeVN0YXRlJ10gPT0gNCAmJiAhY2FsbGJhY2tDYWxsZWQrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHhoclsnc3RhdHVzJ10gPj0gMjAwICYmIHhoclsnc3RhdHVzJ10gPCAzMDApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvbVsnZmlyZSddKHRydWUsIFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeGhyWydyZXNwb25zZVRleHQnXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeGhyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvbVsnZmlyZSddKGZhbHNlLCBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHhoclsnc3RhdHVzJ10sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHhoclsncmVzcG9uc2VUZXh0J10sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHhoclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB4aHJbJ3NlbmQnXShkYXRhKTtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICBpZiAoIWNhbGxiYWNrQ2FsbGVkKVxuICAgICAgICAgICAgICAgICAgICBwcm9tWydmaXJlJ10oZmFsc2UsIFtcbiAgICAgICAgICAgICAgICAgICAgICAgIDAsXG4gICAgICAgICAgICAgICAgICAgICAgICBfbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvU3RyaW5nKGUpXG4gICAgICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHByb207XG4gICAgICAgIH0sXG4gICAgICAgICdyZWFkeSc6IHJlYWR5LFxuICAgICAgICAnb2ZmJzogb2ZmLFxuICAgICAgICAnd2FpdCc6IGZ1bmN0aW9uIChkdXJhdGlvbk1zLCBhcmdzKSB7XG4gICAgICAgICAgICB2YXIgcCA9IHByb21pc2UoKTtcbiAgICAgICAgICAgIHZhciBpZCA9IHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHBbJ2ZpcmUnXSh0cnVlLCBhcmdzKTtcbiAgICAgICAgICAgIH0sIGR1cmF0aW9uTXMpO1xuICAgICAgICAgICAgcFsnc3RvcDAnXSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBwWydmaXJlJ10oZmFsc2UpO1xuICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dChpZCk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgcmV0dXJuIHA7XG4gICAgICAgIH1cbiAgICB9LCAkKTtcbiAgICBjb3B5T2JqKHtcbiAgICAgICAgJ2VhY2gnOiBlYWNoLFxuICAgICAgICAndG9PYmplY3QnOiB0b09iamVjdCxcbiAgICAgICAgJ2ZpbmQnOiBmaW5kLFxuICAgICAgICAnZXF1YWxzJzogZXF1YWxzLFxuICAgICAgICAnY29weU9iaic6IGNvcHlPYmosXG4gICAgICAgICdleHRlbmQnOiBmdW5jdGlvbiAodGFyZ2V0KSB7XG4gICAgICAgICAgICByZXR1cm4gbWVyZ2Uoc3ViKGFyZ3VtZW50cywgMSksIHRhcmdldCk7XG4gICAgICAgIH0sXG4gICAgICAgICdlYWNoT2JqJzogZWFjaE9iaixcbiAgICAgICAgJ2lzT2JqZWN0JzogaXNPYmplY3QsXG4gICAgICAgICdmb3JtYXQnOiBmdW5jdGlvbiAodHBsLCBvYmplY3QsIGVzY2FwZUZ1bmN0aW9uKSB7XG4gICAgICAgICAgICByZXR1cm4gdGVtcGxhdGUodHBsLCBlc2NhcGVGdW5jdGlvbikob2JqZWN0KTtcbiAgICAgICAgfSxcbiAgICAgICAgJ3RlbXBsYXRlJzogdGVtcGxhdGUsXG4gICAgICAgICdmb3JtYXRIdG1sJzogZm9ybWF0SHRtbCxcbiAgICAgICAgJ3Byb21pc2UnOiBwcm9taXNlXG4gICAgfSwgXyk7XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignRE9NQ29udGVudExvYWRlZCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgY2FsbExpc3QoRE9NUkVBRFlfSEFORExFUik7XG4gICAgICAgIERPTVJFQURZX0hBTkRMRVIgPSBfbnVsbDtcbiAgICB9LCBmYWxzZSk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgJ0hUTUwnOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgZGl2ID0gRUUoJ2RpdicpO1xuICAgICAgICAgICAgcmV0dXJuIF8oY2FsbChkaXZbJ2h0J10sIGRpdiwgYXJndW1lbnRzKVswXS5jaGlsZE5vZGVzKTtcbiAgICAgICAgfSxcbiAgICAgICAgJ18nOiBfLFxuICAgICAgICAnJCc6ICQsXG4gICAgICAgICckJCc6ICQkLFxuICAgICAgICAnTSc6IE0sXG4gICAgICAgICdnZXR0ZXInOiBnZXR0ZXIsXG4gICAgICAgICdzZXR0ZXInOiBzZXR0ZXJcbiAgICB9O1xufSgpOyJdfQ==</script></body></html>";
	},{}],37:[function(g,n,I){n.exports=".section .component-input {\n  padding: 0;\n}\n.component-input label {\n  display: block;\n}\n.component-input .label {\n  padding-bottom: 0.7rem;\n}\n.component-input .input {\n  position: relative;\n  min-width: 100%;\n  margin-top: 0.7rem;\n  margin-left: 0;\n}\n.component-input input {\n  display: block;\n  width: 100%;\n  background: #333333;\n  border-radius: 0.25rem;\n  padding: 0.35rem 0.375rem;\n  border: none;\n  vertical-align: baseline;\n  color: #ffffff;\n  font-size: inherit;\n  -webkit-appearance: none;\n  appearance: none;\n  min-height: 2.1rem;\n}\n.component-input input::-webkit-input-placeholder {\n  color: #858585;\n}\n.component-input input::-moz-placeholder {\n  color: #858585;\n}\n.component-input input:-moz-placeholder {\n  color: #858585;\n}\n.component-input input:-ms-input-placeholder {\n  color: #858585;\n}\n.component-input input:focus::-webkit-input-placeholder {\n  color: #666666;\n}\n.component-input input:focus::-moz-placeholder {\n  color: #666666;\n}\n.component-input input:focus:-moz-placeholder {\n  color: #666666;\n}\n.component-input input:focus:-ms-input-placeholder {\n  color: #666666;\n}\n.component-input input:focus {\n  border: none;\n  box-shadow: none;\n}\n/*# sourceMappingURL=input.css.map */\n"},{}],38:[function(g,n,I){n.exports='.component-radio {\n  display: block;\n}\n.section .component-radio {\n  padding-right: 0.375rem;\n}\n.component-radio > .label {\n  display: block;\n  padding-bottom: 0.35rem;\n}\n.component-radio .radio-group {\n  padding-bottom: 0.35rem;\n}\n.component-radio .radio-group label {\n  padding: 0.35rem 0.375rem;\n}\n.component-radio .radio-group .label {\n  font-size: 0.9em;\n}\n.component-radio .radio-group input {\n  opacity: 0;\n  position: absolute;\n}\n.component-radio .radio-group i {\n  display: block;\n  position: relative;\n  border-radius: 1.4rem;\n  width: 1.4rem;\n  height: 1.4rem;\n  border: 2px solid #767676;\n  -webkit-flex-shrink: 0;\n  flex-shrink: 0;\n}\n.component-radio .radio-group input:checked + i {\n  border-color: #ff4700;\n}\n.component-radio .radio-group input:checked + i:after {\n  content: "";\n  display: block;\n  position: absolute;\n  left: 15%;\n  right: 15%;\n  top: 15%;\n  bottom: 15%;\n  border-radius: 1.4rem;\n  background: #ff4700;\n}\n.component-radio .description {\n  padding-left: 0;\n  padding-right: 0;\n}\n/*# sourceMappingURL=radiogroup.css.map */\n'},{}],39:[function(g,n,I){n.exports='.section .component-select {\n  padding: 0;\n}\n.component-select label {\n  position: relative;\n}\n.component-select .value {\n  position: relative;\n  padding-right: 1.1rem;\n  display: block;\n}\n.component-select .value:after {\n  content: "";\n  position: absolute;\n  right: 0;\n  top: 50%;\n  margin-top: -0.1rem;\n  height: 0;\n  width: 0;\n  border-left: 0.425rem solid transparent;\n  border-right: 0.425rem solid transparent;\n  border-top: 0.425rem solid #ff4700;\n}\n.component-select select {\n  opacity: 0;\n  position: absolute;\n  display: block;\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  width: 100%;\n  border: none;\n  margin: 0;\n  padding: 0;\n}\n/*# sourceMappingURL=select.css.map */\n'},{}],40:[function(g,n,I){n.exports='.section .component-slider {\n  padding: 0;\n}\n.component-slider label {\n  display: block;\n}\n.component-slider .label-container {\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: flex;\n  -webkit-box-align: center;\n  -webkit-align-items: center;\n  align-items: center;\n  width: 100%;\n  padding-bottom: 0.7rem;\n}\n.component-slider .label {\n  -webkit-box-flex: 1;\n  -webkit-flex: 1;\n  flex: 1;\n  min-width: 1rem;\n  display: block;\n  padding-right: 0.75rem;\n}\n.component-slider .value-wrap {\n  display: block;\n  position: relative;\n}\n.component-slider .value,\n.component-slider .value-pad {\n  display: block;\n  background: #333333;\n  border-radius: 0.25rem;\n  padding: 0.35rem 0.375rem;\n  border: none;\n  vertical-align: baseline;\n  color: #ffffff;\n  text-align: right;\n  margin: 0;\n  min-width: 1rem;\n}\n.component-slider .value-pad {\n  visibility: hidden;\n}\n.component-slider .value-pad:before {\n  content: " ";\n  display: inline-block;\n}\n.component-slider .value {\n  max-width: 100%;\n  position: absolute;\n  left: 0;\n  top: 0;\n}\n.component-slider .input-wrap {\n  padding: 0 0.75rem 0.7rem;\n}\n.component-slider .input {\n  display: block;\n  position: relative;\n  min-width: 100%;\n  height: 1.4rem;\n  overflow: hidden;\n  margin-left: 0;\n}\n.component-slider .input:before {\n  content: "";\n  display: block;\n  position: absolute;\n  height: 0.1764705882rem;\n  background: #666666;\n  width: 100%;\n  top: 0.6117647059rem;\n}\n.component-slider .input .slider {\n  display: block;\n  width: 100%;\n  -webkit-appearance: none;\n  appearance: none;\n  position: relative;\n  height: 1.4rem;\n  margin: 0;\n  background-color: transparent;\n}\n.component-slider .input .slider:focus {\n  outline: none;\n}\n.component-slider .input .slider::-webkit-slider-runnable-track {\n  border: none;\n  height: 1.4rem;\n  width: 100%;\n  background-color: transparent;\n}\n.component-slider .input .slider::-webkit-slider-thumb {\n  -webkit-appearance: none;\n  appearance: none;\n  position: relative;\n  height: 1.4rem;\n  width: 1.4rem;\n  background-color: #ff4700;\n  border-radius: 50%;\n}\n.component-slider .input .slider::-webkit-slider-thumb:before {\n  content: "";\n  position: absolute;\n  left: -1000px;\n  top: 0.6117647059rem;\n  height: 0.1764705882rem;\n  width: 1001px;\n  background: #ff4700;\n}\n/*# sourceMappingURL=slider.css.map */\n'},{}],41:[function(g,n,I){n.exports=".component-submit {\n  text-align: center;\n}\n/*# sourceMappingURL=submit.css.map */\n"},{}],42:[function(g,n,I){n.exports=".section .component-toggle {\n  padding: 0;\n}\n.component-toggle input {\n  display: none;\n}\n.component-toggle .graphic {\n  display: inline-block;\n  position: relative;\n}\n.component-toggle .graphic .slide {\n  display: block;\n  border-radius: 1.05rem;\n  height: 1.05rem;\n  width: 2.2652rem;\n  background: #2f2f2f;\n  -webkit-transition: background-color 150ms linear;\n  transition: background-color 150ms linear;\n}\n.component-toggle .graphic .marker {\n  background: #ececec;\n  width: 1.4rem;\n  height: 1.4rem;\n  border-radius: 1.4rem;\n  position: absolute;\n  left: 0;\n  display: block;\n  top: -0.175rem;\n  -webkit-transition: -webkit-transform 150ms linear;\n  transition: -webkit-transform 150ms linear;\n  transition: transform 150ms linear;\n  transition: transform 150ms linear, -webkit-transform 150ms linear;\n  box-shadow: 0 0.1rem 0.1rem #2f2f2f;\n}\n.component-toggle input:checked + .graphic .slide {\n  background: #993d19;\n}\n.component-toggle input:checked + .graphic .marker {\n  background: #ff4700;\n  -webkit-transform: translateX(0.8652rem);\n  transform: translateX(0.8652rem);\n}\n/*# sourceMappingURL=toggle.css.map */\n"},{}],"@rebble/clay":[function(g,n,I){"use strict";function t(g,n,I){function t(){C.meta={activeWatchInfo:Pebble.getActiveWatchInfo&&Pebble.getActiveWatchInfo(),accountToken:Pebble.getAccountToken(),watchToken:Pebble.getWatchToken(),userData:i(I.userData||{})}}function e(g,n,I){Array.isArray(g)?g.forEach(function(g){e(g,n,I)}):"section"===g.type?e(g.items,n,I):n(g)&&I(g)}var C=this;if(!Array.isArray(g))throw new Error("config must be an Array");if(n&&"function"!=typeof n)throw new Error('customFn must be a function or "null"');I=I||{},C.config=i(g),C.customFn=n||function(){},C.components={},C.meta={activeWatchInfo:null,accountToken:"",watchToken:"",userData:{}},C.version=l,I.autoHandleEvents!==!1&&"undefined"!=typeof Pebble?(Pebble.addEventListener("showConfiguration",function(){t(),Pebble.openURL(C.generateUrl())}),Pebble.addEventListener("webviewclosed",function(g){g&&g.response&&Pebble.sendAppMessage(C.getSettings(g.response),function(){console.log("Sent config data to Pebble")},function(g){console.log("Failed to send config data!"),console.log(JSON.stringify(g))})})):"undefined"!=typeof Pebble&&Pebble.addEventListener("ready",function(){t()}),e(C.config,function(g){return A[g.type]},function(g){C.registerComponent(A[g.type])}),e(C.config,function(g){return g.appKey},function(){throw new Error("appKeys are no longer supported. Please follow the migration guide to upgrade your project")})}var e=g("./tmp/config-page.html"),C=g("tosource"),A=g("./src/scripts/components"),i=g("deepcopy/build/deepcopy.min"),l=g("./package.json").version,c=g("message_keys");t.prototype.registerComponent=function(g){this.components[g.name]=g},t.prototype.generateUrl=function(){var g={},n=!Pebble||"pypkjs"===Pebble.platform,I=n?"$$$RETURN_TO$$$":"pebblejs://close#";try{g=JSON.parse(localStorage.getItem("clay-settings"))||{}}catch(A){console.error(A.toString())}var i=e.replace("$$RETURN_TO$$",I).replace("$$CUSTOM_FN$$",C(this.customFn)).replace("$$CONFIG$$",C(this.config)).replace("$$SETTINGS$$",C(g)).replace("$$COMPONENTS$$",C(this.components)).replace("$$META$$",C(this.meta));return n?t.encodeDataUri(i,"http://clay.pebble.com.s3-website-us-west-2.amazonaws.com/#"):t.encodeDataUri(i)},t.prototype.getSettings=function(g,n){var I={};g=g.match(/^\{/)?g:decodeURIComponent(g);try{I=JSON.parse(g)}catch(e){throw new Error("The provided response was not valid JSON")}var C={};return Object.keys(I).forEach(function(g){"object"==typeof I[g]&&I[g]?C[g]=I[g].value:C[g]=I[g]}),localStorage.setItem("clay-settings",JSON.stringify(C)),n===!1?I:t.prepareSettingsForAppMessage(I)},t.prototype.setSettings=function(g,n){var I={};try{I=JSON.parse(localStorage.getItem("clay-settings"))||{}}catch(t){console.error(t.toString())}if("object"==typeof g){var e=g;Object.keys(e).forEach(function(g){I[g]=e[g]})}else I[g]=n;localStorage.setItem("clay-settings",JSON.stringify(I))},t.encodeDataUri=function(g,n){return n="undefined"!=typeof n?n:"data:text/html;charset=utf-8,",n+encodeURIComponent(g)},t.prepareForAppMessage=function(g){function n(g,n){return Math.floor(g*Math.pow(10,n||0))}var I;return Array.isArray(g)?(I=[],g.forEach(function(g,n){I[n]=t.prepareForAppMessage(g)})):I="object"==typeof g&&g?"number"==typeof g.value?n(g.value,g.precision):Array.isArray(g.value)?g.value.map(function(I){return"number"==typeof I?n(I,g.precision):I}):t.prepareForAppMessage(g.value):"boolean"==typeof g?g?1:0:g,I},t.prepareSettingsForAppMessage=function(g){var n={};Object.keys(g).forEach(function(I){var t=g[I],e=I.match(/(.+?)(?:\[(\d*)\])?$/);if(!e[2])return void(n[I]=t);var C=parseInt(e[2],10);I=e[1],"undefined"==typeof n[I]&&(n[I]=[]),n[I][C]=t});var I={};return Object.keys(n).forEach(function(g){var e=c[g],C=t.prepareForAppMessage(n[g]);C=Array.isArray(C)?C:[C],C.forEach(function(g,n){I[e+n]=g})}),Object.keys(I).forEach(function(g){if(Array.isArray(I[g]))throw new Error('Clay does not support 2 dimensional arrays for item values. Make sure you are not attempting to use array syntax (eg: "myMessageKey[2]") in the messageKey for components that return an array, such as a checkboxgroup')}),I},n.exports=t},{"./package.json":7,"./src/scripts/components":13,"./tmp/config-page.html":36,"deepcopy/build/deepcopy.min":3,message_keys:void 0,tosource:6}]},{},["@rebble/clay"])("@rebble/clay")});
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(23)))

/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

	/**
	 * Copyright 2024 Google LLC
	 *
	 * Licensed under the Apache License, Version 2.0 (the "License");
	 * you may not use this file except in compliance with the License.
	 * You may obtain a copy of the License at
	 *
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *
	 * Unless required by applicable law or agreed to in writing, software
	 * distributed under the License is distributed on an "AS IS" BASIS,
	 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	 * See the License for the specific language governing permissions and
	 * limitations under the License.
	 */
	
	module.exports = function(module) {
	    switch(module) {
	        case "message_keys": return __webpack_require__(3);
	    }
	    throw new Error('Module not found: ' + module);
	};


/***/ }),
/* 24 */
/***/ (function(module, exports) {

	'use strict';
	
	// Clay retains the established preference keys. Page-only choices translate to
	// these fields, so notification privacy remains compatible with earlier builds.
	module.exports = [
	  {type:'heading',defaultValue:'Dynamic Settings'},
	  {type:'section',items:[
	    {type:'heading',defaultValue:'Appearance'},
	    {type:'text',id:'dynamic-preview',defaultValue:'Layout & colour preview'},
	    {type:'text',id:'dynamic-theme',defaultValue:'Theme'},
	    {type:'color',messageKey:'BACKGROUND_COLOR',defaultValue:'0xFFFFFF',label:'Background color',layout:'COLOR',sunlight:false},
	    {type:'color',messageKey:'TEXT_COLOR',defaultValue:'0x000000',label:'Text color',layout:'COLOR',sunlight:false},
	    {type:'color',messageKey:'ACCENT_COLOR',defaultValue:'0x55AAFF',label:'Accent color',description:'Color for reading symbols and rain gauges.',layout:'COLOR',sunlight:false},
	    {type:'text',id:'dynamic-contrast',defaultValue:''},
	    {type:'text',id:'dynamic-palette-code',defaultValue:'Share colours'},
	    {type:'toggle',messageKey:'NIGHT_PALETTE',defaultValue:false,label:'Quiet Time colours',description:'Use these watch colours while Pebble Quiet Time is active.'},
	    {type:'color',messageKey:'NIGHT_BACKGROUND_COLOR',defaultValue:'0x000000',label:'Quiet Time background',layout:'COLOR',sunlight:false},
	    {type:'color',messageKey:'NIGHT_TEXT_COLOR',defaultValue:'0xFFFFFF',label:'Quiet Time text',layout:'COLOR',sunlight:false},
	    {type:'color',messageKey:'NIGHT_ACCENT_COLOR',defaultValue:'0x55AAFF',label:'Quiet Time accent',layout:'COLOR',sunlight:false},
	    {type:'select',messageKey:'CLOCK_FORMAT',defaultValue:0,label:'Time format',serializeValueAs:'integer',options:[
	      {label:'Follow Pebble',value:0},{label:'12-hour time',value:12},{label:'24-hour time',value:24}
	    ]},
	    {type:'toggle',messageKey:'ANIMATIONS',defaultValue:true,label:'Animations',description:'Short transitions when activities change.'},
	    {type:'toggle',messageKey:'SHOW_STATUS',defaultValue:true,label:'Status indicators',description:'Low watch or phone battery and lost connection.'},
	    {type:'text',defaultValue:'Language follows your watch.'}
	  ]},
	  {type:'section',items:[
	    {type:'heading',defaultValue:'Content & priority'},
	    {type:'text',id:'dynamic-readings',defaultValue:'Your two readings'},
	    {type:'text',id:'dynamic-reading-help',defaultValue:'Choose slots 1 and 2 in Pebble → Settings → Complications.'},
	    {type:'toggle',messageKey:'SHOW_ACTIVITIES',defaultValue:true,label:'Show activity plugins',description:'Show activities from installed plugins. Music and Notifications have their own switches in the list below.'},
	    {type:'text',id:'dynamic-activity-order',defaultValue:'Activity priority'},
	    {type:'toggle',messageKey:'SHOW_MUSIC',defaultValue:true,label:'Show music while playing'},
	    {type:'text',id:'dynamic-notification-mode',defaultValue:'Notification details'},
	    {type:'text',id:'dynamic-notification-disabled',defaultValue:'Enable Notifications in the activity list to change its details.'},
	    {type:'toggle',messageKey:'SHOW_NOTIFICATIONS',defaultValue:false,label:'New notifications'},
	    {type:'toggle',messageKey:'NOTIFICATION_PREVIEW',defaultValue:false,label:'Include message text'},
	    {type:'toggle',messageKey:'NOTIFICATION_APP_ONLY',defaultValue:false,label:'App name only'},
	    {type:'select',messageKey:'NOTIFICATION_VIBRATION',defaultValue:0,label:'Additional vibration',description:'One additional vibration per new notification burst, using your app filter. Respects Quiet Time. Turn this off if Pebble already vibrates for those notifications.',serializeValueAs:'integer',options:[
	      {label:'Off',value:0},{label:'Short pulse',value:1},{label:'Double pulse',value:2}
	    ]},
	    {type:'text',id:'dynamic-notification-help',defaultValue:'New notifications use the same activity priority and primary/secondary layouts. Allow notification access in Pebble. Pebble’s system notifications remain separate.'},
	    {type:'text',id:'dynamic-app-mode',defaultValue:'Notification apps'},
	    {type:'input',messageKey:'NOTIFICATION_APPS',defaultValue:'',label:'Selected apps',description:'Use exact app names or Android package names, separated by commas. For example: Signal, org.thoughtcrime.securesms',attributes:{type:'text',maxlength:160,autocapitalize:'none',autocomplete:'off',spellcheck:'false'}}
	  ]},
	  {type:'section',items:[
	    {type:'heading',defaultValue:'Connection & help'},
	    {type:'text',id:'dynamic-save-status',defaultValue:'Changes apply after you save.'},
	    {type:'text',defaultValue:'Status when settings opened. Reopen settings to refresh.'},
	    {type:'text',id:'dynamic-source-status',defaultValue:'Dynamic content: waiting for Pebble'},
	    {type:'text',id:'complications-status',defaultValue:'Complications: waiting for Pebble'},
	    {type:'text',id:'context-status',defaultValue:'Dynamic content: waiting for Pebble'},
	    {type:'text',defaultValue:'Timeline Peek keeps the clock and complications 1 and 2. Its event panel takes priority over music and notifications.'}
	  ]},
	  {type:'submit',defaultValue:'Save'},
	  // Transport components have no preference keys and are never submitted.
	  {type:'text',id:'dynamic-settings-data',defaultValue:'{}'},
	  {type:'text',id:'dynamic-settings-strings',defaultValue:'{}'},
	  {type:'text',id:'dynamic-preview-assets',defaultValue:'{}'},
	  {type:'input',messageKey:'__dynamicActivityPreferences',defaultValue:'',attributes:{type:'hidden'}}
	];


/***/ }),
/* 25 */
/***/ (function(module, exports) {

	'use strict';
	
	// Clay copies only this function to its offline page. Everything used below is
	// either supplied as a transport component or declared inside the function.
	module.exports = function() {
	  var clay = this;
	  var style = document.createElement('style');
	  style.id = 'dynamic-settings-style';
	  style.textContent = [
	    ':root{color-scheme:light;--page:#f4f5f7;--card:#fff;--ink:#15181c;--muted:#5d6571;--line:#d9dee6;--accent:#145ca3;--field:#f4f5f7;--track:#cad0d6}',
	    '@media(prefers-color-scheme:dark){:root{color-scheme:dark;--page:#11151b;--card:#1d232d;--ink:#f3f5f7;--muted:#b5bfcc;--line:#465165;--accent:#8abfff;--field:#262e39;--track:#565f6a}}',
	    'html{font-size:16px!important;height:auto;background:var(--page)!important;color:var(--ink)!important}',
	    'body{box-sizing:border-box;height:auto;max-width:512px;margin:0 auto;padding:20px 16px 140px;padding-bottom:calc(var(--dynamic-save-height,108px) + 32px + env(safe-area-inset-bottom));background:var(--page);color:var(--ink);font:16px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}',
	    '*,*:before,*:after{box-sizing:border-box}',
	    // Clay adds component styles after this hook. Scope colour rules to the
	    // form so late defaults cannot reintroduce white inputs or orange text.
	    'body{background:var(--page)!important;color:var(--ink)!important}',
	    '#main-form{color:var(--ink);font:inherit}',
	    '#main-form .section{background:var(--card);color:var(--ink)}',
	    '#main-form label,#main-form .label,#main-form .component-select .value{color:var(--ink);font-family:inherit}',
	    '#main-form strong{color:var(--ink);font-family:inherit}',
	    '#main-form .description,#main-form .component-text p{color:var(--muted)}',
	    '#main-form input,#main-form select,#main-form option{color:var(--ink);background-color:var(--field);font-family:inherit}',
	    '#main-form input::placeholder{color:var(--muted);opacity:1}',
	    '#main-form .component-select .value{background:var(--field)}',
	    '#main-form .component-toggle input{background:none}',
	    '#main-form .component-toggle .graphic .marker{background:#fff;border:1px solid #59636f}',
	    '#main-form .component-toggle input:checked+.graphic .marker{background:#fff;border-color:#fff}',
	    '#main-form .component-color .picker-wrap .picker{background:var(--card);color:var(--ink)}',
	    '#main-form .dynamic-save-state p{color:var(--muted)}',
	    '#main-form .dynamic-warning p{color:#934300}',
	    '@media(prefers-color-scheme:dark){#main-form .dynamic-warning p{color:#ffbd77}}',
	    '#main-form>.component-heading:first-child{padding:0 2px 20px}',
	    '.component-heading h1,.component-heading h2,.component-heading h3,.component-heading h4{margin:0;color:var(--ink);font:700 20px/1.3 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;text-transform:none;letter-spacing:0}',
	    '#main-form>.component-heading:first-child h1,#main-form>.component-heading:first-child h2,#main-form>.component-heading:first-child h4{font-size:28px;letter-spacing:-.6px}',
	    '#main-form>.component-heading:first-child:after{content:"";display:block;width:48px;height:5px;margin-top:12px;background:var(--accent)}',
	    '.section{margin:0 0 16px;border:1px solid var(--line);border-radius:14px;background:var(--card);box-shadow:none;overflow:hidden}',
	    '.section>.component{margin-top:0!important;padding:13px 16px;position:relative}',
	    '.section>.component-heading:first-child{padding:16px 16px 10px;background:none;border-radius:0}',
	    '.section>.component-heading:first-child h1,.section>.component-heading:first-child h2,.section>.component-heading:first-child h4{color:var(--accent)}',
	    '.section>.component:after{left:16px;right:16px;background:var(--line)}',
	    '.component-text p{margin:0;font-size:14px;line-height:1.5;color:var(--muted);overflow-wrap:break-word;word-wrap:break-word}',
	    'label{min-height:28px;padding:0;gap:14px;color:var(--ink);font-size:16px;line-height:1.4}',
	    'label>.label{min-width:0;flex:1;overflow-wrap:break-word;word-wrap:break-word}',
	    'label>.input{flex-shrink:0;margin-left:0}',
	    '.description{padding:0;margin-top:7px;color:var(--muted);font-size:14px;line-height:1.45;overflow-wrap:break-word;word-wrap:break-word}',
	    '.component-toggle label{min-height:44px}',
	    '.component-toggle input{display:block;position:absolute;opacity:0;width:44px;height:44px;right:12px;top:13px;margin:0}',
	    '.component-toggle input:focus-visible+.graphic{outline:2px solid var(--accent);outline-offset:5px;border-radius:16px}',
	    '.component-select:focus-within .value,.component-color label:focus-visible{outline:2px solid var(--accent);outline-offset:3px}',
	    '.color-box.selectable:focus-visible{outline:3px solid var(--ink);outline-offset:-3px}',
	    '.component-toggle .graphic .slide{background:var(--track)}',
	    '.component-toggle .graphic .marker{box-shadow:0 1px 3px #0003}',
	    '.component-toggle input:checked+.graphic .slide,.component-toggle input:checked+.graphic .marker{background:#145ca3}',
	    '.component-color .value{flex-shrink:0;border:1px solid #8886;box-shadow:none}',
	    '.component-color .picker-wrap .picker{max-width:416px;background:var(--card);border:1px solid var(--line);border-radius:14px}',
	    '.component-input label{display:block}',
	    '.component-input label>.label{display:block;padding:0}',
	    '.component-input .input{display:block;min-width:100%;max-width:none;margin:9px 0 0}',
	    '.component-input input{min-height:44px;padding:10px 12px;border:1px solid var(--line);border-radius:8px;background:var(--field);color:var(--ink);font-size:15px}',
	    '.component-input input:focus{outline:2px solid var(--accent);outline-offset:1px;border:1px solid var(--line)}',
	    '.component-select label,.dynamic-choice label{display:block}',
	    '.component-select .value{margin-top:9px;padding:10px 28px 10px 12px;min-height:44px;border:1px solid var(--line);border-radius:8px;background:var(--field);font-size:15px}',
	    '.component-select .value:after{right:12px;border-top-color:var(--accent)}',
	    '.dynamic-choice select{display:block;width:100%;margin-top:9px;min-height:44px;padding:10px 12px;border:1px solid var(--line);border-radius:8px;background:var(--field);color:var(--ink);font:inherit;font-size:15px}',
	    '.dynamic-choice select:focus-visible,button:focus-visible,summary:focus-visible{outline:2px solid var(--accent);outline-offset:3px}',
	    '.dynamic-section-nav{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 16px}',
	    '.dynamic-section-nav button{flex:1 1 auto;min-width:0;min-height:44px;width:auto;max-width:100%;margin:0;padding:9px 10px;border:1px solid var(--line);border-radius:8px;background:var(--card);color:var(--ink);box-shadow:none;font:600 13px/1.35 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;text-transform:none;letter-spacing:0;white-space:normal;overflow-wrap:normal;word-break:normal}',
	    '.dynamic-section-target:focus{outline:2px solid var(--accent);outline-offset:3px}',
	    '.dynamic-preview-tabs{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;margin:0 0 16px}',
	    '.dynamic-preview-tabs button{min-width:0;width:100%;margin:0;text-transform:none;letter-spacing:0;box-shadow:none;min-height:44px;padding:7px 8px;border:1px solid var(--line);border-radius:8px;background:var(--field);color:var(--ink);font:600 13px/1.3 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;white-space:normal;overflow-wrap:anywhere}',
	    '.dynamic-preview-tabs button[aria-selected=true]{background:#145ca3;border-color:#145ca3;color:#fff}',
	    '.dynamic-preview-stage{width:212px;max-width:100%;margin:0 auto 14px;border:6px solid #101216;border-radius:12px;overflow:hidden;background:#fff;line-height:0}',
	    '.dynamic-preview-stage canvas{display:block;width:200px;height:228px;max-width:100%;image-rendering:pixelated}',
	    '.dynamic-preview-note{margin:7px 0 0!important;font-size:12px!important}',
	    '.dynamic-preview-title{margin:0 0 12px;color:var(--ink);font-size:15px;text-transform:none!important}',
	    '.dynamic-preview-palette{display:block;margin:0 0 14px}',
	    '.dynamic-preview-palette>.description{display:block;margin-top:7px}',
	    '.dynamic-example-disabled{padding:7px 9px;border-radius:7px;background:var(--field);color:var(--muted)}',
	    '.dynamic-save-state{padding:0 0 7px!important;margin:0;color:var(--muted);font-size:14px;line-height:1.4}',
	    '.dynamic-save-state p{margin:0;font-size:14px;line-height:1.4}',
	    '.dynamic-save-state:after{display:none!important}',
	    '.dynamic-palette-code label{display:block;margin-bottom:7px}',
	    '.dynamic-palette-details summary{min-height:44px;display:list-item;align-content:center;cursor:pointer;color:var(--ink);font-size:15px}',
	    '.dynamic-palette-code input{display:block;width:100%;min-height:44px;padding:10px;border:1px solid var(--line);border-radius:8px;font:15px/1.4 ui-monospace,SFMono-Regular,Consolas,monospace}',
	    '.dynamic-palette-actions{display:flex;gap:8px;margin-top:9px}',
	    '.dynamic-palette-actions button{flex:1;min-width:0;width:auto;margin:0;min-height:44px;padding:9px 12px;border:1px solid var(--line);border-radius:8px;box-shadow:none;background:var(--field);color:var(--ink);font:600 14px/1.35 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;text-transform:none;letter-spacing:0}',
	    '#main-form .dynamic-palette-code input:focus-visible{outline:2px solid var(--accent);outline-offset:2px}',
	    '.dynamic-palette-code p{margin:7px 0 0!important}',
	    '.dynamic-app-filter label{display:block;min-height:0;margin-bottom:7px}',
	    '.dynamic-app-entry{display:flex;gap:7px;align-items:stretch}',
	    '.dynamic-app-entry input{flex:1;min-width:0;width:0;padding:10px;border:1px solid var(--line);border-radius:8px;background:var(--field);color:var(--ink);font:inherit;font-size:15px}',
	    '.dynamic-app-entry button,.dynamic-app-chip button{width:auto;margin:0;min-width:0;box-shadow:none;text-transform:none;letter-spacing:0;font:inherit}',
	    '.dynamic-app-entry button{min-height:44px;padding:9px 13px;border:0;border-radius:8px;background:#145ca3;color:white}',
	    '.dynamic-app-chips{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0 0;padding:0;list-style:none}',
	    '.dynamic-app-chip{display:flex;align-items:center;max-width:100%;padding:3px 3px 3px 10px;border:1px solid var(--line);border-radius:9px;background:var(--field);font-size:13px}',
	    '.dynamic-app-chip span{min-width:0;overflow-wrap:anywhere}',
	    '.dynamic-app-chip button{flex-shrink:0;min-height:44px;min-width:44px;padding:3px;border:0;background:none;color:var(--ink);font-size:20px}',
	    '.dynamic-app-filter .dynamic-app-error{margin:7px 0 0;color:var(--ink);font-size:12px}',
	    '.dynamic-activity-list{padding:0;margin:12px 0 0;list-style:none}',
	    '.dynamic-activity-row{display:grid;grid-template-columns:44px minmax(0,1fr) auto;align-items:center;gap:6px 8px;padding:10px 0;border-top:1px solid var(--line)}',
	    '.dynamic-activity-row[data-hidden=true] .dynamic-activity-name,.dynamic-activity-row[data-disabled=true] .dynamic-activity-name{color:var(--muted)}',
	    '.dynamic-activity-name{min-width:0;overflow-wrap:anywhere;font-size:15px;font-weight:600}',
	    '.dynamic-activity-name small{display:block;font-size:12px;font-weight:400;color:var(--muted)}',
	    '.dynamic-activity-row button{width:auto;min-width:44px;min-height:44px;margin:0;padding:7px;box-shadow:none;border:1px solid var(--line);border-radius:7px;background:var(--field);color:var(--ink);font:inherit;text-transform:none;letter-spacing:0}',
	    '.dynamic-activity-row button:disabled{opacity:.35}',
	    '.dynamic-activity-handle{touch-action:none;cursor:grab;font-size:21px!important}',
	    '.dynamic-activity-move{grid-column:2/4;display:flex;gap:8px}',
	    '.dynamic-activity-move button{flex:1;min-width:0;font-size:13px}',
	    '.dynamic-activity-visible{display:flex!important;align-items:center;gap:6px;min-height:44px!important;font-size:13px}',
	    '.dynamic-activity-visible input{position:static!important;width:20px!important;height:20px!important;opacity:1!important;margin:0!important}',
	    '.dynamic-activity-announcement{font-size:12px!important;min-height:18px;margin-top:7px!important}',
	    '.dynamic-reading-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:12px}',
	    '.dynamic-reading{padding:12px;border:1px solid var(--line);border-radius:10px;background:var(--field);min-width:0}',
	    '.dynamic-reading small,.dynamic-health small{display:block;font-size:12px;color:var(--muted)}',
	    '.dynamic-reading strong{display:block;margin:4px 0;font-size:15px;color:var(--ink);overflow-wrap:anywhere}',
	    '.dynamic-reading .dynamic-example{font-size:19px;line-height:1.2;color:var(--ink);margin:8px 0}',
	    '.dynamic-state{display:block;font-size:12px;color:var(--muted)}',
	    '.dynamic-health{display:flex;justify-content:space-between;align-items:flex-start;gap:14px;padding:10px 0;color:var(--ink);font-size:14px}',
	    '.dynamic-health+.dynamic-health{border-top:1px solid var(--line)}',
	    '.dynamic-health .dynamic-state{text-align:right;max-width:60%}',
	    '.dynamic-health-help{font-size:12px!important;margin-top:4px!important}',
	    '.dynamic-details{padding:13px 16px;border-top:1px solid var(--line)}',
	    '.dynamic-details summary{min-height:44px;display:list-item;align-content:center;color:var(--ink);font-size:14px;cursor:pointer}',
	    '.dynamic-details .component{padding:10px 0!important}',
	    '.dynamic-details p{font-size:12px;line-height:1.5;color:var(--muted);overflow-wrap:anywhere}',
	    '.dynamic-warning p{color:#a84d00}',
	    '@media(prefers-color-scheme:dark){.dynamic-warning p{color:#ffbd77}}',
	    '.component-submit{position:fixed;left:0;right:0;bottom:0;max-width:512px;margin:0 auto;padding:10px 16px;padding-bottom:calc(10px + env(safe-area-inset-bottom));z-index:20;background:var(--page);border-top:1px solid var(--line);box-shadow:0 -6px 18px #00000008}',
	    'body.dynamic-picker-open .component-submit{visibility:hidden}',
	    '.component-input input,.dynamic-app-entry input,select{scroll-margin-bottom:calc(var(--dynamic-save-height,108px) + 16px)}',
	    '.component-submit button{display:block;width:100%;min-width:0;min-height:48px;margin:0;padding:12px 16px;border:0;border-radius:8px;background:#145ca3;color:#fff;font:700 16px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;text-transform:none;letter-spacing:0}',
	    '.component-submit button:disabled{opacity:.65}',
	    '@media(max-height:420px){.component-submit{position:static;max-width:none;margin:16px 0 0;padding:12px 0;box-shadow:none}body{padding-bottom:24px}}',
	    'body.dynamic-actions-flow{padding-bottom:24px}.dynamic-actions-flow .component-submit{position:static;max-width:none;margin:16px 0 0;padding:12px 0;box-shadow:none}',
	    '.component-submit .dynamic-reload-saved{margin-top:8px;border:1px solid var(--line);background:var(--field);color:var(--ink);font-weight:600}',
	    '.dynamic-save-buttons{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:8px}',
	    '.component-submit .dynamic-discard{border:1px solid var(--line);background:var(--field);color:var(--ink);font-weight:600}',
	    '[hidden]{display:none!important}',
	    'a{color:var(--accent)}',
	    '@media(max-width:340px){body{padding-left:12px;padding-right:12px}.section>.component{padding-left:12px;padding-right:12px}.dynamic-reading-grid{gap:6px}.dynamic-reading{padding:9px}.component-submit{padding-left:12px;padding-right:12px}}',
	    '@media(prefers-reduced-motion:reduce){*{transition:none!important}}'
	  ].join('\n');
	  document.head.appendChild(style);
	  var viewport = document.querySelector('meta[name=viewport]');
	  if (viewport) { viewport.setAttribute('content','width=device-width,initial-scale=1'); }
	
	  clay.on(clay.EVENTS.AFTER_BUILD, function() {
	    function item(id) { return clay.getItemById(id); }
	    function field(key) { return clay.getItemByMessageKey(key); }
	    function node(value) { return value && value.$element && value.$element[0]; }
	    function clear(element) { while (element.firstChild) { element.removeChild(element.firstChild); } }
	    function make(tag, text, className) {
	      var element = document.createElement(tag);
	      if (text !== undefined && text !== null) { element.textContent = String(text); }
	      if (className) { element.className = className; }
	      return element;
	    }
	    function transport(id) {
	      var element = node(item(id)), value = {};
	      if (element) {
	        try { value = JSON.parse(element.textContent || '{}'); } catch (ignored) {}
	        element.hidden = true;
	      }
	      return value && typeof value === 'object' ? value : {};
	    }
	    var data = transport('dynamic-settings-data');
	    var words = transport('dynamic-settings-strings');
	    if (typeof data.language === 'string') { document.documentElement.lang = data.language; }
	    var assets = transport('dynamic-preview-assets');
	    function t(key,params) {
	      var text = typeof words[key] === 'string' ? words[key] : key;
	      return text.replace(/\{([a-zA-Z][a-zA-Z0-9_]*)\}/g,function(match,name) { return params && params[name] !== undefined ? String(params[name]) : match; });
	    }
	    function show(value, visible) { var element = node(value); if (element) { element.hidden = !visible; } }
	    var sections=document.querySelectorAll('#main-form > .section');
	    if (sections.length) {
	      var sectionNav=make('nav',null,'dynamic-section-nav');sectionNav.setAttribute('aria-label',t('title'));
	      Array.prototype.forEach.call(sections,function(section,index) {
	        var heading=section.querySelector('.component-heading');if (!heading) { return; }
	        var target=heading.querySelector('h1,h2,h3,h4') || heading;
	        target.id='dynamic-section-heading-'+index;target.tabIndex=-1;target.className+=' dynamic-section-target';
	        var button=make('button',target.textContent.trim());button.type='button';button.setAttribute('aria-controls',target.id);
	        button.addEventListener('click',function() { target.focus();target.scrollIntoView({block:'start'}); });
	        sectionNav.appendChild(button);
	      });
	      sections[0].parentNode.insertBefore(sectionNav,sections[0]);
	    }
	    function choice(id, label, options, value) {
	      var host = node(item(id));
	      if (!host) { return null; }
	      clear(host); host.className += ' dynamic-choice';
	      var wrapper = make('label'), title = make('span', label), select = make('select');
	      select.id = id + '-select';
	      wrapper.setAttribute('for', select.id);
	      options.forEach(function(option) {
	        var child = make('option', option[1]); child.value = option[0]; select.appendChild(child);
	      });
	      select.value = String(value); wrapper.appendChild(title); wrapper.appendChild(select); host.appendChild(wrapper);
	      return select;
	    }
	    function state(value) {
	      var names = {empty:'sourceEmpty',loading:'sourceLoading',ready:'sourceReady',unavailable:'sourceUnavailable',
	        expired:'sourceExpired',denied:'sourceDenied',unsupported:'sourceUnsupported',disabled:'sourceDisabled',playing:'sourcePlaying',
	        idle:'sourceIdle',paused:'sourcePaused',off:'sourceOff',waiting:'sourceWaiting',permission:'sourcePermission'};
	      return t(names[value] || 'sourceWaiting');
	    }
	    function nativeColor(value) {
	      var number = typeof value === 'number' ? value : parseInt(String(value).replace(/^#|^0x/i,''),16);
	      if (!isFinite(number)) { return 0; }
	      return [16,8,0].reduce(function(result,shift) {
	        return result | (Math.max(0,Math.min(3,Math.round(((number >> shift) & 255) / 85))) * 85 << shift);
	      },0);
	    }
	    function color(key) { return nativeColor(field(key).get()); }
	    function css(value) { return '#' + ('000000' + value.toString(16)).slice(-6); }
	    clay.getItemsByType('color').forEach(function(value) {
	      var element = node(value), opener = element && element.querySelector('label');
	      if (!opener) { return; }
	      opener.tabIndex = 0; opener.setAttribute('role','button'); opener.setAttribute('aria-haspopup','true'); opener.setAttribute('aria-expanded','false');
	      opener.addEventListener('keydown',function(event) {
	        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); opener.click(); }
	        if (event.key === 'Escape') { var picker = element.querySelector('.picker-wrap'); if (picker) { picker.classList.remove('show'); } }
	      });
	      Array.prototype.forEach.call(element.querySelectorAll('.color-box.selectable'),function(box) {
	        box.tabIndex = -1; box.setAttribute('role','button');
	        box.setAttribute('aria-label',css(Number(box.getAttribute('data-value'))));
	        box.addEventListener('keydown',function(event) {
	          if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); box.click(); opener.focus(); }
	          if (event.key === 'Escape') { var picker = element.querySelector('.picker-wrap'); if (picker) { picker.classList.remove('show'); } opener.focus(); }
	        });
	      });
	    });
	    var initialSnapshot = '', appEntry;
	    var bridge = window.DynamicSettingsBridge, phonePhase = 'ready', phoneConfirmed = false, reloadSaved, discard, confirmedForm, restoring = false;
	    function updateDirty() {}
	    var activityHost = node(item('dynamic-activity-order'));
	    var activityPreferences = data.activityPreferences || {}, activityOrder = [], activityHidden = [];
	    var activityProviders = Object.create(null), activityList, activityAnnouncement;
	    var activityPluginSwitch=field('SHOW_ACTIVITIES');
	    function providerKey(value) { return typeof value === 'string' &&
	      (value === 'builtin:music' || value === 'builtin:notifications' || /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(value)); }
	    (data.activityProviders || []).forEach(function(provider) {
	      if (!provider || !providerKey(provider.uuid)) { return; }
	      activityProviders[provider.uuid] = {name:String(provider.name || provider.uuid).slice(0,96),available:provider.available !== false};
	    });
	    activityProviders['builtin:notifications'] = {name:t('notificationsSource'),available:true};
	    activityProviders['builtin:music'] = {name:t('musicSource'),available:true};
	    var visibleProviderKeys=['builtin:notifications'].concat(Object.keys(activityProviders).filter(function(id) {
	      return id !== 'builtin:notifications' && id !== 'builtin:music';
	    }),['builtin:music']);
	    var unavailableBudget=Math.max(0,64-visibleProviderKeys.length),unavailableCount=0;
	    (Array.isArray(activityPreferences.order) ? activityPreferences.order : []).concat(visibleProviderKeys).forEach(function(id) {
	      if (!providerKey(id) || activityOrder.indexOf(id) >= 0) { return; }
	      // Reserve room for installed apps and built-ins before remembering absent
	      // apps. A full old preference list must never hide current controls.
	      if (!activityProviders[id] && unavailableCount++ >= unavailableBudget) { return; }
	      activityOrder.push(id);
	    });
	    (Array.isArray(activityPreferences.hidden) ? activityPreferences.hidden : []).forEach(function(id) {
	      if (providerKey(id) && activityHidden.indexOf(id) < 0) { activityHidden.push(id); }
	    });
	    function activityVisibility(id,visible) {
	      activityHidden=activityHidden.filter(function(value) { return value !== id; });
	      if (!visible) { activityHidden.push(id); }
	    }
	    activityVisibility('builtin:music',!!field('SHOW_MUSIC').get());
	    activityVisibility('builtin:notifications',!!field('SHOW_NOTIFICATIONS').get());
	    function activityValue() { return {order:activityOrder.slice(),hidden:activityHidden.slice()}; }
	    // A hidden Clay field carries phone-only ordering through its serializer.
	    // PKJS removes it before numeric AppMessage conversion; no native key exists.
	    var activityPreferenceField = field('__dynamicActivityPreferences');
	    show(activityPreferenceField,false);
	    function syncActivityValue() { activityPreferenceField.set(JSON.stringify(activityValue())); }
	    syncActivityValue();
	    function activityName(id) { return activityProviders[id] ? activityProviders[id].name : t('activityUnavailableApp'); }
	    function moveActivity(id, target, focusAction) {
	      var from = activityOrder.indexOf(id);
	      target = Math.max(0,Math.min(activityOrder.length - 1,target));
	      if (from < 0 || from === target) { return; }
	      activityOrder.splice(from,1); activityOrder.splice(target,0,id); syncActivityValue(); renderActivities(); updateDirty();
	      if (activityAnnouncement) { activityAnnouncement.textContent = t('activityMoved',{name:activityName(id),position:target+1}); }
	      if (focusAction && activityList) {
	        var row = activityList.children[target], button = row && row.querySelector('[data-action="' + focusAction + '"]');
	        if (button && !button.disabled) { button.focus(); }
	        else if (row) { row.querySelector('.dynamic-activity-handle').focus(); }
	      }
	    }
	    function activityAt(target) {
	      while (target && target !== activityList) {
	        if (target.getAttribute && target.getAttribute('data-provider')) { return target.getAttribute('data-provider'); }
	        target = target.parentNode;
	      }
	      return null;
	    }
	    var draggingActivity = null, touchActivityTarget = null;
	    function renderActivities() {
	      if (!activityList) { return; }
	      var focused=document.activeElement,focusedProvider=activityAt(focused);
	      var focusedAction=focused && focused.getAttribute && focused.getAttribute('data-action');
	      clear(activityList);
	      activityOrder.forEach(function(id,index) {
	        var provider = activityProviders[id], row = make('li',null,'dynamic-activity-row');
	        row.setAttribute('data-provider',id); row.setAttribute('data-hidden',activityHidden.indexOf(id) >= 0 ? 'true' : 'false');
	        var disabled=id!=='builtin:music' && id!=='builtin:notifications' && !activityPluginSwitch.get();
	        row.setAttribute('data-disabled',disabled?'true':'false');
	        var handle = make('button','≡','dynamic-activity-handle'); handle.type = 'button'; handle.draggable = true;
	        handle.setAttribute('aria-label',t('activityMove',{name:activityName(id)})); handle.setAttribute('data-action','handle');
	        handle.addEventListener('keydown',function(event) {
	          if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
	            event.preventDefault(); moveActivity(id,index + (event.key === 'ArrowUp' ? -1 : 1),'handle');
	          }
	        });
	        handle.addEventListener('dragstart',function(event) {
	          draggingActivity = id; if (event.dataTransfer) { event.dataTransfer.effectAllowed='move'; event.dataTransfer.setData('text/plain',id); }
	        });
	        handle.addEventListener('dragend',function() { draggingActivity=null; });
	        function moveTouch(x,y) {
	          var target = activityAt(document.elementFromPoint(x,y));
	          if (target && target !== id) { touchActivityTarget=target; }
	          Array.prototype.forEach.call(activityList.children,function(child) {
	            child.style.outline=child.getAttribute('data-provider') === touchActivityTarget ? '2px solid var(--accent)' : '';
	          });
	        }
	        function finishTouch() {
	          var target=touchActivityTarget; touchActivityTarget=null; draggingActivity=null;
	          if (target) { moveActivity(id,activityOrder.indexOf(target),'handle'); }
	          else { renderActivities(); }
	        }
	        if (typeof PointerEvent !== 'undefined') {
	          handle.addEventListener('pointerdown',function(event) {
	            if (event.pointerType === 'mouse') { return; }
	            draggingActivity=id; touchActivityTarget=null; if (handle.setPointerCapture) { handle.setPointerCapture(event.pointerId); }
	          });
	          handle.addEventListener('pointermove',function(event) {
	            if (draggingActivity === id) { event.preventDefault(); moveTouch(event.clientX,event.clientY); }
	          });
	          handle.addEventListener('pointerup',function() { if (draggingActivity === id) { finishTouch(); } });
	          handle.addEventListener('pointercancel',function() { draggingActivity=null; touchActivityTarget=null; renderActivities(); });
	        } else {
	          handle.addEventListener('touchstart',function() { draggingActivity=id; touchActivityTarget=null; },{passive:true});
	          handle.addEventListener('touchmove',function(event) {
	            if (draggingActivity !== id || !event.touches.length) { return; }
	            event.preventDefault(); moveTouch(event.touches[0].clientX,event.touches[0].clientY);
	          },{passive:false});
	          handle.addEventListener('touchend',finishTouch);
	          handle.addEventListener('touchcancel',function() { draggingActivity=null; touchActivityTarget=null; renderActivities(); });
	        }
	        row.addEventListener('dragover',function(event) { if (draggingActivity) { event.preventDefault(); } });
	        row.addEventListener('drop',function(event) { event.preventDefault(); if (draggingActivity) {
	          var moving=draggingActivity; draggingActivity=null; moveActivity(moving,activityOrder.indexOf(id),'handle');
	        } });
	        row.appendChild(handle);
	        var title = make('span',activityName(id),'dynamic-activity-name');
	        if (!provider || !provider.available) { title.appendChild(make('small',t('activityUnavailable'))); }
	        if (disabled) { title.appendChild(make('small',t('activityPluginsOffHelp'))); }
	        row.appendChild(title);
	        var label = make('label',null,'dynamic-activity-visible'), toggle = make('input'); toggle.type='checkbox';
	        toggle.checked=activityHidden.indexOf(id)<0; toggle.disabled=disabled;
	        toggle.setAttribute('data-action','visible'); toggle.setAttribute('aria-label',t('activityShow',{name:activityName(id)}));
	        label.appendChild(toggle); label.appendChild(make('span',t('activityVisible'))); row.appendChild(label);
	        toggle.addEventListener('change',function() {
	          activityVisibility(id,toggle.checked);
	          if (id === 'builtin:music') { field('SHOW_MUSIC').set(toggle.checked); }
	          if (id === 'builtin:notifications') {
	            field('SHOW_NOTIFICATIONS').set(toggle.checked);
	            updateNotifications();
	          }
	          syncActivityValue(); row.setAttribute('data-hidden',toggle.checked?'false':'true'); updateDirty(); renderPreview();
	        });
	        var moves = make('div',null,'dynamic-activity-move');
	        [['up',-1,'activityUp'],['down',1,'activityDown']].forEach(function(action) {
	          var button = make('button',t(action[2])); button.type='button'; button.disabled=index+action[1]<0||index+action[1]>=activityOrder.length;
	          button.setAttribute('data-action',action[0]); button.setAttribute('aria-label',t(action[2]) + ': ' + activityName(id));
	          button.addEventListener('click',function() { moveActivity(id,index+action[1],action[0]); }); moves.appendChild(button);
	        });
	        row.appendChild(moves); activityList.appendChild(row);
	      });
	      if (focusedProvider && focusedAction) {
	        var replacement=activityList.querySelector('[data-provider="'+focusedProvider+'"] [data-action="'+focusedAction+'"]');
	        if (replacement && !replacement.disabled) { replacement.focus(); }
	      }
	    }
	    if (activityHost) {
	      clear(activityHost); activityHost.appendChild(make('strong',t('activityPriority')));
	      activityHost.appendChild(make('p',t('activityPriorityHelp'),'description'));
	      activityList=make('ol',null,'dynamic-activity-list'); activityList.setAttribute('aria-label',t('activityPriority')); activityHost.appendChild(activityList);
	      activityAnnouncement=make('p','','dynamic-activity-announcement'); activityAnnouncement.setAttribute('aria-live','polite'); activityHost.appendChild(activityAnnouncement);
	      renderActivities(); show(field('SHOW_MUSIC'),false);
	    }
	    activityPluginSwitch.on('change',function() { renderActivities(); renderPreview(); updateDirty(); });
	    var themeChanging = false;
	    var bg = field('BACKGROUND_COLOR'), fg = field('TEXT_COLOR'), accent = field('ACCENT_COLOR');
	    var initialTheme = color('BACKGROUND_COLOR') === 0xFFFFFF && color('TEXT_COLOR') === 0 ? 'light' :
	      color('BACKGROUND_COLOR') === 0 && color('TEXT_COLOR') === 0xFFFFFF ? 'dark' : 'custom';
	    var customPalette = {background:bg.get(),foreground:fg.get()};
	    var previousTheme = initialTheme;
	    var paletteInput, paletteStatus;
	    var night = field('NIGHT_PALETTE');
	    var previewPalette;
	    var theme = choice('dynamic-theme',t('theme'),[['light',t('themeLight')],['dark',t('themeDark')],['custom',t('themeCustom')]],initialTheme);
	    function updateColors() {
	      show(bg,theme.value === 'custom'); show(fg,theme.value === 'custom');
	      var contrast = node(item('dynamic-contrast'));
	      function luminance(value) {
	        return [16,8,0].map(function(shift) { var channel = ((value >> shift) & 255) / 255;
	          return channel <= .04045 ? channel / 12.92 : Math.pow((channel + .055) / 1.055,2.4);
	        }).reduce(function(sum,channel,index) { return sum + channel * [.2126,.7152,.0722][index]; },0);
	      }
	      var background = color('BACKGROUND_COLOR'), foreground = color('TEXT_COLOR');
	      function ratio(first,second) { var a=luminance(first),b=luminance(second); return (Math.max(a,b)+.05)/(Math.min(a,b)+.05); }
	      var secondary = [16,8,0].reduce(function(result,shift) {
	        var front=(foreground>>shift)&255,back=(background>>shift)&255;
	        return result | (Math.floor((2*(front/85)+(back/85)+1)/3)*85 << shift);
	      },0);
	      var low = ratio(background,foreground) < 4.5 || night.get() && ratio(color('NIGHT_BACKGROUND_COLOR'),color('NIGHT_TEXT_COLOR')) < 4.5;
	      var adjusted = ratio(background,secondary) < 4.5 || ratio(background,color('ACCENT_COLOR')) < 2 ||
	        night.get() && ratio(color('NIGHT_BACKGROUND_COLOR'),color('NIGHT_ACCENT_COLOR')) < 2;
	      if (contrast) { contrast.className += contrast.className.indexOf('dynamic-warning') < 0 ? ' dynamic-warning' : '';
	        contrast.hidden = !low && !adjusted; clear(contrast); contrast.appendChild(make('p',t(low ? 'contrastHelp' : 'accentContrastHelp'))); }
	      updatePaletteCode(); renderPreview();
	    }
	    if (theme) { theme.addEventListener('change',function() {
	      if (previousTheme === 'custom') { customPalette = {background:bg.get(),foreground:fg.get()}; }
	      themeChanging = true;
	      if (theme.value === 'light') { bg.set(0xFFFFFF); fg.set(0); }
	      if (theme.value === 'dark') { bg.set(0); fg.set(0xFFFFFF); }
	      if (theme.value === 'custom') { bg.set(customPalette.background); fg.set(customPalette.foreground); }
	      previousTheme = theme.value;
	      themeChanging = false; updateColors(); updateDirty();
	    }); }
	    [bg,fg,accent].forEach(function(value) { if (value) { value.on('change',function() {
	      if (!themeChanging && value !== accent) { theme.value = previousTheme = 'custom'; customPalette = {background:bg.get(),foreground:fg.get()}; }
	      updateColors();
	    }); } });
	
	    function paletteCode() {
	      return 'DYN1-' + ['BACKGROUND_COLOR','TEXT_COLOR','ACCENT_COLOR'].map(function(key) { return css(color(key)).slice(1).toUpperCase(); }).join('-');
	    }
	    function updatePaletteCode() {
	      if (paletteInput) { paletteInput.value = paletteCode(); paletteInput.setCustomValidity(''); }
	      if (paletteStatus) { paletteStatus.textContent = ''; }
	    }
	    var paletteHost = node(item('dynamic-palette-code'));
	    if (paletteHost) {
	      clear(paletteHost); paletteHost.className += ' dynamic-palette-code';
	      var paletteDetails=make('details',null,'dynamic-palette-details');
	      paletteDetails.appendChild(make('summary',t('paletteCode')));paletteHost.appendChild(paletteDetails);
	      paletteHost=paletteDetails;
	      var paletteLabel = make('label',t('paletteInput')); paletteLabel.setAttribute('for','dynamic-palette-input'); paletteHost.appendChild(paletteLabel);
	      paletteInput = make('input'); paletteInput.id = 'dynamic-palette-input'; paletteInput.type = 'text'; paletteInput.maxLength = 32;
	      paletteInput.autocomplete = 'off'; paletteInput.spellcheck = false; paletteInput.setAttribute('autocapitalize','characters');
	      paletteInput.setAttribute('aria-label',t('paletteInput')); paletteInput.setAttribute('aria-describedby','dynamic-palette-help dynamic-palette-status');
	      paletteHost.appendChild(paletteInput);
	      var paletteActions = make('div',null,'dynamic-palette-actions');
	      var copyPalette = make('button',t('paletteCopy')), applyPalette = make('button',t('paletteApply'));
	      copyPalette.type = applyPalette.type = 'button'; copyPalette.id = 'dynamic-palette-copy'; applyPalette.id = 'dynamic-palette-apply';
	      paletteActions.appendChild(copyPalette); paletteActions.appendChild(applyPalette); paletteHost.appendChild(paletteActions);
	      var paletteHelp = make('p',t('paletteCodeHelp'),'description'); paletteHelp.id = 'dynamic-palette-help'; paletteHost.appendChild(paletteHelp);
	      paletteStatus = make('p','','description'); paletteStatus.id = 'dynamic-palette-status'; paletteStatus.setAttribute('role','status'); paletteStatus.setAttribute('aria-live','polite'); paletteHost.appendChild(paletteStatus);
	      paletteInput.addEventListener('input',function() { paletteInput.setCustomValidity(''); paletteStatus.textContent = ''; });
	      applyPalette.addEventListener('click',function() {
	        var match = /^DYN1-([0-9A-F]{6})-([0-9A-F]{6})-([0-9A-F]{6})$/i.exec(paletteInput.value.trim());
	        if (!match) { paletteStatus.textContent = t('paletteInvalid'); paletteInput.focus(); return; }
	        themeChanging = true;
	        [bg,fg,accent].forEach(function(value,index) { value.set(nativeColor(parseInt(match[index+1],16))); });
	        theme.value = previousTheme = 'custom'; customPalette = {background:bg.get(),foreground:fg.get()};
	        themeChanging = false; updateColors(); updateDirty(); paletteStatus.textContent = t('paletteApplied');
	      });
	      copyPalette.addEventListener('click',function() {
	        updatePaletteCode(); paletteInput.focus(); paletteInput.select();
	        if (typeof navigator !== 'undefined' && navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
	          navigator.clipboard.writeText(paletteInput.value).then(function() { paletteStatus.textContent = t('paletteCopied'); },function() { paletteStatus.textContent = t('paletteSelectCopy'); });
	        } else {
	          var copied = false; try { copied = document.execCommand('copy'); } catch (ignored) {}
	          paletteStatus.textContent = t(copied ? 'paletteCopied' : 'paletteSelectCopy');
	        }
	      });
	      updatePaletteCode();
	    }
	    function updateNight() {
	      ['NIGHT_BACKGROUND_COLOR','NIGHT_TEXT_COLOR','NIGHT_ACCENT_COLOR'].forEach(function(key) { show(field(key),!!night.get()); });
	      if (previewPalette) {
	        previewPalette.parentNode.hidden = !night.get();
	        if (!night.get()) { previewPalette.value = 'day'; }
	      }
	      updateColors(); updateDirty();
	    }
	    night.on('change',updateNight);
	    ['NIGHT_BACKGROUND_COLOR','NIGHT_TEXT_COLOR','NIGHT_ACCENT_COLOR'].forEach(function(key) { field(key).on('change',updateColors); });
	    updateNight();
	
	    var notification = field('SHOW_NOTIFICATIONS'), preview = field('NOTIFICATION_PREVIEW'), appOnly = field('NOTIFICATION_APP_ONLY'), vibration = field('NOTIFICATION_VIBRATION'), apps = field('NOTIFICATION_APPS');
	    var noticeMode = choice('dynamic-notification-mode',t('notificationDetails'),[
	      ['app',t('notificationAppOnly')],['summary',t('notificationSummary')],['preview',t('notificationPreview')]
	    ],appOnly.get() ? 'app' : preview.get() ? 'preview' : 'summary');
	    var appMode = choice('dynamic-app-mode',t('notificationAppsMode'),[
	      ['all',t('allApps')],['selected',t('selectedApps')]
	    ],String(apps.get() || '').trim() ? 'selected' : 'all');
	    function parsedApps(value) {
	      var seen = Object.create(null); return String(value || '').split(',').map(function(name) { return name.trim(); }).filter(function(name) {
	        if (!name || seen[name.toLowerCase()]) { return false; } seen[name.toLowerCase()] = true; return true;
	      });
	    }
	    var entries = parsedApps(apps.get()), appHost = make('div',null,'component dynamic-app-filter');
	    var appLabel = make('label',t('appEntryLabel')); appLabel.setAttribute('for','dynamic-app-entry'); appHost.appendChild(appLabel);
	    var entryRow = make('div',null,'dynamic-app-entry');
	    appEntry = make('input'); appEntry.id = 'dynamic-app-entry'; appEntry.type = 'text'; appEntry.maxLength = 160;
	    appEntry.autocomplete = 'off'; appEntry.setAttribute('autocapitalize','none'); appEntry.spellcheck = false;
	    var addApp = make('button',t('appAdd')); addApp.type = 'button'; addApp.id = 'dynamic-app-add';
	    entryRow.appendChild(appEntry); entryRow.appendChild(addApp); appHost.appendChild(entryRow);
	    var chips = make('ul',null,'dynamic-app-chips'); chips.setAttribute('aria-label',t('selectedApps')); appHost.appendChild(chips);
	    var appHelp = make('p',t('appEntryHelp'),'description'); appHelp.id='dynamic-app-help';appHost.appendChild(appHelp);
	    appEntry.setAttribute('aria-describedby','dynamic-app-help dynamic-app-error');
	    var appError = make('p','','dynamic-app-error'); appError.id='dynamic-app-error';appError.setAttribute('aria-live','polite');appHost.appendChild(appError);
	    var canonicalInput = apps.$manipulatorTarget && apps.$manipulatorTarget[0];
	    if (canonicalInput) { canonicalInput.required = false; canonicalInput.setCustomValidity(''); }
	    var appNode = node(apps); appNode.parentNode.insertBefore(appHost,appNode);
	    show(notification,false); show(preview,false); show(appOnly,false); show(apps,false);
	    function appValidity(message) {
	      var enabled = notification.get() && appMode.value === 'selected';
	      appEntry.required = enabled && !entries.length;
	      if (enabled && !entries.length && !appEntry.value.trim() && !message) { message = t('appFilterRequired'); }
	      appEntry.setCustomValidity(enabled ? message || '' : '');
	      appError.textContent = enabled ? message || '' : '';
	    }
	    function draftAppError() {
	      var value = appEntry.value.trim();
	      if (value && /[,\x00-\x1f\x7f]/.test(value)) { return t('appInvalid'); }
	      if (value && entries.some(function(name) { return name.toLowerCase() === value.toLowerCase(); })) { return t('appDuplicate'); }
	      if (entries.concat(value ? [value] : []).join(', ').length > 160) { return t('appLimit'); }
	      return '';
	    }
	    function renderApps() {
	      clear(chips);
	      entries.forEach(function(name,index) {
	        var chip = make('li',null,'dynamic-app-chip'), text = make('span',name), remove = make('button','×');
	        remove.type='button'; remove.setAttribute('aria-label',t('appRemove',{app:name}));
	        remove.addEventListener('click',function() {
	          entries.splice(index,1); renderApps();
	          var remaining = chips.querySelectorAll('button');
	          (remaining[Math.min(index,remaining.length-1)] || addApp).focus();
	          updateDirty();
	        });
	        chip.appendChild(text);chip.appendChild(remove);chips.appendChild(chip);
	      });
	      apps.set(appMode.value === 'selected' ? entries.join(', ') : '');
	      appValidity(draftAppError()); updateDirty();
	    }
	    function commitApp(report) {
	      var value = appEntry.value.trim(), error = draftAppError();
	      if (error) { appValidity(error); if (report) { appEntry.reportValidity(); } return false; }
	      if (!value) { appValidity(''); if (report && !entries.length) { appEntry.reportValidity(); } return entries.length > 0; }
	      entries.push(value);appEntry.value='';renderApps();return true;
	    }
	    addApp.addEventListener('click',function() { commitApp(true); });
	    appEntry.addEventListener('keydown',function(event) { if (event.key === 'Enter') { event.preventDefault();commitApp(true); } });
	    appEntry.addEventListener('input',function() { appValidity(draftAppError()); updateDirty(); });
	    function updateNotifications() {
	      var enabled = !!notification.get();
	      activityVisibility('builtin:notifications',enabled);
	      syncActivityValue(); renderActivities();
	      if (enabled) {
	        appOnly.set(noticeMode.value === 'app');
	        if (noticeMode.value !== 'app') { preview.set(noticeMode.value === 'preview'); }
	      }
	      show(vibration,enabled);
	      show(item('dynamic-notification-mode'),enabled);
	      show(item('dynamic-notification-disabled'),!enabled);
	      show(item('dynamic-notification-help'),enabled);
	      var privacy = node(item('dynamic-notification-help'));
	      if (privacy) { clear(privacy); privacy.appendChild(make('p',t('notificationsHelp')));
	        if (noticeMode.value === 'summary') { privacy.appendChild(make('p',t('notificationSummaryHelp'))); }
	        if (noticeMode.value === 'app') { privacy.appendChild(make('p',t('notificationAppOnlyHelp'))); }
	      }
	      show(item('dynamic-app-mode'),enabled); appHost.hidden = !enabled || appMode.value !== 'selected';
	      appValidity(draftAppError()); renderPreview(); updateDirty();
	    }
	    noticeMode.addEventListener('change',updateNotifications);
	    appMode.addEventListener('change',function() { renderApps(); updateNotifications(); });
	    renderApps();
	
	    var readings = node(item('dynamic-readings'));
	    if (readings) {
	      clear(readings); readings.appendChild(make('strong',t('twoReadings')));
	      var grid = make('div',null,'dynamic-reading-grid');
	      [0,1].forEach(function(index) {
	        var slot = (data.slots || [])[index] || {}, card = make('div',null,'dynamic-reading');
	        card.appendChild(make('small',t(index ? 'rightReading' : 'leftReading')));
	        var propertyKeys = {temperature:'readingTemperature',feels_like:'readingFeelsLike',high:'readingHigh',low:'readingLow',condition:'readingCondition',condition_code:'readingCondition',humidity:'readingHumidity',wind_speed:'readingWindSpeed',wind_direction:'readingWindDirection',precipitation:'readingRain',uv_index:'readingUv',battery_level:'readingBattery',title:'readingTitle',artist:'readingArtist',name:'readingName'};
	        var property = slot.category === 'phone' && slot.property === 'battery_level' ? t('phoneSource') : propertyKeys[slot.property] ? t(propertyKeys[slot.property]) : '';
	        var label = slot.label && String(slot.label).toLowerCase() !== String(slot.property || '').toLowerCase() ? slot.label : property || slot.label;
	        card.appendChild(make('strong',label || state(slot.status || 'empty')));
	        if (property && property !== label) { card.appendChild(make('small',property)); }
	        if (slot.value !== undefined && slot.value !== '') { card.appendChild(make('div',slot.value,'dynamic-example')); }
	        if (label) { card.appendChild(make('span',state(slot.status || 'empty'),'dynamic-state')); }
	        var age = typeof slot.observationAgeSec === 'number' && isFinite(slot.observationAgeSec) && slot.observationAgeSec >= 0 ? ['observedAge',slot.observationAgeSec] :
	          typeof slot.receivedAgeSec === 'number' && isFinite(slot.receivedAgeSec) && slot.receivedAgeSec >= 0 ? ['receivedAge',slot.receivedAgeSec] : null;
	        if (age) { card.appendChild(make('small',age[1] < 60 ? t(age[0] === 'observedAge' ? 'justObserved' : 'justReceived') : t(age[0],{age:Math.floor(age[1]/60)}))); }
	        var recovery = slot.status === 'denied' || slot.status === 'permission' ? 'permissionHelp' :
	          slot.status === 'empty' || !slot.status ? 'readingSetupHelp' :
	          ['expired','unavailable','unsupported','disabled'].indexOf(slot.status) >= 0 ? 'sourceNoUpdateHelp' : '';
	        if (recovery) { card.appendChild(make('small',t(recovery))); }
	        grid.appendChild(card);
	      }); readings.appendChild(grid);
	    }
	    var readingHelp=node(item('dynamic-reading-help'));
	    if (readingHelp) { clear(readingHelp); readingHelp.appendChild(make('p',t('complicationsHelp')));
	      readingHelp.appendChild(make('p',t('sharedReadingsHelp'),'description')); }
	    var health = node(item('dynamic-source-status'));
	    if (health) {
	      clear(health);
	      [['music','musicSource'],['notifications','notificationsSource'],['phone','phoneSource'],['activities','activitiesSource']].forEach(function(pair) {
	        var source = data.sources && data.sources[pair[0]] || {}, row = make('div',null,'dynamic-health');
	        row.appendChild(make('span',t(pair[1]))); row.appendChild(make('span',state(pair[0] !== 'music' && source.state === 'idle' ? 'ready' : source.state),'dynamic-state'));
	        health.appendChild(row);
	        var recovery = source.message === 'DISCONNECTED' ? 'connectionHelp' : source.state === 'denied' || source.state === 'permission' ? 'permissionHelp' :
	          source.state === 'disabled' || source.state === 'unavailable' ? 'pluginHelp' : '';
	        if (recovery) { health.appendChild(make('p',t(recovery),'dynamic-health-help')); }
	      });
	    }
	    var saveStatus = node(item('dynamic-save-status'));
	    var submitHost = document.querySelector('.component-submit');
	    function visibleViewport() {
	      var view=window.visualViewport,top=view?view.offsetTop:0;
	      return {top:top,bottom:top+(view?view.height:window.innerHeight),height:view?view.height:window.innerHeight};
	    }
	    var saveFrame=false,lastSaveHeight,lastSaveFlow;
	    function saveSpace() {
	      if(saveFrame)return;
	      saveFrame=true;
	      (window.requestAnimationFrame||function(callback){return window.setTimeout(callback,16);})(function(){
	        saveFrame=false;measureSaveSpace();focusedVisible();
	      });
	    }
	    function measureSaveSpace() {
	      if (!submitHost) { return; }
	      var flow=visibleViewport().height<=420;
	      if(flow!==lastSaveFlow){document.body.classList.toggle('dynamic-actions-flow',flow);lastSaveFlow=flow;}
	      var fixed=window.getComputedStyle(submitHost).position==='fixed';
	      var height=fixed?Math.ceil(submitHost.getBoundingClientRect().height)+'px':'0px';
	      if(height!==lastSaveHeight){document.documentElement.style.setProperty('--dynamic-save-height',height);lastSaveHeight=height;}
	    }
	    function focusedVisible(target) {
	      target=target||document.activeElement;
	      if(!target||['INPUT','SELECT'].indexOf(target.tagName)<0||target.type==='checkbox'||target.type==='hidden')return;
	      var viewport=visibleViewport(),rect=target.getBoundingClientRect();
	      var fixed=submitHost&&window.getComputedStyle(submitHost).position==='fixed'&&!document.body.classList.contains('dynamic-picker-open');
	      var bottom=(fixed?Math.min(viewport.bottom,submitHost.getBoundingClientRect().top):viewport.bottom)-12;
	      if(rect.bottom>bottom)window.scrollBy(0,rect.bottom-bottom);
	      else if(rect.top<viewport.top+8)window.scrollBy(0,rect.top-viewport.top-8);
	    }
	    if (saveStatus && submitHost) {
	      saveStatus.className += ' dynamic-save-state'; saveStatus.setAttribute('role','status'); saveStatus.setAttribute('aria-live','polite');
	      submitHost.insertBefore(saveStatus,submitHost.firstChild);
	    }
	    if (bridge && submitHost) {
	      var saveButton = submitHost.querySelector('button');
	      saveButton.classList.add('dynamic-primary-save');
	      var actions = make('div',null,'dynamic-save-buttons');
	      discard = make('button',t('phoneDiscard'),'dynamic-discard'); discard.type = 'button';
	      discard.addEventListener('click',function() {
	        if (phonePhase === 'saving' || phonePhase === 'uncertain' || !confirmedForm) return;
	        restoring = true;
	        function previous(name) { var value = confirmedForm[name]; return value && typeof value === 'object' ? value.value : value; }
	        noticeMode.value = previous('NOTIFICATION_APP_ONLY') ? 'app' : previous('NOTIFICATION_PREVIEW') ? 'preview' : 'summary';
	        appMode.value = previous('NOTIFICATION_APPS') ? 'selected' : 'all';
	        entries = String(previous('NOTIFICATION_APPS') || '').split(',').map(function(value){return value.trim();}).filter(Boolean);
	        appEntry.value = '';
	        Object.keys(confirmedForm).forEach(function(name) { var value = field(name); if (value) value.set(previous(name)); });
	        var preferences = JSON.parse(previous('__dynamicActivityPreferences') || '{}');
	        activityOrder = (preferences.order || []).slice(); activityHidden = (preferences.hidden || []).slice();
	        syncActivityValue();
	        var background = color('BACKGROUND_COLOR'), foreground = color('TEXT_COLOR');
	        theme.value = previousTheme = background === 0xffffff && foreground === 0 ? 'light' : background === 0 && foreground === 0xffffff ? 'dark' : 'custom';
	        customPalette = {background:bg.get(),foreground:fg.get()};
	        renderApps(); updateNotifications(); updateColors(); renderActivities();
	        phonePhase = 'ready'; restoring = false; updateDirty();
	      });
	      saveButton.parentNode.insertBefore(actions,saveButton); actions.appendChild(discard); actions.appendChild(saveButton);
	      reloadSaved = make('button',t('phoneReload'),'dynamic-reload-saved');
	      reloadSaved.type = 'button'; reloadSaved.hidden = true;
	      reloadSaved.addEventListener('click',function(){bridge.reload();});
	      submitHost.appendChild(reloadSaved);
	    }
	    function signature() {
	      return JSON.stringify(['BACKGROUND_COLOR','TEXT_COLOR','ACCENT_COLOR','CLOCK_FORMAT','ANIMATIONS','SHOW_STATUS','SHOW_ACTIVITIES','SHOW_MUSIC','SHOW_NOTIFICATIONS','NOTIFICATION_PREVIEW','NOTIFICATION_APP_ONLY','NOTIFICATION_VIBRATION','NOTIFICATION_APPS','NIGHT_PALETTE','NIGHT_BACKGROUND_COLOR','NIGHT_TEXT_COLOR','NIGHT_ACCENT_COLOR'].map(function(key) { return field(key).get(); }).concat([notification.get() && appMode.value === 'selected' ? appEntry.value.trim() : '',activityValue()]));
	    }
	    updateDirty = function() {
	      if (!initialSnapshot || restoring) { return; }
	      var dirty = signature() !== initialSnapshot;
	      var saved = data.save && data.save.state || 'none';
	      var key = bridge ? phonePhase === 'saving' ? 'saveSending' : phonePhase === 'uncertain' ? 'phoneSaveUncertain' :
	        phonePhase === 'failed' ? 'phoneSaveFailed' : dirty ? 'saveUnsaved' : phoneConfirmed ? 'phoneSaved' : 'phoneNoChanges' :
	        dirty ? 'saveUnsaved' : saved === 'saved' ? 'saveLastDelivered' : saved === 'pending' || saved === 'failed' ? 'savePhoneWaiting' : 'saveNone';
	      if (saveStatus) { clear(saveStatus); saveStatus.appendChild(make('p',t(key))); }
	      var button = submitHost && submitHost.querySelector(bridge ? '.dynamic-primary-save' : 'button');
	      if (button) { button.disabled = bridge ? phonePhase === 'saving' || !dirty && phonePhase !== 'uncertain' && phonePhase !== 'failed' : !dirty && saved !== 'none'; }
	      if (reloadSaved) { reloadSaved.hidden = phonePhase !== 'uncertain'; reloadSaved.disabled = phonePhase === 'saving'; }
	      if (discard) discard.disabled = !dirty || phonePhase === 'saving' || phonePhase === 'uncertain';
	      saveSpace();
	    };
	    var technical = node(item('complications-status')), context = node(item('context-status'));
	    if (technical && context) {
	      var details = make('details',null,'dynamic-details'); details.appendChild(make('summary',t('technicalDetails')));
	      technical.parentNode.insertBefore(details,technical); details.appendChild(technical); context.hidden=true;
	      [['music','musicSource'],['notifications','notificationsSource'],['phone','phoneSource'],['activities','activitiesSource']].forEach(function(pair) {
	        var source = data.sources && data.sources[pair[0]];
	        if (source && source.message) { details.appendChild(make('p',t(pair[1]) + ': ' + source.message)); }
	      });
	      (data.slots || []).forEach(function(slot,index) {
	        var lines = [t(index ? 'rightReading' : 'leftReading') + ': ' + [slot.category,slot.item,slot.property].filter(Boolean).join('/')];
	        [['receivedAge','receivedAgeSec'],['observedAge','observationAgeSec']].forEach(function(pair) {
	          var age = slot[pair[1]]; if (typeof age === 'number' && isFinite(age) && age >= 0) { lines.push(t(pair[0],{age:Math.floor(age/60)})); }
	        });
	        if (slot.help) { lines.push(slot.help); }
	        details.appendChild(make('p',lines.join(' · ')));
	      });
	    }
	
	    var previewHost = node(item('dynamic-preview')), canvas, previewCaption, timelineCaption, disabledCaption, formatCaption, previewState = 'idle', request = 0, imageCache = {};
	    if (previewHost) {
	      clear(previewHost); previewHost.appendChild(make('h3',t('layoutPreview'),'dynamic-preview-title')); var tabs = make('div',null,'dynamic-preview-tabs'); tabs.setAttribute('role','tablist');
	      tabs.setAttribute('aria-label',t('samplePreview'));
	      [['idle','previewIdle'],['music','previewMusic'],['timer','previewTimer'],['notification-summary','previewBanner'],['notification','previewMessage'],['timeline','previewTimeline']].forEach(function(pair) {
	        var button = make('button',t(pair[1])); button.type = 'button'; button.setAttribute('role','tab');
	        button.setAttribute('aria-selected',pair[0] === previewState ? 'true' : 'false');
	        button.tabIndex = pair[0] === previewState ? 0 : -1; button.setAttribute('aria-controls','dynamic-preview-canvas');
	        button.addEventListener('click',function() { previewState = pair[0];
	          Array.prototype.forEach.call(tabs.children,function(child) { child.setAttribute('aria-selected',child === button ? 'true' : 'false'); child.tabIndex = child === button ? 0 : -1; });
	          renderPreview(); });
	        button.addEventListener('keydown',function(event) {
	          var shift = event.key === 'ArrowRight' || event.key === 'ArrowDown' ? 1 : event.key === 'ArrowLeft' || event.key === 'ArrowUp' ? -1 : 0;
	          var index=Array.prototype.indexOf.call(tabs.children,button),count=tabs.children.length;
	          if(event.key==='Home')index=0;
	          else if(event.key==='End')index=count-1;
	          else if(shift)index=(index+shift+count)%count;
	          else return;
	          event.preventDefault();var next=tabs.children[index];next.click();next.focus();
	        }); tabs.appendChild(button);
	      });
	      previewHost.appendChild(tabs); var stage = make('div',null,'dynamic-preview-stage');
	      var paletteChoice = make('label',null,'dynamic-choice dynamic-preview-palette');
	      paletteChoice.setAttribute('for','dynamic-preview-palette-select');
	      paletteChoice.appendChild(make('span',t('previewPalette')));
	      previewPalette = make('select'); previewPalette.id = 'dynamic-preview-palette-select';
	      [['day','previewDay'],['quiet','previewQuietTime']].forEach(function(pair) {
	        var option = make('option',t(pair[1])); option.value = pair[0]; previewPalette.appendChild(option);
	      });
	      previewPalette.setAttribute('aria-describedby','dynamic-preview-palette-help');
	      paletteChoice.appendChild(previewPalette);
	      var paletteHelp = make('span',t('previewPaletteHelp'),'description'); paletteHelp.id = 'dynamic-preview-palette-help';
	      paletteChoice.appendChild(paletteHelp); paletteChoice.hidden = !night.get();
	      previewHost.appendChild(paletteChoice); previewPalette.addEventListener('change',renderPreview);
	      canvas = make('canvas'); canvas.id = 'dynamic-preview-canvas'; canvas.width = 200; canvas.height = 228; canvas.setAttribute('role','img');
	      stage.appendChild(canvas); previewHost.appendChild(stage);
	      previewHost.appendChild(make('p',t('sampleHelp')));
	      previewHost.appendChild(make('p',t('previewSafeHelp'),'dynamic-preview-note'));
	      disabledCaption = make('p',t('previewDisabled'),'dynamic-preview-note dynamic-example-disabled'); previewHost.appendChild(disabledCaption);
	      formatCaption = make('p',t('previewUnknownFormat'),'dynamic-preview-note'); previewHost.appendChild(formatCaption);
	      previewCaption = make('p',t('previewSettingsNote'),'dynamic-preview-note'); previewHost.appendChild(previewCaption);
	      timelineCaption = make('p',t('previewTimelineHelp'),'dynamic-preview-note'); timelineCaption.hidden = true; previewHost.appendChild(timelineCaption);
	    }
	    var previewPending=false;
	    function renderPreview() {
	      ++request;
	      if(previewPending)return;
	      previewPending=true;
	      (window.requestAnimationFrame||function(callback){return window.setTimeout(callback,16);})(function(){
	        previewPending=false;drawPreview();
	      });
	    }
	    function drawPreview() {
	      if (!canvas) { return; }
	      var format = Number(field('CLOCK_FORMAT').get());
	      if (format !== 12 && format !== 24) { format = Number(assets.systemFormat) === 12 ? 12 : 24; }
	      var quietPreview = night.get() && previewPalette && previewPalette.value === 'quiet';
	      var background = color(quietPreview ? 'NIGHT_BACKGROUND_COLOR' : 'BACKGROUND_COLOR');
	      var foreground = color(quietPreview ? 'NIGHT_TEXT_COLOR' : 'TEXT_COLOR');
	      var highlight = color(quietPreview ? 'NIGHT_ACCENT_COLOR' : 'ACCENT_COLOR');
	      var exactTheme = highlight === 0x55AAFF && background === 0xFFFFFF && foreground === 0 ? 'light' :
	        highlight === 0x55AAFF && background === 0 && foreground === 0xFFFFFF ? 'dark' : '';
	      var sampleState = previewState;
	      var key = sampleState + '-' + format + '-' + (exactTheme || 'light');
	      var frame = (assets.frames || {})[key];
	      var ctx = canvas.getContext('2d'), serial = request;
	      canvas.setAttribute('aria-label',t('samplePreview') + ': ' + t({idle:'previewIdle',music:'previewMusic',timer:'previewTimer','notification-summary':'previewBanner',notification:'previewMessage',timeline:'previewTimeline'}[previewState]) +
	        (night.get() ? ' · ' + t(quietPreview ? 'previewQuietTime' : 'previewDay') : ''));
	      previewCaption.textContent = t(exactTheme ? 'previewSettingsNote' : 'previewCustomHelp');
	      timelineCaption.hidden = previewState !== 'timeline';
	      disabledCaption.hidden = !(previewState === 'music' && !field('SHOW_MUSIC').get() ||
	        previewState === 'timer' && (!field('SHOW_ACTIVITIES').get() || !field('SHOW_MUSIC').get()) ||
	        previewState === 'notification' && (!notification.get() || noticeMode.value !== 'preview') || previewState === 'notification-summary' && (!notification.get() || noticeMode.value === 'app'));
	      formatCaption.hidden = Number(field('CLOCK_FORMAT').get()) !== 0 || Number(assets.systemFormat) === 12 || Number(assets.systemFormat) === 24;
	      ctx.fillStyle = css(background); ctx.fillRect(0,0,200,228);
	      if (!frame) { previewCaption.textContent = t('noExample'); return; }
	      if (typeof frame === 'string') { frame = {src:frame}; }
	      function draw(image) {
	        if (serial !== request) { return; }
	        if (image.naturalWidth !== 200 || image.naturalHeight !== 228) { previewCaption.textContent = t('noExample'); return; }
	        ctx.drawImage(image,0,0,200,228);
	        if (exactTheme) { return; }
	        // Custom colours reuse the actual native geometry. Reverse-mapping a
	        // quantised capture cannot recover every coverage sample: the page
	        // explicitly identifies these colours as approximate. Provider images
	        // and the OS-owned Timeline card retain their captured pixels.
	        var pixels = ctx.getImageData(0,0,200,228), keep = frame.preserve || [],colorMap={};
	        function blend(front, back, amount) {
	          var result = 0;
	          for(var shift=16;shift>=0;shift-=8) {
	            var a = ((front >> shift) & 255) / 85, b = ((back >> shift) & 255) / 85;
	            result |= Math.max(0,Math.min(3,Math.floor((a * amount + b * (16-amount) + 8) / 16))) * 85 << shift;
	          }
	          return result;
	        }
	        for (var y=0;y<228;y++) { for (var x=0;x<200;x++) {
	          var preserve=false;
	          for(var rectangle=0;rectangle<keep.length;rectangle++) {
	            var rect=keep[rectangle];
	            if(x>=rect.x&&x<rect.x+rect.width&&y>=rect.y&&y<rect.y+rect.height){preserve=true;break;}
	          }
	          if (preserve) { continue; }
	          var i=(y*200+x)*4, r=pixels.data[i]/85, g=pixels.data[i+1]/85, b=pixels.data[i+2]/85, mapped;
	          var source=(pixels.data[i]<<16)|(pixels.data[i+1]<<8)|pixels.data[i+2];
	          mapped=colorMap[source];
	          if(mapped===undefined) {
	            if (r === g && g === b) { mapped = blend(foreground,background,Math.round((3-r)*16/3)); }
	            else if (b === 3 && r < g && g <= b) { mapped = blend(highlight,background,Math.round((3-r)*8)); }
	            else if (r === 3 && g === 3 && b < 3) { mapped = blend(0xFFFF00,background,Math.round((3-b)*16/3)); }
	            else mapped=-1;
	            colorMap[source]=mapped;
	          }
	          if(mapped===-1)continue;
	          pixels.data[i]=(mapped>>16)&255; pixels.data[i+1]=(mapped>>8)&255; pixels.data[i+2]=mapped&255;
	        } }
	        ctx.putImageData(pixels,0,0);
	      }
	      if (imageCache[key] && imageCache[key].complete) { draw(imageCache[key]); return; }
	      var image = new Image(); imageCache[key] = image; image.onload = function() { draw(image); }; image.onerror = function() { if (serial === request) { previewCaption.textContent = t('noExample'); } }; image.src = frame.src;
	    }
	    field('CLOCK_FORMAT').on('change',renderPreview);
	    field('SHOW_MUSIC').on('change',renderPreview);
	    updateNotifications(); updateColors();
	    initialSnapshot = signature();
	    confirmedForm = JSON.parse(JSON.stringify(clay.serialize()));
	    if (bridge) bridge.remember(clay.serialize());
	    ['BACKGROUND_COLOR','TEXT_COLOR','ACCENT_COLOR','CLOCK_FORMAT','ANIMATIONS','SHOW_STATUS','SHOW_ACTIVITIES','SHOW_MUSIC','SHOW_NOTIFICATIONS','NOTIFICATION_PREVIEW','NOTIFICATION_APP_ONLY','NOTIFICATION_VIBRATION','NOTIFICATION_APPS','NIGHT_PALETTE','NIGHT_BACKGROUND_COLOR','NIGHT_TEXT_COLOR','NIGHT_ACCENT_COLOR'].forEach(function(key) { field(key).on('input change',updateDirty); });
	    updateDirty();
	    var form = document.getElementById('main-form');
	    if (form) {
	      function resized() {saveSpace();}
	      saveSpace();window.addEventListener('resize',resized);
	      if(window.visualViewport)window.visualViewport.addEventListener('resize',resized);
	      if(typeof ResizeObserver!=='undefined'&&submitHost)new ResizeObserver(saveSpace).observe(submitHost);
	      function saveVisibility() {
	        document.body.classList.toggle('dynamic-picker-open',!!document.querySelector('.picker-wrap.show'));
	        clay.getItemsByType('color').forEach(function(value) { var element = node(value), opener = element && element.querySelector('label');
	          if (!element) { return; }
	          var picker = element.querySelector('.picker-wrap'), open = !!element.querySelector('.picker-wrap.show');
	          if (opener) { opener.setAttribute('aria-expanded',open ? 'true' : 'false'); }
	          if (picker) {
	            if (!open && picker.contains(document.activeElement) && opener) { opener.focus(); }
	            picker.setAttribute('aria-hidden',open ? 'false' : 'true');
	            Array.prototype.forEach.call(picker.querySelectorAll('.color-box.selectable'),function(box) { box.tabIndex = open ? 0 : -1; });
	          }
	        });
	      }
	      saveVisibility();
	      if (typeof MutationObserver !== 'undefined') { new MutationObserver(saveVisibility).observe(form,{subtree:true,attributes:true,attributeFilter:['class']}); }
	      else { document.addEventListener('click',function() { setTimeout(saveVisibility,0); }); }
	      form.addEventListener('focusin',function(event) {
	        if (['INPUT','SELECT'].indexOf(event.target.tagName)<0 || event.target.type === 'checkbox' || event.target.type === 'hidden') { return; }
	        setTimeout(function() {focusedVisible(event.target);},0);
	      });
	      form.addEventListener('submit',function(event) {
	      if (notification.get() && appMode.value === 'selected' && !commitApp(true)) { event.preventDefault(); event.stopImmediatePropagation(); return; }
	      if (!form.checkValidity()) { event.preventDefault(); event.stopImmediatePropagation(); return; }
	      var button = form.querySelector(bridge ? '.dynamic-primary-save' : '.component-submit button');
	      if (bridge) {
	        event.preventDefault(); event.stopImmediatePropagation();
	        if (phonePhase === 'saving' || button && button.disabled) return;
	        var candidate, sentForm = clay.serialize(), sentSignature = signature();
	        try { candidate = bridge.snapshot(sentForm); } catch (ignored) { phonePhase = 'failed'; updateDirty(); return; }
	        phonePhase = 'saving'; updateDirty();
	        bridge.save(candidate,function(result) {
	          if (result && result.ok) { bridge.remember(sentForm,result.settings); confirmedForm = JSON.parse(JSON.stringify(sentForm)); initialSnapshot = sentSignature; phoneConfirmed = true; phonePhase = 'ready'; }
	          else phonePhase = result && result.notSaved ? 'failed' : 'uncertain';
	          updateDirty();
	        });
	      } else if (button) { button.textContent = t('saveSending'); button.disabled = true; }
	    },true); }
	  });
	};


/***/ }),
/* 26 */
/***/ (function(module, exports) {

	'use strict';
	
	// Actual native 0.17.0 samples; generated by scripts/capture-native-previews.py.
	module.exports = {"version":"0.17.0","source":{"capturedFromCandidatePbwSha256":"06a5e3e971b6ee09409009be1feededded6ac77ca571d09a3751419dfc869190","candidateSourcePbwSha256":"f145fa98e321db8f11fc8f050e1bfa0f36b28fafeb6dc9752faf01ceadb737f2","nativePayloadSha256":{"emery/pebble-app.bin":"5ea0f8d9087d119db5584cb4f0822a358435a56f514644d55d26cea641efa1b0","emery/app_resources.pbpack":"2bf4e3cbeaae59e48d65993ece095cc59364cc91528485a588c8fdd254bb8fbb","emery/manifest.json":"6f8607f1b9d3b00f8d32b3c2e390344953ac62905779b354325e57e17b189bd7"},"timelineSample":"Actual native unobstructed geometry; reserved OS panel, no event payload."},"frames":{"idle-24-light":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAANm0lEQVR4nO2d29akqg6FrT3WK+pDykPWumC1m+YQAyThUPO76PG3pRDiJBwE/Xy/3wMAaf432gCwJxAWUAHCAipAWEAFCAuoAGEBFSAsoAKEBVT4Z7QBFXw+n/C/4dTu81N60B8hTogO9tjGT4c+vza1CVlGWJGq/JEG17ddRScoeH5tatOyRlMYujsbckYBVZVYQ1gPXlWdIWen+zctyzSFEZP0P6IOXOf5tanNzGIRS8rpe9y8mVlDWFG/ytOf1Cs9Gf04awjrOI7v9xtpovOWv14OSfWwjLA8kbza7j0zaE3SjVuUNTrv0Uzm9/u1CSfQVjOLRSw+tPKgGG0WE5aXCyGaqTpGsn3/tUYSawir1K96jqfDxvQ4kaYGsiJYSFKeNYR15HQQHXk9wRjZ3Jdru4WfyALgWSZigbWAsIAKEBZQAcICKkBYQAUIC6gAYQEVICygAoQFVICwgAoQFlABwgIqQFhABQgLqABhARUgLKAChAVUgLCAChAWUAHCAipAWEAFCAuoAGEBFSAsoAKEBVSAsIAKEBZQAcICKii+0c859/x9nqdIgj7NMOUoi/DfqQgtT+3XMD7rpQYa7flKc993yb77vtsSbCjbeZ7iRWuj5BCCNkeFOYpXrVqTJIXFKU+Vff0OGiuvBkk1+0oqUyl7xITFLw/TPsE61xkA2hCxv6Fi9GdKUGFGrd1ZqmoJx1nikdwydMnGjCrL9cKVh19FBYTVUBg6QaWut422lG4tM3ftUYudsNpKMso1Btoaa7lS7g9GwmoWQSlB7Uh+KGtrbK2YynvtwupxYtEaE5T68gb3lbZ8B2F1Vk2NNPsN6MTAbPq+Dlf2X96odZ+I9aNuzIN4g2hWK4hba2CDlrCk6sTAG0PY0MMMlq8qLMFIO/bGeAR7Wsa1omS5QdZ8n3BPlW2/hzglQrA1nMRy7XzlH+mI9wr7048ead/3LT5Py6TNOd7+8zylJgJVe+4NCwhYzhUP9Rk7aigVsta5Iq1hrXPSeCOy/KEqEYOHp+/C0qgKaS7820M7peo2i/i3quBE+9uZzmzCmmUFKVMQr22H4Cq5EOK0qmSJ21+lDKlFfIq8Ss8mYjEzeq1qnRWXWAGW7WfILuvgJ5UaX1WjaDNEYOVRVeDOghEOklVVmiDn8kgcsi1vT2pV154BftxDG9bALJ33kGzYSMeAz6hKZGzVtlBRNk70xD/+hQSCCuNGRRG7H5iZPgIKD0qpvDn2hBc2Z9fvZw1heWTGNMzztCdImeitV26wX2Mg1hYCNfrBnfLijgp9Y0wYYfBo/RDd0jThFrGpuK7ruq7myyumG3zszfZ+bG6S4Bg7qgbzjN6rPKlttnOuWVvVG1bv+xbfiWpMf3B1zk1VcD2FeW01eKxlJ/RUPq2CbtCr0jG4ZBL8FHGt/bPMvNtATH4aW7IW13XVBsXfElaDg5bAoFC1na3fEtZRHuxUzWOJWrQMVdr6OWEdwVtrQqpm3qUt6sIsBldltJKwBENFtk1kPgVvy1Hv9ltGUH7QWklYh2i0yL6k6lt4UvksbZizHTQLohXVo2faPqSqbJ0ZSd3dzqcWGo90mt1opi1mQRTf6NdGVCeywSM8+JxPr8gr5TVbBGpuMX1MfXVCNJPXM7f+QktVFa1qz+XEJBPfjFqhmBWZWYq2RRaRVaVERPaNcZdpcE7ioBrD9bTV2RryM9JeNhMRLVZ7PVm+IJyTODQLi3kJXwGW2wrEFwSbWd6cL1NYg0eF/C6FVlfAkNfC7vRUYKXphgn9LrvKRaTy+P74Q3+CbUw3KiS4rosTtCfUn4deJlBrdjaddOL38/m8TtCoeEyqkW7rY9XOvrw28CKboe8cpRyrsiNyrEok6wdCPbTf+u3PpMk5iYONsI7yewTaJk6rSpHNtyHTaMdRZwp8M1LXNfh/DWF9O7aXdO79Opo26qRVf8gz6cgGy2leph7GC2vg3HeokrZ9hf850ZZI3JbK5k8ojh8VDhRW9HCDeVXPkhsRIo9ZDlYqblZTeMrQ80hniLZ6NnymxVcyMiWNGWZZHzVqGR+xjkFBK/skWyQ1VSYJ8O/wNUjT+RDa2F+d3ZSsB5RMDcl2cQzy9VTpYRZhfQ211T+y6/dAG6PyPQZ+r1BkoZ+NtlIfiQhL237i1mr7rWp1iWcuYX3Hfb+qKhF7+19vrZ7fGlT1lf3C6uQ+Kk3ZVxk/xH7xRYLiWWf82XZZT8E4tor3GwTVwOltCN7jqlsr67dmVX3FvwnNMZefmvGmCU5SfF+L3OO21XwifutdW9tzccqrN2vN7ZRXVXaveTXUYKnnmLX0+E1kbernqzARkt0r0vO0+EmTOZPZ83DaZ5HdLNRsf9U7I06hV+LUZt35RD9CRViqhPu9/B+hLwZOTHPIqvYIzNazP/VbmKN4vusJCyzBFM8KwX5AWEAFCAuoAGEBFSAsoAKEBVSAsIAKEBZQAcICKkBYQAUIC6gAYQEVICygAoQFVICwgAoQFlBhpVdFgof/Lwc9/lr5eR6zfBIBK0hXIlpVHKkqZLjCJhKWO47sqv/zLPvvZ8huiCCE5RkorymEdfE2sNy/qi9im82rto5BfhssLKakQn5NXlXv7irpzN5pw4Tl3NH8srPzOObooery+h2v0iVZeRk3i2OE1aMqzy9oKysspjicc6m8LOPWgHmsflUd5Z7+NvSoyp95Jm62fA2udcQSUdXDrnGL2CpdS9SLNWsQrSOWbJXZMmbVqurz+RC/Rs2fO06buGUqLOYY0F0fd1HOakhzb166+SMqoJ2wWIVz7pGUuz7MbtRO0qoNV/7DcfTn4+IPDpgELcOIxShL1AHj9sd2UtbfvPaHSu+QibCfx5ouYlH/7Ul5R8JANdtXGo2EpV3ouZxqRSimV2GFPS3Og6BOrCIWlMUg+0q0Emm/qq6npRzhELFWJVXGVK0hVpAuSWnuip7TsgTCWg86Mk0St2YXlnNUv+E3oftS9K9mzCSsbFVzbvOnzZtiJCzO6LYUnDhBa8cn0cIY106riKV957dQFnNGgP68QOnXMDGDNQ4TRayZ05+K1++ymFlCYNfHei3ueearWuk4P+X9KK2iKx2376Yadt4Zysos28serE15WYi5g+/fX4DyH3UqphP8bbOKxnQFKWvtlHNPb/08b84K0c327QguH/UMWURqusX+PhnaOs/zrND6ZqoSxyWqssnXeh5LVgZbiioNJ22T6Zc7LpdpBPdc8y64X37XnRRHQVuVO1e5KSsxYOZdRFsbq8pD7EdlkXbUbDesjnmN0Xny1x3nLt9dVQTZz3+mv0bY76fAuxtmR2S1gv2sKd42swCd2hoyFz+FsDx4PxZBs7Z++v1YgEmVvPBGP1ANobBJHkJDWECFmVaQgo2AsIAKeM/7JtATpwP4GvJa5vM8/bqiH+FZRpwW/L5vf9D/et93KYWsV0vnm2EnLHql9lROMYOo5xy3vFbUgZ60ExZTVcefxZDbk61pjxReVcJs8kZpC533JbmuizlZOmr/qtVLQbDpNKH5vci1a7OGaGvGiDXLuEaZ5rXttbV0SK0eOd3wjHrS4/bGGNP5cYDsted5loKZc+Zfa7LpymVLZZP1nNA992+58569MBzuvJ5gw8im0P1hoA2j6PzwBHFhth2wd/LIpjDsVPo5wIHGGCPbwZqw8zDLqNA59/l8fiR6yRYzVVXvRgwJ5hoV8qdn9kNpSDgKi6awdtIl23XdiaxDJnkTnxRzRSxP+LUFone/bsd/NrNVPGkz+GywKurLh6lFrcZyD63b7pQvZno8nUog5jIe14VXZRPpLaNscgRZNZRGgtF6ktfz13puzZUSqQyi7CVhRcfDBOXLKJ4ijS9edCTrBf/H90/J0/c/hS5eK2i1yKosrFQWpXOeKurd+/yhUS0NP9L0pyFnDn/8ac8cxHmeT/fWO+KJYaXFbtPSM2PHmUp4nSSLvhmmMYNoNEHqnAtHPaEUiCdfz+yDPz+7+nYtSXl8xaD7y1WDxOu6HpcSF3ofRt8M05qXFo+BKUTHqMoqS5uHk/qEWAP46s/n2mfF8yPE8Iik/YJplagNKqUm/0nHwObh0OKo8mfWY0/vKptFPzPOY706Lgrms00LaVNbUbP+9D58Bkb+D0lPSimUoKqG0ZUmPDN8jL/WqJAD7Rm+S7PhPzsqLJ3caL9UQjRMR7zqY495LA6vzuG4tOQW/2uayHrC8tAxnBl10smF/VT15d1yWlsltzzhyv9XaTpwwEtB0l5RaY3yazrHmtMNfDj7mxv8ma5UFl+7jLfNABVmHBWCDYCwgAoQFlABwgIqWDyEzj4W9YPe9Kf7vv3BcCz9nJa9asvtPXQZSy4K/fP8mp5swLwRi/94f7PV4lmyZZy54BYR67XqtFWmUszbiWwZmUX2a2lUzGIwb8R62Fs6uzKFsK4/pMdfr9K0azxEGTkBe6B/phDWK3RI37LzHpHug6i9xJgp3ppMuICocz+ip2wHa/6RzbwR6xd0w6dNHwN9OEXEivZZRL/+uMLSoHX8PdAeO/orMW/EAikNU52jNIdlM0AFRCygAoQFVICwgAoQFlABwgIqQFhABQgLqABhARUgLKAChAVUgLCAChAWUAHCAipAWEAFCAuoAGEBFSAsoAKEBVT4FxVeksyiRT7yAAAAAElFTkSuQmCC","sha256":"e58c33789c2877a1f30b3ad354e29da386f5584d9e3cc9d865c49725cd875028","preserve":[]},"music-24-light":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAANJElEQVR4nO2da7KsqBKFseNOUQepg/T+oDdN8UgSyATU9cWJE7Ut3iyTFIHa7vs2AEjzz+wCgHcCYQEVICygAoQFVICwgAoQFlABwgIqQFhAhf/NLgBoZNs299nNctuL9s/c5/hPDWCxHomvqvjPFYCwHsx931VWZ6T+MBQ+njXf9g4V1nVdwZV93x+XxTo0uErbtg0S4t3KeZ5+n+37TgQmenff9/M8m4vhl4fIojlujEhpRYg70f8z+dl4QtQtW1u0pFCS/cc0GMW+J2DKghAEJ7pPc1E18ItU/DysFi2pE1rhh4xp01aVsUlmUZWCZbrRssXo+WxWExatFT9kQ4c1aKs2i1gTDU7YIsLy4VwPwuiWsCp0sQ9+km6iqs/aHPOwCZQLqUSuRsnr9J8qxWOGY5ofF77nWUy2SDGBLPpTADGsXuR34X/pdsDsNhHtjhmvPwhrHus4jvq+S+NPUhzHEU87GWOu6+KIJhnXGLPvu41+XVcuTDELl0jyq2LZQNliVd3TLlay9WNTlEyEYxJypQriEuKg08Fg14nWu8Jg+tR1p/9nzpz4AY7j2DxcFMJcBcWoK/dv7sUSgiwc9TWnZuVlsVd2j1wiLnDyW2tLctHjwtMhOeOa1LuBT9HovPP79SczHrlMLbaPcwqIM80VlRYoM3GQgzUU2lvW9oH/uQrmsFJMuXZ4ohPkp2bH5aqsZbHOgFT42tRq4a5uCAYvJeejTbIO7ec1q60ev62NWgXQ4cesylproR9Hr/u+S8m6IZ3xduuJqjILCst1GzFTMHcmCY+KHMYJiykI/yH//nWurXsnW6S2iCONlvWFpcLXptZOm8+f6+A4WPCgfv7BXyWRJBmralWMLVhuvs0WUrzdmqnNlw4/oBYqwop7KzcPRM8FUOVOUTXdEFTHBWO+oq5oLAlq86XDD6iFirD4Wml+oyI1QVqkM7oUtfnS4QfUQt7HIt77CuaS6+8gl9xrmWDq5PhDsIRfp02PDRbLRHaIcGJcSOeQBe4aJ+7NGGrjdJi5tLVbM7X50uEH1GKosCzFd4UunaRb/V/RS7kQ3zr1tEUf/3onaJnO8LWpNaDlvBO9UsR2W9H9ap4s8N+It6Uw/p20yzp5nR++LbUGVOaxOicwmdGb5ds/v7rIWj/ZaXTZ1BTXY7VFrJpYb1tY7NJv08f4d4U57pI/MDE1xQnSzuXkzJmIWnEEFamNjsUzTCSFFTd6527SZLCejYFJ36gzOkjS7qnF/VE7ve7ILdFMLjBMZlFUMG1pOMt1oKoqus4e8eceOQv0ckfB8NfiFUPawPZ/lzjTJvlx21IAjlGH2oCPsdZ6LPAaICygAoQFVICwgAoQFlABwgIqQFhABQgLqIAfENDl33l8421iM6zTv55Oy8z7dZng1cxujFJbFVesL4tfcl9YFhF5xcfH5Q6Uc4UZ1nR1wjpK+yFO0WLnjvzrPOJBG3rbiJT1co1jX+H7m8jpYxPF9/0mqRgKi6qyYaS01XPQ40TKv7niDY6X2U1rXYpn0JnMnTnmaBOu885RVW3I15NcFvG3k+RPFtEoyYGz4oO+M7VPoGAJK6mV69iuI71KWkNb+y/yGUjguzLFfT7OtLcdeuMnlQwTbJOMvbHaTKsoD4XJAjhJXce2nwkv7bp63Xm/5os7VZaGrtrNdZm9YUDkHN/q/2k9ad8Pm2+x2vKXLbU94jbny69GUiL+ybx0SJHskgFG3pwFYfV0Y6cEcl6nf8/FUrv+6MtcGFvm9NSJCSe6ilQt3A3CBGcLmMjfkjpnoDQUdipL4Q5xDeF6yw6UwVl7Yx6q/VK5fHPf5ubk7GX+o+7PDNl19ewHDOYsBE+vWNdiUSn/nsxmpRYcBbiI3Qo6PjkgTsSqef87fVNwHmfdd4X33+YZd0Ka+8rV3/aTaxe3N//mbbwZQHJAn1gGYhg9jkPwiVvgXeF1HfuuMui4+8mkhhgntX3frbnKORMT0RAW/dKG+CoO44Y/e3PaGXyRpisIa+eMaFfa9ewsnR3+nbbi4X8R6dDs0RnP4XxSU5px3WMX0/9227agJO52tTMR1lw5/6Hf3peGwlzifq65EnQUzPeQrugE7NwvZThXdLyD5bqBllF8xQbXWPIQtBJRMHcDW6MlkntBWHldncnPnLgciME++ZVrDjfjtciklzMJlrvvZxZrs2a2oT/8STVa2XnPauu87b+qWHyI84w54Se++Yn7xm08D64ff+ZKqSScNrTmyv2clnsM6syatWym4d2f4PqZ2vnAiWsf6NmsANeqguNgsu7FBtRoMe56rCptya7KehbM20BDVUvBncfia+XLqgpIPkP4F/UGweksvYL0oVT5v680V2b9Ne/PpSivt0rKMuIYo+SrTftgEn/l5oL9Jxd/NXcca51DQWNyL56LEek65prIbx9/CiZOQZt1t3/x12VP+XFKJlJmKVnHlSs+QljFW6etdXI2700k68is8lzZrbu6wfFu6byVJYSV+40kWlJf+Fkloo4cgz2xfZYQVhHapC/rZwgS1JFT5bnNsoTzTjQBcc99RE9JB4tvimYZrXUt1hd0w6dNHxPbcAmL5bea1DPja0jucfAftNecdFjXYoGYhqnOWZrDDwgAFWCxgAoQFlABwgIqQFhABQgLqABhARUgLKAChAVUgLCAChAWUAHCAipAWEAFCAuoAGEBFSAsoAKEBVSAsIAKEBZQAcICKkBYQAUIC6gAYQEVICygAoQFVICwgAoQFlABwgIqQFhABQgLqABhARUgLKAChAVUgLCACgJnkG7b5j7jfEBgKQvL103ME5XkaiRVeNxaMRgKgQoQljC0gf8OdT4W7HwMlJRE9wcEcs5HfD32e5KeUDHB+77tZ/49EMeN0we1aA2F27YFt7J/pdhnSZ3FCRIRG+CkD5g828daqu9jW/tl6obCoMlyhocY6bat8FsYyQBEgjE9Q1hDafszfSW6Fss1N7N7GhIUNA8QhyDThsJ39yJGw/nTDbmHsmR2S3WYX5ilCrYCKzrv6KQXsMQPYfJ50ABadPzfja7F8h+vOOH581tVyWoQPKj6zCrSUqhYLN9bItwmPxjdH0SCYE1W9LEsT7n1iXJ++R7Q8rHiacxOoSTnRWeJ78uKYfJpBxPose5QCB4NhAVUgLCAChAWUAHCAio87JXO4iwyG7ICsFhAhQdYrHdscHhHLfjU7YQOWgQLcwlym4s+wgOGQub65mX5oKrMI4ZC81hJBbyjFkweYLHAExG2WMSGZhOtUAh2LRevG9JxKS6Qp3dO5xIhClAkuSyRriwnU7rwizwlzLRYOeeD45TEYYqLSzk7p4nd2/yyVZEsZ7EYybgDSsvnkUNhUZE9km3OPSZYqfyphctdO6H7yTU0swOK21Y5+1pzu5+rtl/3wDwuJbk7Y3BR+TzSYhXh72uoCjPydAapSZZZCnvGdEORotMNBtO1E3rlnhMs28rVXJZ3DoXxpr+JhfkmLxkKc28tRSQFXTageKKfUsrjmTI5pLRBl6hLbrasDUWLNaADiln0lGHK9mvmJvI2bIJ22iKYxaAnNRoQtlhjRo3i7BcGr+nID4UaXk4xFzrf5jIkHX9t1caZajx/5JpLKiPshJZkkRfAK/DO6YYVeNPjSwMQFlABwgIqwMcCKsBiARUgLKAChAVUgLCAChAWUAHCAipAWECFlyz00+M4DvvhPM+5JXkWBWEV3neRc6u3ISNvhchVoPtXAxbrBwhUCgirABTWxjuFFRie2A65K8lg7vN5nkkb5ocMlEd89Sm++FQYqCp5hR89lmNbsi/ji8JyBBbF//M8z6S98Q1Yzlb5X31WW+8cCvmIjFbHcXx51EvyaWE1C8LFoq3al/niUBi44dCBBh+1WMFjoOxYhmHRPFRYUtOY8SwDvwC5iQxgUdiwajb7TzxlR/DMVdu74sNfLt8vD7KFzRRV7wrrxNT3rjDZZ8WHfMJEJeMmJ0jj6HS+37RtYhZL1UTFxN0TzEI1x63Nms73IzKKkbFYLaoSXd2wPrBYQJGPqMpAWEAJCGsc3zFXBj4WUAIWC6gAYQEVHvlKB/isOZHxVGERb0smtu+afTwFDIVAhadarPj1HIzEUjxVWEySe2Zyr4rF995UZUS/Gq8txvTNQq8dCuO1MfQiFuJb2b03bTuC+NWprbgSMsLaFp7QJO7XYKdNcneNyN4bTka5wPG3/EyrCimL2FC4mXvwyhmaoCOfvuaOX51FKi7pY1m7tY68ZNt0ujT5BZheVKPhvLthca7CVmhcQZ6lKvP6p0LTsWMimc50+NWRqngbr30qtCyiBime4rmb1wsr2MYjmOYU+NXRqHgV7x8KOxvXPVgFp8romQR6bvMpztZrLVZy80xbW6+w94ZfHcGK9yC5rzD6ctwZpC/gZS89X2uxwFwgLKAChAVUwA9hAhVgsYAKEBZQAcICKkBYQAUIC6gAYQEVICygAoQFVICwgAoQFlABwgIq/B8eePtIJ4FQ9AAAAABJRU5ErkJggg==","sha256":"b9d61cd62e1a77c09b5958c7a58d98d76e6103ff25a2a046ee2ec7c8d1fd3566","preserve":[{"x":10,"y":176,"width":40,"height":40}]},"timer-24-light":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAAPL0lEQVR4nO2d65LjIA6Fyda+In7I8JDZH2wzNBchhIRx+nw1NZV2MAg4FljG5PX5fBwA2vznbgPAdwJhARMgLGAChAVMgLCACRAWMAHCAiZAWMCE/95tABDyer3S5xTljgfjn73P9Z8WwGM9klxV9Z8nAGE9mM/nM+V1duoPQ+HjOfNp71ZhhRCKI977xxVxDoKp0uv12iTEj5T3+533mfeeSEz0rvf+/X6LzcjtIYoQn1ujYq0KdSfmfzY/u0yItrbJTmsKpdl/TIcx7HsCpiwIQXBOzxGbakFu0vDztlpIcie0wk9ZI9PWlLNpFjGVQ+R2pxXNWPnsThMWrZU8paDDBNqaLaLWhGASdoiwcjjHizS2Fk6lHvbBr6xFTPWZbGJeNoGxkUb0atQ8Tv9pYh4zHdP9pPQr92K6JtUUsljPAdSwepHfhf/yXYDZbSra3TNe/0FYcazruub7rk0epLiuqw47OedCCBzRNM91znnv4+khhF6aYREpk+ZXQ9vA2GNNXdPprGbr166omQnHJfSsKs4lxEHng8FuEatnhUX4NHVn/mfPneQJrut6ZaRTCHdVmDFn9+/ShxaCLhz1iXOL8orEIz6jl0lK3Pw2+pLe6bXxdErOuKb1bOBPIZy88/v1V2E8eoVGYh/3FFAX2jOVFigzc9CDNRTGSzb2Qf55CuawMsx5dniiM+TnFsflqaJ1iZMBrfSzuc3CXd1QDF5Gkw+ZZBPW92tRWyvzNhmzCqDT71mVddZCP45evfdashbks99vPVFV7kBhpW4jIgX3RpJwq8hhn7CYgshv8j+/J9dxeqdrkuzEnU4rzoW10s/mJkc25+91cJ2suFF//8BfJdGkedbUqphoWC/eFo1Ubzcxs+XS6TfUwkRYdW/14kB0LICyu8VUuKGoTkrGfEQ90VgazJZLp99QCxNh8bUifqKiFSAdsni6FrPl0uk31EJ/jkU891UspdffRSm9xzJF6OT6QdHCv45MjwKP5So/RExiUso0ISuma5xzP4yhts6HWYqs3cTMlkun31CLrcKKDJ8Vpnya0+p/po9KIb5N6pGdvv/xTtEyi+lncxNgNXknemVI7Lbh9EscLMifiMty2P9MOhXdPM5PL8tNgEkcazGAyTxdLN/1+Ooha/10w+i6uRmux5KdOBVYly0sTvnL9LH/WWGPz2g+cGNuhgHSxeXkzEjErDiKisyejsUzTDSFVTf64tukzWQrLwY250aLp4Mm8pla3R+z4fVEb4lmc4Fhs4ihgmlPw1muA1VNsbT3SB575CzQ620Fw1+LN0wZE8f/U+ZMn5SfK8sBJHZtagP+GGetxwJfA4QFTICwgAkQFjABwgImQFjABAgLmABhARPwAwK2/D+O77KX2Bxr96+nI4m8h+CKRzPeOaO2Gq5YP5bc8lxYERV51dvH9TaUS8Zsa7o5YV2j9yHeqmb3tvxb3OLBGvq1ES3vlRonPsLPXyKnt01Uf++3ycRQOFRVTKOlrZWNHm9k/Jsr2eAYnHfSugz3oHOdK3PP1ibcyTtHVbMpv57msoifN0l+ZFGNkhw4Kz7oK9N6BwqWsJpaCdcrXO1V0hba8r/RL0CDfCozfM8nuXbZpjd5Vs00xWuS9WxsttApxkNh04AkqXC9/LsxSwthdTqf1/zwSVVE0FXeheC8YEDkbN+a/xln0vk87H6PJStf1+q4xW1vLn8aTYnkO/PSKVWKaybYeXEOhLXSjYsS6M0682uullr4Ya1wZaLN7dCJKwNdQ6YW7hZpir0FXDXf0tpnYDQULirL4ApJDZF6Kw6UxV57e26qc6tSub1vezG5eJh/q/srQhbCyvuARcxCcfeKcz0WlfPvndmi1IqtAA/xW0XHNwfEG4lq9j+7byrGcc59Vvj5eXkm7ZCWvkr1j/2U2iW9m//hvXizgeaAfqMNxDB6XZfiHbfCs8IQLu9NBp10PbnWEJOk5r2P7qo3mbgRC2HRD22Ir+o0afiLF2eM4Ks03UBYnjOihfbUc9G6OPwnbdXD/yHSofHVHs9lPEmUZ133eoqZf/t6vQpL0uUaIxHRXaX5w7q/Hw2FvczzUnsWLBiWz5BCtQN275cy0lR0/wQrdQMto/pITG6x5KFoJcKwdAFHp6VS+kBYfV29m58553IgBvvmV6k5UsTrkKBXcgmRz9rPLM4WzWzDfPjTarTx5L2rrfcn/ps6iw+xnzEn/Y1Pfuq+SS+eF8evH3dlZAmnDaO7Sj+nlW6DFotmLZsRPPtTXD8zGw+8ce0DHc0qSK2qOA426z5sQIsW467HmtKW7qqsZ8G8DCxUdRTcOBZfK39ZVQXNe4j8oN0geDtHryB9KFPz3690V+78Ne/PZSivb5VUZMc2Rs1Hm/HGpP4qxYLzO5d8NXd91jmbgtb0HjwPT6Tr2GuivH3yEEydgzXnvv7FX5d9y49TMtFyS806nlzxHcIaXjqy1un5vG+iWUdmle+V3bmrGxLfLZ1v5Qhh9X4jiZbUX/hZJaKOHId9Y/scIawhtEs/dp6hSFFHTpXvbZYjJu9EExDX3B/RU3OCxXdFdzmtcz3WX9ANH5k+bmzDIzxW3mpa94xfQ/Mdh/xG+8ygw7keC9QIQp13aQ4/IABMgMcCJkBYwAQIC5gAYQETICxgAoQFTICwgAkQFjABwgImQFjABJVtjFwgX/zqPUO9ZZG/uNDhifQLDjJuaSIV5MIKaacU755X70m+fqmqOkJhXcH5yddTn3jZ1Wxeo/LcRpN7LPXXLetVWb135erP+Vm9g3SJdMp1mPY3/6TrNTzoWgN0fVyXUybvzQW4w/cFZO9FMXNrGnMjK2uUUzLdFiPYt4KUc6Hw3zzJcyBequYYpvt+osoaYsJy4l3wejUp3TKmE8cjliYP6V1wxEEL4th0wlLgZIDMkg0ttk9Yt3fGHnqzGTvOvGN9hsei2TDpdqf2H3MyWrDhIj9l8t4j9/nn+LzbRXb+W+BneSxmYzX39Gl+pYXWALeuBpVZJt1iKi8Jz3msK/z/nzqCV8jFZ/FR9ArrttGVVW+x+u5yionXv4qN/LArJCCY8Fhfuw8rMGBCWL7zGYCaGWExfj4HgAhesQcmnB7HAg9lEMc6PAoH7oUIQ2AoBCZgKAQmQFjABAgLmABhARMgLGAChAVMgLCACRAWMAHCAiZAWMAECAuYAGEBEyAsYAKEBUyAsIAJEBYwAcICJkBYwAQIC5gAYQETICxgAoQFTICwgAkQFjABwgImQFjAhCP2IA3h36ZuXnuHJNPMBTZYmHFCHUs+N/F+v4km8N6/32+LzL33i5mv26BihmkDrnODsPg7pQpah27uPU3Pt8G6js65u+S1W1gCR81vGtPM7WyYMkOwgbH3XreOHLYKSzz8c5rGNHPrCj6ojkz2CWtxUklf04uZq7T7+qyZNmNxp/jN2tokLJWt/XuZq9wHLba71m8X9MxQyX/nfGuTsNYbxXUaXfHXKFbaXcuGnhlaQQRxBacbZEMZipGVutG1co7IKqj7Uyv19aOY/7YBcYewtBqlbhf1H8+ROS31mKRp/vKOnMH8kU4RdNbNTTdziwwTPmPWDNM2tMJaucN2zCOEHA+UO5Vh4iJzTv4WdSwc4dCM3DFPtQkndrpnNDQX1mwl+Y0+TNkc12Rn0dB5CibjebPMqpZzymwFBdiWIetFZrsMM+9ZNWVS9AE5Uzb33ANfWLS1sjvlDXEHW2HJLh1mu9DJCIdPW5U3+pRcanvEQalFr/yZvHgsuHM9FtFtmy1pEkLozXObX0U1JA+XpnQhhOu6XhnDH5KZeoYtyGHH/N1UtnTRxHXDcSpij8W0ij9aEcgCIszTCRvE8wQtHrmClHPB9WShdbEy8xH8ylWuiU2hAQNOHArpr6bSFMRRafasnTADXSmxqTErGAprw9XWc/jNcA5TVTf2FjPSxmFYC+veOWLNu5g4yeCsKFdXlYX+QggnO6Epni2syPAOiLi/I7Ly3hNnGQnrui71B6C38MjJO5/YVXxVFcIibuaZwprV3/mzQC6m95ziosW32cwc+PYU07Ve5F3RDMcOedCWCCqryKFxrEVhCcYp02B0/lyIaQ+nIifHsQ4VlvhKlXmI9XXJuW7ih2F6TuM8N0B657NClcd5/LMEZqzUcZgtbRVHWK6vj/W5xCJ3Tt6JOfVslCWE8Hq9BLGZxdDR7PPEHJX7SqL09cyXMJWt0ZKp2fRNZqfhsgoS5zK98rAWAqsev2zmw1jkWaSfWl3JSa/VstG3zVrbK4h/Ihb6dQpgkOYTs0uTmfkX+D6cTvKTa6lrpzK72ngqMWeEVe/lmvvXvM9imrljr97kpFkh5X/Im0izPPv1L8Wcczh3ZPyhSkBRTd0iNvT4Z89doWK75FnZ3fjEnOn807dGwiL+VMzZkA3iVVwKYpFtk4/qizRTNG/0tIqw7uvEJo+lIoJjl5Qwp8z83OqDKvlvXTexTcKLTSO41V9haHDtV7T6vteAi/XdEG3PefbGaysNPSxO8DxK/eKxbkA7nr1VpJHTmrorVDGJ3/GC/Per6vMFm9uqT7zybuiZqrhuR/ZkiZ//nqhVzetjNqDQ0CuGZ1cvKYYe6kLFu7QTdczX2IjM/PeQm8j/xtud24SVc+L+99rEOtrVzjSuJuAIYYHv48tfpgB3AWEBEyAsYAKEBUyAsIAJEBYwAcICJkBYwAQIC5gAYQETJvbHuuaf876PeGwFboDrsQSqEp8FvgCusGS+Bx7rz8Jd3ZD7nqFcphKDr4TrsXJ5XMH1hrgAVQHn3NR6rOBcvlbRO1csKQu/Bee9g67+LNML/Yr5ePJJvePgbyJZQVp7JtqTcSC2Cv6O7an/GpJ93qNukph+qQrDH3DOLa55txj+kuuCo3o0wl+mKCbykSuYe6x8xKyVR38LdiJ5VhhCOfz1vtKlmIflf17XRXwL9jMtrCKI9fbO/x4Eg82TnHyITN6oVg8c1SFMCKtQTKGnt+cGUS14/+CgrTPgzrFCJZTmNKs4xeKl3N4Yh7HvKLgeS+Z+tq1ugKpOg+ux3v6U9VjD3YUcdHYAX7UeC7Orc3jweqzaLcUjcFcncNxuM0TkvakYYuyDA7uRJ71MUQslHcm/IqJcYBvHeSzwHTzJY4EHAWEBEyAsYAKEBUyAsIAJEBYwAcICJkBYwAQIC5gAYQETICxgwv8As5j9Yp7s6GUAAAAASUVORK5CYII=","sha256":"3d99a251e0bb31d4261fa9b2b079bf9bc6cc69cf2ac419a305e9dc17963f5172","preserve":[]},"notification-summary-24-light":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAALzUlEQVR4nO2d67KjKhBG9dS8oj5kfMicH8xm2FwbpAGTtWpqKjEICJ9N2wJ7f7/fG0Bv/ptdAfhMEBaogLBABYQFKiAsUAFhgQoIC1RAWKDCn9kVgEb2fbefbZTbHDRfU5/DrxpgsR6Jq6rw6wogrAfzfr+rrM5I/TEUPp413/YOFdZ1Xd6R4zgeV8Q6NLhK+74PEuK7ldfr5fbZcRyZxJnePY7j9Xo1V8OtT6aI5nNDutS2C2Enul+jnzdHiLp1azstKpRo/wkNRrHvMwhlkRGE5HSX5qpq4Fap+HnYVbTkntGKPGVIm7aqjE20iKocDNONlqnGnc/basLKa8VN2dBhDdqqLSLURIMTtoiwXCTHvTS6NaxKXeyDX1k3UdVnbY653wTKlVQidUXR4/mvKtUTphOaH5v+zrNY3yqFeLK4nwOEiHpR3oX/8r2BsNu6aHfMeP2FiOJY53nW910cN0hxnmcYdtq27bouiWii527bdhyHOf26rlSaYhE2k+hPxbpB2WJV3dP2rGjrh6YomonEJKRq5Z2bEUc+Hwa7m2i9K/TCp7Y73a8pc+ImOM9zd7CnZMyVV426ev8uvVhDSCJRX3NuRl4Gc+RwSGViE0d/NbYkdXpY+XxKybjW693AV9HovMv79VdhMlKFGkwfpxQQFpqqal6gwswhhWgoNLes6QP3cxXCYaWYc+3wlM9QnpsZl6uK7otxBnqlr82tFunsBm/wUnI+2iRr0X5eM9q647e1UauAfPoxs7LWmugn0etxHL1k3ZDPeLv1RFVtCwrLdlsmUjA3ksSjooRxwhIKwn3If/92ro1717dKbSeONFrGF+6Vvja3dtp8/lQHh8m8B/XXD/JZElGiZ1XNijEVS8XbTCW7t1szteXm0w+4ChVhhb2VigPlYwG5eseoCjd4l2OTCV9RVzRWD2rLzacfcBUqwpJrpfmNSq8AaZGbp/eittx8+gFX0d/Hyrz37VhKqr+9UlKvZbzQyflDxxp+O216bLBYW2CHMk6MTWkdMs9dk5z7Fgy1YT7CUtrarZnacvPpB1zFUGEZiu8KbT5Rt/pf1UulZH616mk7ffzrHa9lbqavza0BLec90ytFTLcV3a/mYIH7Rrwth/HvpG3R0ePy9G25NaASx7oZwBSe3izf+/HVReb69Q2j981NcT5W24lVgfW2icU2/zZ9jH9XmOJd8gcm5qYYIL05nVwYiagVh3chtaczeUZIT2GFjX5zNWk02Z2FgVHf6ObpEKXdUwv7oza8bklN0YxOMIwWUVRw3tJIpuugqipu7T3ixh4lE/RSW8HI5+IVU5rE5n+budAmuee25QCWUZvawJex1nws+BgQFqiAsEAFhAUqICxQAWGBCggLVEBYoAJ/QECXv3H8zVnEtol2/3o6LZH369q8VzPHtim1VXHG+rK4NXeFZegir3D7uNSGcrYyw5quTlhnaT3Eq2u1U1v+3dziQZv8spFe1ss2jnmF7y4iz2+b2H3db5SKobCoKpOml7bubPQ4kfLfXHEGx2s7ttZrKe5BtyXuzDFbm0idd4mqalN+PNFpET8rSX5kEYySEiQzPvJ3pvYOFCJhRbVynft1xmdJa2jr+E3/AnrgujLFdT7WtLdteuNmFU3jLZMMvbHaQqsoD4XRClhJXed+vCJe2nXddefdK1/cqTI0dNWxXdd2NAyIku1b3a/Gk3b9sPkWq638vrU2W9ymfPnViErE3Zk3n7JLcdEEI2/OgrDudONNCaS8TveeC6V2/XCv8M6YOsdDJ5sf6CpSNXHXS+PtLbAF/lavfQZKQ+FNZSncIbYhbG+ZgdLba2/MQ7VbK1tu6tdUTM4clj/q/oqQXded9YBezKLj7hXrWqxczr93ZjNS87YCXMRueR0fHRAnYtR8/Oy+2TGOs+67wvfP4hm7Q5r9yV6/6SfbLnZt/lu28GYA0QF9Yh0yw+h5nh2fuDu8K7yu8zhUBh17P22xIcZK7TgOY65SzsRENISVf2mT+SlMY4c/c3OaCH6XpisI65CMaFfc9bxZOzP8W22Fw/8i0slzBHs8+/GkpjzDaw9dTPfXfd+9mtjb1UQijLmy/sN9e18aClOZu6WmanCjYq6HdAU7YKf+UoZ1Rcc7WLYb8jIKj5jkGlMevFbKVMzewMZodSm9IKy0rl7Rz5JzJWQG++hPtjlsxGuRoJc1CYb3vT+zWFu0sA3d4a9Xo5Wd96S2Xm/zr+osOZn9jCXpJ775CfvGLjz3jp8/5kqpJpI2NObK/jkt+xh0s2jRtJmGd38d58/UxgMnzn3IR7M8bKt2HAej115sQI0Wk87HqtJW31lZz0J4G2ioaimkcSy5Vr5ZVR7RZwj3oN4gOJ2lZ5A+lCr/9yPN1bb+nPfnUpTXp0rKMGIbo+irTfNgEv5kY8Huk4s7mzs8a51NQUNSL56LJ+avMdVEbvu4IZgwB23WXf4ln5c95Y9TCulllqLXuPKFjxBW8dZpa52UzfskotcovOS5slt3doPls6XzqSwhrNTfSMpL6hv+rFLmGiUGe2L7LCGsInmTvqyf0RHvGiWXPLdZlnDeM02Quee+RE9RB0tuimYZrXUt1jfoRk6bPia24RIWy221Xs+MH0N0jYP7oL1m0GFdiwUhDaHOWZrjDwiAClgsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQpdtjHaruzCr9Q71CmT/JsLLZ6YX+DQxpQm6kK7sC67U8qxPe+6K/n4qardaRTWeW1H5fLUJ952IYPnqDy30dotVvflluGsrNRaufCze1bqYL7EfMr7COsf/Zq/ruLBLTZAh8f7sorzHp2AW1wv0LYuSphbtDITuTNH2Sbr22IZxs0gldwo8pUnbg6ZRdWSivVdn9hlDnGm5pm14OFs0nzLqDqOS0xNLpK64TIHNTBj0wpTgW0F2moyoMXGCWt6Z4wh5c3oseYT6zMsVp4BTve2av8JnVGPATf5Ks57Ctfmr2Pzpots/VXga1ksYWNF9/SJ/tSLXgPcfTV08TLzLdZlkXCdxTqvv/+607CEvPksOR2twv265S+2e4uFT5dVVCz/8jbyY1dIyFBhsT52H1ZQoEJYR+IzQEiNsAR/PgfAwBJ7UGH1OBY8lEIca/EoHMwlE4ZgKAQVGApBBYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKvwZX+S+7/bz+/0eXwEYQFlYKR206cM9Cz6YDkMhqoKQssV6v9+hIG5KhBHw46mzWKGekAhEETnvntHKm6uo7+WdYr4iyg+m2sfK+Oz7vkcFBF+IVFjN1sUaJzcH7yt8Hu1PhaG5cn9CN19OhbCEWrHJUg4WfAMVwkIfIKf9lc6+71Ebhv5gk1ss5AJVVFssN6YVNVq47bAJLZZnrvLSIZQFW63FCiVljZZnybpUDp5L2WKhEmigMY4VnZgVjYvicn0n8ZABwE2Y8w4qICxQAWGBCggLVEBYoALCAhUQFqhQeKVTG3UnKAaGCUvsz/O0n1+vl3fcPdKrrL55goTRQ6GrKvPVOwKfgdRiFce4qkHTmpCU9YKnM2EodMkMhZ4lM8ejB8P0aHQ6c54Ki8OfcHy0yRhPV2O0sFyDVFTD6/WK2p7icXQ2nQkWKzV+3cyT4W8p5vhYrl05z7OLJrBSSzEh3GAV0NHGWMcfu7UIvNIBFeYMhbUPfX2zhQFMeyrMHEkdbMsfplBYTLHCS2je9z2RyZH3FAxqT2dR592zT5irx8G6QlBhUYsFTwdhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1T4H7XaoPcvWW5BAAAAAElFTkSuQmCC","sha256":"79e9f3e9026f71aba233c286d0a7093912d075ae7a0ffde097b67c43462e00e2","preserve":[]},"notification-24-light":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAAMQ0lEQVR4nO2d7bKsqg5F9dR9RX3I9iH7/uA0hwUhhEAAdY7atWu1jYAyDTF89P79fjcAevPP7AqAZwJhARMgLGAChAVMgLCACRAWMAHCAiZAWMCE/82uAFCy77v/20e53UH3Mfd3+tECWKxbEqoq/bgCENaN+X6/VVZnpP7QFd6eNUd7hwrruq7oyHEctytiHRSu0r7vg4T41fL5fMI2O46DScy07nEcn89HXY2wPkwR6nNTutS2C2kjhh/Jv7dAiLZ1051GCoVsP6HBKLY9g1AWjCAkp4eoq2pBWKXi38OuQpM7oxV5yhSdtqqMDVlEVQ6O6UbLVaPl7201YfFaCVMqGkyhrdoiUk0onLBFhBUiOR6lsa1hVepiG/zJWkVVm+kc8/gWGFfSiNwVkcf5jybVE6YTmh+fvuVdrG+VUiJZtOcAUkStKG/C//JtQNhsXbQ7pr9+IaI41nme9W1HEwYpzvNMw07btl3XJRENee62bcdxuNOv68qlKRbhMyG/KtYNlC1W1TPtzyLvfmqKyEwkJiFXq+hcRhx8PujsGrEaK4zCp745w485cxImOM9zD/CnMOYqqkZdvf+WXqwhyCJRnzo3Jy+HO3IE5DLxiclvnS3JnZ5Wnk8p6dd6jQ28CqXzLm/XP4XJyBXqcG2cU0BaaK6qvECFmYMcoq7QPbKuDcK/qxB2K8Wca7snPkN5bq5friq6L84Z6JW+NrdapLMbos7LyPnQSdZj/b7mtNXit+moVQCffsysrLUm+kn0ehxHL1kr8hlvt+6oqm1BYflmYyIFcyNJeFWUME5YQkGEL/nfv861c+/6Vkl34kij5XzhXulrc9Oj8/lzDZwmi17UPz/ksyRIyLOqZsW4iuXiba6S3e+bmtpy+fQDrsJEWGlr5eJAfCyAqzdFVbghuhyfTDhEXXGzelBbLp9+wFWYCEuuFfWISq8AaZHG03tRWy6ffsBV9PexmHHfjqXk2jsqJTcsE4VOzh8da/h2dHpUWKwtsUOME+NTeocsctck534FXW2aj7AU3X1TU1sun37AVQwVlqM4VujzId3q/6peKoX51qtHd/r44Z3ozjSmr81NgZXzzrRKEddsRfdLHSwIR8R1OYwfk/ZFk8fl6XW5KTCJYzUGMIWnq+XbHl9dZK5f3zB639wM52PpTqwKrOsmFvv8dfoYP1aY41vyBybmZhggbZxOLoxE1IojupDa0zF5RkhPYaU3vXE1KZmsZWEg6Rs1ng5I9J5a2h614XVPboomOcGQLKKoYN7SSKbrQFVVNO09EsYeJRP0clvByOfiFVO6xO5/n7nQJoXn6nIAnlGb2oCXsdZ8LPAYICxgAoQFTICwgAkQFjABwgImQFjABAgLmIAfELDl3zj+Fixi20S7f90dTeT9urZoaObYNqN7VZyxvixhzUNhObrIK90+LrehnK/MsFtXJ6yztB7i07XauS3/Grd4sIZfNtLLevmb44bww0Xk/LaJ3df9klR0hUVVuTS9tNWy0eNEyr+5EnSO13Zs2msp7kG3ZZ7MMVubSJ13iapqUz4eclrEbyXJTxZJLylBMuODfzKtd6AQCYvUynXu10nPkrbQ1vGX/gX0IHRliut8vGnXbXoTZkWmiZZJpt5YbaFVlLtCsgJeUte5Hx/CS7uuVnc+vPLFnSqHoqmO7bq2Q9EhSrZvDT86Tzr0w+ZbLF35fWvttrjN+fKrQUok3JmXT9mlODLByIezIKyWZmyUQM7rDJ+5VGrXj7bCO+PqTIdOtjjQVaRq4m6UJtpbYEv8rV77DJS6wkZlGTwh/kb41nIdZbTX3piX6rBWvtzct7mYnDssf9X9EyG7rpb1gFHMouPuFetaLC7nvzuzOalFWwEuYreihic7xIk4NR+/3Tc7xnHWHSv8/hbP+B3S/Ff++l07+fvi1+Z/ZQtvBkB26BPrwHSj53l2fOPuMFZ4XedxmHQ6/nnaqC7GS+04Dmeucs7ERCyExQ/aMF+laXz35x5OF8HvcusKwjokPdpFu56NtXPdv9dW2v0vIh2eI9njOY4nqfJMrz11McNv932PauIfVxeJcObK+w/t9r7UFeYyD0vN1aChYqGHdCU7YOd+KcO7ouMdLN8MvIzSIy65xZSH6C4xFfMPsDNaXUovCCuvqw/5t+RcCUxnT37lb4ePeC0S9PImwfFt+5nF2qKF9zDs/nrdtLLzntXW5+v+VZ0lh9nPWJJ+4shP2jZ+4Xl0/PyZK6OaSO6hM1f+57T8a1Bj0aJpM4qxv47zZ2rjgRPnPvDRrAh/Vzv2g+S1F2+gxR2Tzseq0lbfWVn3QvgYWKhqKaRxLLlW3qyqCPIdIjxo1wlOZ+kZpDelyv99pLna1p/zfl+K8nqqpBwjtjEihzbdi0n6lY8Fh28u4Wzu9Kx1NgVNyQ08F0/krzF3i8L7E4Zg0hysWXf5l3xe9pQfpxTSyyyR17jyhY8QVvHR0d2dnM17EuQ1Ci95ruzWnd3gebZ0nsoSwsr9RhIvqTf8rBJzjRKDPfH+LCGsIrxJX9bP6Eh0jZJLnntblnDemVvAPHMv0RPpYMlN0Syjta7FeoNu5Oj0MfEeLmGxwrvW653xMZBrHMIX7TWDDutaLJCiCHXO0hx+QACYAIsFTICwgAkQFjABwgImQFjABAgLmABhARMgLGAChAVMgLCACRAWMAHCAiZAWMAECAuYAGEBEyAsYAKEBUyAsIAJEBYwAcICJkBYwAQIC5gAYQETICxgAoQFTICwgAkQFjABwgImQFjABAgLmABhARMgLGAChAVMgLCACRAWMAHCAiZAWMAECAuYAGEBEyAsYAKEBUyAsIAJEBYwAcICJkBYwIQJv1e477v/G7899lTKwsrpQKeP8CzwYDp0hVAVSClbrO/3mwqiUSLoAR9PncVK9QSJABKR8x4ZLd5ckb5XdIr7CFE+mGofi/HZ930nBQReiFRYauvijVOYQ/QRPA/9W2FqrsKvoJuXUyEsoVZ8spyDBd5AhbCgDyBHP6Sz7ztpw6A/sMktFuQCqqi2WGFMizRacNvBJrRYkbnipYNQFthqLVYqKW+0IkvWpXLgvpQtFlQCFCjjWOTELDIuCpfrndAhAwAawZx3YAKEBUyAsIAJEBYwAcICJkxYV/gwwmjL3JoshVRYVaM6AIiERS7/eqS2iuYH9klI3ZBObiU0ABFlw5M+o+RTy6+4l6zHlxRUVLk7KLEraVbFVZNkAvIB4xcE5Kr0JDRvhd8f/gg/VUY4kSZ3x/nFiQoGL1N75zyiDnPeyUHodAoN+S2TYa495PkUiaRcXKDGJ+h1+c+gbu+GZ7iukT7e0MzjkS6x3/4+Z+RboXzpvRzGqLQwXkxvk2/dfCzrt8IxhvBtbTyFio3X0inIEbwsqkQzpu1zL4N2Zb2Hm40VdhTB21p6MNVvhZKmbXG2chOguyO/HItyH49oZKYYA+QTSEKIZHGS+CRTRK4UeW2Lp4eOQS42W3v5z0BksYpLJIohn2KGimqobRt5op0heecCkxXHkrHf3wNYznl/iQvyeNYSFlT1GNYSlgf94N1Z0ccCD2BRiwXuDoQFTJi5SucZk3AAyUOWf0Gjq9EkrKrmRNu/ipkWCwp7MJp1heSE0o0dxyUTV632eedQ7n3RbBXJxMcbF8C8c0HLI9H/5ElxyYo8sUO4oOVty11uSuuuyUwCLIB5MxXCEu7X0HetH7gp5a4w8qAt1ni1AzmuhnQGae3Cr5wjZcf4EgGDfl0hn1JbH/jjD0EUbqht7CkLYBT1BHZU/Kxc2nLha38xBMUkZhIIjR8ktRp1znvuCPmVItqk3qkB3tVqYAYpMAET/YAJEBYwAcICJkBYwAQIC5gAYQETICxgQmHaTG1AG0Ex4JiwmOI8T//35/OJjodHepXVN08gYXRXGKrKfYyOgGcgtVjFPq6q0/QmJGe9wN2ZvBKa6QojS+aOkwfT9NDodOa8FRa7P2H/6JOhP12N0cIKDVJRDZ/Ph7Q9xePQ2XQmWKxc/9WYJ7q/pZjjY4V25TzPLpqAlVqKCeEGr4CONsY7/rBbi4AhHWDCnK6w9qWvb7ZgANPeCpkjuYO6/MEUCospVhiExnjfHVl0D1J0andnUec9sk8wV7cD6wqBCYtaLHB3ICxgAoQFTICwgAkQFjABwgImQFjABAgLmABhARMgLGAChAVM+D/zcGDp3vN6BQAAAABJRU5ErkJggg==","sha256":"22049425189da53cae9a3ccce88d656bc8394b301b93ee98e1a6935d19c110bb","preserve":[]},"timeline-24-light":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAALyklEQVR4nO2d7ZKkqhJFqRvnFfUh5SHr/qCbZvhMIDdi1V4xMdFdrQjpEhAofb3fb0OINv+7OwPkM6FYBALFIhAoFoFAsQgEikUgUCwCgWIRCP/dnYEOXq9X+Gs4tOv/lH7oPqlsEH04kzd5OvXte1PbkMeIFVnlPhkI/dhe9QQVt+9NbVue0RSG4c5WOXdBq0o8QyyPs2qyyvmk87ctj2kKIzbpf0QduMnte1PbmYfVWFpB/4yTtzPPECvqVznmk2oyc6Av5xliGWPe73fkxOQpb+5OpWZ4jFiOSK+xcy+stDbpxj2UZ3Teo5HM9/u9pjqhW8M8rMaSUzePxqB5mFhOl4o0W3WMdPv+z7qTeIZYpX6V/zy9bUw/r6SJQFeCBynleIZYJudB9Elzg8XoHv1xbbfyjCwhjsfUWORZUCwCgWIRCBSLQKBYBALFIhAoFoFAsQgEikUgUCwCgWIRCBSLQKBYBALFIhAoFoFAsQgEikUg3Pb1L2tt+OtxHMOJhP9HCYb/34K1Fpq9KNlegJF5L+e6rmxOruuaT6REV+IqdJ2zgez1RmBxZJaKdV1XPdySQs4EdI1ew9WAPHtaVuHCsk4sYSzqicxX3cdxQIs5mUPhOdZtwhAxWSSW/AqrRFYrmsdxIK7RlW2TyoFC1KOxQqyuiJfCqt7NVHdLMYf1vOm2gw7dULwXiKXSy0aEUrf+V/d+5bEM4DLDjmOd53mep0o684lE+IGArZLyIIq8FF1PQ8YurPTSQVRXHpWSgvJWqkUQx1KJwz+ZVE/RoXjLrRvBiPkGcb33yw40A0SsmU5AJBb0tDkmCwvNW7bSUj8KYrhBv491nqd6hwPKTG7RJU3TVz+iG3zRTdOozxXeaFU0rG9/ae5orR2uYrsK68+fvLM/HExhiY7jQE0XKtZ+KuKPNYWlLEn2nWkIhIVKDzE8YqwygbEAzaYQUVdJrqdKrKHrGoTlzbY18gYoOorkoDeu5vBoigUqT/0EICpza+15nq+AmQG5UvaE2X5Wh/UPxdoP0RR6SqehMmQszE/UTsnXXwjNqERsIAXJ9ub3enP14volQ2/14QZhsSvURQnPRCiE+5Nn+IiSfbs2rnfghOqHOZRsX8rJSsOUxZqvtAYKP9kUhkl15VClOF2JzId3mV7K41iVPinoznZyni4aodDI0da47uOCkuoPkE7eBPUyGaOBXGXXsJdoXkuSiw0xw42e5IasbnAdC9fvcRUvbmZmJugL5ou2xVVduPSBy2acVTuMqaQ49XfIW1cedKsuqFv8XmE3O+ioBWIlmeNLxcperPsbg5AAVGk9XqyZ+eMxt/b3rxeEW98rlsm5Jfnm4/DhtgVREX6CWJNuRWF1cyDREL+/vUXMS8o33vPmOsszXt1b57qu0I/eGJ3nGY2AA1cpDeEz4/xutlx+e3koZhal5Vkwuu8RroFJd/S1iHxWtWukY2yWQyXlsZhUVkxEG8uDMBCBWnB0k6szEMTKLooPerhRrJlEouCUJrwlhzBfJZZKLCQxHVtEesvqhmwiKt+c1p2c3rfzLlyu3tzm3t6SSqe4XoTdeoSOfcWScO/XheeXgA7n369xVZxO1rXz2WIZwbm5fTFMaZnK8PqIcOmLux1+vV6V1O6JgGKz2qSrjyUfsyn1Y2a+CRO1L6X1ccL0s4dQ3zEbB/n3wLpOZZNPGMdyl2yoQteSqYhsBePHydKxU+FRzvMcGF4yyVLESg3t4xB+Ij+QMrqe1lG/K9TCH1FSkYQlQs/wRBUJ7kDq65W3FmvNxFx48iTbR+cAmreBLwWNoX6ut+68r7mLDr/5PrO7OsvGERBF2Fosg19NMH/mcKd/2egU4kC7i4W+alXEReQwLTgoDqBLd3exjGCN1EzKKukg7M9+00n9KLjr9gFiGYxbummqp7bgKLjv5BmzdrhBUozKfa/umcseYmZfrRyqrLRpoj4iGrH6QUrNAtd3V/mOeSV9yTmr53DyrAvHkybjgLbqvV6sekSEYR0+eZL0m2veJ8tYYuBkj8VhzbMb7nn7VxqR0mRcPR35OetKPM2h6+TOF1MlexFrjtLL671w5gRE5YWAZuFoUInSxOWh+i7FypJ/3QMJ+QSxyIY8Y7iBPA6KRSBQLAKBYhEIFItAoFgEAsUiECgWgUCxCASKRSBQLAKBYhEIFItAoFgEAsUiECgWgUCxCASKRSBQLAKBYhEIFItAoFgEAsUiECgWgUCxCASKRSBQLAKBYhEIFItAoFgEwr7v0qm8NGbPN/Rl+Xk4lglev2Nm377sI+PjEL4SOw1O9Hag45eZPDQZeT6WtSZ6ttdhjG4+628jMsbs/1iv8FyGYnmuoYhFkXHPDYzU8cGphBH3kHNHX411Ft4JYo1x5RoLVibBu18yOEPmmXomI9lpFWqvOpWL8zxPqFtSsdJaKstp9WuvZ1F6YuXfJ67lModxktk+t5rpe5qvCD3PE1fxizrvQqt+Nv6tvUBgH3s/R9qVyW52HMd1/FRj1kjfeJgeomvLbH5wLUNbLGvyVtnz5f7Jd5ETnaHwcbzozsEwUZ6b2x/H0euWvLpKt7x+qWymiECs3KGtPbM/1/caw/VAS29W3pDs+X69Mlfg3ztXc737sQP9JHj3M6QbYhVPZfiHwkbDGpTenLuzXuHdfumv2Zz72x1JuYbLHuZqzbt9W2JNJI3Icnr/vKdnES7Pzd50k8rLqnWZT7Mm1nx+QefcnSH3bm1Xjf0d0drzPN3ny5yTVFfpzx63U7Onlf71/GWypGlrMJ9mdbhBxSxAm+5bRvP7HnlrbTRO6D+8/RYy9D57h3/ArkAhPofW2vf77WI42RvbscZyNvgXddTfGPPX//1tFKLdh7KgRtr8zTeIurighTeMbux0MtlN5wqdEGHxXM0UbnNdl28Hj+Nwt12+irpdKVPoAPmqtDe1mRKFR8wOtnndfTyHj+UYEittfa3VHW73jZqve7LvHkod2sEnT6lyGh7y9u1URGpwdB16sbJZcpeo/+G6rvnWsCZWqe1Px+GtsUeuMzWWr6gXmc/bHi2dCl0dhub9QXYzd6NTSs31N4wx53n6PquZm+SoDjeUzlq2xupKYY5scP0V2ZRyO6wx/05Uq9B0Ip3kcRWb+z80bICaWEUr0vNa6ln3Z8gI6qFsyPxebrjh9Xo1195oke2+mOo7w8Nf/T66FXBz0VWUDVddaeWhMUCaPUja6im2g6ZaA/tKW7jXvW1l9jxFH6qMtZV6mZV51XTS0PfDwhGc4QC2F/oV12D9Tj8fVz6F+bVZUVUsLGd9uBJH6bhhxRmdab8SZH5hVqXUkjBGvfX5zntbrLFlMEe2EvtoulY3hFF1vavPuBHxtFc3HP2N2sAuH8DY5O5HWmXka97la/24gjT8VTI68HlWmd4vU5T6Wx6tNe+PpusW/SOtMtt+S+cDaOr1qUo5RsTqpTSNkP1TOL2QppDd6/b1CxUK62TaStXLWApRGJ9wUjlNAc2mk9CmZ45dZTYehFa1lC3jzgVfIVbz0hmLTqnO+ySyZRQW+V7tHvDshs9W51PZQiy/xDb9vLkXMl/3UymjpMK+MT5biNWkXqVv289QJCqjpMj3hmWLznslBJVr7kt8ynaw5FXRXZXWvjXWN3gjZ8yPG2O4RY0VPZcn+uuXG5ZWWubfG+09Bx32rbFIysBQ513OrRh5J18IaywCgWIRCBSLQKBYBALFIhAoFoFAsQgEikUgUCwCgWIRCBSLQKBYBALFIoQQ8uVwPdbX8VryUHn2sQgEikUgUCwCgWIRCBSLQKBYBALFIhAoFoFAsQgEikUgUCwCgWIRCBSLQKBYBALFIhAoFoFAsQgEikUgUCwCgWIRCBSLQKBYBALFIhAoFoFAsQgEikUgUCwCgWIRCBSLQKBYBALFIhAoFoFAsQgEikUgUCwCgWIRCBSLQKBYBALFIhAoFoFAsQgEikUgUCwCgWIRCBSLQKBYBALFIhAoFoFAsQgEikUgUCwCgWIRCBSLQKBYBALFIhAoFoHwf5qOhOvJfoOOAAAAAElFTkSuQmCC","sha256":"36c91abc9eb76e63e09bba36c4ec76af7b8ab0f7c3f7cf283d3c1a17cd3b6f18","preserve":[{"x":0,"y":171,"width":200,"height":57}]},"idle-12-light":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAAMbElEQVR4nO2d25qsIA6FrfnmFfEh5SFrLtjF2JwMh4SA67/qtjxgWAYIET/f7/cAYDT/mV0AsCcQFmABwgIsQFiABQgLsABhARYgLMAChAVY+O/sAlTw+Xzu/95Du/6neKPbUtgh2NhTNvp5yvvXnk0hywgrUJXb0mD6tqPKJxy4f+3Z1LJGU3g3d9LlzAKqyrGGsDxOVZ0uZ6f6U8syTWGAkv5H0IHr3L/2bJpZzGONMvoelaeZNYQV9Ksc/ad6pOdCL2cNYR3H8f1+A010Vvnj4ZBUD8sIyxHIq63uiU5LSTduUdbovAeRzO/3K+NOoK1mFvNYdMrKg2K4WUxYTi4F0ajqGI3t+681klhDWLl+ld8eDxvj7YVzcjBWBAtJyrGGsI6UDoItjzsIM/bqy7Xdg2dkAXAs47HAWkBYgAUIC7AAYQEWICzAAoQFWICwAAsQFmABwgIsQFiABQgLsABhARYgLMAChAVYgLAACxAWYAHCAixAWIAFCAuwAGEBFiAswAKEBViAsAALEBZgAcICLEBYgAUIC7AAYQEWtK/oZ631fxtjJhbDleReHo8rmDFmYAmTF2pgmtG+KsmZwxgjWYzrumorpr+Ew6VwXdcQa1ShTljXdWmwVIOk7jTLi8nBCD+QX23CIpqV20yjarf2AWBttoT9liJhVZmVz0xja7eqnAOvGyPstLQIq7Y6mYTF4TOIRaX0ATrhsFiO+cJq681wPH98LRFFWwLDt+EWKzA53GCtPc9zbhkcPqDAwXme37et9Sqp4oAe5z/cYw00aVuBuQtwyNb1tMi7Hl91HIdASVg9okYkVezp76gO9FgCvWbP3DKMshiFCR7rPE89vuoYN3mi7VoBwnM70sI6z1NViyDcQr1HWKLuceC9jWoK5edopxRDfkpHzmPp7L22FckY0zyZKG+E67ok+5H/EJPw2GIPeQQbzB2HOoekP3QerhAhj6Wqt+6pdR5JL1XruhS6bQ60J/o1ENTcwFSF3Kmu66r6nqC1trlUE7Md65BxjMPNkWwRClfpbICOJ0NVtapBYaqOnZK114CQxzLGcDcBZZ9hrf18/nycsao8jw+GmCMJxkA+K1rm6hWISXhssYOHviFDcLifqKrd+4FDhmxuoDqqsvqRE9bYEW+zRPxRzTrI0ZyoODa8p0RecnGssS+x3Klq1PhaZA3tkZva1zAGF53SKY/MO99f4IO7VMO1riFzRHquMBkFdu2asKqGV6eqp8INVibGzCbEsZyMlLyJSoGjeD6UxVr3EzNXpwVIlYtpG87znDBR+Nq1G14yr3LM62/tICw4vzJT8kp2EFYV2lQoU+XyTmsHYdEjZL63oU1eAgg7rR2EddBiYHwR2iUQdlqbCOv4RciS0nETHVMGRzl8OSVLJem09hHWkZ8p64zpc9eHmLYgLAmGN4vN1UaceAgeG7UzYP8QmuymQbeU8MJ5lBMOycOpXcqwVlvt9qpkw9TkJShkOR+pbD4NWdF1iEmYgqTH0pPo14mSBesC3tvHqoLSf6L3scb6DJ09rfc2hbXvbJUbkVEDrnsjSAy8jU3eH4aMYyQi2RRWXe7xilU2z8VEkhd9bLyqLt1lrxo29FjxEzzkMXVpAsnqrw1qx+XJ5SA4B1aILEzPFM0iJmEKPR6rHNdJ+puGyGQcTGo4Q0MxYtc15eMGdDYRFrGC4ytWVcwQYn3MujQrmwir7aiqK44iKMDES7OyQ7iBPiyK9xSemQ50LDl5t/mKfhx0vlcoaXEI60WIWXxuQhiEJY1YfSdfqBS4bvLS3EBYxyFi91z8k/u6xyRPCWH9g1tb5XQGVvBeYQUcK7nxVUDhzKzXLV+aF8nYxiN0KzSHv8sF4GgyKGFJpuqfuKTRqsJqO4oypzG2jquqduxCWdXWH4ouYX1pxm0OoEt+k7KtaideeizqhPV9Uklz9ndtu9BTx51tUPOl9azo92e9Vz3klht4HDknD+wZb9sflJ3Nj7Zr6bl0P0qFpRBfwbl15PkqdeKlm4GwAAurxrGAciAswAKEBViAsAALEBZgAcICLEBYgAUIC7AAYQEWICzAAoQFWICwAAsQFmABwgIsQFiABQgLsLDhin5v4P85pcef3FFzSK22/QQySFciSE0OVHVnusIUCcseR/K9AWPy9nsNyVcqCsJyTJSXCmGdtFWirrfqq/CizqO2jkl2mywsoqTuvE1edcvKZXQmb7RpwrL2aF7NzhyHjh4qL2VJJds4d0hSXsLN4hxh9ajK8QZt5V7ZJR4by0vSb02IY/Wr6sj39LehR1VuTxOZWXLJU2mPNURVnl391sAVeINerFiDKO2xxj4yW/qsWlWVv1cYNH/2MDJ+S1RYxDGgPT/2pH7csWFcuR8P3fwZD6CcsEg3Z62XlD0/xG7UTtKqdVfuI03lTzWFi8uLOC1Bj0W4l6ADRu2P7aSsvzz2h3IL0QTIx7HUeazSvz1n3pG7o5Ic8VEQEhb3TesyqhR3MT0K697TokwEdSLlsaAsArl11ZLE/aq6nhazh4PHWpVYGapaQ2SQLkkudlWOaUkCYa1H2TMp8VvahWWt1o9pz6Pcl1Ly+XFNwko+atZuPtu8KULCooxuc86J4rR2nIkejPDTKeWxuGt+C2URIwLl71bkfr2fTCDHQZHH0nx+VTx+EkasJAXk+liPt2tM+lHLbaefeT9yWXS57fLdVMHOO0FZibS95MbaMy9LIXbw/ftdKvftqux5bn/LZNGIZpCScqes9b11Yy5Khuhm7+0MTB91TEkiFX3F/jIEbRljTIXWN1PVcGykKpnrSsexxspgS1HF7qQtmH7a47SJRnDPnPeB78vv+ibFkdFW5Zur1DMzMSHyPkRbG6vKUXgflUTcUZN9YXXOMkbG0POOU4fvrqoCXltVypN/nwJrN2hnSLaCfNQUq80sQKe2psTiVQjLgfWxCjRr69XrYwEiVfLCin6gmoLClExCQ1iABU0ZpGAjICzAAtZ534Ry4HQCX0Ee79kY4/KKXoJPI45v/Lout9H9el1X7gxJq+b2F0NOWOVMbVVGEaPwnFPM8vigTrSknLCIqjp+yZDbk3zSvBQeVUJs8mZpC533JTnPkxgsnfX+qtSiIHjpNKJ5XeTa3Kwp2tLosbSMa5hpzm2vfUqnPNUzww1+1BNvly+MMJ0fB0gea4zJOTNrxb/WJNOVS96VzKV1Uu65f/Od9+SB9+HO4w4yzGwK7Y+JZZhF54cnCgcm2wF5I89sCu+dShcDnFgYYcZ2sBR2HrSMCq21n8/nJd5r7G3Gqup9EWMEukaF9PDMfjANCWch0RTWBl2SXdedSBpEyUp8o9DlsRz3ry0Uevfrdvy1FZvFkjKDz4ZSBX35+9mCVmO5Seu2mnK3GW+PQwmFWIY33f2o5El673Hs6Qok1ZAbCQb5JI/7rzVvTZVSURmFe88JK9h+P+H4exx+xjLu9oItSSu4P76/O4/Xf7qbeC2n1SKrvLBiWeT28Y+oM6//g+OxFPxI068hJw5/3G4+BmGM8d1bZwjvw3LJbmrpidhRQgmPQbLgm2EcEUShAKm19j7quUuhMPPlow9u/2T27VqScrgHo9xfrhoknufpTVo40Nkw+GYYV1x6uA+MKXSMqkolWebpxDYp5AA+2tMf6zOevRDvW0aWf+C5ctQ6lVyT788jUObplMVRZc+kxXzvKnmJfjTGsR4NFzhzbWEhbmof1KQ9nQ39wMj9MdKSoxRaoOoJKz809z3v0/hrjQoplC1DN2nS/SdHhbmdG8s/6kRliIZ41McecSwKj8ahmDRnFvdrfJL1hOUo+3Ci14mDC/up6kur8rK2cmbx7sr9yxQOnLAoSNwryuUoP57nWDPcQIfyfnODPeNM5eG5y1htBrCgcVQINgDCAixAWIAFCAuwIDEJnZwWdYPe+KfrutzG+1ja75Y8asvXe8r3mDPR3T7+13hnAfR6LPr0/mbZ4kmS96j5xiU81uOj0/Yw5XzeTiTvkXjLLpeGpVgE9Hosz97S2RUVwjp/xNsfj+Is13wK90hx2BPto0JYj5Rd+pad94D4PYjaQ4RRsWpywQSFZ+4lekp2sPSPbPR6rDfohk6bPibaUIXHCt6zCH59ucJip3X8HWjPHf3l0OuxQExDqHOW5pA2A1iAxwIsQFiABQgLsABhARYgLMAChAVYgLAACxAWYAHCAixAWIAFCAuwAGEBFiAswAKEBViAsAALEBZgAcICLEBYgIX/ARioB1l2xc8LAAAAAElFTkSuQmCC","sha256":"6ef6de4fcb53194df1a1e27ce1bf110c2ae8145ac7acfab9530ad33f63da32ab","preserve":[]},"music-12-light":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAAMpElEQVR4nO2d65KtKAyFdWpeUR9SH9L5QTdDcwkBEwm6vjp1arcbEWGZxAju9bquBQBp/hndAPBOICygAoQFVICwgAoQFlABwgIqQFhABQgLqPDv6AaATtZ19Z99ltttdH+WPqd/agCLNSWhqtI/LQBhTcx1XU1W50n9wRVOj82nvTMJ6zzPaMu2bUNaYoSOUGld14eEeGlyHEc49sdxdNdTav+2bXS1xL4p3S0cQjqI4Z/Zz0sgRN226VWdNSetI8eUxbZtpRr4qppRWxdDTNdfYXl0W6VUb8lJEQpIaTI22ZqbanBMIayqgKqflxmFRYQ+TcK6r4mOIKyphaNIm83ZHpXRbaFsdRwLwayqLzC/X8kUFusqO7XsdvpPleYJ1sX0O9yWdRHZm44aZhGWccSExY9mOLXdySP8Ob17u4NuxLIa/Kwu54il2rZtc5o7zzNNazl8juM8z33fiUqyX1XbBliIyLPp5utObZxi3huWCsDZPcDIZ4X7vq8BWesSEgmlZF1KliwqwykG+pFSaOsRifRpSTHpQUslXT0cO1pN3IM+xCxWayoyazBarQgdEjFN177vVWMJWhETlrv0w8/EqNNDnv1WNaw+z3NdV+PO0QUMUuVba2tFcnaDi5r9n8PHqbUB+75fQvfIsrQqgC7/zKysMcG72bt6gz5xRlUtA2eQZrUlKLg+e4m7RSmGCSsKwqphWSvdVVkTlrvJkirfWls3I2eQEhlOkdG9rmvf96iqau7emrBmRS+TwU9Hde/Iya2HhjBKWZX6xGBmq3W86PIPjP5Mq3RSW1KyLqmTdWcbSbZjGiBgYlFY/Gc1HLe1/8KpEIihZwyrHu04Duen0ucqpdaGxaqzn1ODFLnI5/ukm9a20eUfONNhwsqO6//NIqHv+EqOj7m7zanJaRfdKd9aWwfDhEVr4k70c7MGg5H7VZZCdiNRvq+2DsbEWKXgxm/vzkJ5PXXHT2afCqTIptFla7MYvDs6TE44NbRPH3PdJ16iqU7Z2p4WFn+8iQnEnMr7djdrrlIvFm7nl++rrQcRh5ole/X70DjbmDsLA7OxEd8C2YzZ50X31jqVBRGel4a2Kg5aE5xHkDYD9qlRf/dIGESnA0x/G5V0hd3/YSzFtGrZGiy7v6l56qU24GPYvSsEUwNhARUgLKAChAVUgLCAChAWUAHCAipAWECFmd7zPiM/uf4leDq+nF/I9fdk3s9zieY6bcui1FfPv8dBirDlobAcIvI6z7iSdEvUmMe6rk1Ye23y3CHa7HRV4M9RRJe2ilN55YmQ9fKd41YMhK8vDPsnu7LygWlnDa6wqipXRkpbxGr30nVpgfrvsgTO8Vy2pfdc/IEIHWevTCdBbW1xg3eOqlpLvp7s1IntZ+uvLBIvyYEzK4S+MrWXvrGEldXKua/nnp8lraGt7S/yB5AgDGWqa4G8ae8YY46woqWUaTTWetAm6q4w2wAvqXNftyMTpZ3n3XA+PHPjQZWjY6i25TyXrcMhVo8VFXCRdBiHjbdYfceXbbV7DW4plrdGViLZNwaKXC3VSm4uMOmjIqw7w3hTAqWoM7zmUqmdv9w7uDCuzfnUyRInuqrwp92mZcLPfj5tWKHUq+dqrvCmshSuEN8RfrSco4x+LuCZm+qwVf64pW9LOTm3mX+r+ydDdp531gNGOQvBFxratVhUzb89e12Xk1SoKvr1Vw8TDby1V+g6NW+/LyQTzOPYfVZ4/S6wSV/a7s/fjZPvF7dcx5e3EO/3vSFHrw2EG933XfCOW+BZ4Xnu26bidPz1tORcTPj2b2euSsHEQDSERT+0Ib5Ky3j35y5Ol8EX6bqKsDaORzvzoefN1jn377WVun8j0qHZktdexvmkrjqzC+miEDP8dl3XqCX+cnWZCGeufPxw397XXGGp8vCopRbcaFgYIZ3Jj3hlF7suQSj6fIDlh4GWUbrFFdeY8hD1EtEwfwE7oyVy9Iqwyro6sp85+3IgnH32K98dPuNlJOm1/f1RheveTzG2HprZh6H7k+q0evBe1NZxuX9Ne/HJWmMiiZC+33uUr0zHxi88j7bvv+ZKqSWcPnTmyr9a0d8G3Tw0a9pMx7M/wfkzrfnAgXMf6GxWhO9VQT+YPfdqB2r0GHc+VpO2ZGdlzQXzMtBQlSm4eSy+Vr6sqojsPUS4Uc8JDsf0DNJJaYp/X2muFvtz3uelKq+3SsrxxGuMso823Y1J+pXPBYd3LuFs7nQvyy8OLT14ru5In2Opi8L+CVMwaQ3a2F3+xZ+X/cAM7m6kzFL2HC2f+BPCql46fb1TsnlvInuOzFMeKzu7sxs875bOWzEhrNLvKNGS+sKvzxPnyDHYA/vHhLCq0CbdbJwhSHSOnFMe2y0mgneiC4hr7iN6ygZYfFM0ymjZtVhf0A2fPn0M7EMTFivsNal7xteQXeMQ3mjbTDrYtVggpSPVOUpz+AEBoAIsFlABwgIqQFhABQgLqABhARUgLKAChAVUgLCAChAWUAHCAipAWEAFCAuoAGEBFSAsoAKEBVSAsIAKEBZQAcICKkBYQAUIC6gAYQEVICygAoQFVICwgAoQFlABwgIqQFhABQgLqABhARUgLKAChAVUgLCAChAWUEHgHaTruvrPeD8gcNSFFeomZUYl+TOSajwurRS4QqAChCUMbeC/Q1uMBTufAiVl0f0BgVLwkW5P455sJFSt8Lou95l/DaT7pvWDVrRc4bqu0aUcbqmOWVZnaYXEjh1w6gdM5o6xTI19amu/TJsrjLqsZHgIT7euld/CyBYgKky548I6Wnv/oK9E12L57mYOT0eFguYB4hBkmCt89yjCG45PN5RuyrKHMzVgYWNMNcwCFoN3DNILMPFDmHwmcqDVwP/d6Fqs8PaKU56f32qqVoPoRjVkVJNMoWKxwmiJCJvCYvR4EBUCm1iMsRyzXPpEO798DWjFWGka86ZQsnnRUeL7smKYfDrABHrYdYVgaiAsoAKEBVSAsIAKEBZQYbJHOsYxkg2xACwWUGECi/WOBQ7vOAs+bSuhox7BxFyC0uKijzCBK2TObzbLB1W1TOEKl2klFfGOs2AygcUCMyJssYgFzUsyQyFatVzdvpCBS3WCPL1yulQJ0YAq2WmJ9MlyDko33shdwkiLVQo+OEFJWqY6uZSzcppYvc1vWxPZdlabkd33gdbymdIVVhV5R7LdR0+JZip/auLyrZXQ9yl1NHMAqstWOetaS6ufm5Zf34H5upTs6oyHm8pnSotVhb+uoanMk29nkEqyjFLYHOmGKtWgGzzMrZXQlkdOsG2WT9Ms73SF6aK/gY35Ji9xhaWnliKSgi47UHyjn1LNzzMkOaS0QJc4l1K2rA9Fi/XAAFQPcacNQ5ZfMxeR9+EqdGmLKItBJzU6ELZYz3iNavYLzms48q5QI8qpHoU+bncbsoG/tmrTg2rcf5S6S+pAWAktiZEHwBZ4Z7rBAm+6fekAwgIqQFhABcRYQAVYLKAChAVUgLCAChAWUAHCAipAWEAFCAuo8JKJfnrs++4+HMcxtiVzURFW5XkXmVu9FnLntbJzExh+a8Bi/QEClQLCqgCF9fFOYUWGJ7VDfku2mP98HEfWhoUlI+URX32KL94VRqrKbuHvnsqxr9qX8UVheSKLEv55HEfW3oQGrGSrwq8+q613ukI+It5q3/cve70snxZWtyD8XrRV+zJfdIVRGA4daPBRixXdBsr6MrjFZVJhSaUx0ywDvwGlRAZwKCxYXVb3T7xmT3TP1Tq64u6vdNwvO9nKYoqmZ4VtYrr3rDA7ZtWbfMJEZffNJkjT3enjftO2iVksVROVkg5PlIXq3rf10PRxPyKjFBmL1aMq0dkN9oHFAop8RFULhAWUgLCe4zvmakGMBZSAxQIqQFhAhSkf6YAQm4mMWYVFPC0Z2L82x3gIcIVAhVktVvp4DkbCFLMKi0l2zUzpUbH42pumA9GPxlubMXyx0GtdYTo3hp7EQnwru/amb0UQ/3RaT1wJGWGthhOaxPUarbTJrq4RWXvDOVCpcPot/6BNjZRFzBWuy/XwzBmaaCBnn3PHPx0jJy4ZYzm7ZUdesn06XJr8Bgxv6qIRvHu3OFZhFjpXkLlUtbz+rnC5sWIiW89w+KcjdeJ9vPau0GFEDVLMErkvrxdWtIxHsM4h8E9H48SbeL8rvNm5/sYqequMnkmgc5uzBFuvtVjZxTN9fW1h7Q3/dARP/A6S6wqTL597B+kLeNlDz9daLDAWCAuoAGEBFfBDmEAFWCygAoQFVICwgAoQFlABwgIqQFhABQgLqABhARUgLKAChAVUgLCACv8BFuB1rsBSK3EAAAAASUVORK5CYII=","sha256":"b6816e926dc9c69562a077257e49bf3f6b98c57a24b6c34fbdae036a8d74b4ed","preserve":[{"x":10,"y":176,"width":40,"height":40}]},"timer-12-light":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAAObElEQVR4nO2d7ZKsIA6G7a29RbxIuUj3B2dYho8QYgLY8z516lSPjRjja4gI9Oe+7wMAbf6z2gDwnUBYwAQIC5gAYQETICxgAoQFTICwgAkQFjDhv6sNAEI+n0/8HHu5w8bwZ+tz+acFiFivJFVV+ecOQFgv5r7voagzU39oCl/Pnm973yQs7322xTm3xJJNEKRKn89nkhBvS67rSq/9dV3ielr2O+foaol9S8QWLqG8iOmf1c9HIkRb2+yqroaT0SvHlIVzrlUDX1Vv1NbNENP9W1gRW6uM6m01UoQCSoaCTbXmoRoCrxBWV0Ddz8cbhUWkPkPCeq4JQRI2ZOEqSrM527MythbqVseJEMyqZIn580peEbHudqNW3U7/aWKeYl3MdodrmYgs3ghqeIuwNkdNWPxshlPbk36EX6f3bHcgRq1Xg9+ryzliqzbnXNCc977s1grEPg7v/XmeRCXVr7q2ARYq8hx6+HpSG6dYbA1bBdDYTWDlu8LzPD8J1eiSkgmlFV1akSwrwykG5GgpdPSIRPdpSzHlQVslQz2cONrtuAcy1CLWaFdkNWCMRhE6JWKGrvM8u8ESjKImrHDrp5+Jq05f8uq3pmm19/7z+WzeOIaEQav8aG2jaI5uCFlz/HP5dRo14DzPW+kZWZdRBdDl54zKWpO8b/tUv2Gb+EZVHQtHkFa1pSg4WbzE06IWy4SVJWHdtGwUcVW7CSs8ZGmVH61NzMoRpEQPp8rVve/7PM+sqm7f/W7Ceit2PRn87ijxjpy+9TQQZl1WLZ9s2LM1er3o8hOu/ptm6ZSxpBVdykY2nG0mWcEwQMBkR2Hx39Vwmq3zB06FQA27YNht0a7rCu1U+V6lZW1arDv6uQxIWRM53ydiRm2jy08402XCql7X/5tFQj/xtRo+5u57Dk0uXfSk/GhtApYJi9bEk+znYQ0bZu53WwrVjUR5WW0C1uRYreQmbhf3QkU9ifOnbd8KlOh2o+vWtmPyHhCEnHRoqEwf73pOvFW7OnVrmy0s/vUmBhBzKpftvm24KluxdDu/vKw2CSoNapXq3R9T46oxTyYGVnMjfgTaM2d/L7aP1qUsiPS8dWm74qA1wXkFuWfC/mrM1x5Jk+jyAtPfZiVD4fB/mksxo1q1hp2bv1cza1Eb8MfY96kQvBoIC5gAYQETICxgAoQFTICwgAkQFjABwgImvGmd9zfyr6//SN6OH/4v9PVLet69P7KxTu44jHw1fx0HLVLLU2EFVOTlfV5JuSUzZprrxoR19gbPXapml7MC/x1FdWqrOp0lT5SiV3ROmDGQLl+Y+qc6s3LCsLOBprCrqlBGS1vEbPfWfbkD/d9lSRpHf7hDei7xQISOq3dmkKC1trjJO0dVoyW/nurQCfdv648silaSA2dUCH1nWk99YwmrqhV/fvxZHyVtoS33G/0DaJCmMt25QDG0C64xR1jZVMoyGxs96BD9prBqQJSUPz/uqmRp3j9N59Mz3zypCggulTu8P5ygQeweKysQMuk0D1sfsWTH17U6LIPbyuV3oyqR6oqBKndLt5KHE0xkdIT15DI+lEAr60zvuVJq/odnB1cm2FzvOjnyjq4u/GG3ZZn0cxxPm1aotfRcryl8qCyDOyQ6Il6t0FBmPxcw56E6tSoet/Vtq08ubOY/6v7qIfP+yXzArM9CcUHDfSMWVfOPZ+/7DpJKVUUvfzWZ7MLvtoRuULP7WZBMsR9n33eF988Em3LR9nj+4TpFv4TpOrH8Dvm+bIUcOxuIZvQ8T8UnboV3hd6fzpk0OvF+OmpNTLr6dwhXrWRiIRbCol/aEF+VZWLzF27O0IOv4rqOsBynRfP11POhdaH5j9oqm/9NpEPjimUv8/4kUZ3ViXRZipl++/l8Mkvi7Rp6IkK4ivnD83jfawpbladHbVnwwLA0Q/LFj3hVJ7seSSo6P8GKl4GWUbklFLcY8pB5iTAs3sAhaKkcvSOstq6u6mfOvhyIxr76VXRH7PHapNPL/f5RhfvZTzGOHprpw7T503JaP3lvauu6w7+hvfhUozHRiVCu772qrSyvTZx4nm0/f8KVkSUcH4ZwFZdWjI9BDw/NGjYjePenOH5mtD9w4dgHujcrI3pVsR2snnvXgRYe447HGtKW7qisd8G8DSxUtRXcfiy+Vv6yqjKqzxDpRrtGcDlbjyB9KUP571eGq2P/Me/vpSuvb5VUYMYyRtVXm+HBpPwq9gWnTy7paO5yr50XDm29eO7uSJ9jy0Wpf9IumLIGa/ad/sUflz1hBLcYrbBUPcedT3yGsLq3jsw7rZj3TVTPkXnKa2W37+iGyHdL51vZQlit31GiJfUXfn2eOEdOwF7ony2E1YUO6dvmGYpk58g55bVu2SJ5J1xA3HN/RE/VBIsfilYFrX0j1l/QDR+ZPhb6cIuIlXpN65nxa6jOcUgftPfsdNg3YoESQVfnKs3hBwSACYhYwAQIC5gAYQETICxgAoQFTICwgAkQFjABwgImQFjABAgLmKCyjNHhyYlfrXeoSwb5iw/a3ZGe4CBjiYtUkAvLx5VS3PG+8x7k64eqqiMU1ukPNzg99Y23XcnkMSrvdZo8YqlPtyxHZbXmypWf071aG+kj0iWfw7S/+id9Xt2NR62BLrfrskvyXh2A250vIJsXxaytasxCnoxRjsV0PUYwbwQp50bhzzxJayAmVXMM052fqDKGmLCcmAtejialPWOaOG4xNLlL64YjNloQ2qYdhgJHA2SWTPDYPGEtvxhzaGUzduz5xPqOiEUzIek+dr1+zGQ0Y8JNvkvy3iKN+fvEvOUi238W+F4Ri+ms6po+1a+00GrgnqtBJcukPaYySXgsYp3+3z91BFPIxXvxUYwKz22jT1bdY+XT5RAD07+yhfywKiQgGIhYX7sOKzBgQFiu8RmAkhFhMX4+B4AAptgDE3bvxwIvpdOPtXkvHFgL0Q2BphCYgKYQmABhARMgLGAChAVMgLCACRAWMAHCAiZAWMAECAuYAGEBEyAsYAKEBUyAsIAJEBYwAcICJkBYwAQIC5gAYQETICxgAoQFTICwgAkQFjABwgImQFjABAgLmABhARN2WYPU+/+v6+a0F0kyrXy5DWnN6pXLuddxXRfhBefcdV0WlTvnHlY+ZANhxttPkGCNsPiLpQocROtV8dKussHUe1osEJYgVvO9Y1o5E8Eaw865F50gh9nCEmcAHNebVr7DCcpq1j1BJlOF9TCvpO+8h5WruN7UBlPvqTNPWCqr+7cqV3kUeqgtlRNs2aBygjO1NU9Yz/1yNPyu+IMUYteb2qBV+cwGcZKwFDtXSr9r1RxYfoKlDabeM2KSsLT8chS3nfrv5whcb22DYs3TgtYMYan7Pa1cvaNZ4HpTG7reC51VkW7lCleUwYzDdP2e9uNxXJPe0N3CWeUWrh+ygXmOTO+Vt0G38jmt4QxhdZ2elefco8ySVSfqup5vrcwGWlhVUwW7qGP+Ejp7RVpSeiG86iJ27NZJVN7aSOC9L1/08iupamiXV8V2WCu368HqXswbmi5GZEv8e5p40csxVWxD3HG0KbzHmwgLFo/HIi7bZEuqlLGK89VMvPfpz9Jkfy7EXFi09+lhMwbm/IOpCbrYQ2Exd+/6wXv/+eE8zx3kfrx3BCnHfa1LouX6J/XwU89NgvcomzaF9FdDZTLUG4tuDvTcBvWOwBmYZnBdj4j37ebOso6GzCrmk4epDUxL+MxJ3ncZ8y4muIkz7psZJ/iXMG2trG24ruvz+TANG63cBFPZTohYTDOGup2YNoz2NMpsYBrD5xt63ncQ1tD1KKvt9mNNsIFjD59vENbd66wjdnwuLMEt3qonvZxDMxSGgmWgW/nD0MW0/CGLhUU48aGwdph0YGpDVbKc9/2659hiX2GJ36TKbmhdj8+3gfOOS/00CRa/K1R5ncffa467F9rQPcr3jCCVvYS+x0OdOPPQ9bVMVSo27NMO3hOEZTRkarR8y9GKqlpoA/PQ3zZLp3vCWfnRREF2RWVj21t7TbOhPC4/Rj481hCfW3uWSwmnyzg4KHRed/umM28KuqTpd5TZt+WQAfcDUUbXhuPnvXV6lKEjCjo+HjFBvOrnY1r58TsicswwekmseJozs6t/fpt0GD0yHynWnMJ5eo8NmZEN/KH9XeZc5ZRJw2Z0X87Hz3aD2sp2R1ZG0RgxS0bdvExYQ7MYnrDDOEwVG2anVj/ME5bKffPS4ZSrWKWqY+YI0ufBZqGbXke4k1e6a3JOJz7V1nONrjeywzHfR5naIHDazI7QFq9fKtIoMx16KjSyQfBUOL9bocU3LG6rHvDTy9MyVaX3n2lD9xx1302pMKPnvYX/ofpt2bvdrU3LsFavN1Fgvg20JctZKayUHdb4B4rsIizwZbx1JjTYHAgLmABhARMgLGAChAVMgLCACRAWMAHCAiZAWMAECAuYMLDw2jn+gvXCS7+/CjdiCVQl3gt8AVxhyWIPItafhTu6IY09XbkMFQZfCTdipfI4/dFq4jxUBY7jGBqP5Y8jHcPojiMbkOd/C865A7r6swwP9Mvy8RiTWtvB30QygrSMTHQk40CsMPPK32X480h+QCDoJorpl6rQ/IHjOB6Oebdo/mLoQqB6NcKfPMkS+cDpzSNW2mKWyqO/BTORvCv0Pm/+Wl/pkuVh6Z/neRLfgvkMCyvrxLrc4X43gt7mTU7aRMZoVKoHgWoTBoSVKSbT0+W4nagWXD8c0NYecHMsXwilmmZlu1hMaW61cWj7toIbsWThZ9roBqhqN7gR63K7jMfqLi10QGcb8FXjsZBd7cOLx2OVYSlsQbjage1WmyF63quKIdo+BLCFvGkyRSmUuCX9iujlAtPYLmKB7+BNEQu8CAgLmABhARMgLGAChAVMgLCACRAWMAHCAiZAWMAECAuYAGEBE/4HnISAtKNI4HUAAAAASUVORK5CYII=","sha256":"4e405144bc2a37e00fdd023ac49b5a5ecb2947abb05bf94fd833afdec0390513","preserve":[]},"notification-summary-12-light":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAALS0lEQVR4nO2da5KsKBBGdWK2qIvURTo/6GZongmSglXnxI0bVRYi4mdmmgK9Xte1APTmn9ENgM8EYYEKCAtUQFigAsICFRAWqICwQAWEBSr8O7oB0Mi6rvazzXKbjeZr6nP4VQMs1itxVRV+nQGE9WKu66qyOk/qD1f4euZ82/smYZ3n6W3Ztm1ISyahIVRa1/UhIV6aHMfhXvvjOJrrSbV/27Z8tZl9Q5pbOITwIrpfo58XR4i6bdOrOmpOaq+cUBbbtqVqkKvqjdq6BGK6/grLotsqpXpTTiqjgJAqYxOtuaoGwyuEVRRQ8fPyRmFlQp8qYd3XREMQVtXCUYTNlmz3yui2sG91EgshrKotML9fySss1pV2atHt+a8qzetYl9DvSFvWhGdvGmp4i7Amp5uw5NGMpLY7eYQ/p3dvd2imW1ZDntWVHDFV27ZtRnPneYZpLYPNcZznue97ppLoT8W2gYgu8qx6+LpTm6SY9YapAji7Bxj5rnDf99Uhal1cPKGkrEvKknllJMWgnV4KrT1iJn2aUkx40FRJU4/EjhYT99BGN4tVm4qMGoxaK5IPiYSma9/3orGEWroJy9z67ufMVc9f8uivqmH1eZ7ruk7uHE3A0Kt8bW219BzdYKJm+3X4daptwL7vV6dn5L7UKiBf/plRWWOC92mf6if0iW9U1TJwBGlUWx0F12YveVrsxTBheUFYMSyrpbmq2YRlHrJ6la+trZmRI0gzGc4uV/e6rn3fvaqKufvZhPVW9DIZ8nRU846S3LprCL2UVapPJsxs1V6vfPkHrv6bZumEtiRlXUIna87Wk2zDMEAQMqOw5O9qJG5r/0VSIXRDzxgWPdpxHMZPhe9VUq11ixVHP4cGyXORz/dJM7Vty5d/4EyHCSt6Xf9vVpb8E1/K8Ql3n3NocthFd8rX1tbAMGHlNXEn+rlZw4SR+5WWQnRjpnxbbQ2MibFSwY3d3pyFsnpqjp+mfSsQ0jeN3re2GYN3Q4PJcYeGtunjXc+JV9dUZ9/anhaW/HpnBhBLKm/bfVpzFXoxd7u8fFttLXRxqFGid78NjaONuTMxMBobyS3QnDH7e9F9tA5lkQnPU5e2KI68JiSvIOcM2F+N+tojbhAdXuD8r15JU9j878ZSQqsWrWFm9/dqnlrUBr6MeZ8K4dUgLFABYYEKCAtUQFigAsICFRAWqICwQIU3rfP+Rn5y/Yvzdnw5vyHX35J5P8/FG+u0LYtSXz2/jkMv3Ja7wjJ0kdd5+pWEW7zGPNZ1dcLaS4Pnjq7NDmcF/hyl69TW7hSWPOlkvWznmBkD7vKFbv9EZ1Y+MOyswhUWVWXK9NJWZrZ76r6cgfLfZXGc47lsS+u52ANldBy9M40EtbUlDd4lqqot+fFEh05sP1t/ZRF4SQmSUSH5O1N76ptIWFGtnPt67vFR0hra2v7S/wA9cEOZ4lwga9obrrFEWN5UyjAaqz1oFWVXGG2AldS5r9sRidLO824475755EGVoeFSbct5LluDQyweyytgImk3DhtvsdqO37fVZhncVCw/G1GJRFcM7HK3FCu5OcGkjYKw7lzGmxJIRZ3uPRdK7fzl3sE7Y9ocT50sfqKriHzYbVjG/WzH07oV9lp6ruQKbypL4Q6xHWGvlnGU3p8LeOah2m2VPW7q11ROzmyWP+r+yZCd5535gF7OouOChvNarFzNvz17XZeRlKuq/PJXD+Nd+NmW0DVq3n4XJOuYx5n3XeH1O8EmXLTdnr+5TrZfzHQdW36GeL9thRy9NmTc6L7vHZ+4O7wrPM9921Scjr2flpiLcVf/NuYqFUwMRENY+Zc2mZ/CMtb9mZvTZPC7dF1BWJvEo53x0PNm64z7t9oK3f8k0smzBcte+vmkpjqjE+m8ENP9dV1XryX2djWZCGOubPxw396XXGGqcveoqRbcaJgbIZ3BH/GKTnZdnFD0+QDLXoa8jMItprjGkAevlzINszewMVpdjl4QVlpXR/SzZF8JGWcf/cl2h814TZL02v7+UYXr3p9irD20sA9d99er08rBe1Jbx2X+Ve0lJ2qNM0mEcH3vUb4yvDZ24rm3ff81V0otkfShMVd2aUX7GHTz0KJhMw3v/jqOn6nNBw4c+5DPZnnYXu3oB6PnXuxAjR6Tjseq0lbfUVnvQngbaKhqKqR5LLlWvllVHtFnCHejnhMcztQjSF9KVfz7keZqmX/M+3spyutTJWV4Yhmj6KtN82AS/mRzwe6TizuaO9xr5oVDUy+eizvmzzHVRW7/uCmYsAZt5p3+JR+X/cAI7mZ6maXoOc584k8Iq3jrtPVOyuZ9EtFzFJ7yWNnNO7rB8tnS+VSmEFbq7yjlJfUNf30+c44Sgz2wf6YQVpG8SZ82zuiId46SUx7bLVME75kuyNxzX6KnaIAlN0WjjNa8FusbdCOnTR8D+3AKi+X2Wq9nxo8hOsfBfdCeM+kwr8WCkIZU5yjN8QcEQAUsFqiAsEAFhAUqICxQAWGBCggLVEBYoALCAhUQFqiAsECFLssYLWd24lfqHeqQQf7NBy3umJ/g0MaQLupCu7BOu1LKtrzvvCv5+KGq3WkU1n4uW+X01DfediEPj1F5b6e1W6zu0y3DUVmpuXLhZ3ev1Mb8EfMl7yNsf/Rr/ryKG5eYgw6392WW4D06ALc4X6BtXpSwtmhjBnJnjLIt1rfHMjw3glRyo8hnnrg1ZCZVSxrWd35ilzHEmZZn5oKHo0nzPaMaOE4xNLlI6obLbNTA+KYZhgLbBrS15IEee05Ywy/GM6SiGT3mfGJ9h8XK80DQvcx6/YTBqMcDN/kswXsK1+bPY/OGi2z+WeBzWSxhZ0XX9In+1IteDu6+GrpEmfke6zJJuM5i7efPv+40TCFv3ktOR6twv235k+3eY+HTZRUV07+8hfxYFRIyVFisj12HFRSoENaW+AwQUiMswZ/PATAwxR5UmD2PBS+lkMeaPAsHY8mkIXCFoAKuEFRAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKDCv88fcl1X+/m6rucbAA9QFlZKB236cPeCD6aDK0RVEFK2WNd1hYK4KRE84MdTZ7FCPSERiCIK3j2jlTdX0djL28V8RZQfTHWMlYnZ13WNCgi+EKmwmq2LNU5uDd5X+DzanwpDc+X+hG6+nAphCbVii6UCLPgGKoSFPkBO+yuddV2jNgz9wSK3WMgFqqi2WG5OK2q0CNthEVosz1zlpUMqC5ZaixVKyhotz5J1aRy8l7LFQiXQQGMeKzowK5oXJeT6TuIpA4CbMOYdVEBYoALCAhUQFqiAsEAFhAUqICxQofBKpzbrTlIMDAOm2O/7bj8fx+Ftd7f0OlbfOkHC067QVZX56m2Bz0BqsYo+rsppWhOSsl7wdga4QpeMK/Qsmdke3RiWR6PDGfNUWHR/Qv9oi+FPZ+NpYbkGqaiG4ziitqe4HZ0NZ4DFSvmvm3Xi/qZiTIzl2pV937toAis1FQPSDVYBHW2MDfyxW5PAKx1QYYwrrH3o61stPMCwp8LMltTGtvphCIXJFDO8hOZ93xsZnHlPgVN7O5MG7559wly9DuYVggqTWix4OwgLVEBYoALCAhUQFqiAsEAFhAUqICxQAWGBCggLVEBYoMJ/rkIbXXBYbaIAAAAASUVORK5CYII=","sha256":"a5102e1aec374c25b4237c4f5b45ff6cf848552f6af2883cce342e4156a850a4","preserve":[]},"notification-12-light":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAALxUlEQVR4nO2d67KsIA6FdWpeUR5SHtL5wWmGzSUEJBJ0fXXqVG8bEWEZQgR6v65rA2A0/5ldAPBOICwgAoQFRICwgAgQFhABwgIiQFhABAgLiPDf2QUAnez77j/7KLc76P4sfU7/lAAWa0lCVaV/agDCWpjrupqszpP6Q1e4PDrf9q4kLGttdOQ4jiklUUKHq7Tv+0NCvCQ5zzNs+/M8u/Mplf84Djpb4tyU7hJOIW3E8M/s5y0QomzZ5LLOmpPWlmPK4jiOUg58Va2orYshpuuvsDyypRLKt9RJEQpIaTI22ZybcnAsIayqgKqftxWFRbg+TcK6r4kOJ6yphLNIi805HqWRLeHY7DgWgplVn2N+P5MlLNZV7tSyx+k/RYo3MC9mv8MtWReRvenIYRVhKWeYsPjeDCe3O3GEP7d373TQzbCoBj+qy7liKbfjOJzmrLVpWMvhYxzWWmMMkUn2q2rZAIsh8mwafN3JjZPM94alBOjsHmDmu0JjzB6QtS4hkVBK1qVkyaI0nGSgn1EKbb0iET4tKSa9aCmly4djR6uBe9DHMIvVGorMGoxWK0K7REzTZYypGkvQyjBhuUc//Ey0Ot3k2W9F3Wpr7b7vyjtH5zCMSt+aWysjZzc4r9n/Ob2dWgtgjLkGjZHH0qoAOv0zs7LmOO9qR/UK+8QVVbVNnEGa1dZAwfXZS4wWRzFNWJETVnXLWunOSpuw3CBrVPrW3LqZOYOUiHAOad3ruowxUVbV2L02Ya2KXCSDH47qPpETWw8NYRSyKtWJwshWa3vR6R9o/ZVW6aS2pGRd0k7W3W0k2Y5pgICJRmHx39Vwui3zg5MhGIacMaz2aOd5un4qfa9SKm2YrDr7OTVIURf5fJ1001o2Ov0DdzpNWNl2/X+xSOgRX6njY56uc2pyWkV30rfm1sE0YdGauOP93MxBoed+laWQPUik78utgzk+Vsm58ce7o1BeT93+k9q3Ailjw+hjc9PovDs6TE44NbRPH2uNE6+hoc6xuT0tLH57ExOIOZn3na7WXKW9WHicn74vtx6GdKhZsk+/d42zhbmzMDDrG/EtkE6ffV1kh9apLAj3vNS0VXHQmuC8gtTpsC+N+N4joROdNjD9bZTSJXb/h74U06plc9Dc/S3NU5vagI+hd1QIlgbCAiJAWEAECAuIAGEBESAsIAKEBUSAsIAIK+3zviL/Yv1b8HZ8s1+I9fdE3q3dorlOx7YJ1dXz+ziMIix5KCzHEHlZG2eSHokK81jVtQnL1CbPnUOLna4K/HeVoUtbh1PZ8mSQ9fKV41YMhNsXhvWTXVn5wLSzhq6wqiqXZpS2iNXupedSA/XfZQk6R7sdW++9+AsROs4+mU6C0triOu8cVbWmfD3ZqRPHv6M/WSS9JAfOrBD6yZRe+sYSVlYr1uzW5GdJS2jr+Mv4C4wgdGWqa4G8ae9oY46woqWUqTfWetEm6l1htgBeUtbsx5nx0qy9686Hd67cqXJ0NNWxWbsdHR1i9VpRAudJh37YfIvVd/2xpXbb4JZ8eW1kJZLdMXDI01LN5OYCkz4qwrrTjDclUPI6w2culZr9ce/ig3FlzodOtjjQVYU/7TZNE37282nDDEdtPVfrCm8qS+AJ8RXhW8t1lNHPBTwzqA5L5a9b+rYUk3OH+UPdPxEya++sB4xiFgM3NNRrsaicfzV7XZeTVKgqevurh4kaXtsWuk7Nx29DsoFxHL3vCq/fApt003Z//66dfL245To+vQZ/v2+HHLkyEN2oMWbgiHvAu0JrzXGIdDr+edpyXUy4+7czVyVnYiISwqJf2hBfpWl89+ceThfBH1J1FWEdnB7N5l3Pm6Vz3b/XVtr9K5EOzZFsexnHk7ryzC6ki1zM8Nt936OS+MfVRSKcufL+w317X+sKS5mHVy2V4EbBQg/JJj/ilV3sugWu6PMOlm8GWkbpEZdcYspDVEtEwfwD7IzWkKtXhFXW1Zn9zDmXA9HZZ7/y1eEjXkqCXsffH1W47v0UY+ulmXUYdn+jKq3uvBe1dV7uX9NZfLLWmAgipPt7z+or07bxC8+j4+ZnroRKwqlDZ6781op+GHTz0qxpMx3v/gbOn2mNB06c+0BHsyJ8rQ7sB7P3Xq1AiRrjzsdq0tbYWVlrwXwMJFSlCm4ci6+VL6sqIjuGCA/KdYLTUT2DdFGa/N9XmqtN/5z3danK662ScjyxjVH21aYbmKRf+VhwOHIJZ3OnZ2neOLT04rl6In2PpSoK6ycMwaQ5SKN3+Rd/XvYDM7i7GWWWsveo+cafEFb10emrnZLNexPZe2Te8lzZ6Z3d4Hm3dN6KCmGVfkeJltQXfn2euEeOwZ5YPyqEVYU26Wr9jIFE98i55bnVosJ5J6qAeOY+oqesg8U3RbOMll6L9QXd8OnTx8Q6VGGxwlobNWZ8Ddk1DuFAW2fQQa/FAikdoc5ZmsMPCAARYLGACBAWEAHCAiJAWEAECAuIAGEBESAsIAKEBUSAsIAIEBYQAcICIkBYQAQIC4gAYQERICwgAoQFRICwgAgQFhABwgIiQFhABAgLiABhAREgLCAChAVEgLCACBAWEAHCAiJAWEAECAuIAGEBESAsIAKEBUSAsIAIEBYQAcICIkBYQAQIC4gAYQERICwgAoQFRICwgAgQFhABwgIiQFhABAgLiDDh9wr3ffef8dtjb6UurJIO+vQRngVezICuEKoCKXWLdV1XKoibEkEP+HraLFaqJ0gEZGE575HRos1V1veKTnF/QpQvptnHInz2fd+zAgIfhCusbuvijVOYQ/QneB/9o8LUXIVfQTcfp0FYTK34ZCUHC3yBBmFBH4BP/yudfd+zNgz6AxvfYkEuoIlmixXGtLJGC2472JgWKzJXtHQQygJbq8VKJeWNVmTJhhQOrEvdYkEloIPOOFZ2YlY2LgqX65vkQwYA3ARz3oEIEBYQAcICIkBYQAQIC4gwYV3hywijLXNLogqusJre6gDAElZ2+dcrtVU1P7BPTNpe6ZRWQgMQUTc86TOafWrpFfec9ficC1VV7g5y7EqaVXXVZDZB9gGjFwSUivQmekaF1w9/hJ4qw5xIU6pxenFiBw8vU/vmPKIBc96zL6HTKTTZb4kMS+3Bz6dKJOXqAjU6wajbfwdteze8w3WN9PGFZn4e7hL77e9zlh0V8pfe8yGMyh2eF9PX5Ns2H0t6VPiMIfxaG0+hYeO1dApyBC2LJtE80/alwaDctb7DYu8KB4rgay39MM2jQk7T3nG2ShOgh8O/HYnrvh7Wm5lqDJBOwAkhZi/HiU8SlyhdhV/a6umhY1CKzbbe/jtgWazqEolqyKeaYUcxum1b9kQ5Q/LNBSYa3yVjv78XoM55/4gL8np0CQuqeg26hOVBP7g6Gn0s8AKUWiywOhAWEGHmKp13TMIBWV6y/Asa1cYtYTU1J9r+U8y0WFDYi+lZV5idULqR73GziZtW+3zzVe669GwVScTHby6A+eaCllfS/5Mn1SUr/MQO5oKWry13WZS7uyYTCbAA5ss0CIu5X8PYtX5gUepdYeRBS6zxug/kqA3uDNLWhV8lR0qO568ICPrXFdIpe8sDf/wlsMINrY09ZQFMRzmBHA0/K5e2XDjsr4agiMREAqbxg6S00ea8l45kv+qINnXv1ADvShuYQQpEwEQ/IAKEBUSAsIAIEBYQAcICIkBYQAQIC4hQmTbTGtBGUAw4JiymMMb4z+d5RsfDI6OuNTZPwOHprjBUlfszOgLeAddiVfu4pk7Tm5CS9QKrM3klNNEVRpbMHc8eTNNDo9OZMyqsdn/M/tEnQ3+qjaeFFRqkqhrO88zanupx6Gw6EyxWqf+6mSe6P1XM8bFCu2KMGaIJWClVTAg3eAUMtDHe8YfdUgJe6QAR5nSFrYO+sdmCB5g2KiSOlA725Q+mUFlMoeElNN73rYjSPUjRqa2OUuc9sk8wV8uBdYVABKUWC6wOhAVEgLCACBAWEAHCAiJAWEAECAuIAGEBESAsIAKEBUSAsIAI/wPr2NtAyZhrGQAAAABJRU5ErkJggg==","sha256":"2811198bfec92e3ec3c2ae979c68fe21dd552bcc60504fb5c74a6c91a12d7c9a","preserve":[]},"timeline-12-light":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAAK4UlEQVR4nO2dW5KkIBBFcWK2qIuURTofdDE0ICaPq4l1T0xMdFerKByTZ+lyHIchZDR/nj4B8k4oFoFAsQgEikUgUCwCgWIRCBSLQKBYBMLfp0+ggmVZwl/DoV3/p/RD90lhg+jDnnOTH6e8fe3RFDKNWJFV7pOGrG/bq3zAgdvXHk0tc1SFYXZnQ85T0Koz5hDL46zqDDlvKj+1TFMVRihpf0QNuM7ta4+mmcki1qhMf0fhaWYOsaJ2laP/UJf0JPTlzCGWMeY4jsiJziK/3J1K9TCNWI5Ir7ayFwYtJc24SZmj8R6NZB7HcU84oVvNTBax5JTNozFoJhPL6VKQRlXDaGzbf66exBxinbWr/OdptzH9vHBMBGMlmEgpxxximZwH0SeXG9zM2NSnq7sHz8gS4pgmYpG5oFgEAsUiECgWgUCxCASKRSBQLAKBYhEIFItAoFgEAsUiECgWgUCxCASKRSBQLAKBYhEIFItAmOPrXyHW2vDXdV3vSdSlm009/L/5+D2nd08m1HHMw77v2UvY9x2XorzM1nVtOJOzi6oFlwltTCNWuYDXdb05xcKZyMt4lFUOVW5NIJYw98em2Fm5CMu4J4kUxN3VjHax5Pf0qPv1trppbLhyDMmBIajuFVprt227OdFRKW7b1tkkn5unzT6l9oYeUhEM717dmVY5uZtRGrG2bbs/VvkxhYHcfxVaeNrsDM3dsc50h+et46yxhUirMwcGoi5iPdU0wSX6pS2tp83+RU+zozNiDczSlDQ5RJdQ1XCDooj1YDcKne4NLS03MItORY6WucJnO+dVSfvykzf2my9NGMLXdVU3Xfh0yDyOQfVCT0XQnETz+K3EA1VVWy2KqsKnEIaTbF2jMVTo4M1iuYH7JSA7PCYXK/u5MGhFqUgSnVvZp0PmcWCqwnKphBWTsPwK599wBNElfSKiC5aqFi9cokKsY8T8RiiW5Gh+49qDpzSsv5Bsf3YmUximRaz+oBWWvWR7XzxVG59RdZCxF6sTLW2swjBMbQO5qm8/6bC4tXZZFs0nr0Usc97t6l9218/lCTxyho9M1QtRJJb5RHhn0v7h6ZMahg8wAyPNI0vWJGgZeQ/h4FAVbgJAW47pilhfAmLVl7b21gvFGn7vCqdfxiZai7YK8YVimdEqSIKBPGB8ycKvd4p12ZF8sE+Ai22qgtY7xTLGuB5lWIp+buTAfJFBDi51PUFLY69wFNp6l/5k9n2XDBP47avqWSWX/NqINZbLoq0NFeWBXz+e5+eelehSwbMzSkIkTaLm6TNJLo2dK4wuLZKm81s9bZkwHC3nUeZxsYavbsgepLxB//KeO2FVKGpKl2u6IU1mndORzVAsaYEV7GleDurXuGqeTm7jzb3CsWzbduTqTaEQqVjhPIz7YVmWQotez1CCiKfrYhFtbSxXSNFQVrYpI8yrdHd59STfMduek38PrDuzx/BascolER2/qvni16HLd4lSFF5OQ0J6Vi2/UyxJQ7j2+D2EyUHTolh11IrVUAbdZVoiTAjaubupPAS8sFfY1sjFBZLIJFwbXNVq2xeK1QYukNw2/qRqoIti/Qdxx6fDB6DiVxWuzJvEGvKV1xtWnyK+dKRtHYd5k1hDGFvqhVdpDEyl8JXMJ3m69yBCknG13zMuJDek1EdNKpfRMyIaMYdYh2A4INy46tkNWTpLXTie1JmKWquOicQqx6G0IPsLvq1+qS3s5mpRz1holmnEOk7KoPD0lWyPrLY85Hr1PAdGrldPKneyHOBB59eQfV+hGfGyQkkqRmXXrwDFIhA43EAgUCwCgWIRCBSLQKBYBALFIhAoFoFAsQgEikUgUCwCgWIRCBSLQKBYBALFIhAoFoFAsQgEikUgUCwCgWIRCBSLQKBYBALFIhAoFoFAsQgEikUgUCwCgWIRCBSLQKBYBALFIhD0vv2r8FatiZ4U9fO8KxO8KMr0vrbZ54zPB2utf6RWmjnha8ZM67uAaml5Ppa1Jnou2GrM2PO8fBe3/sd6hWUZiuXZm3Isyhn3KMBIHZ85hWxEPBU8pC5ibSdv67DGuOtqy6zMAed6N99vMk/9MxnJNjsgepUp3JzbtkHdkoqVRqksmx0fveYisirz0FRXc5nVOMlsnVuXx/dcvqHz7NWeQxA13oVW/Wz8iV4glD4v3xjzu9QL7Zh1Xff1J4xZs1aFZ/nGqYLp+eBqhmuxrMlbZbfF/ZPvIicqofBxvOjGQTPROV9uv65rrVvycJVuuX8obDYQgVi5pK3dsj+X92rDtUCj9qlmsuW9LJk70G+Zbd23JfRzwBMFb7snL8Q6LcrwDycbNWuQCuS605r1Cnv7Z3/Nnrnv7kiuq/naoxdj9x/wkiuxOg6NOOW0/6zTswh3zsL33Rc4u+U6DytJqJaSWP3nCypzV0LW2mVZXBj7n6K127a5z29zThKu0p89bqfLllb61+1D55WmtUH/MYvDDUPMAtTpvmY0xqzr6n6Nxgn9h493IUPvsz38FXYHCvFnaK09jsPlYWdrTGPEcjb4V4m4zmCh6/6T1qdSiHZvOoVhpNVff4U4FpdpYYfRjZ12HlbpXKETIrw8F5nCbfZ99/Xguq6u2+VD1ONKmZMGkA+ltUfruaIwxexgm9fd52dzWo4msdLa19qxw+2+UvOxJ/t2pNQhDT55zoJT85C3r6ciUoOj+9CLlT0ld4v6H/Z9768NS2Kd1f3pOLw1ds01ptrOK2pF5s9NR003hKoGw2X/ILuZ6+icHc21N4wx27b5Nqvpm+QoDjeclVo2YlUdoY9s5vo78lJKdVhjfk9UD+HSiXSSxwU2939oWAMlsU6tSMv1rGVdf0JGEIeyWeb3csMNy7Jcrr0ZRbb5YoovGw9/9fuMDcCXi66i03DhatQ5XAyQZhNJa72B9aApRmAftIV7PVtXZssp+nDIWNtZK7Mwr5pOGvp2WDiC05yB1wv9Ttdgfaaf1z1/hP61WVEoFl5nebgSx1m6YeCMStqvBOlfmFW4akk2Rq31/sb7tVhty2DWbBB7NVWrG8Jcda2rd3REPNerG9b6Sq1hlxfQNrn7SquMfM27fK0fV5CGv0pGB95nlan9MsVZe8szas371FR10V9plVH7LZ0XcKnXW5VytIhVy9k0QvZP4fRCeoTsXo+vXyhwsk7mWqnyNZ5lUZg/4aRyegQ0SiehTc0c+5DZeBCjwlL2GjVf+B1iXd46bblzFvPeRPYahZf8rHYTPLvh3eq8FRVi+SW26eeXeyHP63kK1ygJ2A/mjwqxLimHdLXtjIFE1yi55GezRUXjvZAFhXvuS3zKNrDkoeipoKU3Yn2DN3La/HgwD1VErOi5PNFfv9ywNGiZ3x1tnYMOeiMWSWkY6nzKuTtG3skXwohFIFAsAoFiEQgUi0CgWAQCxSIQKBaBQLEIBIpFIFAsAoFiEQgUi0CgWIQQQr4crsf6OpZbHirPNhaBQLEIBIpFIFAsAoFiEQgUi0CgWAQCxSIQKBaBQLEIBIpFIFAsAoFiEQgUi0CgWAQCxSIQKBaBQLEIBIpFIFAsAoFiEQgUi0CgWAQCxSIQKBaBQLEIBIpFIFAsAoFiEQgUi0CgWAQCxSIQKBaBQLEIBIpFIFAsAoFiEQgUi0CgWAQCxSIQKBaBQLEIBIpFIFAsAoFiEQgUi0CgWAQCxSIQKBaBQLEIBIpFIFAsAoFiEQgUi0CgWAQCxSIQ/gFsRU7WmzXLaAAAAABJRU5ErkJggg==","sha256":"072e126e640d40a1287e03795448980becba79730496dd6b668f2ec6261359ff","preserve":[{"x":0,"y":171,"width":200,"height":57}]},"idle-24-dark":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAAMrUlEQVR4nO2dXdakKAyGqTmzRVykLLLmgm6H4icGCAH0fS769GcphBBCQEBjAAAAAAAAAAAAAAAA4KV8ZgtQwff7Df/8fD7pT+lFf4W4IbrYIxs/Hfr+2tQW5N/ZAnCJrMpfaVB921N0goL316a2LP/MFoBFqO6sy5kFrKrEHoZ14a2q0+U8qf6WZZuuMGKR+CMK4Drvr01tZTbzWFJKf0blrcwehhXFVZ7+pG7pyejl7GFYxpjP5xPZRGeV3z4Ok+phG8PyRObVVvdMp7VIGLcpewTv0Uzm5/PRcSewrWY281h8aMuDxYxmM8Py5kIYzVKBkWzsv9dIYg/DKsVV1/V02JheJ9IcgawRbGRSnj0My+TsILpye4Mysrmj7wYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPQx8AwTa+31f+ecSII+zTDlNAvnnEh2slzCm5z8XuDwX5Ecs3nRpLmvoszzPL85zvOsLaTHWltKk+A8T/GitdEgfJuiLto0NlSkLjjlqarvfgXNNa9O4ZvbYU+m4vL0wi8PUz7BNjdFIyLyNzSM/kwJRiiKoqqVcJQl7sk1XZesz6j18YJZp6g20QYjEE+Qg45tDapaZu6DVHeh1z7bSjJLNQp6mSv5oNxrxeil2QjEE+QzVDVzW8XofpAjw2QlltIUVAHBIO0otAo6xHmCYXUqcUSa/QJ0oiA2Xa9L+fvqc959sxgxOtAccYi3PLWRwToTv5JIOds0ZU13VZKhhxUkn94XNyLYhc+tGI+gjpRbRUlyhaylNPY/soHhFKVECPYpi0g+Ol95dyU+3OhPP3ql3fZWcaJyzoCGxxXqKKR5AcEN4q4+zaLq8VIha5Uroqxa5aT+psEmUsnF36oNZ0RTSHPhVw9tDVXVLGJYVQUnarQznapqUhiAr/LpXuccp7Rqi/giYUqZ1tbQcRzET3xHkvVYVZLMR8djMTO6VV+nxyJitWycUZXdrd3wk0qFr5KEFkOPqgJ3FoxQkPjLsqhuOI9HMsj2vD2p1Zp4yDRvpxC8h2TdRjoGjOgUo22hoqyf6AnA+Q/y09RARO4LZqbegHqaJkGz7wkfbM6uX88jDKtKVBlGT5AyGbdeuUH+ESP8Nhc4Ig7u7B+5L6Gdc8SIZtZgrRn9LWKrbKJi4wOM5scrVjc45z6fT6qg4zgImxNEMMaMBN5vrG6MCcQeJH/PYorqZTPejHyLP44ja2qDkFJffzNo2wu6I/MX6ijMo/QHWCUd1cYo44rcNoG+4B6Kao+1NSXnul0ApEx4PgCTdxlWZ0C6LAqdcq3e3mVYphw08J3Wa91blW3tZFiCx7CkTZwf0esMgfmojSGqMnqjYRljsi/IOBbTbFXjql/Tgw7cpTMXQW+RPaTKz55kz4hSnlupYrsZnwrUlm0IHv7UfwyVeF7NalTb0MEsyCoL/S5uV9hFHiWcfa41FGvtmh6ogeM47F+I26JXc/PnP2/p9FjE0peqktc23J4iz30JTUz2lhIR2TembYjNhtWwvE5Qks7ekJ/R6GUzEemSNfpm8YKI0WxYzEf4FqC5rUA8suSnJlvB4vlOHhXy63VQQ9Ec5tzmVSXM4tHhNoZVe7MOVbXLWfPeJ86fXJg94B60dQojYm3NGEtwi2zbCgtO2WU3oewRY9VqU1ZH30JNp5EvYRBV2RE5ViWS1QNRBbTe+rMeiNpi7VI1ixzfQKdQW52cdNrEbtvhmKpOZHf/WEaPClNCj9KcQm0RUtsasZHhlh7ly2Y9nPXfRaREnoP5VNpkhwqZEhm3pmXv9BJ64rA5ernBfCr79lpMJgZRdpp904TK6pkqnOK0osZX9Wxa/EFCpqQ+Qy3rb00/ON9jmUlOK/smWyS1oUx08HOy7n8JPa6dpXSGKVkNDBI1JBviKOTrqbKHJTyWMcbvVdTJi97V3YzCkuVsFjp6m7Ygu6rRlxLR8VvZY7GqUpgiPzEiG623ma+GRAzLjNeRyJokfflvq3ac3ua/cFxcR1JvZvTlF18kKJ71WJgF48iqXzf8HDlDSEH5q6pWdrJ0Casy7FLxU5OqHuZsAicpvq5FhG+bB5mY9Shui9Sw36FHTbXrvRpeQtNIvcespUdvIo7q059ESlayzrPOOFtQorzasivl0iM/Hd6lGQmO7flZ9ygtZYhhDaV0NpXXyOILdom2MVp+OuvF9QYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABR9ltBCky4gNb+rgJ3ehvKaWBYOxGvLbblXQ+zLWwlw7LW5jTl3GHWaIUTyS9XJwzLM8+8ljAse7I2G7pjCWn1obbZ3NqWcW7GeR6Tq4ppUiFvM6+arZHWlPbhqCttWiVZe5a0cI9zzq31mdMR3H7Hq/iItcYkz+p2i3MMq8uqPC+wrdK+We6zcS+p2idOOHhNwKpMMdJ/DD1W9edOdxgT3q+qMW2PJWNVFw/1W4IHM9vz/OkWtTpEdY8le4bJUieiCFFrVV/yAJ+4+6v/Dm0bqobFn1bgj2IaxpXP48ZWfpy6UlNUNCxOQ3HuMil3fLjzog/yW7Xuyh/sQx885Jz7CbZUnJaeYVlGW3E/wWb8Z0/Km3IbD4XfWqfSObSd1nIei/qzJ+UnEn0L6O72nxHiCHlCtAxrdN2/0rZCY7o3LFW70jKs0b3VM3rDyDg40RV95Te1n+Hh6DALHmtXsp9B4D8tK0zKKp88AVWU5q7oOS1NYFj7QXumRY7RXt2wHvnGphM6llrk1P+VDCsbqzqH5aMDGK5SLcNiGEfJObGcFozvFt0uUsmwmHPoy6avA/Njz/TnBUq//qTmhh+Iv5DHWjr9laBtovxraKaP6QrNfd2XlqHdL097k1V5Pp/86o/S9V8dPms91n1vZXN7AbIXa1PeFmLu4PP5hM7JOVeyKp+QCW6VEY5EdQUpa+1UsCiUudz0Yft2BJeP/knwR+3OqHw559/RGYS443NvW9ZaWzF9/DCrEicOJLTCBvV5LNmCPTG6St1J22S6Pb/2/Kad4DPXvEvul3/oTgpTsK0688rc7LzKuiRjM2HmXca2nmtVHmo/KoPMOiLdjxKqxlgXzh3WYCd0C5dt3Vmei3Z9jRYsAmc3rI7IagX9M2eWqCScNkPTaVtTTjJaqapwPlaZZtt69flYgEmVeeFEP1ANYWGLnEEKAAAAvBzEWA+Bnjh9OOd5fknO81xkk4kO1tpSwa21/qL/tRSt+9uymlQpwQLcWtULlZKWnfgpta1blS6yx3AsTKt6j2Fd7ipb9lu1MBvqLNtaaV/hy+g5vpboHNM768QSQuu0mTf4ZAk4hlW7NmuKba3osV4yrmle217bSqe0aqX1WHy373TXo82ip7JLynTOlZyZtfaZWs1GmrOFmklWIaFNlIJ3OuTn3KDDzK7Qz9Mg/LpgBlj0g1mX/1glc6ZGZ8uoyq0GSjdwfP8K/cMqo0LvwB/bsH6RLWbqnzo3Yoiw1qjwJT1j72e9dkBjVFg76UKdQfBcHhYMrOWxPJeK/RtW4v3rLs03YjWxN373T0fu2UgzGjaHqUXB6XZKqdVGWMzS9ZDsjIO35kt14VM76vB/Imvw5cyqwP96lf9aOkLcv5deuKaUK2M64uMbVnQ9NLUJWpAl7b9KWvD/MX9LnrbXUMVvNqzULEr3+OuXhfkwY5D2FL/+Za0vAHP442+7GpZz7iq/P2TsOA7/r2eY4PKIS5u21eiGUOdh2/b/2Ut7P2SdsIdoglFAcP25WvDbhiUpeSwiePDJEgtKo2fDrmBLiMAoe/1b/p4H8evDKBlH9qdbfYYu6nqTdvWMu75b4y9KjjRYSkdZ/ikQaqnVZ1ZjV3TF0XwDK85j3Xb50cv8/ZpaH7UhUfb+MN7ddalSqSvMQltJ1LweFnWFEB7L1Kg064SuN7PRiHu/eIupCOa7aqb6tuZWORyVltTif00T2VWNdHDA9Do22Um3qzpIOFVO21ZJLdFCklCZgo5/wuveNCpq6+Ov+S0xydbjUhRRzAZ92mSlcnoFAAAAAAAA8A40RoXZca+fDk5/Oo7DXwzni6/bsk9t/HK+DF3GkopC/Vy/pjcrsOIrHQ9/duqR81gR2TKuXHCNzRS3TaetMZV83pPIlpFZ5PM8J/rydT3WxbNN56ksYVjnX9Lrt0+NlGs+RBk5DnuifpYwrFtol/7I4D0iKiOnyHPVMuezchGECog29xJ7ygZY649s1vVYb7AbPm32MVGHS3isUGtSY8bHkDot8zvQnjv6K7GuxwIpDVOdC9ocAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcPkP9ctlQNk8bfoAAAAASUVORK5CYII=","sha256":"3629d99a35f6628860e95c3ce8e358457e1a16514c2ff04c4a0136bc9a9eb7c3","preserve":[]},"music-24-dark":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAAMdklEQVR4nO2daZKEKBCFcWKuiIfUQzo/6GZoliSBZBHfFx0dVYqszwQTsJQCAAAAAAAAAAAAAACAj3LMzgCo5Hke+/k4Dveg+Zr6HH7twT/9ogb9cFUVfl0BCOvFHMdRZHVG6u/fYSmBTnTt0aoZKiyttf1/37f9/64k1qFiqPQ8z5pC/B+t9XVdzy/XdRGB3ZAe13UZHTRCJ5EtS+raEJHcimCz5B0hPtv/Cw7LlEq0YrT9iPYuansCpiwIQXAud6nOag/cLGU/L1sKpUit8EOG1GmryNi0SN9lutEy2Wj5/KwmLLoZ+CGjVGirNIlQE2PyKUuYJc5xL8ycrEfJtoEbuLS1KtqsQhNPUKG9M9mJVImix+mvM2H2ODZ8XZMXFbioE3TxZFERw/SucBP4TWgvqWit0mYT0W6FOlcwV+vD8mMJVuV5ntaxlHI0aK05zqeU/u77NpdrrVNhskmkztrIQStF97S9iumPqDYJqVx516asmg2WigedXSO95gpdy+QedL9mG8/zwbrtTZgrIsVoEsQpyKsvlI36i3ehUYbBHLkcUpHYwIQtSV0eZp4OyRmoSc0NAJ+wv+C3q0u2Cd1I6M6OOOWRyiotUGbkIAWrK7zv23Zt5nNFSsybXnxoTEfIN0XG+krkqBL3rmsPXxpbKdzVDd7TUKeuIToyWwejrbr7qoVSBdDhu+rJstZCP6ZepWRdEc94u/VGVakFhWWbLWW6pls1DOQ5jBMW07XoPuQfx+FeUj28I7JUd+FIo1W6/pgOXxpbNX1XkLorOZVS53m6uknd+td12cK3K4k2MF6WDDbDhOO+MVcgDu1uCB2bqVuc9gUQ8D0CHM+Im2Ev6bjvYfjSgNJ06fCzSpGHbi2+VqpnVKQcpI0lHUZpunT4AaWQH2PN7T48o5WalvFcJ970AJhGhcUK7RAxve2Ow2yru5dzriXy6cZPXE6k0qliU5SmS4efVYo8dcIyZOcKn/REnmtUsqkQZ6166i4fb9u8mmkMXxrbONpndrPNlh1+VafizojXxTD+qdAmHT3OD18XWwVd/FiNPgLm7F51Ku3+1UXmnaRE0CO2juux6i50139yAlfHX834ucIUsq7OJXZIM51DpV2MO3ZpXCOaglkQTg6BPNFWDyu9cTdpNFjLxsCoFcSSrLUI24OYosk2GLPJU02bVTCtiXCqIATTOEU0davW/cgZuER9lZwXwpgL+SFV8LYZ5qAqnMcsjQEAAAAAAAAAAAAAAAAAWGBCe2t+XPlaK/U763AvvdtbihphaX0pb3Lmvu+7y2KS7Ir1ZfmTc1dYBokaC18fl3qhnJ0WG1Z1ZcLSV2Yt2H1KmsDU5LT4zlVZMtPV2pkOb7BetnJMbbibyOnXJo6pvQIdZFVlkNIW8ZaElYWVmmj3A1h51Wrr+fuzcq6AbP1MvDO5K0iZqioKuT3RrufnoO0Hq1bjuHJJ6ZJ4X9yAlxWyhBXVyn0eKeMkoq3QgLu0x98D12ZkX577W3ta6+L1gxxZpN4bwI+hhfy7G6LFtpK6zyMqI60vweH89DfMcKhpqvtU+lJaa8V6UXQ0rdRo3f1q1rO7o4sFLFZdDkTzbZZ3vuVdoNGWjq5Bve9bKRO4vlxZRdoAI2/OnLBaGrJNBGEz2F3R0a/24IABRCl2p2TkXLmuOAOsVA2Er2X0qktqXX+mK9QNd5JW+lbyt4itCHffqfe8rYY/Obqjq9TZxAPaqfVjisVfQu1+fhr2A3o+C8HdIutaLDLiH23ZN7Pp4FWAi9gtr+FX25RhvaZW+lLd5VqvinQxojF30nEcrvnRWpuvtp3sbWdCmv8rjPejHfqAdDldpBfmui7BJ26BN/rd91nxwMyO/E7tzzHdnwlgrIIbZgVVqT7C4jwGRk+FYWz3Z4yWrdLGHKq8sO4736Pdd3wk1pY/0/3bckYfqRZRD4HtZdwjf0L8nC0oSLTg3iOzF+B5Hi8n9nY1nghjruz4od3eZ7rC5Ojbn2EtuZaBt8Uv0za/R2zljh9g2Swxs2r5CX93/+UEImP2BrZjjPbay42xkl31Ff3MuZYDYY2ij3v2iPV4LeL0sibB4L0HWin162mQN72E1fGq1+3+pCqNMXhPaet6zF/RVXyi9UI4EbzwEzvKsG2OX/yQpvYk8hkdX3Lq0JgrE9J2l+2eGtZKhIq5P8H1M+5Ii6MVwWfmUmhvlh/4p1ZvJXcPRMvuuhJSA3/xGuM2f5G2ZFdlvQuOW1y59bnpglL2jzQlJpujIRvysxXWuxYeVEoZWzU8U4NYegXpSyka/25prtT6a97fS1Zeu0rKMMLARKc27drZ8Lg56D6YuKu5w6uWXaasGjaD0GVMVZFbP64LJoyhN31/pKkF/k9OTvlxSiZSZilaxpULPkJY2VunrnZSNm8nomVkFnmu7NZd3WDZWzq7soSwUr+RREvqCz+rRJSRY7An1s8SwspCm/RlxxmCeGXkFHlutSwxeCeqgLjnPqKn6ACLb4pmGa11LdYXdMOnTh8T63AJi+XWmtQz4zZE9zi4D9prOh3WtVggpMLVuaDmAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJBE4Ld0zC/I/0QX/Igo+Cb5l9u6ugl5o5JsiaQyj1srBC+3BV2AsIShDfx3KHvPO+x8CJQUpe8PCKQGH+HxcNwTHQllIzyOw3zm3wPhtWH8oJReXeHzPN6t7B7JtllUZ2GExIUVcOIHTN49xlqq7UNb+2XKukKvylKGh+jpnuehzVU0ABFhSEsXVpHb9kS3pK/FstXNbJ6KCAXNA8QhyLSucO9WRG84392QeiiLJrdUg7mZWSpjK7Di4B2NtAFL/BAmnxd1oNmB/970tVju4xUnPN+/VRRtD7wHVZdZWVqKLhbLHS0RwyY3GN0eRIRgTVYcYxnecusT+fzyPdBrjBW6MRuFEvWLzhLflxUDAAAAAAAAAABkeYev6C0s4g1ZgXUdpODVvGASeo8NDnuUgk/ZTmivRrAwlyC1uegjvKArZK5vXpYPqkq9oitUr5WUxx6lYPICiwXeiLDFIjY0q2CFgrdrOXtckQOX7AJ5eud0KhIiA1miyxLpwnISpTO/yFPCTIuVGnxwBiVhmOziUs7OaWL3Nj9vRUTzmc1G9NoBueXzyq4wq8gWyVanHuKtVP7UwuWmndDtpCqa2QDZbaucfa2p3c9F269bYL4uJbo7Y3BW+bzSYmXh72soCjPy7QxSTpZZCnuHuyFLdtANBtO0E3rllhPM28rFXJY9u8Jw09/EzHyTTbrC1KyliKSgywo6vtGvU8zjmeIc6rRBlyhLyltWR0eLNaABskm05GHK9mvmJvI6TITGbeF5MWinRgXCFmtMr5H1fqHzmo58V9hjlJNNhU63Og/RgX9v1YaJ9nj+SFWXVEK4syVZZAJ4BfZ0N6zATo8vFUBYoAsQFgAAAAAAAAAAAAAA4LN8ej6Lw3Vd5sN5nnNz8i6y67HICa/MSVK1B3XxUah4NP9qbLI0WQoIVAoIKwMUVseewvIMT2iH7JFoMPv5PM+oDXNDesojTn2KL65u8FQVPcK/PJRjXbSb8UVhWTyL4n49zzNqb1wDlrJV7qnPamvPrpCPSG91XdeXe70onxZWtSDsVbRV+zJf7Aq9YTh00IOPWizvMVC2L0O3qF4qLCk3Zuhl4Gcg5cgABvmu8FGH+ROP2eI9c5W2rnj3l0r3y51stvkL5grLxNQ2Vxhts+xDPmGiotdGHaTh5XS637RtYharq4kKCZvH80JVX1uaNJ3uR2QUImOxalQlurphfWCxQEc+oioFYYFOQFjj+I65UhhjgU7AYoEuQFigC6+c0gEuazoy3iosYrZkYv2u2cZTQFcIuvBWixVOz8FILMVbhcUkumcmNVUsvvemKCF6arw0G9M3C23bFYZrY+hFLMRZ2b03dTuC+MUpLXgnZIR10H7UqRD3q7fTJrq7RmTvDSehVODwLD/RokzKItYVHuoZvHKGxmvIt6+54xdnkYJLjrGM3VpHXrJ1Ol2a/AxMz6rqMXi33eJcha1QuYK8S1Vq+6dC1bBjIhrPdPjFkSp4Hds+FRoWUYMUbxm5q+2F5W3jEYxzCvzi9Ch4Eft3hY2Vax+svLfK9DMJtG/zLYOtbS1WdPNMXV2vsPeGXxzBgrcgua8wODnuHaQbsNmk57YWC8wFwgJdgLAAAAAAAAAAAAAAAAAAAAAAAACI8R/ILOwjA+EPQAAAAABJRU5ErkJggg==","sha256":"0ad28f9450df3add1cdb4417597c8c063c6e9749fb691be94f3d257d07ddfd57","preserve":[{"x":10,"y":176,"width":40,"height":40}]},"timer-24-dark":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAAOE0lEQVR4nO2d65KtKAxG2VPziviQ8pDOD7oZNpcQQkC0v1WnTvVWxBBiiNw0BgAAAAAAAAAAAAAAAP4on7sFAEKu6wp/fz6f+KD/Wfs7/zmDf+ZlDeYRW1X+cwdgWA/m8/l0eZ2V9vfvsjuBSUxt0cQsNSxrbfjfORf+f9Yt9kEQKl3Xtach/o+19jzP65fzPInEccqE8zy9HQxC36JZltq1OSrSqhBESo4Qf4f/NwzLjKnUYrH+iPruqnsCplkQBsG5PEYs6gxikZp/b1sKY0hb4afMkdlWl7MZMf2Y252WF2Pk72s3w6KrgZ+yiMC2em+R28QaOXXJReIcT9LcI3qRZh3EiXtrS1BnApu4MoXOFnIStRIVj9M/74TZ4oT0sirvKnBXIxiTmIUgh9ubwpfAr8JwiaC2eqtNxXYF1rmDu9ofVj+WoiqP4wgdS7WOBmstp/OpZn/OOX+5tbaWpnmL2tmQORil65kOVzH7I8QuoSZVcm3Nq4VktXzQ2A0ya6ww9kzxwfhns/KSPti4vgl3RdyxeAviFMxrLpSP+ia50FuGxx85I2qZhMSEL6ldngtPp+QEalpjAyAlby/49RrTrMI4E7qxI04l1ESlDZSZOajBagqdc6Fp838L7sR86NVDYzpDvivy3ldDIiHxUzeevje3XrizG5K3oUlNQzEy2wdvW7LnaoReC6DTT7WnwF4T/Zj2qmXWgnzW+60nWpXZ0LBCtdVc1+1eDYE8h3WGxexajF/yP59PfIk4vCNEkl240mn1zj+m0/fmJmbuDNJ4Jqcx5jiO2G5qj/55nqHw45ZEO5hEJE8QmOi4H5QKlKG7G/KOzdojTvcFEPB7BDg9I7HAya3LfQ/Lpwb03pdOf1cp2tC1xbcV8YiKVgfpYEmX0XtfOv2CUujHWPc2H4nTqg3LJF0nyfAAuA2Bx8r9EDG8HcdhodbjyznXEnLG+ROXE3eZpNgavfel099VijYyw/I0xwqv+kBe7FSadyHOBuuRXb7etyWaGUzfm9s6xkd2m9XWDL/Ed4lHxGU5rH8rDLcuHuenl+UmYEo/1mAfAXN0T3yX8f7VTcadtIxgRm4T52PJLoznf3ISi/MXs36ssIZuV+cWK6SZnUO9TUwcuwzOEa3BLAhHQqBPsdZzpQ+uJi0mG1kYWPSCmJK1F3l9EEM0zQpjVnmtapsWTNtEPlSQg2GcLoaa1dD9yAlcin2VnA1h/IX8lCbbbYYZVOXjmL05AAAAAAAAAAAAAAAAAAAbDGi/mp+ufGuN+R11cFuv9tZCYljWniYZnHHOuSmTSZoz1rflS/LYsDwaGsu3j6ttKBeGxZaprs+w7NmYC+YOTRdYG5xWX7mqS2O42kbD4QPeKyjHayNeRE5vm7hGex120LQqj5ZtEbsk7GxYtYH2NEEwL6ltXd+flYsNKOjnxieTO4OUaVVdKV9Psen5ORjaQdFsnNhcanZJ7Be3YLNClmEVbcUdn5pzUrGt3IHHjOc/g9hnNDfP/dWetbZ7/iDHLGr7BvBzGKG9d0Ox2MGk3PEpmpG1p2I4f/sOMxwkVeUOY09jrTWsjaKL96pF6/FPP589ji428FgyCVTl9tM7n7IXaLGmi3NQnXPG+MTycjUtMiRY+XC2DGukIseMIK+GsCq6+DMcXBBA9BJWShbO9dsVJ8CqaSDfljFRl9a8/kZTaAeeJGusM/qPSFBEvO40ed82y98c4+iqdrbygnZYe/li8adQx39fA+sBkz4LxdUi+3osMuMf2wo7s9lsK8BN/FZS8bstygi9psH0tZrLvbaKjPFG45+kz+cTux9rrf8Z6ik8dj6l/3+HeL/YoC+4L6eJTNKc56n4xq2wo59zh+CFmZ25q63P8c2fT+C9QpxmB6sycwyL8xpYPJWnCc2fd1pBpYMSmrZhOddu0ZwrR2Jj8vnmP5Sz+Eq1ifUQhFYmPvKV4udsR0GKBU9emZME13UlkoTH1fdEeHcV4odxf99oCqvRdzrC2nMtg2SJX6Nufo8E5a4PsIJITFEDP+nd9C8nEIKFBzjEGOPaa8VY1ab6LP7NuZYD4Y2Kr3vhSOjx2qTTK7gET7IPtDHmt6dB3/USXidRb9z8aSmNEbzXbOu8/L+uq/gU9UJ0IiTpb2wo87r5/JKm9NrTkLMYX3J06N2VTxmay/GeGtZMBMHYn+L8mTjS4tiK4jtzL3RvVpr4R6vO6D0DxbLHXQm1wF9dY9zq77It3VlZz4LTLW5ifb50Qin7I02VweZiygF5XkXoXcsPGmO8r1ou1CK2nkH6ULri31e6K7P/nPfn0jSvt5qUZ4WDKQ5thrmz+XF/MH4xiWdz51dtO03ZDCwGoctYU1Gsn7gLJs9hNnM/0jQC/5OTt3yckomWWyqWceeCrzCs5qMj007N572JYhmZRb7X7Pad3RB4t+m8lS0Mq/aNJNqk/sJnlYgychz2jfrZwrCa0C592zhDkaSMnCLfq5YtgndCBcQz90fsqRhg8V3RXU5rX4/1F+yGj8w+btThFh4r1prWO+NrKK5xiF+09+x02NdjgRxBV+eGNgcAAAAAAAAAAAAAAAAAAAD2QGExhV+0Qyz8qo2h3jLJX3zT5oX0AgcZt6hIhYHZDdb67UCcO8wDS97F66eqqiM0LHte5v+dylk88bHLWTxH5blKk3ss9RWq+ays2lq5/O/4qtpB+o50ynGY8hd/0uVqHjSlBjo/rssu87GKE3Cb6wVk66KYuRWFuZGROcrxDtNEnoqsm0HKeVD4K0/iHIhF1RzBdNcnqswhJiQn1oLns0lpzUwNHLeYmtyk9sARB2fg26YdpgIHAWSSLNDYOsO6vTLWUItm5rHnG+szPBbNgqDb7Fp/zGA0YcFDvkvwXiP2+fv4vNuNbP9V4Ht5LKayinv6FE9podXAjVuDSpRJa0xlkXCfx2rslDyAYAm5+Co+il5hXDa6sOoay98uu+j5JvT3Rn7YFRIQ9HisDfbjB0+hx7DizelevX8mGEe4azLaQQAAAG+h0aJt3gsH7mWfLmsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAudtmNyMZ7BWpvvjU189tlsN8b4t1VwI2w1p7neVU4z9MO7CFIZO63HB7JvEsGQoynF3A7rLU1exrXPm2vilV7lwxTtfdgmBqP4WtHkLn6Vk1TZZiqvQcj0Atf9VMz36GAspx1C7gjYqV76CdvMHMV1U+VYar2HsygXjxTMx//3OE8GVQyf6dtjevlquidH8w2Eat+qgxamb+wQVR54Dy53rVy9txewFyGqdp7Nlp6ubLHTtFVeASqny2DYs6vclrqeo8z13UVl0j1U2Voas93VgWamSvU6CY09R7343FUEz/QzcRJ5hwj6C1glwzMMjK1lz8Gzczf0xo2lZ6k5zyjvSm78u9S/WwZaMMqiiq45HnIarHpV7qS5dBX5WHc+U2X+xmUQd2wXhJmyeqeaY5iDfIvJAZ6e7OSySDIn0hPi6TIzd+Ers3x2GTuhw+He0+txHvT2s8bmW5YtPYJA6Jta7BSmZfTydbI0HzGYu++z3SG3b9iTyNzbFrPtK9CmQz86t/EefeyaVOocnnxLKcJ65JKJkPTuOMLH2pbExG/MRl20Fq7RdF6mF21TBlCyqkyMCXhsyYI+3fBPabinPt8Ppx538z4g+8eQkq+DMzgOr/2OI7c2v4uCzwWUwz+E8/vo+oNk2UyMIXhs0l0P8QOhtXViOTZNvuxFsggzqrIGwzLtDrriAvHDUvwiNfyiYXpeqXvcpaeZuaDrosp+e6IlThoWDssOpi6qqJospzxft0y3oa4LsWGJXugdTW+XgavSdmI+COZNJRWs0hZCKKr7htlaN7lJQGWmTYBQXFiuK6uZValIsMfagfN5Gkz/LvUFK1oVTfKwLz1e9yVp1ngJH1voCCrUdncdmKywxoZ8vvyfeTgvbpYsdsMp0jHcTjnwiwrOrFz7jiOrvzzHIhTydncqbhfiDS6MpiSWXfd0Wu4S8LdUV9rMDXz69sjcsSYIcOlWsxXRVcxWrrOdaSYc34XuoELkkyVoSkGh8XVbZZNm1F0wnFWs6NRTv4LIuLBW8RhwzIeZlhJ8DGvUrsGbW6XgeCu0GqdYakU723h52RuDNjXzSAdL2RunTvY2Q4y5PgX5z1lm4L47ab2XjMY1dK3Y45HTZVBoLTXvgPS6I75T3rV54zpxiv3Z8ggeCv8oyYV6NJUM4ZVt61kpV4zTVeJBDI0y7jPqq/Anfu821+KZ/PebRqth7XZ601IpbWKldnzrvVKNIM/8QEBAAAAAAAAAAAAAAAAAAAAAEBGx1ihPftXWR27jEWCxXBnkAqsSnwVeAFcw5L5HnisPwu34mPf0zSXrsTglbAXU8SLrs7L1KazWQurAqZvop+11kazNJ1z7vg+f5qv+XqHwZS9v0q3R0ni8eCTasfB30RS/Zlncl9zsTNPxoGYsX7LCnEwiOQDAs4dPpjyPy2aP5Ax1GDNaP6C64KjejTST54kgbw/dl6zPVbcYuaWR58FK5Hs3WDtGVvV9/YvZ25wWuRrOOO/ibNgPd2GlXRiueNj3PHVCH53ZWkRN5HBG+XWA0e1CT2GlViMc7E9uePD7USdwPGLgW3tATfGSroY/CFrKc9k7emcfm9WrY1D27cVbI8lcj/LZjfAqnaD67Hc8dlkPhbd0vmzsLPbedV8LERX+/Dg+VjFj1YWj4P1bDdUTPS8Fy2GaPvgwG5k3ea24+SGEo7Ep4heLgAAAAAAAAAAAAAAAAAAAAAAAFP5D5OgCJu96ejaAAAAAElFTkSuQmCC","sha256":"e915827413b2820407531be0c194f8cc34fa764f9cf2704b83f2fd577dbf3d12","preserve":[]},"notification-summary-24-dark":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAAK1UlEQVR4nO2daZKkIBBGcWKuiIfUQzo/6GZo1mQRKfu9mJioohBZPhNMllYKAAAAAAAAAAAA4JeyPZ0BaOS6Lvt52zY30HxNfQ6/3sGf+5KG+3BVFX5dAYT1wWzbVmV1Zurv77Q7wU3c2qM1M1VYWmv7/3me9v/PusU6NAyVrutaU4j/0Vofx3F9cxxHJrIb0+M4DqODTvK3KJYldW3IkNwOwWbJC8l8tv8vOCxTKtGK0fbLtHdV22cQyiIjCMnlLs1ZvQM3S8XPy5ZCqaxW5DFD2rRVZWx6pO/yuNEy2ej5fK0mrHwzyGNGadBW7S1CTczJ51jCLEnCvTjPZD1KsQ3cyLWt1dBmDZq4ggq9O5M3kSpRNDz/9UmEPY6N39bkVQWu6gRdPFk0pPB4V/gS5E1oL2lordpmG6LdBnWuYK7WR+THGliV+75bx1LK0aC1ljifUvo7z9NcrrVOxSneIvWrTRx6qXqm7VVCf0SzSUjlyrs2ZdVstFQ6dHad3DVX6FomN9D9Wmw8zwfrtnfGXGXuGL1F5ifkdS85G/UT70KjDIMJORxSidjIGVuSujzMfD6mZKA2am4AfML+Qt6uLsUmdBPJd3aZnzxSWc0LVJg4pBB1hed52q7NfG64k/ChHz40zicoN0XG+o7IUSPuU9cfvza1WqSrG7y3oZu6hujIbB2Mttqeqx5qFZCPf6ueLGst9BPqdZSsG9KZb7c+UVVqQWHZZkuZrsetGgN5CfOEJXQtui/527a5lzQP7zJZartwptGqXX+cj1+bWjP3riB1V3IqpfZ9d3WTevSP47CF71dS3sB4WTLYDGcc9525gjh5d0Po2Ew94nlfQAa5R0DiGXEz7N067nuYvjSg9r75+E+Voky+teRaaZ5RGeUg7SzpNGrvm48/oRTjx1jPdh+e0UpNy3iuE296AB6jwWKFdigzve2Ow2yru5dLrs3k000/c3nmLjdVbIra++bjP1WKMm3CMhTnCq/0RJ5rVIp3yfxq1dN2+Xzb5tVMZ/za1ObRP7NbbLbi8Kv5Lu6MeFsK898K7a2j4fL4bak1cIsfq9NHIJzda75Lv391kXmnUSK4I7Ub12O1Xeiu/5REbk6/mflzhSnGujqX2CEtdA7VdjHu2KVzjWgKYUEkOYTxRFs9rPTO3aTRaD0bA6NWkCVZaxG2R2aKpthgwiZPNW1RwXlNhFMFIUzjVNHVrVr3o2TgEvVVSg6EMRfKY6rgtBnhoCqcx6xNAQAAAAAAAAAAAABggQntV/Plytdaqe9Zh3Pp3d6jaBGW1ofyJmfO8zxvWUxSXLG+LD9y7grLMKLGwuPjUgfK2WmxaVVXJyx9FNaCnftIE5ianB6+c3Ushelq7UyHd1gvWzmmNtxN5PljE+fUXoUOiqoyjNJW5pSElYWVmmj3I1h5tWrr+vln5VwB2fp58MmUriAVqqoq5uuJdj1fgbYfbFqN48olpcvMeXETDisUCSuqlXPfUsZpiLZCA+7Sn/4duDajeHjud+1pravXD0pkkTo3QJ5CD+WzG6LFtpI69y0qI62PgcP5x0+YkdDSVOeu9KG01kp0UHT0XqnRuvvVrGd3RxcLWKy2HAzNt1ne+SlngUZbOroG9TxPpUzk9nIVFWkjzHw4S8Lqacg+EYTNYHdFR7/awAkDiFrsTsnIb/W6kgywUjUQHsvoVdeodf2FrlB3PEla6VONf0RsRbj7Tr33bTX9zdEdXaV+Tbyg7VpfpljyJdTu56tjP6Dnsxi4W2Rdi5VN+Etb9mQ2HRwFuIjd8hp+tU0Z1mtqpT+qu1zrqEgXIxrzJG3b5pofrbX5atvJPnYmpvl/hfF+tEOfcF9JF+nFOY5j4Bv3gBP9znNveGEWJ36m9ueY7s9EMFbBjbOCqtQ9wpK8BkZ/CuPY7s8YLVulnTlUZWGdZ7lHO8/4SKwvf6b7t+WMvlItop4MtpdxQ37E+Pq1oiDRgnuvzF6E67q8nNjH1XgijLmy44d+e1/oCpOjb3+GteZaAd4Wv0LbfIfYyp0/wLJZEmbV8hX/vP0vJ2QyZh9gO8bor73SGCvZVR/Rz5JrJWSsUfR1z4ZYj9ciTi9rEgzeOdBKqW9Pw3jTm7E6XvW63d+oShMM3lPaOi7zr+oqOdF6yTgRvPgPdpRh22zf+DFN7Y3IZ3R8KalDY65MTNtd9ntqRCsRGub+Bq6fcUdaEq0MfGeuJe/N8iN/1eqpxj0D0bK7roTUwH94jUmbv0pbY1dlfRYSt7hy6/OlC0rFf6QpMdkcjdmRn1dhvWthoFLK2KrpmZrE0itIP5Sq8e8rzZVaf83751KU11slZZhhYKJTm3btbBhuAt0XE3c1d3jVssuUVcdmkHwZU1Xk1o/rgglTuJt7/0hTD/I/OfnIH6cUMsosRcu4csFnCKv46LTVTsrmvYloGYVFflZ2665usLxbOm9lCWGl/kZSXlK/4c8qZcooMdgP1s8SwiqSN+nLjjMG4pVRUuRnq2WJwXumCjLP3C/RU3SAJTdFTxmtdS3Wb9CNnDZ9PFiHS1gst9ZGvTO+hugeB/dFe02nw7oWC0IaXJ0Lag4AAAAAAAAAAAAAAADWYMBmCrNpJ7PxKzWH+sgi/+abFi/Mb3Bo45EqGkLH6gatzXEg57mrDyx5Fa9fqjqcRmHp41L/TyoX8YmPXcjkNSqfW2ntFmv4DtVwVVZqr1z42b0qFZi/Yz5mP8L8R7/my1UMVLEOOgwfyyrrsaILcIv7Bdr2RQlTi2bmQXrWKLsnTGfSHMi8FaSSB0W+88RNIbOpWpKxsfsTh6whzuQ8sxc8XE2ar5lbB45LLE0uknrgMoF3YPqmFZYC2wy05WRCjc0T1uONMYfUaOY+1nxj/QyLlWfCoFut2n7CwajHhId8lcF7Ctfmr2PzHhfZ+rvA17JYwsqKnukT/WkUozq4fjUMGWXma2zIJuE6i1U4KbmDhi3kzVfJGWgV+vOWL+zwGgvfLquo+ZvQPw/y41RIyFBjsRY4jx8+hRphuYfTvfr8TOin8dRk+kEAAHgLhR5tcS8cPMs6LmsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFBqm3/L67r+3357IAMwgb/FGCkdtOnDvQpezJ/+JFAVhJQt1rZtoSA6JUIP+HrqLFaoJyQCUap7Mc+AhcKK/hq1cIjyxVSPsTKquq7LExCDql+LVFjN1sVoa9s2NwXvK7yP9rfC0Fy5P6GbX06FsIRasdHyAyx4NxXCQh8gp+zHSnFdV9SGoT9QcouFXKCKaovl+rGiRothOyihxfLMVV46uLJA1VqsqJ/dBHqWbEjm4HMpWyxUAg00+rGiC7OiflGGXAAAAAAAAAAAALAqRe9lrdsddygo1bMeq5njOOznfd+9cDdk1L3GpgkSBuyErsJVlfnqhcA7kFqs4kx01ZSgNSEp6wWfzgNdoUumK/QsmQmPBobx0ejjzO4KDcXuT9g/2mj0p6sxW1iuQSqqYd/3qO0phqOzx3nAYqX6r8406f6W4pkxlmtXjuMYogms1FI84G6wChhoY+zAH7u1CM8M3uH1PNMV1r70jU0WJvDYW2EmJBXYlj48wgdMQjPf94k87HlPQaf26Sw6ePfsE+YKAAAAAAAAAAAAAAAAAOAj+Ae672qUimobMgAAAABJRU5ErkJggg==","sha256":"e0eca9b03e6a410412aa2e2cb3bf47275afe7a140b443654d7022e3395f0a2cf","preserve":[]},"notification-24-dark":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAALXElEQVR4nO2daZKEKBBGcWKuqIfUQzo/6GZo1mQRUd+Ljo4qChHhM8FkUSkAAAAAAAAAAACAj7LcnQGo5DxP83lZFjtQf4199r9ewT/XJQ3XYavK/zoDCOvBLMtSZHVG6u/fYWeCi7i0RatmqLDWdTX/j+Mw/591inmo6Cqd5zmnEP9nXdd9389f9n1PRLZjOuz7rnXQSPoU2WuJHevTJbddMFlyQhKfzf8Ju2VKRWoxWH+J+i6q+wRCWSQEITncpjqrV2BnKft52qtQKqkVeUyfOm0VGZsW6dvcbrR0Nlo+n7MJK10N8phBKrRVegpfE2Py2Rc/S5JwJ849WQ+SrQM7cmltVdRZhSZOr0CvzuRFxK4oGJ7+eifCFsfEr6vyogsuagRtHFlUpHB7U/gS5FVoDqmordJq66LdCnXOYK7mR+TH6liU27YZx1LM0bCuq8T5FNPfcRz68HVdY3Gyp4j9ahKHVoruaXOU0B9RbRJiuXKOjVk1Ey2WDo1dI1eNFdqWyQ60v2Yrz/HB2vWdMFeJMwZPkfgJeV1Lykb9xTlQK0OjQ3aLWCImcsKWxA73M5+OKemo9RobABe/vZDXq022Cu1E0o1d4ieHWFbTAhUmDjFETeFxHKZp058rziS86bt3jdMJyk2Rtr49clSJfde1xy9NrRTp7AbnaeiipiHYM5sHra26+6qFUgWk41+qJ8NcE/2Eeu0l64p0xtutJ6pKTSgsU20x03W7VaMjL2GcsISuRfshf1kW+5Dq7l0iS3UHjjRapfOP0/FLU6vm2hmk9kxOpdS2bbZuYrf+vu/m4tuVlDYwTpY0JsMJx31jriBM2t3gOzZjt3jaF5BA7hGQeEbsDDunDvsehk8NKD1vOv5dV5EnXVtyrVSPqPRykDZe6TBKz5uOP+Aq+vex7m0+HKMVG5ZxXCfO8ADcRoXF8u1QYnjb7oeZWrcPlxybyKedfuLwxFkuKtgYpedNx7/rKvLUCUuTHSs84wN5tlHJniXxq1FP3eHjbZtTMo3xS1MbR/vIbrbast2v6rPYI+J1KYx/KjSnDobL49elVsElfqxGH4FwdK/6LO3+1UnGnXqJ4IrULpyPVXegPf9TErk6/WrGjxXG6OvqnGKFtNA5VNrE2H2XxjmiMYQXIskh9CdY636hN64mDUZrWRgYtIJMyZoLvz4SQzTZChNWeaxqswpOa8IfKvBhGKeIpmbVuB8lHZegr1KyIYw+UB5TebvNCDtV/jhmaQoAAAAAAAAAAAAAABMMaL+aH1f+uir1O+pwTL3auxc1wlrXXTmDM8dxHJdMJsnOWJ+WPzm3haXpUWL+9nGxDeXMsNiwoisT1rpn5oIdW08TGBuc7r5ytS+Z4erVGg5vsF6mcHRp2IvI09smjim9Ah1kVaXppa3ELgkzCys20O5GMPKq1db597VytoBM+dx4Z0pnkApVVRTz9QSbnp9A0w5Wzcax5RLTZWK/uAGbFYqEFdTKsS0x49RFW74Bt2lP/wpsm5HdPPe39NZ1LZ4/KJFFbN8AeQot5PduCF62kdSxLUEZrevesTt/+w4zEmqq6tjUuqt1XZVoo+jguWK9dfurns9u9y4msFh1Oeiabz298yl7gQZrOjgH9TgOpXTk+uvKKtJEGHlz5oTVUpFtIvCrwayKDn41gQM6EKWYlZKB38p1JelgxUrA35bRKa5e8/ozTeHacCetaj1U/1vEFIS97tR53lbDnxzt3lXs18gD2raup74s+RRq+/PZsB7Q8Vl0XC0yr8VKJvyjLbMz2+ptBTiJ3XIqfrZFGcZraqTfq7mca6tIGy0afScty2Kbn3Vd9VdTT+a20zH1/xn6+8EGfcB5JU2kE2ff945P3B129DuOreKBWZz4EVufo5s/HUFbBTvODKpS1whL8hgY/MmPY5o/bbRMkTbmUOWFdRz5Fu04wj2xtvzp5t9cZ/CRahL1JDCtjB3yJ8bPrwUXErxw55HZiXCep5MTc7tqT4Q2V6b/0G7vM01htPftjrCWHCvAWeKXqZvfEFO44ztYJkvCrBp+4h+XvzkhkTFzA5s+Rnvp5fpY0aZ6D36WHCshYY2Cj3smxHi8JnF6GZOgcfaBVkr9ehr6m96E1XGK127+ehWaoPMe09Z+6r+io+QEyyXhRHDi39hQ+nWz/OLG1KXXI5/B/qWkDLW50jFNc9nuqRHNRKgY++s4f8buaUm00vGZuZS0N8uN/FOqh+p3DwSv3XYlxDr+3UtMWv1F2uo7K+tZSNziyi7Pl04oFb+kKTLYHIzZkJ9XYbxrfqBSStuq4ZkaxNQzSB9KUf/3leZKzT/n/blk5fVWSWlGGJjg0KaZO+uH60D7wcSeze0fNe00ZdWwGCR9jbEissvHdsH4KVzNtS9pakH+yslbXk4ppJdZCl7jzBc+QljZW6eudGI2700Er1F4yffKbt7ZDYZ3S+etTCGs2DuS0pL6wmuVEtcoMdg3ls8UwsqSNunT9jM64lyj5JLvLZYpOu+JIkjccx/RU7CDJTdFdxmteS3WF3Qjp04fN5bhFBbLLrVez4yvIbjGwX7QntPpMK/FAp8KV+eEmgMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgD8s4095nuf/p19uyAAMIP8izJgO6vRhHwUvpsOLMFEV+OQt1rIsviAaJUIL+HrKLJavJyQCQYpbMceA+cIK/hq0cIjyxRT3sRKqOs/TERCdqs8iFVa1ddHaWpbFTsH5Cu+j/qnQN1f2T+jm4xQIS6gVEy3dwYJ3UyAs9AFy8n6sGOd5Bm0Y+gMlt1jIBYootli2HytotOi2gxJaLMdcpaWDKwtUqcUK+tl1oGPJumQOnkveYqESqKDSjxWcmBX0i9LlAgAAAAAAAPga+AJasb0t9+ZkKqSe96JRHQCRsILLv16praz5wT4JKRvSia2EBnDI33b+PRq8ayvWhFWcKKtyHSixK35S2VWTwQiSlW0f3K6iZjHF8osJSU+VEU6kiZV4bO58tckcvEztm/OIOsx5Dw5C+1Nogr8mEozVhzydLI6UswvU0hF6Xf47KNu74R1dV0cfX6jm8YieCv0uSPCpUGKHSkkYlRbGi+lr8i2bj3X1U+EYQ/i1Or6Fgo3X/CnIDmlZFIlmTN3HHgavO9d36LDx2kg6iuBrNT2Y4qdCSdW2dLZiE6C7I7+cK877ekQ1l/UBpiOUbo4Ve/ZMODCLWmd5brOH2x2DmG/2m3uDiSxWdolE1uWTTbAiG9W2LXjgdYaEBSaz4HvG4XFM13lHUu9gLmGhqtcwl7AM9EIAAADg0dzZlXnHJBwIUr8H6VSg0dloElZRdVL3n+JOi4XCXkzNIHR2TYtwAUzRah/hyDFinYSarSIT/vHGBTDfXNDySupfeZJdsiKPrBEuaPnacpeH0rprciICC2C+TIGwhPs19F3rBw8l3xQ6Pegr1ni1gxxnQzqDtHThV6wjdR3jzwgJ6tcVpmPW5of++EsQuRtKK/uWBTBMaJ6KgtfK+TVnP/ZnXVCJyIkIQuOHpGajrPMeCwn+VOFtqt6pgd4VAAAAAAAAAAAAlJP1K5Z6tHFUglK3LKbY99183rbNCbdDep2rb5ogYfSmILaq9FcnBN6B/LVymQhFg3XGhMSsFzydm1dCJ5pCx5Lp8GCgHx+N3s49+2Nlmz9h+2ii0Z7Oxmhh2QYpq4Zt24K2JxuOzm7nBosVa78a06T5m4p7+li2Xdn3vYsmsFJTcYO7wSigo40xHX/s1iRMurktPJ17msLSh76+ycIAbnsqTITEAuvSh1t4wCA0431PZNI9SGnUns6knXfHPmGuAAAAAAAAAAAAAAAAAAAewX9V6gI56qAP3AAAAABJRU5ErkJggg==","sha256":"9d6dc907929bfa5d1864860f2a1c72b97980d7afc59ca83afdceab0a6caea478","preserve":[]},"timeline-24-dark":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAALC0lEQVR4nO2da7KsKhJGsaOnqIOUQVb/oIrmIGDySEX3WnHjxj4W8kg+UkAEYwAAAAAAAAAAAAD+KMvdGajg8/mE/1yW5fjT8aK7UggQXezJmzyecvja2Cbkv3dnQEqkKnelwfRtd5UjHBi+NrZp+c/dGRARmjvpcu4CVeV4hrA8TlWdLudN9Tctj3kURkzS/4g6cJ3ha2ObmYd5rFFGf0flzcwzhBX1qxz9UZ3Sk9Af5xnCMsYsyxJporPKT29HUj08RliOSF5tdS90WpN04x7KMzrv0UzmsizXuBO01czDPJacsvJQjDYPE5aTS0E0U3WMxvb9nzWSeIawcv0qf/04bDxeL8SpwVgRPEhSjmcIy6R0EF05DXAxY1Pn2Q0AAAAAAAAAAAAAAAAAAAAAAAAAAJNz24LXdV3Df1pr2yLx8eQitNa2RT4En0Ol7IUWqMIleqNlxrPv+ydFlYHWdU1GkqPN+j3kijkqe7UWmMcy41nXtWzufd8lkUxuxCpJtWVvlKquNIsWQluUI2muM49Euz105lBYx/12CNG2iSLyFlaw7Chr7vuu0UavfDYNSShkuDWuoMriudYzto1+FPz/wByW8zb2OegYa4orqDV3Ulgaphzr/4fr/sq0PgrNTPdL6FEPHY1OgBtJjIpKw/+NjfA9tDWso0E1GqhnSEmV8pYTq0ZaQ+xwBc1qOAprrAVPk6tF4zHtSaZ4WULT0eNjoppWrTZHZ2FV85Z0WsNT0Xjsju9jjR3MXzB315OEdvaO8Q9P0Vq7bdvYOM3wrSKVpogkbNsWvvlaf5zeuK5r8yuzqsL614Lyzn6zMeUl0lDVYIY8ttoehbksNaRYRVuhqmwVaUvYzWgu0ShGPgo1fJWk5RXanOrbe2F5k88a+aKGBqvOsGbhATv6lX21xqqY48vyfd+bHVsue8Jn0LPfEA9B41HoaVhsI8xPlGL5WRMm1/9UaohBEv7zawmON0hTWOyyRXKRR44kDOl+8lSlWKuVqsBlPyeUfphDSfhcTh6ssH6n1fDE6ZyaD6OShPfVUxU4R1UkQ8x7jbwG97EKkyJKS4Q739NFMxTCFJuTa2PsvGBPf1HO+M57bhCkNF/SafTmXMmHhJ0BGhKVxKOtLZWzdKy1y7J4X6I6Bddj6wfMDarhtKVnAcVDmu79PKaMngd9EKraesA81pw8eIQVoLGSzPFHhZXsZAj9671fKQ6PU6mz9Xhh9bw/btPW+z71fMaymYvp/Iw4smm0ROLIK3tmGo7wDcIa+4n6tm2RvFwS27Yty3Kvo9JLfbi2nnF0b5lt20J91Npo3/fo0LZpx7OupKdPLp/5qk+r5yyyiOaXa9GrQOHyPfmrnrb2OiTmNpvk7joaR26EBgvMQoMRC7cI5SWxaVvvdUjMkkhyJT2u7WlO4jNaWFP3sQo2NbKxjKp774+8/33UsiyuU+j+yAW7IDMR8wpLUs7btXXKkNoqF2HOHuGzhXXv9LewOgvqb55A8j3IgUsVJlSnlKo+lrDXOaQT01Y3nVvoNBcwmW65zyBJqMECs1AlLHm15WTRHIMfhIYBkqkI4/8cKr5ZlIUbkzkc1T5recM8lrO1f9PSMKEVPgWS0xnuyufzOc6dClPZ971heskcliKWl257OzQk9GBqpxuEbbqfqhyGJRry/UiBSEZ6CQ2X4Lydd3NVd7K2iYdhtHMYudJrEhrC1MK65o2vT6VtzbteJi+bR9BIZWphGX1t9dtUr/ovG/9rGHl2YWm32iE21cjhZe7q7y5NPl0j1RPzkHg0RHDMm4Yd9OT7AGEZHZuOjXN4bBek8p4vSiSD8/4Z5J7Rdc+9o3I4ZKXNKRd8s3oppwUu3679CX/tPFZbDAXk0609qbxNVaZmL5fmSDrj789hm/ov27TitdPxybWdDZtVyM1aG/mQ/bHkS1g7N+q4JpVabjuvcCC5ry4n+U6r8FHowEHZmjoV0adiJrADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAiHn3xypsdDbnCX1JvhtWrasxv52rrLW2a0tZbxlvh3ALrqNxoi3X7I+ePJzSIqx13U20wVe3sQ5JnBypHR0PPiH/7IEWCuuLtU07FkeWcfsoR9LxximYUW+Tc0fd6V/rntnadV3X9WOMsduY+n70PpmJzFtrzK8W1/0bav8YW127VZYpn8Gpqi2psBJeKhls/wz3Xs8iqvhEzdllXdevD1v31XSZq6CM001T933Xc/yiAwSEqvKh11X3nKppO1jHrkwymLXWbptxv+Z3KD1NoipkMj96TwaBsL7NK8Zui/tPfoucqIaWAHdoe0/kStQeN2et15Z0P+Nzd5gP6ewW3XKnsJLuJ/TeSU8+0Gn5g3Sf0vFK1vcndfKAtdu376UvLPfHZW3yRFhZfYRFyhSvWVvJk3Mnl1c42s/9mt4r+1vTdQ/EWqLjhqOMaXDmsXoSVsj0cfw8p84iXJ7zvWlX03WHu/orGhboj7MorP4cN8UgOaXI/E4Wic6M8OdBNJwl0YzEXR3/9nzvWk8Kfvx1/9Gpg+PToD/OkrBWQRsq0xbDac/XPxnN7xx57xK8RcIw9xLmIZ0fK/VYSjijhWY03SdZzOix3BDGH9ThBoOFobv7w0vqmlcWQo5KmkHrIc5o4YBxXdf+Pn7dzPtluEKGxXOeyf/TFd4/77Ztc8OuqQ53THaA3MUG3fc0lTDF5GSbl/sQd2UahZWYTbZju+re/fiWlJzucxrKDXluJ+ecmqe8l2VJdn2OCj62w0hAIa6J+ru2bfO+vyGTjqKwMnKxJk7PGpvuTjXlLOpFZrL2ohOtvoUVleV0fJAM5gY6udhcf8MYs++705YXVrP7L/WxjgLy2Tm/Uo6hj6RxfYs8FeVsfNvkaFOdtrpjT9Q5Nvf/UGENFDvvuZwdE8sl3+RRTi2SbEZhL94d/XjZqDDZfTHFM8P/+ffPY411wKeLF6JsOHc1Kg9nE6RJx3t46g18DpqiB/ZOW3jXvc/KZD1FF3/vJ0aeTe//LmgrslU4pPC+qkdn513I3Bos//r5NEAzkSsWlrPfKG3kpklDxxnXtF8JUr8wS5i6kZnRhfFq6++8C+reF76G/7+6/zNElXce2lvVxmPbFyBYNmNttUQabnk+jS933zS8DZA+rSrW+lnLClKPZHbgfaoytR9TZNe8/xi15v3RVA3RX6kqM+1XOi/gVF5vlZTjCgeTe42Q/Mm/XgjHw+Go6njXPC8Hj5TWyRQplzFnotA+/tdj4AuY9CW0+X2fNDbk9YxyS8kyzlzwK4R12nTarJPzeW8iWUZhke+Vnejzr3t5t3TeyhTC8ktsj9dP79LM1/0Uyihx2DfaZwphnVJ26dP2MwYSlVFS5HvNMkXnvWCCQpv7I3pKdrDkrugupzWvx/oLupHTpo8bbTiFx4r25Yl+/eMKOzot8+9Ae85Jh3k9FhxpmOqcUHMAAAAAAAAAAAAAAAAAAAAAAABQwZLcmhJezHLJl/2sIAUVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKACwgIVEBaogLBABYQFKiAsUAFhgQoIC1RAWKDC/wBMGKVMLa4RxQAAAABJRU5ErkJggg==","sha256":"37df396cd10bd8fa90590c90d61336cf4036408261e7c97697c70c79103b775f","preserve":[{"x":0,"y":171,"width":200,"height":57}]},"idle-12-dark":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAALdElEQVR4nO2dW9akKgyF9ayeIg4SBlnngS7a4ma4hYD7e+jVv6WCYRsiRDwOAAAAAAAAAAAAAAAAeCnn7AoU8Pl87n+e5xn+FG60WzI7eBtb6kY/T37/0rMJ5M/sClDxVGW3VJi+7qj8CTvuX3o2sfw3uwIk7uaOupxZQFUp1hCWw6qq0eXs1H5iWaYr9BASf3gBXOP+pWeTzGIeq5fR92g8yawhLC+usrSf6pGWgl7OGsI6juM8T08TjU3+eDgk1cIywrJ48qpre6LTEhLGLcoawbs3knmeJ487gbaqWcxj0ckrD4oZzWLCsnLJiEZUYNQ39l/rSWINYaXiKrc9fGwMt2fOOYK+IlhIUpY1hHXEdOBtedyBmb6lo+8GAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC0IX0NE6WU+78xZmI1bE3u9XHYihljOtYwU1yKaOkTjSYRrfUnhtaasxpKqVRNUrTXsLREhirtgFLq0VJF93F1NVoauLotu6uqsT6bQDTraDP1at3SG2CQquoqsw9FZh1npr6tW1TPjuWGvNRp8YcyXapBgagtSgzQyAiLyaUumhkhrHE9EUVbQ/tBS3eLyaX6Nu0urNEO47ECEFY3Wtqyu7A6tl9dhUdX4MMrrGnLcdsecFbpHgw1cUOsYCDt/U5HKTBEzY65dehlMQoTPJbWWo6vOgqnTRYqy4N5bodbWFprUT0Ccw+VKouhDjsLS5qqDnYXMuvy+06QU+ATlkBVHbUtbb5UHMsfBhhjrutiLpSPvnFol+apCJlDIXaZM2g8/L3ITAUprVXKvZWeJzwD84UzsMane4vwmr9XbJHp+67risolhVIK+Xd94PFYmVIaO6DPk26KelWvMi3HioXJYxljRkfu+ba3jXf/nGR71m/RDh25a8tlRbOVLo4i91B641ZkCBb5ie7pCdUHppD50M1B31mLaom4o6p1kKI6UbFjnCBHXnzjWOPG6IpMOc7uEvojO7UvIQ5jHXm/ritj/fyvvagQ1oha3avRXesSMke45wqv6wpHgY0x53ky3/Hdm1OCx3LY8GBitzhhHMvKyM3+8k9jiWJo22ut7w/CnEwbIH25ntjQWk+ZKJyWQToXIY9Ox/iazIq3XiesF7rJKVnROwirSCsvFNYxI1dnE2ER5eJ2e6G8mLW1g7AO2hjY5vluTzD3hpsI6/iOkKXWiIqOn0mAs1ac2toqH2vRIYzrunj6Kc48sH08VindTVydh0OceLB+9/zCMwO2CfR5fuaF8ygn7JKHU7qUYXtW9CC26grn0iVz0IZc3sgTsqJb4fRYchL9GhGyYJ3He2OsIijtQW+zN/iM93aFRa1r+6bMIb08gZfP3l2Cb9B0BM6usKi4xxLp50n1R9GumZJqXFR0k73WpYuwXHquJdMwvRY+bX80ywd8HS8ha/59aRFWfi3TqCYq3u/wlFp3hopqhHfIlI8brEq1sIgNHJZY1DBdCPUxq+gXUS2suqOKSuyFV4GJRQ9lh+EG+o0Y7sk8M+09lHG6kG3XxxpH43uFnBaHsLZlorDmJl9AWNywtffEhDD+oiGs42Cxe1S7PO09xVO+Tlj5tIJxpM7PoC28VziToRnxmTOPzsSXmZDNDX1UqXoZoF4VoEPMjOheLrHoV0C3b91RlDmNvm1c1LR9F8oqtv7eUIxbPYDO+U3KuqbttbpfRdH7kzdudYpBab/Q0saNfVB10XJW9Juzxs0jqeUGHp+cowe2PG+rL5SdW75YIarodoQKSyCZNh69dLEtN3WnDS0aAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAO4IM0iX5l02qft8AMFK+KgBhrYSfnazSb+PMVpgkYSmlYpYy5jpk3IUTiafbZ4RlmScvEcJSmrTYnLlE1Jaf3Is6j9o6jJnxlv3kpiJK6s7b5FXynqA6Uu8RsRttWiMppVNWeMYYY/Zf6yIvqWgf9/cQpY4jOJa3W5wjrCZVWV6grcyLhKRj/V6StU+csIxRB1UdyUh/G1pU9XdPcx3HfX9Wi3F7rD6qcmzqtzoulKq0/ukWuTpEdo/Vd8kKGQtg9KVUVZ/sol9+90deDKIRVmHRhxXoTzEVz5X78aCVH6e+3/cKKTeKMU5S5jqp46Ib+a1Sd2UXdcoviGWM+Qm2WJwWn7AU4V4xP8Gm/2fLmRflMR5yEnkYm7i4nZY4j5X7s+XMO3J3VAQn9POEOKI+d7iENbrtX6kt7wN3D3uz6opLWKN7qz16Q08clOgqv+X3bD+Ph6PDLHisVQmVUTarOBh8QGBJUmNX+TEtTiCs9ch7JiGrJksX1pYzNo3kYykhi7xLElY0VjUG6aMDGG5SLmERxJFyTiSnBfE9wttFMgmLOIYu9vw8ED/sm/+gV+rXn7OZ4UvDC/JYos8vibwm0r/eZbpNV3g8t30qDe05Pe1NqrKcZzz7I7X914Z75WM991Yq9i5AdGPpmZclM3ZwnufdORljUqqyJzpuu/apXBbWDFJS7tQtKZSYbrrZezsd00f/nvDH7OZg+ZbTn9EF3DHX+awtpZQqGD7eTFXd8QMJrrCBfRyr74XtGF2F7qRuMF3pj9KfsBPcM+e95/vym75JcSS0VSavyM7GmqypZmQmjLz30da+qrLk3kclEMkj4v1MJmuM5TDmUgfehK7BaetJecZ762t0xTywdoN0umQr8K85I6KRsNpMnkZtTVnJSFJTYX2sNNXaevX6WIBIkbywoh8oJqMwIWuQAgAAAC8HMdYm5AdON0dr/cmitRbykgkPSqnUhSul7Eb7aypat7tFLclyBQJ4VNULjRJee+anUFuPJhXyjuFYiKp6j7Ccu4pe+6NZiDfqLG1Jeq/wZbQsX5vpHMM9y6rVCa7VZt7gk3tAEVZpbtYUbUn0WC95rqnObS+9S6fc1Uz5WHS3b3jz0WbR0tgpYxpjUs5MKbWnVaOR5uxKzSRqkLsmUsF7PuSn7MDDzK7QjtMg/HIQA6z8gVGXv62RKUOjs+vIyqMFUjtQfL+E/kHKU6F14NveWL/0vczQPzW+iNEFWU+FL+kZWz/rtQIcT4Wlgy65NQj2ZbNgQJbHsjgT2xnWzPzrKrevh7RqLzz3n4/co5Gm99h8P5sXnC5nlFJr3C8ztf1OdMTBqtmZ7n7Uijb8h6cGe51RE9hf3fW71JHM/mvZhSql2DWGT3x0YXnb71KbYIW+hP1Xygr2P8f3ysP79W7iNwsrlEVqH7vdKcyGGYOsx/j1L6XsBRAff+xu7sYyxrjrt4uMXddl/7UMq3h/utc2vFe9He42v9/b9j9rWe+HqBO2ZG5BLyBwf0oLfutQWVIeKxM82NNmEkq9Y+9dwZJkAqPo9k/6ex6ZXzcjJY7oT4/2vLsoN5PmesZV59boScmeBVPnYa7/FDJmKbVn1GIuuqJYvgKJ41iPXb43mb/erdZGaUgU3f8e766aqpTqCqPkVeLdXptFXXcyHusoMWnUCbmZWe+Je714i2gI4lw10XxL82gciklTZrG/hidZ1Yz54IDodVTwJt2q5shCafK8tlJm8RJJ7sbs6PgnTPeGUVFdH+/Gt7rVTB7OUJnLrLCnCjKVwy0AAAAAAACAd8DxVBh97rXDweFP13XZjffxYrdb9KiFJ+fT5K8xZaK7fdyv4c4MSJzSsdBHp7Ycx/KIXqPkC+d4meLx1qm7mVI+byei10i8ZK31RF8u12M59pbOrogQlv4Sbn88amS95pO5RorDnmgfEcJ6JO/StwzePbxrpFzyXLPM+aycR8YEmXvuJXqKBljyn2zkeqw36IZOnT4m2lCEx7pbrdcz4zaETuv4fdCe+/SXQq7HAiEVQ50CNQcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABU/geMOYU19vaMLgAAAABJRU5ErkJggg==","sha256":"46f8d15b4f186ae711670524b1f1b7c015cb5b8a72e5c44bef65774e7125b8fa","preserve":[]},"music-12-dark":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAAMAUlEQVR4nO2daZKlKhCF8UVvURcpi/T9oIqgGJIEEkn1fNHRccuLyHBMkvEaAwAAAAAAAAAAAAAAAB9lW50A0Ml1Xf7ztm3hRfdn6XP65wz+mxc1mEeoqvRPDUBYD2bbtiarc6f+/t32JDCJqS1aN08S1r7v/oO11hjj/v8sHa7SdV06hdjGvu/neV6/nOfZHc9V4DxPL7jWe1PoqLThkx1dIT77/xW6ZVxCSXXXHFMWhGT5qnqitgxDTOavsDxLUjtKVlW0AlKajE025qYYOlK4iqqAqp+vJwqrpKrWamvVRGpsiJSIpHAVabI516Mwa5LeB8dCMKPq0EQa+VuFZcqNWvY6/ad2mO0OM7ZWQWRlMR4DWAzfm+HE1meu0vgHbwfdiA1p8KuEM45Sis1a68au9n0vdd+O4/BhsuanNPrlIwdaaDIw1dgI48cJ5sVUDQC009Sr93dFcvT1XZJpaqLoR5RStf9yT+GAIVqFRQyfloSVPpSWIMeOVgfuQR9iqxuO42gKn63O1joed4mcH4bGURwxYVlrvbbcZ6LWq7N72fj5iembOFJuukpmuy98a2ytSK5usNaGPb7l9dSagPM8dc78tyqADj9VT541C/3U9uoVtolPVJVZuII0qy1BwfXZS/QWpVgmrMgJq7plrXRHpU1YreuP6fCtsWmEP2rAubFpVYwXRxqVG19wPcHSGIRwQUjQmjY6vOac1pEVVvbGqrDM31WszClqbUbLQFgh4sLiL7caTCGENY7G7V8l9yitb44Czl8EUgY0UDUn3tdJ51WyN0a2pLr6OW0ooyay9JTJBdPD4yzWRGhhZb/195aq3EuH+Jbw3Dm367RtaRGNhG+NTRe0sOhK7dgEEcXfHYNCB8uUpZC9SITvi62DNT5WtfK6R6H8fGW3PtTOCqRIiWBGbBqdd0frcgnzdwlonz46HroQ2aFO2djuFha/vjsWCkdD+R23qzVX2y/Z6/zwfbHpIuvleC+K6d/wFz2XFngxb9fps4M8qSzCgz2YVVsVB62J6PwIvijBCNPtnl8vkG1o3Leco2N8PD42d53ffmVj0Nz8AQAAAAAAAAAAAAAAAHgi6mccH87PZNG+G/M7a2Qld7mppUdY+36aaHLNWmunLDgZP8dhFX9SHgrLIVFifjaMuOKvu69uK7o2Ye1nZS2YPSRNYOmMofAAEoVUprT3YMp8wHr5wnGlER5fGG79TcvwntJr0EFVVQ4pbZUOejS6hZWqKjUqxgTy6tXW9fdn5UIB+fJZ+GZyF/oxVdUU8vVkm56fi74d7D1jIowwG4Y4U+6GIypYwspqxR5byTiJaCs14CHj8c8gtBl0Iq21v6W373vzGkOOLNICbI1hhPr5WNlse0nZY8vKaN9PQXde9ryQSfRUlT3Mfpp9303e6eY8q+Sth3+6Bcehd6HAYvWlQDTdbgnoU84LzdZ0dp2qtdYYF7g/X1VFDm4w6aMmrJGKHBNBdkN9uFk+e3yozhORXSLzqWrXFcfBKpVAGN6vp432lzckpUylKdwH3qTd7NbIvyK+IMLju6P+trm95xh6V6VvCx20Y98vly3+Guvw8zWwHzAasxDcUaLXYpER/2hr27b0RyiqP11xJ1HFa9u44UdNvfSlmku9G1adaNybtG1baH72fXd/+nryr50L6f7X4O/3nZAzDqeJjMKc5ynY4xY4Ndnao6PDzI7clvbwuObPBXBWIdqwOilJTcwQFqcbmP0qDeObP2e0fJEOptDUhWVtvUWzNu+JjaXPNf8+n9kulRL1EPhWJrzyJ8TPtw0ZyWY86jJHAa7rilLiX1c3EuHMlfcfxu19pSkset/xDGvLvQxCDyn1lrLD2SYo3PsdLJ8kZlI9P+GtvImlR0Sj7qF7gb2PMV56NR+r2FSf2c+cezkQ1ijb3fNX/IiXkkEv+/dHFXxvI6DZYjEhrE5UvGHzJ1VoDOe9pK3zcv+a7uKTLRdiECE933tVQ5nWTekQjp/Sk0hn1r/klKEzVy6kby7HR2pYKxE65v4E18+EnhZHK4J95lbo0aw48E+pWiP3DmTzHg4llBx/8RLjVn+TtmRXZT0LzrC4CcvzpQtKucMNpcnmbMiB9LwKP7qWXjTGOFt1e6JuQvUK0ofS5P++0lwZ/Wven0tVXm+VlOMOA5Od2vRrZ9Pr7mLYMQlXc6d3qV2mbAY2g9B5LBVRWD7hEEwaw2wkfwhTFrdmQTbk/UiZpWweNWf8DmFVX52+0inZvDeRzSMzy2tlp3d1g+fd0nkrKoRV+h0lWlJf+OklIo8cg72wfFQIqwpt0tX6GYJEeeRkeW2xqHDeiSIg3rmP6CnrYPFN0SqjpddifUE3fPr0sbAMVVissNSk+oyvIbvHIexo6xx00GuxQErHUKdCzQEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACgiMBv6bhfkP+JLvkRUfBN6ofbhrpJeaKSfI6kEo9XKwWH24IpQFjC0Ab+O7Sd8w47nwIlZZn7AwIl5yO9nvo9WU+oGuG2be4z/x1I703jB63Magqv64pe5fBKtc6yOksjJG7sgBM/YPJsH0tV3ae29su0NYVRkZUMD9HSXddFm6tsACLClJEmrCO14w99JXMtli9uZvV0RChoHiAOQZY1he+uRbSG64cbSp2y7ONUVViYGFUJ04BG5x2V9AJU/BAmnwc1oFXH/93MtVhh94oTnj++1RTtDKKOasiqJKliisUKvSXCbQqD0fVBRAh0otHHcjzl1SfS+eV3YJaPlQ5jDgolOy66SnxfVgwAAAAAAAAAAFDlGWNFT0HJaIgG9A6QgkfzgEnod2xweEcu+LTthI5KBAtzCUqbiz7CA5pC5vpmtXxQVeYRTaF5rKQi3pELJg+wWOCJCFssYkOzSVYoRLuWq9cN6bhUF8jTO6dLkRAJqJJdlkhnlvNQOvFKegkrLVbJ+eA4JWmY6uJSzs5pYvc2P21NZNNZTUb23htSy+eRTWFVkSOS7X56SrRS+VMLl4d2Qo9TKmhmBVS3rXL2tZZ2Pzdtvx6BeVxKdnfGzUnl80iLVYW/r6EpzJ2nM0gNsqxS2DOGG6pUnW5wM0M7oTXXnGDaNGdTLe9sCtNNfwsT801e0hSWZi1FJAVddjDxRL9JMd/PksGhSRt0ibyURsv6mGixbqiA6iNG0rBk+zVzE3kfLkI3bBGNYtCDGh0IW6x7Wo3q6Bcar+XIN4UzvJzqU+jndqch6/jPVm360Bn9j1JxST0Ib7YkSiaANfDO4QYNvKn70gGEBaYAYQEAAAAAAAAAAAAAAD7Lp+ezOJzn6T4cx7E2Jc+iuh6LnPCqfEmqdqNu3hoVj+rXxkuWJksBgUoBYVWAwvp4p7Aiw5PaIX8lG8x/Po4ja8PCkJHyiK8+xRdXN0Sqyl7h357KsS/al/FFYXkiixL+eRxH1t6EBqxkq8KvPqutdzaFfERaq/M8v9zqZfm0sLoF4e+irdqX+WJTGLnh0MEMPmqxom6gbFuGZtE8VFhSw5jpKAM/AaWBDOCQbwovs7l/4jF7oj5Xa+2KN3+l5365ka1Wf8NcYZuYxuYKs3VW7eQTJip7b3aANL2dfu43bZuYxZpqolLS6olGobrvbX00/dyPyChFxmL1qEp0dYN+YLHARD6iKgNhgUlAWPfxHXNl4GOBScBigSlAWGAKj5zSASE6BzKeKixitmRh+eqs4yWgKQRTeKrFSqfnYCRU8VRhMcnumSlNFYvvvWl6ED013pqM5ZuFXtsUpmtj6EUsxLeye2/6dgTxs9Oa8UnICGujx1GXQryv0U6b7O4akb03nAeVAqff8h/alEhZxJrCzVw3r5yhiSry6Wvu+NlRknFJH8vZLT3yki3T5dLkJ2B5Us0M5903i2sVpqFwBXmWqszre4VmYMdENp7l8LMjlfE+XtsrdChRgxRP8dzN64UVbeMRjHMJ/OzMyHgT728KBwvXd6yiU2XmmQR6bPMpztZrLVZ280xfWWvYe8PPjmDGR5DcV5h8ed8ZpC/gZZOer7VYYC0QFpgChAUAAAAAAAAAAAAAAAAAAAAAAECM/wHjdUKbcEwdlQAAAABJRU5ErkJggg==","sha256":"feb4704ffb9e120ffbd56a979f37e1ef9bb4d81904b6f92e1da869ca3f9e5989","preserve":[{"x":10,"y":176,"width":40,"height":40}]},"timer-12-dark":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAANnUlEQVR4nO2d67KsKAyFcWpeER9SHtL5wW6GllsIAaO9vjp1qreNGOMyRATaGAAAAAAAAAAAAAAAAPhRtrsNAEzO8wyft22LN/o/S5/TP2fwz7yqwTxiVaV/agDCejDbtnVFnZX6+3fZkcAkprZobJ4kLGtt+OCcM8b4/38WRqp0nqdOIfZhrT2O4/xwHAe7nrPAcRxBcL37ptSr0kYw+7Kl8jn8rzAtoxJLin3liLKoSJauqidqyxDEZL6FFbjF2lGyqqorIKUr2GRr7qqBYeFdNAXU/Hw+UVglVfVetl5NpMGmYomIhXeRmk3Zfilzj+k8KBGCWBVDE2nlbxWWKTdq2e31P7VDbHeItfUKIiuL8RrAzdCzGUptvHCV1j+4O2Aj1qVBvySUfpRSbc4533dlrS09vu37Hspkw0+p9ytUDrTQFWCatVWCH6VYEFOzANBO11N92Osix3C9SzJNQ1T9ECWr7Ic1zgFD9Aqr0n1aElZ60LoEKXG02XEPeIiNbtj3vat89nL2XuPxlMjnYWgcxRETlnMuaMt/rlz15tu9bP10Y3gvjpSHrlLY5pXvra0XydENzrn4ie/269RrwHEcOt/89yqgXn6qngL3DPRT+1SvsE18oqrMjSNIs9oSFBwvXuJpUYrbhHVJwpppWS/sqrQJq3f8cb18b20aofcaUHbsGhUTxJFW5fsX/JNgqQ9C2BES9NpWL6/5TNvICiu7Y1NY5nsUK/EVtbagZSCsGHFh0YdbDVoIYY2jcfpXKT1KrzdFAccHAcuABprhJOQ66XuV7I6XWNIc/Zw2lJcmsnSUyY7h8LiINZG6sLLfhn1LlzxIp/JtJXOn7K4ztqUuGinfW5su6sKqX1TGJIhL/ewaFCZYpiyF7MZKeV5tDO7JsZoXj90LFd5XsvWh9q1AipQIZtSmMXn39A6XMN9DQHn6YBz0RmS7OmVrWy0s+vVmDBS+dOUzdlcbrrYP2e308rzadJHNckIWRcxv6IOeSwO8iLvrzNlBnlQW8cIexEvbFEddE5f1I+iiBCNMj3thvEC2ofHfUpaOCfWE2vx2evuVrUFz8wcAAAAAAAAAAAAAAADgiah/4/hw/l4WWWvM562Rk5zlphaOsKw9zOXlmnPOTRlwMr6Ow118WR4LyyPhsfA2rLIlbPdfLXNdn7Ds0RgL5nbJEFhaYyhegEQhjVfaNnplPhC9gnO8N+LlC+Opv6kP13ivQwdNVXmktFVa6NHoFlaqqjSoGBPJi6ut8/tn5WIBBf/ceGdSB/oRVdVV8vVkm56/jaEd5K4xEVeYLVNZU27BEhUkYWW14vatFJxEtJUG8Jjx+mcQx4y6kc65j/estd1jDCmySB3YW8MI7fWxsqcdJOX2LSsjaw/BdF52vZBJcC6V2409jLXW5JNuyrFK2Xr8px9wHGcXCiIWzwJRu/0Q0KesF5q90tlxqs45Y3xh/nk1FTk4wYRHS1gjF3JMBNkJ9fFk+ezyoTpXRPZG5q3q1xUlwSp5IC4fxtNe5pd3mFKm0RTagTvJGuuM/C0SHBEv33153jbLnxzj7Kr0beEBbbf29KdFH2Mdfz4H5gNe+iwEZ5TojVjViv+0tW1b+iMUzZ+uWMnlwmubuBF6TYP0pZpLvRNWvWj8nbRtWxx+rLX+z3Cdwm3nS/r/NeT7vBVyxqE0kZcyx3EIPnELrJrs3M54YCZX7kpzeHzz5wv4qHCZsDrJpC5mCIvyGJj9Ki0Tmj8ftIJLBy00bWE5127RnMtnYmP2+eY/nGf2kUqJeiqEVibe8lXi79uOE8me+OWR+VLgPM+LJeF29T0RPlyF/GE83jeawmL2fX3D2rMvgThDSrOlbHe2iZy7PsEKJhFNDfyVd/Ihtt4jenk89DdwyDHGvdfKsYpN9ZH9TNmXQiUaZR/3wpbQ46Wk08t9/6hCeNqI6I5YRCpR5+LeuPmTchoheS9p6zj9v6696GT9UulESNf3vquhTK9NaRGOP+9J2JnNLyk+9OHKlwzN5XhPDWkkAuPdn+D4mTjTomhF8Jm5l3pv1rXwn1edkbsHsucedyWUEn9xj1Evf5e2ZEdlPQtKt7iJ/fnSAaXU7obSy+ZsyQF7XkXoXUs3GmN8rFpu1CJUjyB9KF357yvDldE/5v25NOX1Vkl5VgSY7KvNMHY23e43xg8m8WjudC+1w5TNwGSQ+jmWXBT7J+6CSWuYjeQPYcrixyzIllyPVFjKnqPmE18hrOatw/NOKea9iew5Ek/5XtnpHd0QeLd03ooKYZV+R6kuqV/46aXKOVIC9o3+USGsJvWQrjbPEORyjpRTvtctKpL3igsq99yP6CmbYNFD0V1BS2/E+gXd0OHp40YfqohYsdeknhlfQ3aOQ/ygrbPTQW/EAimMrk6FmgMAAAAAAAAAAAAAAAAAAAA6EJhM4SftVCZ+ld6h3jLIn33Q5o71CQ48bnGRCAOjG6z1y4E4t5sHnnkXrx+qKg5TWPY4zf8rlZN44m2XsniMynOdxo9Y4jNU01FZpbly6ed4r9LG+hHrJcch2p/9s35ezY0m10Cn22XRMh4rOwC3OV+ANy+KWFvWmBsZGaMcrzBdqVOQdSNIKTcKfeZJXENlUjXFMNn5iSJjiCuWV+aCp6NJ656ZmjiqGJrcpHTDVTbOwLdNGoYCBwN4lizw2Dph3X4x1lDKZuah84n1GRGrzoKk22i9fsRk9MKCm1xL8l4ijvl6Yt7tItM/C1xXxCI6K7umT/YrKaQauHE1iGSZdY+JTBLui1iNlZIHYEwhZ+9FRzAqjNtWP1lxj6VPl130/Cb090J+WBUSVOiJWArW4wdPoUdY8eJ0r14/E4zDXDUZ7SAAAIC30GjRlPfCgXvR02UNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADchZbViGy8VqD04ltTK7/dBvu9IN5dJ6gIa+1xHGeB4zjswBqClcr9ksMjlXfZUDHj6SeoDmttSU/j3q/rVfDS3mXDVO89GKLHY+jeYVQuvlTTVBumeu/BMPxCd/3UyjWcIK9m2RPUCNvpnvqdN1i5iOun2jDVew9m0C+eqZWP/9zhPBtEKn+ntsb9chb8Tk9mm7BdP9UGqcpf2CCK3HCe1O9SNXtuP8HUhqneezZSfjmT204wVHgYrp9tg2DNrwpa4n6PK5cNFSfL9VNtaHrPd1YFmpULXFElNP0e9+NRXBPf0M3Cl8opIug9wS4biOdI9F56GzQrf09r2HT6pTzlHu0t2VV/l+tn21AXVtZUxi7Pg3cVm3Glq1hKfa80jTu+6Qo/gzaIC+slaRbv2hPlyPYgfcfKi97eqng2MOqvlK+bJMjNvwldGuOhZOyHT4d7v1qJj6alP29kurDq3q8IqK6twYtK3L1ebI0NzXssju56hjNo/xX7OrzAJnVP+0vIs4F++ZUE716UNoUiu2e/pTRhXVbxbGiKO97xodqaCPuJyZCT1tIhsuohdtUSbQglp9pAtITOmiTs3wXHmIpzbts2yrhvYv5BDw+hJN0GYnKd7rvve6q232VBxCKaQb/j6X1UvWkyzwaiMXSUZPdDaBBWVyOSVtvsx1pgA7uqLG8Qlml11lV2HBcW4xYv1RMb0/VI3xUsPc3KB0MX0XLtsJ04KCwNkw6mzqrISpbyvl/2HG+DfS3ZwuLd0LIeX2+D9yTvjfgjmfQqraRIXgoi6+4bbWge5SUJlpk2AEFwYLisr3mqErHhh9pBM3nYDP0oJUcLqupGG4iHfk+48jRP+FK+N1HgXVHe2PbKYIc1NqTHpcfIwWN1sWK1Gcop7fvunAujrOqFnXP7vnfVn9ZQ+erybRpU3IdKGVkbTE7WXUf0Hu6yUDvicw2mVn5+R0SKGTNsOEVP81XZVYyUr1MfCdacHqXewAVLptrQNIPC4sttlg2bEQzCcVWzs1FK/Qsy4sFDxGnDMh4mrEvyMe+idr20ud2GCnelVuuEJXJ6b0s/J3Njwr5uBOn4Sabq1KAzDTak+AdnnbZNgf10U3quGcxq64cjvo+aagPDaa99Bqwj+85/0qM+5Z1uPHN/hg2Mp8IflVSgy1PNHFZcW5eZes0yXWfEsKF5jnpmfQXuXOfdfsh+m/Zu15G6WZu93hWrpGaxEnvepR6JZvATPyAAAAAAAAAAAAAAAAAAAAAAAEjoeFdoj/5ZVruWd5FgMdQRpAxVsfcCL4AqLF7sQcT6WagXPo49Tbl0FQavhDyZIp50dZymNJzNWqgKmL6BftZaG43SdM65/fv7w3yN19sNhuz9Kt0R5ZKPh5hU2g5+E87lTyKT+xqLnUQyCpUR67fMEAeDcH5AwLndJ1P+T4vmDyQMNVgzmr8QuhCoHg33J08uibzfdpyzI1bcYqbKq38LVsJZu8HaI1bV9/IvRyo4KdI5nPHnyrdgPd3CunRiuX0zbv9qBL+7sqSIm8gQjVL1IFApoUdYF8U4F+vJ7Ru1E3UC+wcDbemAmmNduhj8Jmtrkcnawzn53qxSG4e2TxXkiMUKP8tGN0BV2qBGLLdvSsZj1Vs6/y10djuvGo+F7EoPDx6Plf3Ryux2sB51r4orPe9ZxVTaPgSwG1m3uO04qVDClvirSi8XAAAAAAAAAAAAAAAAAAAAAACAqfwHrulfBOHaAfIAAAAASUVORK5CYII=","sha256":"5aba91cb03818648d1886bf3efd694f9492f0b45c41abf067956f15b1773318b","preserve":[]},"notification-summary-12-dark":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAAKXElEQVR4nO2d65KDKBBGcWtfER9SHtL9wQxL5NZcIuicU1NTCUGC+Nk02BClAAAAAAAAAAAAAP4o2+wKQCPnebrX27b5ifZt6nX49hv8872i4Xv4qgrfrgDCejDbtlVZnTv19+9t3wRf4qs9WjNPEpbW2r0wxiil7P8/S4OrdJ7nmkKsQ2t9HMf5y3EczeWcCY7jcIKrPTYkX9RquGpfUjKv3f8F3TIpvqSar5xQFhnJylX1RG0pgZjUp7AcU2rbS1RVeQWEVBmbaMlVJTTUcBZFARVfn08UVkpVtZetVhOhscnUZEgNZxFWW5J+yTOn6m1ILISwqAZNhIW/VVgq3alF0/NvV0fY7whLqxVEVBb9JcBk5N6MpLQ2cxWW33k4NDNsSkN+SSTzKKnSjDF27kprnRq+7fvu8kTNT2r2yxUOq1BlYIqlZYyfJJsTUzEDrE7VqN4ddZGju94pmYYmKv8VqVrpX+5pHOiiVliZ6dOUsMIvzUtQYkeLE/fQxrDohn3fq/JHL2ftNe53iawfRuc4nGHCMsY4bdnXmatefLoXLV9embYHR4ubrpTZbstfW1otI6MbjDH+iG/6daqtwHEcaz75r1VAPv9X9eSYE+i37Kh+wT7xiapSEyNIo9oaKLg2e8locRTThHVxwopuWS3NRa0mrNr443z+2tJWRD5rIDmwKirGiSMsys4v2JFgag5icEOMoLZu+fwrn2mZscKKHlgUlvqMYhU+ol7NaCmE5TNcWPJwq84aIqx+Vlz+lXKPwustUcDxy4CawQoUzYnzdcLnKtEDL7akGP0cdpSXLjL1LV9umBYeZ7G+SF5Y0U/dsalL7qST+TTjuUsOX9O2hU3Uk7+2tLXICyt/URsWQVzKby5hQQdLpaUQTczkbyutgTk+VvHiNc9CueeVzfpY9qlAyCgRfKO0FZ13S224hPoMAW3TR8OXTmTsVOfY0u4Wlvx6NwQKX6byGw5f1lxtv0TT5fnbSluLqJfjvCihfyMPek4FeAkPX9NnhzihLPyNPYSXtiiOvCYu+0fIRQk9fN3uuXiBaEdjP5VsHePKcaXZdHn/FS1h5e4PAAAAAAAAAAAAAJ7I8k8cH87PwyKtlfp9amRGrnJblhZhaX2oy8M1Y4z5SsBJ/z4Os/iouS8sy4gWc0/DMiku3X50W9PVCUsfhVgws480gak9hvwNSBak8Ehbe4/MO6yXaxzbGv72hf7S37AN72m9Ch0UVWUZpa3URo9qbWGFqgqNilKevFq1dX7+rJwvINc+E+9MaaCfUFVVOV9PtOv5SXT9YOseE36B0TyZPeVu2KJCJKyoVsy+pYzTEG2FBtynv/xv4NuMfCWNMb+tp7WujjGUyCJswNoSeijvjxU9bScps29RGWl9DHTnx+4X8iVaLpXZlT6U1lrFnW7Jd6W8df+tDTj2vYsFLFZbDYbW24aAPmW/0OiVjsapGmOUspnbz6uoyM4FJm2UhNVzIftEEF1Q7y+Wj24fuuaOyLaS8VrV60riYKVawM/v4mkv68srqpKm0BXqjjtJK23U+FvENYS/ffdlvK1uHzn63lXq08QAbdf6tKclj7H2X58d6wEvcxYDV5Ssa7GyBf9oa9u28Ecoij9dcSeXC7/awg03a+qkP6q7XHfBqhWNvZO2bfPNj9bavnXXyd12Nqf9v4K/37ZDTj+SLvKS5ziOgSPuAbsmG7M3DJjFhZvUGh7b/dkM1ipcFqx+qUpVfENYkmFg9KMwj+v+rNFyTdpZQ1UWljHlHs2YuCfWVz/b/bvzjA6pFlFPBtfL+CkfOX4+rTiR6IlfhsyXDOd5Xmriblc7E2HNlfMf+u19oStMet/XJ6w1xwrwPaTQW4pOZyuvce93sFyVhFV1/OQ3401sfkb0Mjy0N7DzMfpbr+RjJbvqI/pacqyEjDWKDvdcipvxWmTSy3z+qIIbbXhUWywhGatzaV6/+xvVaALnPaWt47R/VUfJibZLZhIh3N97VkcZXpvUJhw/rTeinlH/UtKG1lzZnK677J+pEUUiNDz7Gxg/43taEq0MHDPXkp/Numb+aVWjxt0D0XP3pxJSjv/wFpNe/iptjY3KehaSaXHlt+dLA0ql0w2ph83RnB31eRVudi1MVEpZW3V7pW5i6QjSh1Ll/77SXKn1Y96fS1Feb5WU5Q4DE3206WJnw3Sb6A9M/Gju8Khlw5RVx2KQ/DmmmshvH38KJizh24z8Icyx2JiFsTnvZ5RZip7jyid+h7CKt05b66Rs3puInqPwlOfKbt3oBse7pfNWlhBW6neU8pL6Cz+9lDlHicGe2D5LCKtI3qQv62cM5HKOklOe2yxLOO+ZJsjcc39ET1EHS26KZhmtdS3WX9CNnDZ9TGzDJSyW32qjxoyvIbrGwR9orznpsK7FgpCGqc4FNQcAAAAAAAAAAAAAAABrMGAxhV20k1n4lXqGOiXIv/lLiwfmFzi0MaWJhtAR3aC13Q7EmF098MyreH2o6nAahaWPU/2/U7mIJ952ITfHqDy30dot1vAVqmFUVmqtXPjaPyqVmP/GfM5+hPWPvs2fVzFRxTroMH0sq8RjRQNwi+sF2tZFCUuLVmYiPTHK/g7TmTIHcl8EqeRGka888UvILKqWVGzs+sQhMcSZmmfWgofRpPmW+arjuERocpHUDZdJ/Aa2b1ohFNhVoK0mN7TYfcKafjHuIeXNfI81R6zPsFh5bnC61arXT+iMXrjhJl/FeU/h2/x1bN50ka2/CnwtiyVsrOiePtGPRjGqg+tXwxAvM99iQxYJ11mswk7JHTQsIW8+Ss5Aq9Bft/zJDm+xcHRZRc1vQn9u5MeukJChxmItsB8/PIUaYfmb0716/0zop3HXZPpBAAB4C4UebfFZOJjLOlPWAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACg1Hb/V57n+f/XbxMqADfwbzFHSgdt+vCPghfzT38RqApCyhZr27ZQEJ0SoQd8PXUWK9QTEoEo1b3YxYCFwop+GrVwiPLFVPtYGVWd53kREE7Vn0UqrGbrYrW1bZtfwuUtvI/2UWForvyP0M0fp0JYQq24bHkHC95NhbDQB8gpz2OlOM8zasPQHyi5xUIuUEW1xfLnsaJGC7cdlNBiXcxVXjpMZYGqtVjReXabeLFkQyoHz6VssVAJNNA4jxUNzIrOi+JyAQAAAAAAAAAAwKoUZy9rp92ZDgWleuKxmjmOw73e9/2S7qeM+q6xZYKEASuhq/BVZd9eUuAdSC1W8Ul01SNBZ0JS1guezoSu0CfTFV4smU2PJob50eh07u4KLcXuT9g/umz0p6txt7B8g1RUw77vUdtTTEdn05lgsVL9V2eZdH9LMcfH8u3KcRxDNIGVWooJ0w1OAQNtjHP8sVuLMMd5h9czpyusHfSNLRZuYNqoMJOSSmwrH6bwgIfQPO97IpNn3lPQqT2dRZ33i33CXAEAAAAAAAAAAAAAAAAAPIL/ANY4wP0LALECAAAAAElFTkSuQmCC","sha256":"0c8534747e3cf71e60519ada99af343bce1d95237e9d582c8ef8d48246a16d53","preserve":[]},"notification-12-dark":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAAK40lEQVR4nO2da5KsKBBGcWK2qIuURTo/6GZongmioJ4TN25UU4gIn0nyLKUAAAAAAAAAAAAAPsoyOgPQyHEc9vOyLG6g+TP1OfzzCv65Lmm4DldV4Z8zgLAezLIsVVbnTv39e9ud4CIubdGaeZKw1nW1H7TWSinz/2dpcJWO45hTiHWs67rv+/HLvu/N6RwJ9n23gqu9NiSf1GzYbHshmc/2/wndMimupJprTiiLjGTlqnqitpRATOqvsCxDcnuWqKryCgipMjbRlKtSaMjhKIoCKn4+niislKpqq61WE6GxyeSkSw5HEWZbEu7FGZP1NiQWQphUgybCxN8qLJVu1KLh+T9nR9juCFOrFURUFudTgMHIvRlJam3mKkz/5OXQTLchDXmVSMZRUqlprc3Y1bquqe7btm02TtT8pEa/bOIwC1UGpphaxvhJolkxFSPA7FT16u1VnhxtfadkGpqo/C1SuVp/uadw4BS1wsoMn6aEFd40L0GJHS0O3EMb3VY3bNtWFT9anbV1fN4lMn4YjWN3uglLa221ZT5nar04uxdNX56ZtomjyU1Xymy3xa9NrZaeqxu01m6Pb3g91WZg3/c5Z/5rFZCPf6meLGMW+k3bq5+wTXyiqtTAFaRRbXUUXJu9pLfYi2HC8pywoltWS3NSswmrdv1xPn5tajMiHzWQXFi1KsaKI0zKjC+YnmBqDKJzQfSgNm/5+DM/aZm+wopeWBSW+ruKVThFPZvRUgjLpbuw5MutTuYQYZ1nxu1fKfcorG+JAvZfOuQMZqBoTqyvE86rRC/0bElx9XPYUHpNZOouFxdMC4+zWBeSF1b0W3ttqsqtdDLfZjx3yeVz2rawiM7Er01tLvLCyldqwyYIL/3mFCZ0sFRaCtHATPy21BoY42MVK695FMrOVzbrY9pZgZBeIrgitRmdd0Ptcgn1dwlomz4abjqQvkOdfVO7W1jy+m5YKOwN5TdcPq25Wn6Jhsvjt6U2F1Evx3pRQv9Gvug5tcBLePmcPjvECWXhHuwhrNqiOPKa8M6PkIsSznC53bPrBaINjflWcnSMTcemZsLl7Vc0hZmbPwAAAAAAAAAAAAB4ItPPOD6cn8midVXqd9ZI99zlNi0twlrXXXmTa1prfcmCk/PnOIziT85dYRl6lJidDcuE2HDz1W1FVyesdS+sBdNbTxOYOmPIPYBkQgpT2qszZX7CetnCMaXhHl/obv0Ny/Ce0qvQQVFVhl7aSh30qOYWVqiq0Kgo5cirVVvH35+VcwVky2fgmyld6CdUVVXM1xNten4CbTvYesaEm2A0TuZMuRuOqBAJK6oVvS0p49RFW6EBdzmf/hW4NiOfSa31b+mt61q9xlAii7AAa1M4Q/l8rOhjW0npbYnKaF33ju583/NCLqKlqvSm1l2t66riTrfkXilv3f3TLDh2vYsJLFZbDrrm2ywBfcp5odGajq5T1VorZSK3P1dRkSc3mLRREtaZijwnguiGenezfPT40DlPRDaZjOeqXlcSBytVAm58u57W219ekZU0haZwPfEmrWrVqv8rYgvCPb7b62+r23uOrneV+jbRQdvW9TCPJV9j7X4+TuwH9MYsOu4omddiZRP+0dayLOGPUBR/uuJOvIqfbeOGHTW10u/VXM67YdWIxrxJy7K45mddV/OnrSf72pmY5v8Z/P22E3LOI2kivTj7vnfscXc4NVnrraHDLE5cp/bwmObPRDBWwduwelGWqrhCWJJuYPSrMI5t/ozRskV6MoeqLCytyy2a1nFP7Fz+TPNvnzPapZpEPRlsK+OG/Inx823Fg0Qf3OsyexGO4/ByYl9XMxJhzJX1H87b+0JTmPS+/RnWmmsFuB5S6C1Fh7OVU7j3O1g2S8KsWn7i6/4mNj8i6nUPzQtsfYzzpVfysZJN9R79LLlWQsYaRbt7NsSOeE0y6KX//qiC7W04VFssIRmr4xWv2/z1KjSB857S1n6Yf1VXyYmWS2YQITzfe1RDGdZN6hCOn9Lrkc+ofykpQ2OuTEzbXJ4fqRGtRGiY++u4fsb1tCRa6dhnriU/muVH/ilVrfq9A9Fnd4cSUo5/9xKTVn+VtvquynoWkmFx5ZbnSxeUSocbUpPN0Zgn8vMq7OhaGKiUMrbq9kzdxNQrSB9Klf/7SnOl5l/z/lyK8nqrpAx3GJjo1KZdOxuGm0C3Y+Ku5g6vmnaZsjqxGST/jKkicsvHHYIJU7ianj+E2RezZqFvzPvpZZaizzjzg98hrOKr01Y6KZv3JqLPKHzksbKbd3WD5d3SeStTCCv1O0p5SX3hp5cyzygx2APLZwphFcmb9Gn9jI54zyh55LHFMoXznimCzDv3ET1FHSy5KRpltOa1WF/QjZw2fQwswykslltqvfqMryG6x8HtaM856DCvxYKQhqHOCTUHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/WO6/5XEc/99+GZABuIHyD2GmdNCmD/cqeDEdfggTVUFI2WItyxIK4qREaAFfT53FCvWERCBKdSvmGbBQWNFvoxYOUb6Yah8ro6rjODwB4VR9Fqmwmq2L0dayLG4K3p/wPtp7haG5cr9CNx+nQlhCrdhoeQcL3k2FsNAHyCmPY6U4jiNqw9AfKLnFQi5QRbXFcsexokYLtx2U0GJ55iovHYayQNVarOg4uwn0LFmXzMFzKVssVAINNI5jRRdmRcdFcbkAAAAAAAAAvgZjAWdxR1vG5mQqpCPvVbM6ACJhRbd/vVJbRfODfRJSN6WT2gkN4FF+7cJ3NPrWNuwJa7hRUeUmUGJXwqSKuyajESQ72z54XEXLZorlFxuSXyojXEiTKvHU2vlmk3nzNrVvriPqsOY9OgkdLqGJfptJMFUf8nSKeFIublDLR+j1+O+g7uyGd7iunj6+UM33I+oVhi5ItFcosUO1ZIzKGe4X09fkW7ce6+pe4T2G8Gt1PISKg9fCJcgeeVlUieaeuk91Bq+713focPDanXQUwddq+maqe4WSqj3jbKUWQHdH/jhX3Pf1iGquOAaYj1B7OFaq75kZwKxqneW5LV7uOgapsdlvng0msljFLRLFIZ9igg3ZaLZt0QuvMyRsMJmFcGQcHsd0zjuSegdzCQtVvYa5hGXBCwEAAIBHM9KVecciHIjSfgbpVKDR2TglrKrqpO4/xUiLhcJeTMskdHFPi3ADTNVuH+HMMWKdhJajIjPj4yc3wHxzQ8sraf/Jk+KWFXlkg3BDy9e2uzyUs6cmZyKwAebLVAhLeF5D371+8FDKTaHnQV+xx+s8yHE2pCtIazd+pRyp67j/jpChfV9hPmZrfvDHX4JouKG2sodsgGFB81RU/KxcWHNut784BJWJnIkgNH5IajbqnPdUSPSrhtGm5pMa8K4AAAAAAAAAAACgnuK4Yu2INgOVoNSQzRT7vtvP27Z54W5Ir3v1TRMk3H0oiKsq86cXAu9A/rNyhQhVk3XWhKSsFzydwTuhM02hZ8lMeDQwjI9GhzPmfKxi8ydsH2002tPZuFtYrkEqqmHbtqjtKYajs+EMsFip9utkmjR/UzHGx3Ltyr7vXTSBlZqKAcMNVgEdbYx1/LFbkzDp4bbwdMY0hbWdvr7Jwg0M6xVmQlKBbenDEB4wCc183xOZ9AxSGrWnM6nz7tknzBUAAAAAAAAAAAAAAAAAwCP4D3EzWKJlQJVWAAAAAElFTkSuQmCC","sha256":"70991f94e74b4eedc2e92b70c1519a96a8632eed0481019f4426555bb4b45595","preserve":[]},"timeline-12-dark":{"src":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADkCAIAAABSVPyEAAAKDElEQVR4nO2d6bKsKhJGsaNfUR9SHrL6B7VpDiAmQypaa8WNG/tYyPiZJINoDAAAAAAAAAAAAMCPstydgQo+n0/4z2VZ0p/Si+5KIUB0sSdv8njK4Wtjm5D/3p0BKZGq3JWGqm+7qxzhwPC1sU3Lf+7OgIiwurMm5y5Q1RHPEJbHqarT5Lyp/ablMV1hxCT+R+TAdYavjW1mHmaxRlX6OxpvZp4hrMivcvRHdUpPQj/OM4RljFmWJdJEZ5Of3o6keniMsByRvNraXmi0JnHjHsoznPdoJnNZlmvMCdpq5mEWS05ZeShGm4cJy8mlIJqpHKOxvv+zRhLPENaRX+Wvp8PG9HohTg3GiuBBknI8Q1gmp4PoymmAixmbOn03AAAAAAAAAAAAAAAAAAAAAAAAAABMzvM2vK7rGv7TWntNoi7dbOrh/zvjr6U/aTD7vn9y7PuulOK6rkeJZrPRII51XYXxl2nTJRyqyjfqxSkWciJv41GqcqCtOoS1PzbFNlXVtnFPEil6lvuFyJ/pUc/rZX3TWHPlGFID76eq6kc9rwObuawthHUPtfU+RFidPWBVSw9Pq5zcxUz6JvS+79d7DM1j/gL4PRPRPBzrTHe4/XAciVUjrc4aGMh0FqttNmhIukoxMwtwPz1uR6cyBpqNlDQ5Dc99qm53Iot1l60y+kblgia31m7bpp2KnFmOirxRVaZSWNZatzYnd/bTYMIbhYuAPkvwD0P6hR6r0JxE8/ytpNOfqmurZYqu8F73Vm480r5Gbip+zYWfQlhKpEt+2emxzl6pzbP5NZ3dg0ZXWO5rwnYVDkUL+W+IQVSkvyfBgRZb6F/fCIUlic0Hro08pWH/hST8UU5QWAX9Ritse0l43zxVgY+oimRsYedkFh+rMA1TO5aumgK48ukfmJaT5symaxZhmeNh1wzzfqfK1pD+Kbcs1QuZZYLUYa1dlsVPPDLvd4ob+c7w7EXMJSzHlXqauTcRMqe2JuoKf4fhatbYSdbJC4UlX18bG+G9zOZsvVBYRiYFuVzGGgM90zKVtt4prG3byrq50SPRs39T9YbvFJYxZtu2SF5uTLBt27Is/vot3dwvaGvGUeEopp2t2LZNsjLjM1/1avWcRZ4Uvd1LwtWVsUs6Pmn5aRTCtdSp3KwHoLotrkETAyPJ7u1pTuIz04s6D+B2YQ3f3ZCNpBygf3vPlbzWeZcjcUpOX5a/IBvPcp4QlpSCeiTCysrC94OS5eR5RnzvQbUrlO+Oas5bNnvZGwvqeVZX+AzahOXsQXjvkWGQNNgnt3tTvvFVfmM2h4wKVWgQVvmWhvjDhCK9SgiTk9jIcLd7Vd7UG+NN1ArrNHzUABovvB8lp5oWflgdtcJqaIPuNi1RW5YhCd3LC0eFPedaaxDFrGdUptrr90JhCYkaWK9VLpt/mmqi64XCajYJGtpKF8KVmn8qc2VeKaxmNHZDpO19ulesgWn3ccxOlfPeuWFhoHPdP9spgSmGdiRaqX3PuJDckFYftahcBlX1clrFYeCqsxuydLa60M/rTAVVDaBsh9KG7G/4tpnM2sZu/rwKc6HDyLZBYY9vuh7S8E66XF4958DI5fWU02ae973Cuyi8FDpwUFY4qoShHwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/ATzno9VOCHtQSdFfU+6Wldj/o68stbarqOzfc34egjP7korJzqrzf7Rk4dTWoS1rruJTgbrrqwkibV89N6yzPtIOP45PC0U1hdrm05mj2rGHe4dScdXTqEaNU4FD6n7iv26H5wJu67r+jHG2G1Mez/iNMQjMpm31pi/Vlz3b6j9Y2x161bVTOHh3PddVVtSYWWsVDbY/hluvZ5F1PCZlrPLuq5fG7buq+mqroIyTk9b3fddz/CLvkwhVJUPva6Kx0TP7GClrkw2mLXWbptxvx4fbXqaRFXIbH70egaBsL6PV4zdFvef/BY5UQstAdu2zfbdGEeU59Pw1nptSQ9CPjeHxyFdvV32KbJzYWXNT2i9s5Z8oNHyX+B9iuOVbe9P7pMF1m5f30tfWO6Py57JE2Ed6iMs0kHxmrWVCsgNp2eWVzjaP/o1f8j2t6XrOsRawlyFf99nsXoSVsh0On6eU2cRLs/H3rRradHHMtIrGjXQH2dRWP05bopB8nkj8/fNiOhjE/4TDw0foWhGYq7Svz3fu9aTgqe/+q+Rd+og7Q364ywJaxU8Q2XaYjj1fH3P6AL7v8PaCcPcS/QV9EwIK7VYSrhKC6vRdH+wc0aL5YYwrmB+SFgYurs/vKSuWbIQkippBq2HuEoLB4zruvb7+HUz75fhChkWz1km/09XeN/fbdvmhl1OlJfnN0/WAXIXG3Tf86iEKWYn27zch5gr0yiszGyyHeuqe/Pjn6TsdJ/T0NGQ53aOjFPzlPeyLFnXJ1Vw+hxGAgpxj6i/a9s2b/sbMukoCutALtbE6Vlj8+5UU84iL/Iga9ZMJqN2voUVleV0fJAN5gY6R7E5f8MYs++705YXVrP5L/lYqYB8ds6vlGPoI1u5/ok8FeVsfJ/J0VV1+tSlnqgzbO7/ocIaKDrvRzlLEztKvsminNZI9jEKvXj/DdJrtJV1X8zxNHd8/c9ijTXAp5sXomw4czUqD2cTpFnDm/R6A/tBU7TA3mgL77q3r8y2U3Txb31iWD7DyAvaiuoqHFJ4W9Wjs3MX8mgPll9+Pg3QTGSKheXsr5Q2jqZJQ8MZt7TfCVK/MUuYupFVowvj1dbvvAva3he+hv8v3f8MUeOdh/a1auOx7QsQbJuxtloiDbc8n8bF3TcNbwOkvVXFXj9r2UHqkcwOvE9VpvZlisM973+M2vP+aKqG6K9UlZn2LZ0XcCqvt0rKcYWBOVpGyP7klxfC8XA4qkrvmmdxMKW0T6ZIuYxHVRTWj/81DXwBky5Cm7/3k8aGvJ5RZilbxpkLfoWwTh+dtto5snlvIltGYZHvlZ3o9a97ebd03soUwvJbbNPrp3dp5ut+CmWUGOwb62cKYZ1SNunT+hkDicooKfK91TKF816ogsIz9yN6yjpYclN0l9Ga12L9gm7ktOnjxjqcwmJF5/JEv/64wlKjZf4daM856TCvxYKUhqnOCTUHAAAAAAAAAAAAAAAAAAAAAAAAFSzZoynhxSyXvNnPDlJQAWGBCggLVEBYoALCAhUQFqiAsEAFhAUqICxQAWGBCggLVEBYoALCAhUQFqiAsEAFhAUqICxQAWGBCggLVEBYoALCAhUQFqiAsEAFhAUqICxQAWGBCggLVEBYoALCAhUQFqiAsEAFhAUqICxQAWGBCggLVEBYoALCAhUQFqiAsEAFhAUqICxQAWGBCggLVEBYoALCAhUQFqiAsEAFhAUqICxQAWGBCggLVEBYoALCAhUQFqiAsEAFhAUq/A8bdlKPW0T21QAAAABJRU5ErkJggg==","sha256":"730169cdd42535620c6922369a14e261ddfc08e37fde31996ec75fb9e5dd15ca","preserve":[{"x":0,"y":171,"width":200,"height":57}]}}};


/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	var state = __webpack_require__(21);
	var localization = __webpack_require__(20);
	var sourceConfig = __webpack_require__(24);
	function html(value) { return String(value).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
	function page(settings,language,metadata,systemFormat) {
	  language = localization.resolveLanguage(language,'en');
	  var normalized = state.normalize(settings,false);
	  if (!normalized) return null;
	  var data = metadata || {slots:[{},{}],sources:{},activityProviders:[],save:{state:'none'}};
	  data.language = language;
	  data.activityPreferences = metadata && metadata.activityPreferences || normalized[state.preferencesKey];
	  var config = localization.translateConfig(sourceConfig,language);
	  function visit(items) { items.forEach(function(item) {
	    if (item.items) visit(item.items);
	    if (item.messageKey && normalized[item.messageKey] !== undefined && item.messageKey !== state.preferencesKey) item.defaultValue = normalized[item.messageKey];
	    if (item.messageKey === state.preferencesKey) item.defaultValue = JSON.stringify(normalized[state.preferencesKey]);
	    if (item.id === 'dynamic-settings-data') item.defaultValue = html(JSON.stringify(data));
	    if (item.id === 'dynamic-settings-strings') item.defaultValue = html(JSON.stringify(localization.settingsStrings(language)));
	  }); }
	  visit(config);
	  var values = {}; Object.keys(normalized).forEach(function(key){if(key!==state.preferencesKey)values[key]=normalized[key];});
	  return {ok:true,settings:normalized,config:config,values:values,language:language,systemFormat:systemFormat === 12 || systemFormat === 24 ? systemFormat : null};
	}
	module.exports = page;


/***/ })
/******/ ]);
//# sourceMappingURL=pebble-js-app.js.map